# Legado Server (Node) · 状态

当前版本：**1.6.1**
代码目录：`legado-server-node/`（`dist/` 运行时代码 + `web-dist/` 前端产物 + `tests/`）
数据目录：`<工作目录>/legado-server-data/`（库、封面缓存、book 文件夹）

## 1.6.1 书架去重 / 壳子回写阅读进度 / 全仓去注释

### 一、书架不再出现重复书

**现象**：同一个 TXT / EPUB 反复导入后，书架里同名的书出现 2～3 条，进度和缓存被拆到不同副本上，历史 tab 也跟着重复。

**根因**（不是查询重复，是数据真的重复）：`book_shelf` 主键是 `(source_id, book_url)`，而 `importLocalBookBytes()` 里本地书地址每次都是

```js
const bookUrl = `local://${crypto.randomUUID()}`;
```

于是同一个文件导入两次就有两个 UUID、两行书架。实测库里 13 行，其中《妻心如刀》《少妇白洁》《新婚》《被讨厌的勇气》四本各 3 条，全部 `loc_book`、`book_url` 互不相同。

**修法两层**：

| 层 | 位置 | 做法 |
|---|---|---|
| 导入时不再造新地址 | `dist/localBookImport.js` 的 `importLocalBookBytes()` | 解析出书名/作者后先查 `findLocalShelfBookUrl(name, author)`，命中就沿用旧 `bookUrl`；同时 `clearBookCacheContent()` + 清 `book_chapter_index`（正文/章节可能变了），旧分组在未显式传 `groupName` 时继承；结尾统一 `saveTocCache()`，壳子 `chaptersOf()` 能直接命中目录缓存；返回值多一个 `reused` 标志 |
| 启动时清掉历史脏数据 | `dist/database.js` 的 `dedupeLocalBooks()`，由 `dist/app.js` 在 `initialize()` 后调用 | 按「书名 + 作者 + 总章数」分组，保留 `last_read_at` 最新的那条，其余连同 `book_content_cache` / `book_cache_status` / `reading_progress` / `book_history` / `book_chapter_index` / `book_shelf` 在一个事务里删掉，删到就打印 `[server] 已清理 N 条重复的本地书` |

新增两个配套方法：`findLocalShelfBookUrl(name, author)`（只匹配 `loc_book`，`lower(name)` 比对，能给作者时优先同作者）、`chapterIndexOf(sourceId, bookUrl, chapterUrl)`（见下一节）。

实测：启动日志 `已清理 8 条重复的本地书`，书架 13 → 5 行（4 本本地书 + 1 本网络书），`/api/bookshelf` 同名组数为 0；再把同一份《妻心如刀》EPUB 通过 `/api/bookshelf/import-local` 上传一次，返回的 `bookUrl` 仍是旧的 `local://93f13a8a-…`，书架条数不变。

**已知取舍**：去重只看「书名 + 作者」，同名不同书（比如两本都叫《新婚》的杂文集）会被合并成一条。要更稳得给本地书落一个内容指纹（如文件大小 + 前若干字节哈希）作为附加判定，本轮没做。

### 二、从壳子返回后，进度不再丢

**现象**：TVBox / DsPlayer 里翻到第 N 章，退回网页点这本书，还是从第一章开始。

**根因**：进度只有「网页上点开书那一刻」写一次。壳子的取章链路 `lr://b/<key>/<序号>` → `chapterPayload()` → `/api/books/content` → `fetchContent()` 全程只读不写：

- `dist/routes/books.js` 的 `POST /api/books/content` 只查缓存 / 跑规则；
- `dist/tvbox.js` 的 `contentOf()` 同上；
- `web-dist/lr-tvbox.js` 的 `chapterPayload()` 拿到正文直接拼 `novel://` 返回。

**修法**：谁取正文就算谁在读。三处都补上进度回写：

| 位置 | 补的内容 |
|---|---|
| `dist/routes/books.js` | 取到 `cached` 后、`loc_book` 分支前调 `db.noteReading(sourceId, bookUrl, chapterUrl, cached?.title ?? null)`（try/catch 包住，写失败不影响取正文） |
| `dist/tvbox.js` | `contentOf()` 里 `cached` 判空之后同样调 `db.noteReading(ref.s, ref.b, ref.c, cached.title ?? null)` |
| `web-dist/lr-tvbox.js` | 新增 `reportProgress(sourceId, bookUrl, chapterUrl, index, chapterTitle)`，`PUT /api/reading-progress`，`.catch()` 吞错；`chapterPayload()` 取到正文后调用 |

配套的 `chapterIndexOf()` 按「`book_chapter_index` 精确查 → `local://` 末尾数字 → 扫 `book_toc_cache.chapters_json` 命中并回填索引」三段反推章节序号；`noteReading()` 拿到序号后走 `saveProgress()`，顺带更新 `book_shelf.last_read_at` 与 `book_history`（`coalesce` 保证不把已有书名清空）。

离线批量缓存走的是 `ctx.pool.run('content')`，不经过路由，所以不会把「后台预热」误当成「用户在读」。

实测（本地书，141 章）：

- 进度原在第 12 章 → `POST /api/books/content` 取第 7 章 → 进度变第 7 章、`chapterTitle` 同步、书架 `last_read_at` 刷新；
- `GET /novel?f=<token>` 取第 3 章 → 进度变第 3 章；
- `GET /txt?f=<token>` 取第 5 章 → 进度变第 5 章；
- 手动 `PUT /api/reading-progress` 亦 200，且 `GET` 能读回。

### 三、全仓去注释

要求是「去除所有注释」，实际难点不是删注释，而是**产物里的注释被工具和测试当标记用**——`/*__lr_zh_only__*/`、`/*__lr_1_6_0_hist__*/`、`/*__lr_1_6_0_shelf__*/`、`/*__lr_strip_reader__*/` 这类标记一旦删掉，`tools/*.mjs` 的幂等判断会以为补丁没应用而重放（锚点已不存在 → 报错或重复插入），`tests/history-ui-test.mjs` 也会直接红。

**策略：说明性注释全删；功能标记注释改判「代码事实」。** 没有任何哨兵变量被塞进产物。

- 扫描器 `tools/strip-comments.mjs`：因为 `node_modules` 里没有任何 JS 解析器（无 acorn / esbuild / babel / terser），自写状态机 —— 正确处理 `'`、`"`、模板字符串与 `${}` 嵌套、`//`、`/* */`，以及正则字面量与除号的歧义（看前一个有意义字符 + `return`/`typeof` 等关键字）。每个 JS 文件删完立刻 `node --check`，语法不过就整份不写。支持 `--dry`。
- 工具守卫改写：`strip-i18n`（产物已无 `"zh-TW"`/`"ja-JP"`）、`patch-history`（已含 `create table if not exists book_history` / `app.get('/api/history'` / `function LrHist({items:hsItems`）、`patch-shelf-ui`（已含 `cache-storage-card` / `.cache-storage-card{`）、`strip-web-reader`（已无 `legado-open-book-v1` 且无 `SS_SHELL_OFF`）、`strip-removed-features`（已无 `/api/subscriptions`）、`patch-web-assets`（改成「每处补丁正文都对得上」计数，不再查 `__lr_patch:*`）、`patch-toc-engine`（不再往文件尾追加标记）、`patch-toc-paging`（守卫改用 `const addCandidate = (u) =>`）。
- patch 工具模板里**嵌着的 16 块注释**也删了（`patch-history` 4、`patch-toc-engine` 5、`patch-toc-paging` 4、`patch-shelf-ui` 2），否则重跑一次就把注释又写回产物。
- 规则页 `阅读书架[书].html` 头部那条「生成物勿手改」的 HTML 注释去掉，`tools/build-rule-page.mjs` 与 `tests/tvbox-entry-test.mjs` 同步改（生成物现在只比入口页多一个 `<title>阅读书架</title>`）。
- `dist/database.js` 建表 SQL 里的 `/*__lr_1_6_0_hist__*/` 删掉（SQL 注释，删了不影响语句）。

结果：`dist/`、`web-dist/`、`tools/`、`tests/`、根目录 HTML 里 `__lr_` 出现次数归零；`node tools/strip-comments.mjs --dry` 报「处理 0 个文件」；bundle 608592 → 606217 字符，CSS 206027 → 205776 字符（字节数见验证表，中文按 UTF-8 三字节）。

注意：`image/*`、`*/*` 这类字符串里的 `/*` 不是注释，扫描器按字符串跳过、不会被误删。

### 四、漫画源：图片能取、能走代理、能按 pics 推送

需求是用「开心看漫画」「图库漫画」两个在阅读 APP 里可用的源验收。一开始两条链路都断在不同的地方，逐个修：

| 断点 | 现象 | 修法 |
|---|---|---|
| 规则引擎不认 `@html` 取图片 | 开心看漫画的正文规则是 `class.blog__details__content@tag.img@html`，`@html` 取的是 `<img>` 的 innerHTML —— `<img>` 是空元素，innerHTML 永远为空，于是「正文规则未提取到内容」 | `dist/ruleRunner.js` 的 `NodeValue.valuePlain()`：`@html` 遇到 void 元素（`img/br/hr/source/...`）且 innerHTML 为空时回退 `outerHtml()`，这也是阅读端能拿到图片标记的前提 |
| 规则引擎不认 `\|\|` 择一 | 开心看漫画的探索规则 `class.product__item\|\|class.product__sidebar__view__item` 直接抛 `Column combinators are not yet supported by css-select` | 新增 `splitTopLevelBars()`（跳过 `##正则##`、`{{}}`、括号内），`nodes()` 对列表规则取各分支并集并按序列化去重，`NodeValue.value()` 对字段规则按顺序取第一个非空 |
| 图库漫画的 `@js` 后处理 | 规则是 `class.content@tag.img@data-original` 再 `@js:` 拼 `<img src>`，靠上面的 `@html`/`\|\|` 修完就能跑 | 无额外改动，`class.content@tag.img@data-original` 走 attr 分支，JS 后处理本来已支持 |
| 正文返回裸 URL 列表 | `/api/books/content` 的漫画分支把图片数组 `join('\n')` 当正文，前端拿不到 `<img>`，缓存回来还丢 `images` | `dist/routes/books.js`：漫画正文改成 `<img src="...">` 逐行 HTML，同时保留 `images` 数组；命中缓存时从正文反解 `images` 再返回，两次请求结果一致 |
| 图床被登录 Cookie 拖死 | 图库漫画的图床带过期 Cookie 请求会失败，代理一律 404 | `dist/comicImages.js`：`Referer` 仍取图床自身 origin，Cookie 作为「先试再退」的一次尝试，失败后无 Cookie 重试 |
| 推送侧没有图片协议 | 壳子只会把正文当小说文本返回 | `web-dist/lr-tvbox.js`：漫画章节改返回 `pics://<url>&&<url>...`，每个地址都是本机 `/api/comic/image?sourceId=&url=`，由后端补 Referer/UA/Cookie 与磁盘缓存 |

实测（真库真站，服务跑在 5268）：

- **图库漫画**《新著龙虎门》：探索 24 本 → 目录 1025 卷 → 第 1 卷 45 张图、第 2 卷 38 张，首图经 `/api/comic/image` 返回 `image/jpeg` 271166 B（`ffd8ffe0`）；
- **开心看漫画**《秘密教学》：探索 24 本 → 目录 337 话 → 第 1 话 55 张图（`image/webp`，10 万～17 万字节），抽 4 张全部 200；《异界猎妻人》第 1 话 14 张图；
- 已知限制：《[3D]奸魔再世》这类单本的章节页服务端就把 `src` 发成空串（211 个 `<img src="">`），不是解析问题，任何静态抓取都拿不到地址；页面本身没带图片地址时不做假数据。

### 五、阅读进度不再多跑两章

**现象**：实际看到第 3 章退出，下次进来显示第 5 章 —— 恒定偏 +2，正好是阅读器预取的章数。

**根因**：`web-dist/lr-tvbox.js` 的 `reportProgress()` 对每一次取章都排一次 2.5s 防抖回写，而壳子取正文时会连着预取后面 1～2 话/章，于是「用户点开的那一章」被后面的预取覆盖，进度落在最后一章预取上。写入端没错，是「谁在取正文就算谁在读」这条规则被预取滥用了。

**修法**：回写改成「本轮第一次立即写，之后的 2.5s 窗口内一律丢掉」。用户点开即写，同一轮预取的连带取章被抑制；`pagehide`/`beforeunload` 上把窗口清零，真正退出时不丢最后一次。服务端 `noteReading()` 与三条取正文路径保持原样（壳子取章已经用 `silent: true`，后台批量缓存也不经过路由）。

两条回归钉住这个行为：`shell-bridge` 新增「壳子预取后续章节不把进度顶上去」（连取 3/4/5 只允许一次 PUT 且 `chapterIndex=3`），`comic-push` 的「一轮预取只记用户点开的那一话」「翻到下一话后进度跟着走」覆盖漫画侧。

### 六、历史 tab 不再白屏报错

**现象**：点开书架「历史」直接报「页面渲染遇到异常：Cannot read properties of null (reading 'slice')」。

**根因**：历史行复用书架卡片的封面组件 `rr`，它找不到封面时用书名首字当占位图：`children:l.slice(0,1)`。而 `book_history.name` 允许为空 —— 只要进度是“先写了 progress、书名后来才补”的路径（壳子回写、`PUT /api/reading-progress` 不带 `bookName`、早期没入架的书）就会落一条 `name = null` 的行，`l.slice` 直接抛错，整页白屏。

| 层 | 修法 |
|---|---|
| 前端（止血） | `rr` 改成 `(l\|\|'书').slice(0,1)`；顺手把详情页封面 `o.details.name.slice(0,1)` 与书架卡片 `ce.name.slice(0,1)` 两处同类写法一起兜底 |
| 后端（数据） | `listHistory()` 的 name 改成 `coalesce(nullif(h.name,''), nullif(s.name,''), '未命名书籍')`，接口不再吐 null；空字符串也当空处理 |
| 写入端（从根上减少） | `web-dist/lr-tvbox.js` 的 `rememberBookKey()` 多记书名与封面（`n`/`c`），推送时从 `book.details` 写入；`reportProgress()` 回写进度时一并带上 `bookName / tocUrl / coverUrl / bookKind`，壳子里读过的书写完就有名字，不再涌出一堆「未命名书籍」 |

实测：真库 `/api/history?limit=200` 共 30 条，书名为空 0 条（修前有 13 条 null）；`history-ui` 新增两条断言（产物里不存在裸 `slice` 写法、后端对空书名兜底成「未命名书籍」），`shell-bridge` 新增「回写进度带书名/目录/封面」。

### 七、服务端口改为 5268

插件原先监听 8998，与设备上其他服务容易撞端口，统一改成 **5268**：

| 位置 | 改动 |
|---|---|
| `config/config.yaml` | `server.port: 8998` → `5268`（这才是实际生效的那一处，插件读的就是它） |
| `dist/config.js` | 首次生成配置 / 解析失败时的默认值 `8080` → `5268` |
| `dist/tvbox.js` | 取不到 Host 头时回退的地址 `127.0.0.1:8998` → `5268` |
| `web-dist/tvbox.html` | `DEFAULT_PORT` 与输入框示例改成 `5268`；规则页 `阅读书架[书].html` 重新生成 |
| `tests/*` | 探活默认地址、壳子 origin、入口页断言里的端口全部跟到 `5268` |
| 文档 | `部署说明.md`、`STATUS.md` 里的访问地址与启动示例同步 |

改完后服务监听 `0.0.0.0:5268`，Web 前端 `http://<设备IP>:5268/`，壳子入口 `http://<设备IP>:5268/tvbox.html`，TVBox 订阅 `http://<设备IP>:5268/sub`。旧地址 8998 不再监听，已经在 TVBox / DsPlayer 里填过地址的，改一下 base 或清一次 `localStorage lr.base`。

### 八、回归

16 套测试全部 exit=0，其中带逐项计数的 13 套共 149 项全绿；9 个产物工具 `--check` 全通过（含 `strip-comments --dry` 报「处理 0 个文件」）：

| 测试 | 结果 | 本轮变化 |
|---|---|---|
| `bundle-load` | 1/1 | — |
| `comic-push` | 8/8 | **新增整套**：目录正序、`@html` 取图片标签、直连防盗链 403、代理 200、漫画整本 `pics` 推送、`pics://` 走本机代理、预取不顶进度、翻话后进度跟进 |
| `shell-bridge` | 11/11 | 「壳子取章顺手回写阅读进度」+「壳子预取后续章节不把进度顶上去」+「回写进度带书名/目录/封面」 |
| `web-reader-removed` | 13/13 | — |
| `removed-features` | 9/9 | — |
| `web-patch` | 10/10 | — |
| `tvbox-entry` | 8/8 | 规则页断言去掉注释 banner |
| `rule-selector` | 12/12 | `\|\|`/`@html` 改动后无回退 |
| `zlibrary` | 6/6 | — |
| `local-book` | 45/45 | 同书再导入复用 `bookUrl` / `reused` 标志 / 清旧缓存 / 不新增行、不同书各自成行、EPUB 同书复用、真库 `dedupeLocalBooks()` 保留最近读的那条、`chapterIndexOf()` 三种路径、`noteReading()` 写进度 |
| `explore-backend` | 7/7 | 无回退 |
| `history-ui` | 13/13 | 新增「历史行封面对空书名兜底」「后端对空书名返回未命名书籍」 |
| `dup-progress` | 6/6 | 无回退 |

另 3 套（`explore-dropdown` / `explore-ui` / `tvbox-chain`）只跑冒烟不出计数，均 exit=0。

## 1.6.0 只留简体中文 / 书架移动端适配 / 历史 tab / 缓存面板精简 / 壳子浮动按钮移除 / 两个书源修复

### 一、语言：只保留简体中文

语言本来就没有独立文件，四套语言表全在压缩产物里（那条 `const` 链 247828..469987，99 个成员、222159 字符）。

| 层 | 处理 |
|---|---|
| 语言链 | 保留 25 个 zh-CN 中文文案成员（`ly`…`My`）与默认值 `Nl`，删掉 zh-TW / en-US / ja-JP 三整组 + 列表 `hf` + storage 键 `ag`，共 74 个成员 174514B |
| 1.5.0 遗留死数据 | 删 `const Vv=[.8,1,1.25,1.5,2],qv=[…30 个 Edge 音色…]`（1842B）—— 1.5.0 下线朗读时只切了 UI，这两张表没人引用却留着全部 zh-TW/en-US/ja-JP 音色名；同链的 `pg` 保留 |
| i18n 初始化 | `Xk={"zh-CN":{translation:My}}`、`sg=Nl`、`document.documentElement.lang=Nl`、`init({resources:Xk,lng:Nl,fallbackLng:Nl,supportedLngs:[Nl],…})` |
| 语言函数 | 删 `wl`（归一化）、`Yk`（navigator 探测）、`Qk`（localStorage 读）、`og`（切换）；`er(){return wl(nt.language)}` → `er(){return"zh-CN"}`（**函数本身要留**，`Accept-Language` 请求头还在用它） |
| 菜单 UI | 删顶部菜单「语言」区块（含分隔线，574B）与切换回调（173B） |
| 启动副作用 | 删 App 启动时 `V.getLocale().then(…og(wl(H.locale)))` |
| API 客户端 | 删 `getLocale` / `setLocale` |
| 后端 | 删 `dist/app.js` 的 `GET` / `PUT /api/settings/locale` 两条路由 |
| CSS | 删全部 `.menu-lang-*` 规则（含藏在 `@media` 里的两条——第一版正则只认出 `}` 边界，补上 `{` / `;` 边界才清干净） |

保留：i18next 库本体（`changeLanguage` 是库内部实现，按字符串搜删会让所有 `t()` 失效）、`er()`、中文文案表。

工具 `tools/strip-i18n.mjs`（幂等标记 `/*__lr_zh_only__*/`，`--check` / `--debug`）。
产物 787463 → 609348 字符（651148 字节），删掉的语言链约有 175K 字符。

### 二、书架页移动端适配

样式全部收在 `@media(max-width:640px)` 里，桌面端一行没动：

- 页面留白 16/12px + 底部叠加 `--safe-bottom`（避开手势条）；
- 标题行压到 25px，「我的书架」小标缩小，冗余说明段在手机上隐藏；
- 导入 / 搜索 / 批量管理按钮全部 ≥38px 触摸热区，搜索只留图标；
- 分组 tab 横滑 + 吸顶（`position:sticky` + 半透明背景 + `backdrop-filter`），高度 44px，「管理分组」右侧常驻；
- 状态筛选用 pill 单行横滑，不再换行挤成两排；
- 书籍网格两列、`gap:12px`，卡片圆角 12px，书名两行截断，底部按钮等分撑满；
- 触摸设备去掉 hover 位移，改 `:active` 轻微缩放反馈；批量栏贴底 + 安全区 + 可换行；
- 561–1024px 自动切三列。

### 三、书架「历史」tab（所有点开过的书都留痕）

需求是「点了阅读但没加入书架的书找不到」。现有 `/api/bookshelf` 只回书架行，所以补了一条独立数据链：

- 表：新增 `book_history`（`create table if not exists`，additive，不影响 Kotlin 版共用同库），存 `name / author / cover_url / toc_url / book_kind / last_read_at / read_count`；
- 写入：`saveProgress` 顺带 upsert（每个 `(source_id, book_url)` 只留一条，`read_count + 1`，元信息「有就更新、没有保留旧值」）；`PUT /api/reading-progress` 新收 `bookName / bookAuthor / coverUrl / tocUrl` 四个可选字段；前端推送壳子时把 `H.details` 里的书名等一并带上，所以「读一次就永久记得书名」；
- 读取：`GET /api/history?limit=N`（默认 300，上限 2000），`reading_progress` 左连 `book_shelf`（给出 `inShelf` / `completed` / 分组）与 `source`（给出书源名），按最近阅读排序；
- 前端：分组 tab 后面多一个「历史」（带条数）；列表行 = 封面 / 书名（未入架时带「未入书架」徽标）/ 当前章节 / 书源名·相对时间 / 「继续」按钮；老数据没有书名的行，点开时先取 `/api/books/details` 再推壳子，不会因缺 `tocUrl` 推空。

工具 `tools/patch-history.mjs`。实测当前库 13 条进度里 11 条不在书架，正是这个 tab 的目标场景。

### 四、缓存管理面板精简

只留「当前占用量 + 清理按钮」：面板正文换成一个占用卡片（「本地空间占用」+ 大号数字），底部保留「清空全部本地缓存 / 完成」。
删掉：LRU 自动清理开关（`lru-toggle-label`）、已离线书籍明细列表（逐本 `清除`）、服务端图片缓存整块（占用/配额/张数/整本保留/清空）。共 5057 字符。

工具 `tools/patch-shelf-ui.mjs`（同一脚本里也带上面第二节的移动端样式，幂等标记 `/*__lr_1_6_0_shelf__*/`）。

### 五、壳子推送浮动按钮移除

既然已经默认推送壳子，左下角那个「壳子推送」小圆点就是多余的。`web-dist/lr-tvbox.js` 删掉 `mountShellHint()`
（连带它动态创建的 `#lr-shell-pill` 与 `#lr-shell-panel` 面板、注释块），19480 → 16730 字节；
`boot()` 现在是 `hookPush(); if (!shellMode()) return; installResolver();`。

保留全部推送逻辑：`lr-push-book` 事件接管、`canHijack()` 的「不在壳子里」提示、`pushBook()` 短键登记、
`deliver()` 的四级降级、`installResolver()` 哨兵解析。换服务器入口改走 `/tvbox.html?setup=1`。

### 六、38看书 / 哔哩小说：既有的上游限制 + 三个真 bug（已修）

排查方法是三层取证，别的书源可以直接复用：

1. 后端全链路：`GET /api/sources/:id/debug?keyword=…`（search → details → chapters）先定位断在哪一环；
2. 上游直连：DNS → TCP 443 → TLS → HTTP，再按页面特征串打标记（登录墙 / Cloudflare 盾 / 空列表）；
3. 书源规则本体：`searchUrl` / `ruleSearch` / `ruleToc` / `ruleContent` / `loginUrl`。

**属上游限制、服务侧无法修的部分**

- 38看书：`searchUrl` 拼的是第三方搜索站 sososhu（`https://www.sososhu.com/?s=<key>&web=38kanshu`），
  页面直接回「需要登录才能搜索」，`ruleSearch` 那段解 `d("…")` Base64 的 `<js>` 自然 0 条；该源自带 `loginUrl`
  就是登录 sososhu（手机号+密码+验证码）与签到，且有 12 次/天限额。**搜索受阻于上游登录墙。**
- 哔哩小说：搜索页 403 且命中 Cloudflare 盾（`Just a moment` / `challenge-platform`）；源里 `loginUrl` 的
  `BLX_open()` 就是让人工在浏览器里过盾。**搜索受阻于上游反爬。** 另外它的书页是 `/novel/<slug>.html`，
  不是 `/book/lastupdate_*.html` 那种列表页（之前拿列表页当书页才会出现「目录出现错误」）。

**属本服务、已修好的三个 bug**

| bug | 现象 | 修法 |
|---|---|---|
| 沙箱缺 Java 桥 | 哔哩小说目录规则用 `org.jsoup.Jsoup.parse(body)` + `Packages.java.util.ArrayList` 选元素，求值直接抛错 → 目录 0 章 | `dist/jsSandbox.js` 新增 `createJsoupBridge()`：用 cheerio 顶替 `org.jsoup.Jsoup` / `Packages`，元素序列化成 outerHTML，再由 `ruleRunner.jsListNodes()` 还原成节点 |
| 序号段不认 | 38看书 `ruleToc.chapterList` 是 `class.recommend.1@class.directoryArea@tag.p@tag.a`，`class.X.N` 在 CSS 里没有等价写法（`:nth-of-type` 数的是同类兄弟，不是匹配集合下标）→ 取不到节点 | `selectAllLegado()` 遇到含序号段的链改成逐段选择，序号段用 `.eq(N)` |
| 目录只取第一页 | WAP 站目录一页 50 章，只取首屏 →「能读但不全」；且目录地址不是 `/toc` 而是 `<书页去掉 .html>/catalog` | `ruleRunner` 加 `nextTocUrl` 翻页（上限 60 页 / 20000 章、按 url 去重）；`books.js` 加 `tocCandidates()`（`tocUrl` → 书页 → `/toc` → `/catalog`）并挑「章数最多」的候选 |

修后实测（真后端）：38看书 1464 章、哔哩小说 2244 章，正文都能正常取到（比如《星际猎人》首章 1482 字、《蛊真人》序章 2437 字）。
搜索仍受上游限制，需要在壳子/浏览器里登录 sososhu 或手动过盾；这两条的「详情 → 目录 → 正文」链路已经完全可用。

### 验证状态（1.6.0 实跑）

```
bundle-load          1/1     产物能作为 ES module 加载（防白屏守卫）
web-reader-removed  13/13    1.5.0 下线的阅读器/朗读/书签仍未回归
shell-bridge         8/8     壳子桥契约（浮动按钮移除后仍全绿）
removed-features     9/9     1.4.0 下线的订阅/替换规则未回归
web-patch           10/10    explore / loadbook 两处前端补丁
tvbox-entry          8/8     tvbox.html 入口
rule-selector       12/12    Legado 选择器（含新增序号段）
zlibrary             6/6
local-book          29/29
explore-backend      7/7     真后端 + 假上游（目录 / 分页 / 兜底）
history-ui          11/11    新增：历史 tab + 缓存面板 + 移动端样式 + 只留中文（含真后端 4 项）
```

`dist/**/*.js` 与 `web-dist/assets/index-68a2edd4.js` 全部 `node --check` 通过；`tools/patch-web-assets.mjs --check`、
`tools/build-rule-page.mjs --check`、`tools/strip-i18n.mjs --check`、`tools/patch-history.mjs --check`、
`tools/patch-shelf-ui.mjs --check` 均通过。

## 1.5.0 下线网页阅读器 / 朗读 / 书签，阅读全面改走壳子推送

网页端不再自己「读」，只负责找书和发起推送；点书（或点某章）→ 页面写一条阅读进度 →
派发事件 → 壳子桥把整本目录推给 TVBox / DsPlayer，正文由壳子按 `lr://b/<短键>/<序号>` 回查后端取。
「书库」改名「搜索」，书签导航入口与整条书签功能线移除。

| 层 | 移除内容 |
|---|---|
| 模块 | `dist/routes/tts.js`（Edge TTS 音色 / 合成）、`dist/routes/bookmarks.js`（书签 CRUD + 概览）、`dist/edgeTts.js`（Edge 引擎） |
| 路由 | `/api/tts/*`、`/api/http-tts*`、`/api/bookmarks*` 全部下线（实测 404） |
| 启动 | `app.js` 去掉三个 import、`EdgeTtsService` 实例、`ctx.edgeTts`、两个 `register*Routes` 调用 |
| 数据 | `bookmark`（含 `idx_bookmark_book`）、`http_tts`（含 `idx_http_tts_name`）两张表 DDL 与 19 个读写方法 |
| 备份 | 导出不再写 `bookmark.json` / `httpTTS.json`，导入也不再读；`toHttpTts()` 删除（现在只导书源 / 分组 / 书架 / RSS 四份） |
| 一键导入 | `httpTts` 类型从 `onlineImport` 与 `/api/online-import` 白名单里去掉（白名单现为 `['bookSource','rssSource']`） |
| 前端产物 | 阅读器三件套（正文 `hS` / 漫画 `yS` / 有声 `AS`）、书签浮层 `sv`、阅读设置抽屉 `dS`、书签页 `oC`、TTS 播放器 `Gv`、Web Speech 朗读器 `zv`、朗读面板 `Kv`、播放条 `Jv`、httpTTS 管理弹窗 `$v` + 引擎表单 `_v`；`#reader` / `#bookmarks` 两条 hash 路由、导航书签按钮、页面分发书签分支、阅读会话 state、书签跳转、API 客户端两段方法；文案改「书库 → 搜索」「在线书库 → 在线搜索」。产物 1063149 → 892948 字节（字符数 787463，中文 UTF-8 占 3 字节，两个数不是矛盾） |

保留（**不要误删**）：

- `reading_progress` 表与 `/api/reading-progress` —— 书架「继续阅读」和推送时写进度都要用；
- `/api/books/chapters`、`/api/books/content`、`/api/tvbox/*` —— 壳子取目录 / 正文 / 短键回查的依赖；
- `dist/jsSandbox.js` 的 `book.setUseReplaceRule = () => undefined` —— 1.4.0 起就有的书源脚本兼容存根；
- `/api/rss-sources` 与 RSS 导入 —— 与已下线的「订阅」不是一回事；
- `__lr_patch:explore__` / `__lr_patch:loadbook__` 两处前端补丁。

### 壳子推送新契约（`web-dist/lr-tvbox.js`）

```
页面点书 → dispatchEvent(new CustomEvent('lr-push-book', {detail:{book, index}}))
                │
                ├─ canHijack() 为假（普通浏览器）→ toast「当前不在壳子里：请用 TVBox / DsPlayer 打开本页再点阅读」
                └─ 为真 → pushBook() → POST /api/tvbox/book-key 登记 12 位短键
                        → 每集 lr://b/<key>/<序号> → deliver()
                          fm.vodInline → fm.openVod → 父页面 postMessage → 只有 fm.play 时退化单章 novel://
```

桥不再有「网页阅读」退路：`legado-open-book-v1` 会话键、`Storage.prototype.setItem` 钩子、
`rememberHash/leaveReader`、`SS_SHELL_OFF` 与「改用网页阅读」按钮全部删除。

### 其它三处

- 发现页卡片超出宽度：`.explore-book-grid` 改 `repeat(auto-fill,minmax(min(290px,100%),1fr))`，
  卡片 `min-width:0; overflow:hidden`，作者名省略号，动作区 `flex-wrap:wrap`；
- 本地导入按钮移到右上角，与「书架」标题同一行（`.shelf-title-row`）；
- 切除脚本 `tools/strip-web-reader.mjs`（幂等标记 `/*__lr_strip_reader__*/`，支持 `--check` / `--debug`）。

### 事故记录：白屏（已修）

切 `const $v=…,_v=…` 这条 const 链时**把 `const` 关键字一起吃掉**，留下 `}Vv=[.8,1,1.25,1.5,2],…`。
`index.html` 用 `<script type="module">`（严格模式），给未声明变量赋值抛 `ReferenceError: Vv is not defined`
→ 整个模块加载失败 → `#root` 空 → 搜索 / 发现 / 书架全空白。

`node --check` 和 `vm.Script` 都查不出来（那在语法上是合法的赋值表达式）。
修复：脚本里切 const 链头改成 `indexOf(anchor) + 'const '.length`，并在偏移 519279 处补回 `const `。

由此新增 `tests/bundle-load-test.mjs`：把 bundle 复制成 `.mjs`（**必须改后缀**，否则 `/tmp`
无 `package.json` 时按 CommonJS 非严格模式加载，检查会假阴性），在最小 DOM 桩里 `await import()`，
模块级异常即失败。对照实验：坏产物 `✗ ReferenceError: Vv is not defined`，修后 `✓ 加载完成`。

### 漫画 / 有声：解析没受影响，但本来也读不了

解析链一行没动（`bookKind.js`、`ruleRunner.mjs` 的 `mangaImages`、`ruleWorker` 的 `case 'mangaImages'`、
`rulePool`、`config.js` 的 `cache.manga.*`、`database.js` 的 `manga_chapter_cache` / `manga_image_cache`）。
但后端从来没有 `/api/books/images/*`、`/api/audio/*` 路由，也没有任何地方执行 `pool.run('mangaImages', …)`
—— 网页漫画阅读器一直是 404，属移植遗留。删掉前后「都不可读」，只是失败姿势从「阅读器报错」变成
「推过去但章节里没图」。书架「清除缓存」调用的 `clearImageCache` / `clearAudioCache` 同理（静默失败）。

待选方案：A 推送前按 `bookKind` 拦截并提示（十来行）；B 补 `/api/books/manga/manifest` + 图片代理缓存；
C 把漫画推成 `format:'images'` 交给壳子渲染。

## 1.4.0 下线「订阅」与「替换规则」

两条功能线整体移除（后端 + 前端产物），其余功能不受影响。

| 层 | 移除内容 |
|---|---|
| 模块 | `dist/subscriptionSync.js`（规则订阅自动更新）、`dist/routes/replaceRules.js`（替换规则 CRUD）、`dist/contentProcessor.js`（替换规则链引擎） |
| 路由 | `/api/subscriptions*`（列表 / 新增 / 立即更新 / 回报 / 删除）、`/api/replace-rules*`、`/api/replace-rule-groups*`、`/api/bookshelf/reclean`、`/api/bookshelf/batch-reclean` |
| 启动 | `app.js` 里的订阅定时器（15s 首跑 + 每 10 分钟一轮）与 `onClose` 清理 |
| 数据 | `source_subscription`、`replace_rule` 两张表的 DDL、旧库升级补列、全部读写方法；`recleanBookCache` |
| 内容链 | 正文读缓存时的规则净化（`routes/books.js` 的 `applyReplaceRules`）、规则执行器的净化步骤（`ruleRunner.js`）、TVBox 出口的净化（`tvbox.js` 的 `applyRules`） |
| 备份 | 导出不再写 `replaceRule.json`，导入也不再读它（老备份包仍能导入，只是忽略这份） |
| 一键导入 | `replaceRule` 类型从 `onlineImport` / `detectImportKind` / `/api/online-import` 白名单里去掉 |
| 前端 | 导航（桌面 + 移动菜单）两个入口、`#subscriptions` / `#rules` 两条 hash 路由、两页组件本体、阅读设置「内容净化 / 替换净化规则管理」、书架「重新应用净化规则」、API 客户端三组方法（产物 982111 → 950737 字节） |

保留：

- **书源 JS 的兼容存根** `book.setUseReplaceRule = () => undefined` 仍在 `jsSandbox.js` —— 那是 Legado 书源脚本的 API 面，删了会让调用它的老书源报错；
- **RSS 源**（`/api/rss-sources`，界面在书源页里）与「订阅」不是一回事，未动；
- 语言表里的 `header.subscriptions` 之类文案键属于数据，无引用，留在产物里也不影响行为。

前端产物没有源码，切除由 `tools/strip-removed-features.mjs` 完成：按锚点切 14 段、切完用 `vm` 解析整份产物、再断言没有残留引用；带幂等标记，重复执行会跳过。若哪天换了新的前端产物，重跑它即可。

回归守卫：`node tests/removed-features-test.mjs`（9 条）—— 模块/表/方法/路由/前端入口都不许回来，同时断言书架、书源、RSS、图书馆、壳子桥和已有的两处补丁仍在。

## 1.3.1 图书馆报 503（Z-Library 中转）

| # | 现象 | 根因 | 改法 |
|---|---|---|---|
| 1 | 点「图书馆」弹 `站点返回 HTTP 503`，首页空白 | 站点把「Checking your browser」算力墙升级成混淆脚本（变长种子 + cookie 探测 + 数组位移解密 + 下标也藏起来）。老代码用正则抓 40 位十六进制常量，抓不到就 `return null`，于是 503 挑战页被原样当成上游错误抛给前端 | `solveChallenge` 不再跟混淆赛跑：把挑战页自己的 `<script>` 丢进假 DOM 里真跑一遍，在 `document.cookie` 的 setter 上接住它自己写出的 `c_token` / `c_time`，再用原生 crypto 顶掉页面里那份纯 JS sha1（几万次哈希 → 几十毫秒）。`send()` 对 403/503 都走这条自愈重放 |
| 2 | 封面全是裂图 | `/api/zlibrary/img` 收到的是 CDN 绝对地址（`s3proxy-alp2-covers.cdn-zlib.sk/...`），`fetchWith` 却把 `pathname` 重新拼到当前镜像域名上，每张图都 404 | `fetchWith` 判断 host 是否属于站点镜像：站外绝对地址原样请求，只有站内相对路径才做镜像故障切换 |
| 3 | 前两个镜像在国内网络下根本连不上，每次点开都要先撞两堵墙 | 镜像顺序是写死的，且「中文镜像优先」恰好选了些被墙的域名 | 默认顺序改成实测能直连的（`z-lib.by` 优先），并加了启动探测 `probeBases()`：并发打每个镜像的 `/`（4s 超时），探通的按延迟排序、探不通的进冷却垫底，10 分钟复探一次。国内 / 海外网络各自会挑出自己能用的那条 |
| 4 | 报错信息只有 `HTTP 503`，看不出是被墙还是验证没过 | 错误串太干 | 503/403 时补一句「镜像在验证 / 被墙，换个镜像或配 `LEGADO_ZLIB_BASE`」 |

配置（环境变量，优先级高于内置列表）：`LEGADO_ZLIB_BASE`（单个）或 `LEGADO_ZLIB_BASES`（逗号分隔多个）。

实跑（手机蜂窝，无代理）：首页 1.8s 出 50 本中文书、搜索 1.6s/50 条、分类页 6.5s/36 本、
详情 2.0s、封面 `image/jpeg`、下载 4.9MB epub 15.7s（共享账号）。

## 1.3.0 本轮改动（对应用户反馈的四条）

| # | 反馈 | 根因 | 改法 | 位置 |
|---|---|---|---|---|
| 1 | 规则页点任意目录只推送这一章 | 老规则页目录项绑的是 `pushIdx` → `pushChapter(index)`，一次只取一章正文丢给壳子 | 阅读入口改成「整本目录一次性推送，`mark` 指向点开的那一章」；章地址是 `lr://b/<12 位短键>/<序号>` 哨兵，点章再回查正文 | `web-dist/lr-tvbox.js` |
| 2 | 规则页要完整复用后端 Web 页面 | 老规则页是一份 90KB 的独立 HTML，把八个页面又写了一遍，跟 Web 前端两套代码 | 规则页只做「找后端 + 带 `?lr_shell=1` 跳进 Web 页面」；真正接管的是 Web 页面里加载的桥脚本，界面/路由/状态全是原版 | `web-dist/tvbox.html`、`阅读书架[书].html`、`web-dist/index.html` |
| 3 | Web 页面从别的页面回发现页，选中的书源丢了 | 发现页 `useEffect` 每次都 `find(enabled) → [0]`，选源只存在组件 state 里 | 选源落 `localStorage lr.exploreSource`（连每个源上次看的分类 `lr.exploreCategories` 一起记） | `web-dist/assets/index-*.js`（补丁源：`tools/web-patches/explore.component.js`） |
| 4 | 测试书源通过，发现页不出书 / 进详情报「目录加载失败」 | ① 发现页遇到「分类返回空列表」不换分类，直接显示「该分类下暂无书籍」；② 详情 `ruleBookInfo` 缺失/失效就把书判死，连目录都不去要；③ 前端把 `tocUrl` 当 `bookUrl` 传给后端，后端拿目录页再取一次详情，`tocUrl` 链断掉 | ① 空分类自动顺延最多 6 个、切源丢弃旧结果；② 详情失败按列表信息兜底，目录一律按书页地址请求；③ 后端目录候选改成 `tocUrl → 书页 → /toc 变体`，成功结果按书页地址做别名缓存 | 同 3 + `dist/routes/books.js` |

补充：

- 整本推送不再把 `base64(书源+书址)` 塞进每一集，800 章目录负载从 ~300KB 降到 ~70KB，不会被壳子截断。
- 短键登记接口 `/api/tvbox/book-key`（写入 / 回查），壳子重启后仍能解析哨兵；`/api/books/chapters` 加了缓存命中（含 `/toc` 变体）。
- 顺手修的真 bug：本地 TXT 的 GBK 兜底。Android 上的 node 没有内置 `gbk` 转换器，旧代码 catch 之后静默退化成宽松 UTF-8，GBK 书全变乱码；现在用 `iconv-lite`（纯 JS，已在 `node_modules`）兜底，`dist/localBookImport.js`。
- 规则页是**生成物**，别手改：`node tools/build-rule-page.mjs`（`--check` 只校验），单一来源是 `web-dist/tvbox.html`。

## 验证状态（1.6.1 实跑）

| 项 | 结果 | 说明 |
|---|---|---|
| 启动去重 | 通过 | 日志 `[server] 已清理 8 条重复的本地书`；`book_shelf` 13 → 5 行，本地书 12 → 4 条；重启第二次不再打印（幂等） |
| 书架接口无重复 | 通过 | `/api/bookshelf` 5 条，「同 sourceId + 书名 + 作者」重复组数 **0** |
| 重复导入幂等 | 通过 | 同一份 EPUB 走 `/api/bookshelf/import-local` 再传一次，返回 `bookUrl` 仍是 `local://93f13a8a-…`，书架条数不变 |
| 进度回写 · 路由 | 通过 | 进度原在第 12 章 → `POST /api/books/content` 取第 7 章 → `chapterIndex=7`、`chapterTitle` 同步、书架 `last_read_at` 刷新 |
| 进度回写 · `/novel` | 通过 | 取第 3 章 → 进度变第 3 章 |
| 进度回写 · `/txt` | 通过 | 取第 5 章 → 进度变第 5 章 |
| 进度回写 · `PUT /api/reading-progress` | 通过 | 200，`GET` 能读回 |
| 去注释 | 通过 | `dist/`、`web-dist/`、`tools/`、`tests/`、根目录 HTML 里 `__lr_` 归零；`node tools/strip-comments.mjs --dry` → 「处理 0 个文件」 |
| 产物体积 | — | bundle 646986 字节 / 606217 字符（1.6.0 是 650145 字节 / 608592 字符）；CSS 205776 字节；`lr-tvbox.js` 14837 字节 / 14581 字符；规则页 9124 字节 |
| 静态与接口 | 通过 | `/`、bundle、CSS、`/lr-tvbox.js`、`/api/bookshelf`、`/api/history`、`/ping` 全 200；历史 17 条 |
| 11 套测试 | 131/131 | 见上表（`shell-bridge` 9、`local-book` 45） |
| 6 个产物工具 `--check` | 全通过 | `patch-web-assets`、`build-rule-page`、`strip-i18n`、`strip-web-reader`、`patch-history`、`patch-shelf-ui`，另 `patch-toc-engine` / `patch-toc-paging` / `strip-removed-features` 也过 |

## 验证状态（1.5.0 实跑）

| 测试 | 结果 | 说明 |
|---|---|---|
| `node tests/bundle-load-test.mjs` | **1/1** | 产物能否作为 ES module 加载（0.12s）。坏产物对照实测报 `ReferenceError: Vv is not defined` |
| `node tests/web-reader-removed-test.mjs` | **13/13** | 1.5.0 下线项：三个模块已删、无 TTS/书签落点、备份不再写 `bookmark.json`/`httpTTS.json`、在线导入只剩书源/RSS、dist 全量语法、`reading-progress` 与壳子取正文接口仍在、前端 13 条禁用串、`lr-push-book`、`shelf-title-row`、CSS 修复 |
| `node tests/removed-features-test.mjs` | **9/9** | 1.4.0 下线项（订阅 / 替换规则），`#bookmarks` 已挪到 mustNot |
| `node tests/shell-bridge-test.mjs` | **8/8** | 壳子桥改为事件驱动：整本推送、缺目录时回源拉、哨兵取正文、只有 `fm.play` 时单章退化、首/中/末章都推整本、漫画与有声也走推送、普通浏览器只提示、桥里不再有阅读器退路 |
| `node tests/zlibrary-test.mjs` | **6/6** | 图书馆：503 挑战页自愈重放、封面不被拼回镜像域名、镜像探测排序、非白名单域名仍拒绝、认不出的 503 如实上报 |
| `node tests/tvbox-entry-test.mjs` | **8/8** | 规则页/入口页：默认跳转、`?base=` 优先、记住地址、`fm.req` 探活、连不上给表单、`?setup=1`、规则页与入口页一致 |
| `node tests/web-patch-test.mjs` | **10/10** | 前端补丁：补丁幂等可解析、发现页记住书源 / 分类、空分类顺延、详情失败仍能拿目录、`tocUrl` 回退 |
| `node tests/explore-backend-test.mjs` | **7/7** | 真后端 + 假上游：裸地址分类、`ruleExplore` 失效按 `ruleSearch` 兜底、无 `ruleBookInfo` 也能出目录、`tocUrl` 取目录 + 缓存命中、`/toc` 变体、正文、书架入口一致 |
| `node tests/rule-selector-test.mjs` | **12/12** | 选择器翻译（逗号分组 / 括号内逗号 / legado 语法 / 排除下标） |
| `node tests/local-book-test.mjs` | **29/29** | 本地书 TXT/EPUB 解析与上架 |
| `node tests/tvbox-chain-test.mjs`（真后端，导入书源后） | **16/16** | 静态页 + 书源导入 + 发现→详情→目录→正文 + 本地书 800 章 + 短键回查。不导书源时与书源相关的 3 项会 FAIL（空库，不是 bug） |
| `node tools/patch-web-assets.mjs --check` | 通过 | 两处补丁均在产物里 |
| `node tools/build-rule-page.mjs --check` | 通过 | 规则页与入口页同步 |
| `node tools/strip-web-reader.mjs --check` | 通过 | 30 段切除标记都在 |
| dist 全量 `node --check` | 通过 | 无语法错误 |

接口实测（1.5.0 重启后）：`/api/bookmarks`、`/api/bookmarks/overview`、`/api/tts/voices`、`/api/http-tts`
全部 **404**；`/api/reading-progress` 400（缺参数，路由活着）；`/api/bookshelf`、`/api/sources`、
`/api/rss-sources`、`/assets/index-*.css`、`/lr-tvbox.js`、`/tvbox.html` 均 **200**。

浏览器级测试 `tests/explore-ui-test.mjs`（切源不出 404、刷新记得源）与
`tests/explore-dropdown-test.mjs`（选源下拉定位）需要 playwright + 本机 chromium，
本机没装，本轮未跑；逻辑等价覆盖在 `web-patch-test` / `explore-backend-test` 里。

```bash
# 不需要服务
node tests/tvbox-entry-test.mjs
node tests/shell-bridge-test.mjs
node tests/web-patch-test.mjs
node tools/patch-web-assets.mjs --check
node tools/build-rule-page.mjs --check

# 需要真后端
LEGADO_DATA_DIR=/tmp/lrdata LEGADO_PORT=5268 node dist/index.js &
node tests/explore-backend-test.mjs            # 自带假上游，随机端口
BASE=http://127.0.0.1:5268 node tests/tvbox-chain-test.mjs --sources 140个书源.json
```

## 壳子怎么用

- 后端托管：`http://<设备IP>:5268/tvbox.html`（会带 `?lr_shell=1` 跳进 Web 页面）。
- 本地规则页：`阅读书架[书].html` 放到壳子的自定义页面/本地页面里，逻辑与上一行完全相同；
  第一次需要填一次后端地址（`?base=192.168.1.10:5268` 也可预填，之后记在 `localStorage lr.base`）。
- 点书即推送：Web 页面里点「阅读」/ 点某章 → 整本目录推给壳子（普通浏览器打开时只给一句提示）。
  网页阅读器、朗读、书签已在 1.5.0 下线，**没有回网页阅读的入口**。

## 已知环境限制（不是解析 bug）

- 海外出口访问国内小说站大量 403 / 域名失效 → 抽样里能跑通的源偏少，国内网络下明显更高。
- 部分书源的 exploreUrl 本身写死成 `https://www.baidu.com/...`（模板没展开），任何客户端都取不到书；
  页面会自动跳过这类分类，最多试 6 个再报错。
- 番茄系源的目录接口对海外出口返回空。
- 不支持 XPath；`@js` 只覆盖 `java.*` 常用子集；依赖 JSLib 自定义函数的源跑不了。

## 已排除的方向（别再重复踩）

- 发现页 404 不是「书源失效」：根因是切源瞬间「新书源 + 旧分类地址」的竞态。
- 目录推不全不是壳子截断：老写法每集塞 `base64(书源+书址)`，换 12 位短标识即可。
- 本地书目录一直是全的（`book_content_cache` 有 800 行），老页面只是推送负载太大。
- 「测试书源通过但发现页空」不一定是源坏了：空分类不换源、`ruleBookInfo` 缺失、`tocUrl` 被当书页，三处都会造成同样的观感。

## 常用命令

```
cd legado-server-node && node dist/index.js        # 启动
node tools/build-rule-page.mjs                      # 重新生成规则页
node tools/patch-web-assets.mjs                     # 重新给前端产物打补丁
node tools/strip-web-reader.mjs [--check]           # 1.5.0 下线阅读器/朗读/书签（幂等）
node tools/strip-i18n.mjs [--check]                 # 1.6.0 只保留简体中文（幂等）
node tools/patch-history.mjs [--check]              # 1.6.0 书架「历史」tab + /api/history（幂等）
node tools/patch-shelf-ui.mjs [--check]             # 1.6.0 书架移动端样式 + 缓存面板精简（幂等）
node tools/strip-comments.mjs [--dry]                # 1.6.1 去注释（自带 node --check，语法不过不写）
node tests/bundle-load-test.mjs                     # 产物能否当 ES module 加载（防白屏，最快）
node tests/web-reader-removed-test.mjs              # 1.5.0 下线项守卫
node tests/removed-features-test.mjs                # 1.4.0 下线项守卫
node tests/tvbox-entry-test.mjs                     # 规则页 / 入口页（无需服务）
node tests/shell-bridge-test.mjs                    # 壳子推送桥（无需服务）
node tests/web-patch-test.mjs                       # 前端补丁回归（无需服务）
node tests/zlibrary-test.mjs                        # 图书馆 503 / 封面 / 镜像排序（无需服务）
node tests/local-book-test.mjs                      # 本地书（无需服务）
node tests/explore-backend-test.mjs                 # 发现页 / 目录后端回归
node tests/tvbox-chain-test.mjs --sources 140个书源.json   # 真后端全链路
node tests/history-ui-test.mjs                      # 1.6.0 历史/缓存/移动端/中文（含真后端）
```