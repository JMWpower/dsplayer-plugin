#!/usr/bin/env node

import fs from 'node:fs';

const CHECK = process.argv.includes('--check');
const BUNDLE = 'web-dist/assets/index-68a2edd4.js';
const CSS = 'web-dist/assets/index-hiHoGuoh.css';
const BACKUP = '.operit/backup-1.6.0';

function backup(file) {
  if (CHECK) return;
  fs.mkdirSync(BACKUP, { recursive: true });
  fs.copyFileSync(
    file,
    `${BACKUP}/${file.replace(/[\\/]/g, '_')}.before-ui.${new Date().toISOString().replace(/[:.]/g, '-')}.bak`,
  );
}

function patchCachePanel() {
  let s = fs.readFileSync(BUNDLE, 'utf8');
  if (s.includes('cache-storage-card')) return { file: BUNDLE, changed: false, note: '缓存面板已精简，跳过' };

  const start = s.indexOf('t.jsxs("div",{className:"offline-cache-content",children:[');
  if (start < 0) throw new Error('找不到缓存面板内容区锚点');
  const footer = s.indexOf('t.jsxs("footer",{className:"source-login-footer"', start);
  if (footer < 0) throw new Error('找不到缓存面板 footer 锚点');
  if (footer - start > 12000) throw new Error('缓存面板区间异常：' + (footer - start));

  const removed = footer - start;
  const replacement =
    't.jsx("div",{className:"offline-cache-content",children:t.jsxs("div",{className:"cache-storage-card",children:[' +
    't.jsx("span",{className:"cache-storage-label",children:n("source.offlineSpace","本地空间占用")}),' +
    't.jsx("strong",{className:"cache-storage-value",children:fl((l==null?void 0:l.totalBytes)||0)}),' +
    't.jsx("span",{className:"cache-storage-hint",children:"清理后断网将无法脱机阅读"})' +
    ']})})}),';

  s = s.slice(0, start) + replacement + s.slice(footer);
  if (!CHECK) backup(BUNDLE);
  return { file: BUNDLE, changed: true, note: `删除 ${removed} 字符明细，换成占用卡片`, text: s };
}

const CSS_BLOCK = `@media(max-width:640px){
.shelf-page{gap:12px;padding:16px 12px calc(20px + var(--safe-bottom))}
.shelf-page-header{align-items:center;gap:8px}
.shelf-page-header .section-kicker{font-size:10.5px;letter-spacing:.16em}
.shelf-page-header p{display:none}
.shelf-title-row{gap:10px}
.shelf-title-row h1{font-size:25px;line-height:1.12}
.shelf-import-btn{min-height:38px;padding:8px 12px;border-radius:10px}
.shelf-import-btn span{font-size:12.5px}
.shelf-header-actions{width:100%;justify-content:space-between;gap:8px;margin-top:2px}
.shelf-header-actions>small{font-size:12px;color:var(--muted)}
.shelf-search-btn{min-width:38px;min-height:38px;justify-content:center;padding:8px;border-radius:10px}
.shelf-search-btn svg{width:17px;height:17px}
.shelf-batch-toggle-btn{min-height:38px;padding:8px 12px;border-radius:10px;font-size:12.5px}
.shelf-tabs{position:sticky;top:0;z-index:24;gap:14px;margin:0 -12px;padding:0 12px;background:color-mix(in srgb,var(--canvas) 92%,transparent);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px)}
.shelf-tabs button{height:44px;font-size:13.5px;padding:0 2px}
.shelf-manage-group-btn{position:sticky;right:0;padding-right:2px!important;background:color-mix(in srgb,var(--canvas) 92%,transparent)}
.shelf-subfilter-bar{margin-top:0;overflow-x:auto;scrollbar-width:none}
.shelf-subfilter-bar::-webkit-scrollbar{display:none}
.shelf-status-pills{gap:8px;flex-wrap:nowrap;padding:2px 0}
.shelf-pill-btn{height:32px;padding:0 14px;font-size:12.5px;white-space:nowrap;flex:0 0 auto}
.shelf-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.shelf-card{border-radius:12px;box-shadow:0 1px 3px #0000000d}
.shelf-card-cover{border-radius:11px 11px 0 0}
.shelf-card:hover{transform:none;box-shadow:0 1px 3px #0000000d}
.shelf-card:active{transform:scale(.985)}
.shelf-card-info{padding:9px 10px 4px;gap:3px}
.shelf-card-info strong{font-size:13.5px;line-height:1.32;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.shelf-card-info small{font-size:11.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.shelf-card-footer{padding:6px 10px 10px;gap:6px}
.shelf-card-footer button{min-height:32px;padding:0 8px;font-size:12px;flex:1 1 0;justify-content:center}
.shelf-empty{min-height:0;padding:34px 16px;gap:10px;border-radius:12px}
.shelf-empty h2{margin:0;font-size:17px}
.shelf-empty p{font-size:12.5px;line-height:1.6}
.shelf-batch-bar{bottom:calc(10px + var(--safe-bottom));width:calc(100vw - 20px);padding:10px 12px;border-radius:14px;gap:8px;flex-wrap:wrap;justify-content:center}
.shelf-batch-bar button{min-height:34px;font-size:12.5px;flex:1 1 auto}
}
@media(min-width:561px) and (max-width:1024px){
.shelf-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
}
@media(hover:hover) and (max-width:640px){
.shelf-card:hover{transform:translateY(-2px);box-shadow:0 6px 18px #00000012}
}
.shelf-history{display:grid;gap:10px}
p.shelf-history-tip{margin:0;color:var(--muted);font-size:12px;display:flex;align-items:center;gap:8px}
div.shelf-history-tip{display:flex;align-items:center;justify-content:center;gap:8px;padding:34px 12px;color:var(--muted);font-size:12.5px}
.shelf-history-list{display:grid;gap:8px}
.history-row{display:flex;align-items:center;gap:12px;padding:10px;border:1px solid var(--line);border-radius:12px;background:var(--surface)}
.history-row:active{background:var(--surface-muted)}
.history-cover{flex:0 0 auto;width:54px;height:72px;padding:0;border:0;border-radius:8px;overflow:hidden;background:var(--accent-soft);cursor:pointer}
.history-cover img{width:100%;height:100%;object-fit:cover}
.history-meta{flex:1 1 auto;min-width:0;display:grid;gap:3px}
.history-title-line{display:flex;align-items:center;gap:6px;min-width:0}
.history-title-line strong{font-size:14px;line-height:1.3;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.history-badge{flex:0 0 auto;padding:1px 6px;border-radius:999px;background:var(--accent-soft);color:var(--accent-ink);font-size:10.5px;font-weight:600}
.history-chapter{color:var(--ink);opacity:.72;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.history-sub{color:var(--muted);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.history-open-btn{flex:0 0 auto;min-height:34px;padding:0 12px;border:1px solid var(--line);border-radius:9px;background:var(--surface-muted);color:var(--ink);font-size:12.5px;cursor:pointer}
.history-open-btn:active{border-color:var(--accent);color:var(--accent)}
.cache-storage-card{display:grid;gap:6px;padding:26px 18px;border:1px solid var(--line);border-radius:14px;background:var(--surface-muted);text-align:center;justify-items:center}
.cache-storage-label{color:var(--muted);font-size:12.5px}
.cache-storage-value{font-size:28px;font-weight:650;color:var(--accent);line-height:1.1}
.cache-storage-hint{color:var(--muted);font-size:11.5px}
`;

function patchCss() {
  let s = fs.readFileSync(CSS, 'utf8');
  if (s.includes('.cache-storage-card{')) return { file: CSS, changed: false, note: '移动端样式已加，跳过' };
  const before = s.length;
  if (!CHECK) backup(CSS);
  return { file: CSS, changed: true, note: `${before} → ${before + CSS_BLOCK.length} 字符`, text: s + CSS_BLOCK };
}

const cache = patchCachePanel();
const css = patchCss();

console.log(`${cache.changed ? '✓' : '·'} ${cache.file}：${cache.note}`);
console.log(`${css.changed ? '✓' : '·'} ${css.file}：${css.note}`);

if (!CHECK) {
  if (cache.changed) fs.writeFileSync(BUNDLE, cache.text ?? fs.readFileSync(BUNDLE, 'utf8'), 'utf8');
  if (css.changed) fs.writeFileSync(CSS, css.text, 'utf8');
  console.log('已写入。');

  const bundle = fs.readFileSync(BUNDLE, 'utf8');
  const styles = fs.readFileSync(CSS, 'utf8');
  const checks = [
    ['面板已换占用量卡片', bundle.includes('cache-storage-card')],
    ['不再有 LRU 开关', !bundle.includes('lru-toggle-label')],
    ['不再有离线书籍明细', !bundle.includes('offline-book-row')],
    ['不再有服务端缓存区块', !bundle.includes('server-cache-section')],
    ['仍保留清空全部按钮', bundle.includes('source.clearAllOffline')],
    ['样式含移动端块', styles.includes('.shelf-page{gap:12px')],
    ['样式含历史行', styles.includes('.history-row{')],
    ['样式含占用卡片', styles.includes('.cache-storage-card{')],
  ];
  let ok = true;
  for (const [name, pass] of checks) {
    if (!pass) ok = false;
    console.log(`${pass ? '✓' : '✗'} ${name}`);
  }
  if (!ok) process.exitCode = 1;
} else {
  console.log('（--check：只校验锚点，不写文件）');
}