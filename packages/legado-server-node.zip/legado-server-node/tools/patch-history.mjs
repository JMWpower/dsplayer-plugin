#!/usr/bin/env node

import fs from 'node:fs';

const CHECK = process.argv.includes('--check');
const BUNDLE = 'web-dist/assets/index-68a2edd4.js';
const DB = 'dist/database.js';
const APP = 'dist/app.js';
const BACKUP = '.operit/backup-1.6.0';

function replaceOnce(text, from, to, label) {
  const at = text.indexOf(from);
  if (at < 0) throw new Error('找不到锚点：' + label);
  if (text.indexOf(from, at + 1) >= 0) throw new Error('锚点不唯一：' + label);
  return text.slice(0, at) + to + text.slice(at + from.length);
}

function backup(file) {
  if (CHECK) return;
  fs.mkdirSync(BACKUP, { recursive: true });
  const target = `${BACKUP}/${file.replace(/[\\/]/g, '_')}.before-history.${new Date().toISOString().replace(/[:.]/g, '-')}.bak`;
  fs.copyFileSync(file, target);
}

function patchDatabase() {
  let s = fs.readFileSync(DB, 'utf8');
  if (s.includes('create table if not exists book_history')) return { file: DB, changed: false, note: '已有历史补丁，跳过' };
  const before = s.length;

  s = replaceOnce(
    s,
    `  primary key (source_id, book_url)
);
create table if not exists cover_cache (`,
    `  primary key (source_id, book_url)
);
create table if not exists book_history (
  source_id text not null, book_url text not null,
  name text, author text, cover_url text, toc_url text, book_kind text,
  last_read_at integer not null default 0, read_count integer not null default 1,
  primary key (source_id, book_url)
);
create index if not exists idx_book_history_last on book_history(last_read_at desc);
create table if not exists cover_cache (`,
    'DDL: book_history 表',
  );

  s = replaceOnce(
    s,
    `        this.db.prepare('update book_shelf set last_read_at = ? where source_id = ? and book_url = ?')
            .run(now(), progress.sourceId, progress.bookUrl);
        return this.getProgress(progress.sourceId, progress.bookUrl);`,
    `        this.db.prepare('update book_shelf set last_read_at = ? where source_id = ? and book_url = ?')
            .run(now(), progress.sourceId, progress.bookUrl);
        this.db.prepare("insert into book_history(source_id, book_url, name, author, cover_url, toc_url, book_kind, last_read_at, read_count)" +
            " values (?, ?, ?, ?, ?, ?, ?, ?, 1)" +
            " on conflict(source_id, book_url) do update set" +
            " last_read_at = excluded.last_read_at," +
            " read_count = book_history.read_count + 1," +
            " name = coalesce(excluded.name, book_history.name)," +
            " author = coalesce(excluded.author, book_history.author)," +
            " cover_url = coalesce(excluded.cover_url, book_history.cover_url)," +
            " toc_url = coalesce(excluded.toc_url, book_history.toc_url)," +
            " book_kind = coalesce(excluded.book_kind, book_history.book_kind)")
            .run(progress.sourceId, progress.bookUrl, progress.bookName ?? null, progress.bookAuthor ?? null, progress.coverUrl ?? null, progress.tocUrl ?? null, progress.bookKind ?? null, now());
        return this.getProgress(progress.sourceId, progress.bookUrl);`,
    'saveProgress 写历史',
  );

  s = replaceOnce(
    s,
    `            bookKind: r['book_kind'] ?? null,
        };
    }
    // ---------------- 书架 ----------------`,
    `            bookKind: r['book_kind'] ?? null,
        };
    }
    listHistory(limit = 300) {
        const rows = this.db.prepare("select p.source_id as source_id, p.book_url as book_url, p.chapter_url as chapter_url," +
            " p.chapter_index as chapter_index, p.chapter_title as chapter_title, p.updated_at as updated_at," +
            " coalesce(h.name, s.name) as name, coalesce(h.author, s.author) as author," +
            " coalesce(h.cover_url, s.cover_url) as cover_url, coalesce(s.cover_key, '') as cover_key," +
            " coalesce(h.toc_url, s.toc_url) as toc_url, coalesce(h.book_kind, s.book_kind, p.book_kind) as book_kind," +
            " case when s.book_url is null then 0 else 1 end as in_shelf," +
            " coalesce(s.completed, 0) as completed, coalesce(s.group_name, '') as group_name," +
            " coalesce(h.last_read_at, p.updated_at) as last_read_at, coalesce(h.read_count, 1) as read_count," +
            " coalesce(src.name, '') as source_name" +
            " from reading_progress p" +
            " left join book_shelf s on s.source_id = p.source_id and s.book_url = p.book_url" +
            " left join book_history h on h.source_id = p.source_id and h.book_url = p.book_url" +
            " left join source src on src.id = p.source_id" +
            " order by last_read_at desc limit ?")
            .all(Math.max(1, Math.min(2000, Math.floor(Number(limit) || 300))));
        return rows.map((r) => ({
            sourceId: r['source_id'],
            bookUrl: r['book_url'],
            name: r['name'] ?? null,
            author: r['author'] ?? null,
            coverUrl: r['cover_url'] ?? null,
            coverKey: r['cover_key'] === '' ? null : r['cover_key'],
            tocUrl: r['toc_url'] ?? null,
            bookKind: r['book_kind'] ?? null,
            chapterUrl: r['chapter_url'] ?? null,
            chapterIndex: Number(r['chapter_index'] ?? 0),
            chapterTitle: r['chapter_title'] ?? null,
            updatedAt: Number(r['updated_at'] ?? 0),
            lastReadAt: Number(r['last_read_at'] ?? 0),
            readCount: Number(r['read_count'] ?? 1),
            inShelf: Number(r['in_shelf'] ?? 0) !== 0,
            completed: Number(r['completed'] ?? 0) !== 0,
            groupName: r['group_name'] === '' ? null : r['group_name'],
            sourceName: r['source_name'] === '' ? null : r['source_name'],
        }));
    }
    // ---------------- 书架 ----------------`,
    'listHistory 方法',
  );

  if (!CHECK) backup(DB);
  return { file: DB, changed: true, note: `${before} → ${s.length} 字符`, text: s };
}

function patchApp() {
  let s = fs.readFileSync(APP, 'utf8');
  if (s.includes("app.get('/api/history'")) return { file: APP, changed: false, note: '已有历史补丁，跳过' };
  const before = s.length;

  s = replaceOnce(
    s,
    `            chapterTitle: body.chapterTitle ?? null,
            positionMs: body.positionMs ?? null,
            bookKind: body.bookKind ?? null,
        };
        return db.saveProgress(progress);
    });`,
    `            chapterTitle: body.chapterTitle ?? null,
            positionMs: body.positionMs ?? null,
            bookKind: body.bookKind ?? null,
            bookName: body.bookName ?? null,
            bookAuthor: body.bookAuthor ?? null,
            coverUrl: body.coverUrl ?? null,
            tocUrl: body.tocUrl ?? null,
        };
        return db.saveProgress(progress);
    });
    app.get('/api/history', async (request, reply) => {
        const raw = Number(request.query.limit ?? 300);
        return db.listHistory(Number.isFinite(raw) ? raw : 300);
    });`,
    'PUT 进度透传元信息 + GET /api/history',
  );

  if (!CHECK) backup(APP);
  return { file: APP, changed: true, note: `${before} → ${s.length} 字符`, text: s };
}

function patchBundle() {
  let s = fs.readFileSync(BUNDLE, 'utf8');
  if (s.includes('function LrHist({items:hsItems')) return { file: BUNDLE, changed: false, note: '已有历史补丁，跳过' };
  const before = s.length;

  s = replaceOnce(
    s,
    `throw o}},addToBookshelf:o=>ve("/api/bookshelf",{method:"POST",body:JSON.stringify(o)}),`,
    `throw o}},history:o=>ve("/api/history?limit="+encodeURIComponent(o==null?300:o)),addToBookshelf:o=>ve("/api/bookshelf",{method:"POST",body:JSON.stringify(o)}),`,
    'API 客户端 history()',
  );

  s = replaceOnce(
    s,
    `body:JSON.stringify({sourceId:z,bookUrl:H.bookUrl,chapterUrl:"",chapterIndex:Number.isFinite(Q)?Q:0,scrollPosition:0})`,
    `body:JSON.stringify({sourceId:z,bookUrl:H.bookUrl,chapterUrl:"",chapterIndex:Number.isFinite(Q)?Q:0,scrollPosition:0,bookName:H.details&&H.details.name?H.details.name:void 0,bookAuthor:H.details&&H.details.author?H.details.author:void 0,coverUrl:H.details&&H.details.coverUrl?H.details.coverUrl:void 0,tocUrl:H.details&&H.details.tocUrl?H.details.tocUrl:void 0,bookKind:H.bookKind||(H.details&&H.details.bookKind)||void 0})`,
    '推送时带上书目元信息',
  );

  s = replaceOnce(
    s,
    `[se,ae]=m.useState(!1),Z=m.useCallback(`,
    `[se,ae]=m.useState(!1),[hsList,hsListSet]=m.useState([]),[hsBusy,hsBusySet]=m.useState(!1),[hsErr,hsErrSet]=m.useState(""),Z=m.useCallback(`,
    '书架组件：历史状态',
  );

  s = replaceOnce(
    s,
    `m.useEffect(()=>{Z()},[Z]);const xe=async G=>{`,
    `m.useEffect(()=>{Z()},[Z]);const hsLoad=m.useCallback(async()=>{hsBusySet(!0),hsErrSet("");try{const G=await V.history(),C=Array.isArray(G)?G:(G&&Array.isArray(G.items)?G.items:[]);hsListSet(C)}catch(G){hsErrSet(G instanceof Error?G.message:"无法载入阅读历史")}finally{hsBusySet(!1)}},[]);m.useEffect(()=>{h==="__history__"&&hsLoad()},[h,hsLoad]);const xe=async G=>{`,
    '书架组件：历史载入',
  );

  s = replaceOnce(
    s,
    `children:[l("search.scopeUngrouped","未分组"),t.jsx("small",{children:yt.ungrouped})]})`,
    `children:[l("search.scopeUngrouped","未分组"),t.jsx("small",{children:yt.ungrouped})]}),t.jsxs("button",{type:"button",className:h==="__history__"?"active":"",onClick:()=>b("__history__"),children:[l("shelf.tabHistory","历史"),t.jsx("small",{children:hsList.length})]})`,
    '历史 tab 按钮',
  );

  s = replaceOnce(
    s,
    `,i.length===0&&!y?t.jsxs("section",{className:"shelf-empty",children:[t.jsx(O,{name:"book"}),t.jsx("h2",{children:l("shelf.emptyTitle","书架还是空的")})`,
    `,h==="__history__"?t.jsx(LrHist,{items:hsList,busy:hsBusy,error:hsErr,onReload:hsLoad,onOpen:o,onSearch:()=>ae(!0)}):i.length===0&&!y?t.jsxs("section",{className:"shelf-empty",children:[t.jsx(O,{name:"book"}),t.jsx("h2",{children:l("shelf.emptyTitle","书架还是空的")})`,
    '历史渲染分支',
  );

  const HC = `function LrHist({items:hsItems,busy:hsB,error:hsE,onReload:hsR,onOpen:hsO,onSearch:hsS}){` +
    `const hsWhen=e=>{const d=Date.now()-Number(e||0);if(!Number.isFinite(d)||d<0)return"";const mi=Math.floor(d/6e4);if(mi<1)return"刚刚";if(mi<60)return mi+" 分钟前";const ho=Math.floor(mi/60);if(ho<24)return ho+" 小时前";const da=Math.floor(ho/24);if(da<30)return da+" 天前";const dt=new Date(Number(e));return dt.getFullYear()+"-"+String(dt.getMonth()+1).padStart(2,"0")+"-"+String(dt.getDate()).padStart(2,"0")};` +
    `const hsOpen=async e=>{if(!e.tocUrl){try{const d=await V.details(e.sourceId,e.bookUrl);hsO({sourceId:e.sourceId,bookUrl:e.bookUrl,name:e.name||d.name||"未命名书籍",author:e.author||d.author,tocUrl:d.tocUrl,coverUrl:e.coverUrl||d.coverUrl,bookKind:e.bookKind||d.bookKind,chapterIndex:e.chapterIndex,chapterTitle:e.chapterTitle});return}catch(d){Y.error(d instanceof Error?d.message:"这本书已无法打开");return}}hsO(e)};` +
    `if(hsB)return t.jsxs("section",{className:"shelf-history",children:[t.jsxs("div",{className:"shelf-history-tip",children:[t.jsx("span",{className:"source-login-spinner"}),t.jsx("span",{children:"正在载入阅读历史..."})]})]});` +
    `if(hsE)return t.jsxs("section",{className:"shelf-empty",children:[t.jsx(O,{name:"activity"}),t.jsx("h2",{children:"无法载入阅读历史"}),t.jsx("p",{children:hsE}),t.jsx("button",{type:"button",className:"shelf-import-btn",onClick:hsR,children:"重试"})]});` +
    `if(!hsItems||hsItems.length===0)return t.jsxs("section",{className:"shelf-empty",children:[t.jsx(O,{name:"clock"}),t.jsx("h2",{children:"还没有阅读记录"}),t.jsx("p",{children:"点开任何一本书开始阅读后，这里都会留下记录，没加入书架的书也能在这里找到。"}),t.jsx("button",{type:"button",className:"shelf-import-btn",onClick:hsS,children:"去搜索"})]});` +
    `return t.jsxs("section",{className:"shelf-history",children:[t.jsx("p",{className:"shelf-history-tip",children:"最近点开过的书，共 "+hsItems.length+" 本"}),t.jsx("div",{className:"shelf-history-list",children:hsItems.map(e=>t.jsxs("article",{className:"history-row",children:[` +
    `t.jsx("button",{type:"button",className:"history-cover",onClick:()=>void hsOpen(e),"aria-label":"继续阅读 "+(e.name||""),children:t.jsx(rr,{coverKey:e.coverKey,coverUrl:e.coverUrl,name:e.name,fallbackClassName:"cover-fallback"})}),` +
    `t.jsxs("div",{className:"history-meta",children:[t.jsxs("div",{className:"history-title-line",children:[t.jsx("strong",{children:e.name||"未命名书籍"}),e.inShelf?null:t.jsx("span",{className:"history-badge",children:"未入书架"})]}),t.jsx("small",{className:"history-chapter",children:e.chapterTitle||"尚未阅读正文"}),t.jsxs("small",{className:"history-sub",children:[e.sourceName||e.sourceId?String(e.sourceName||e.sourceId):"",e.sourceName||e.sourceId?" · ":"",hsWhen(e.updatedAt)]})]}),` +
    `t.jsx("button",{type:"button",className:"history-open-btn",onClick:()=>void hsOpen(e),children:"继续"})` +
    `]},e.sourceId+"|"+e.bookUrl))})]});}`;

  s = replaceOnce(s, `const JC=3e4;function YC({onOpen:o,theme:n}){`, `const JC=3e4;${HC}function YC({onOpen:o,theme:n}){`, '历史列表组件 HC');

  if (!CHECK) backup(BUNDLE);
  return { file: BUNDLE, changed: true, note: `${before} → ${s.length} 字符`, text: s };
}

function polishSubfilter() {
  let s = fs.readFileSync(BUNDLE, 'utf8');
  const done = 'h!=="__history__"&&t.jsx("div",{className:"shelf-subfilter-bar"';
  if (s.includes(done)) return { file: BUNDLE, changed: false, note: '状态筛选条已按历史 tab 隐藏，跳过' };
  const from = '}),t.jsx("div",{className:"shelf-subfilter-bar",children:';
  if (s.indexOf(from) < 0) throw new Error('找不到状态筛选条锚点');
  s = replaceOnce(s, from, '}),' + done + ',children:', '状态筛选条按 tab 隐藏');
  return { file: BUNDLE, changed: true, note: '历史 tab 下隐藏状态筛选条', text: s };
}

const results = [patchDatabase(), patchApp(), patchBundle()];
const polish = polishSubfilter();
results.push(polish);

for (const r of results) {
  console.log(`${r.changed ? '✓' : '·'} ${r.file}：${r.note}`);
}

if (!CHECK) {
  for (const r of results) {
    if (r.changed && r.text != null) fs.writeFileSync(r.file, r.text, 'utf8');
  }
  console.log('已写入。');
} else {
  console.log('（--check：只校验锚点，不写文件）');
}

if (!CHECK) {
  const bundle = fs.readFileSync(BUNDLE, 'utf8');
  const dbjs = fs.readFileSync(DB, 'utf8');
  const appjs = fs.readFileSync(APP, 'utf8');
  const checks = [
    ['产物含 history API 方法', bundle.includes('history:o=>ve("/api/history?limit="')],
    ['产物含历史 tab', bundle.includes('l("shelf.tabHistory","历史")')],
    ['产物含历史组件', bundle.includes('function LrHist({items:hsItems')],
    ['产物含历史分支', bundle.includes('h==="__history__"?t.jsx(LrHist,')],
    ['后端有 book_history DDL', dbjs.includes('create table if not exists book_history')],
    ['后端有 listHistory', dbjs.includes('listHistory(limit = 300)')],
    ['后端有 /api/history', appjs.includes("app.get('/api/history'")],
    ['后端进度透传书名', appjs.includes('bookName: body.bookName ?? null')],
    ['历史 tab 隐藏状态筛选条', bundle.includes('h!=="__history__"&&t.jsx("div",{className:"shelf-subfilter-bar"')],
  ];
  let ok = true;
  for (const [name, pass] of checks) {
    if (!pass) ok = false;
    console.log(`${pass ? '✓' : '✗'} ${name}`);
  }
  if (!ok) process.exitCode = 1;
}