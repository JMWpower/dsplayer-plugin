#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const ENTRY = path.join(root, 'web-dist', 'tvbox.html');
const RULE = path.join(root, '阅读书架[书].html');

function build() {
  const src = fs.readFileSync(ENTRY, 'utf8');
  if (!src.includes('<title>阅读</title>')) {
    throw new Error('web-dist/tvbox.html 里没找到 <title>阅读</title>（入口页被改过？）');
  }
  const out = src.replace('<title>阅读</title>', '<title>阅读书架</title>');
  if (!out.includes('lr_shell=1')) {
    throw new Error('入口页里没有 lr_shell=1：规则页必须带壳子标记跳进 Web 页面');
  }
  return out;
}

const wanted = build();
const checkOnly = process.argv.includes('--check');
const current = fs.existsSync(RULE) ? fs.readFileSync(RULE, 'utf8') : null;

if (checkOnly) {
  if (current == null) {
    console.error(`规则页不存在：${path.basename(RULE)}（跑 node tools/build-rule-page.mjs 生成）`);
    process.exit(1);
  }
  if (current !== wanted) {
    console.error(`规则页与入口页不同步：${path.basename(RULE)}（重跑 node tools/build-rule-page.mjs）`);
    process.exit(1);
  }
  console.log(`规则页已同步：${path.basename(RULE)}（${wanted.length} 字节）`);
  process.exit(0);
}

if (current === wanted) {
  console.log(`规则页已是最新：${path.basename(RULE)}（${wanted.length} 字节）`);
  process.exit(0);
}
fs.writeFileSync(RULE, wanted);
console.log(`写入 ${path.basename(RULE)}（${wanted.length} 字节）`);