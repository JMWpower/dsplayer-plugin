#!/usr/bin/env node

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const ENTRY = path.join(root, 'web-dist/tvbox.html');
const RULE = path.join(root, '阅读书架[书].html');
const DEFAULT_TARGET = 'http://127.0.0.1:8998/?lr_shell=1#shelf';

const results = [];
async function check(name, fn) {
  try {
    await fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

function entryScript() {
  const html = fs.readFileSync(ENTRY, 'utf8');
  const start = html.lastIndexOf('<script>');
  const end = html.lastIndexOf('</script>');
  assert.ok(start > 0 && end > start, '入口页里没找到内联脚本');
  return html.slice(start + '<script>'.length, end);
}

function makeEl() {
  const classes = new Set();
  return {
    textContent: '', value: '', disabled: false, listeners: {},
    classList: {
      add: (c) => classes.add(c),
      remove: (c) => classes.delete(c),
      contains: (c) => classes.has(c),
    },
    focus() {},
    addEventListener(type, fn) { (this.listeners[type] = this.listeners[type] || []).push(fn); },
    click() { (this.listeners.click || []).forEach((fn) => fn({ target: this })); },
  };
}

async function run(opts = {}) {
  const els = {};
  const doc = {
    getElementById: (id) => (els[id] = els[id] || makeEl()),
    addEventListener() {},
    createElement: () => makeEl(),
    body: { appendChild() {} },
    readyState: 'complete',
  };
  const store = new Map();
  if (opts.storedBase) store.set('lr.base', opts.storedBase);
  const out = { redirect: null, href: null, pinged: [] };
  const location = {
    search: opts.search || '',
    hash: '',
    protocol: opts.protocol || 'file:',
    origin: opts.protocol === 'file:' ? 'null' : 'http://127.0.0.1:8998',
    replace(url) { out.redirect = url; },
    get href() { return 'about:blank'; },
    set href(url) { out.href = url; },
  };
  const localStorage = {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => { store.set(k, String(v)); },
    removeItem: (k) => { store.delete(k); },
  };
  const win = { localStorage, fm: opts.fm, location };
  const fetchStub = async (url) => {
    out.pinged.push(String(url));
    if (opts.fetchOk === false) throw new Error('boom');
    return { ok: true, status: 200 };
  };
  const sandbox = {
    window: win,
    document: doc,
    location,
    localStorage,
    fetch: fetchStub,
    URLSearchParams,
    AbortController,
    setTimeout,
    clearTimeout,
    console,
  };
  vm.runInNewContext(entryScript(), sandbox, { filename: 'tvbox.html' });
  await new Promise((r) => setTimeout(r, 60));
  return { ...out, els, store };
}

await check('入口页：默认跳后端 Web 页面并带壳子标记', async () => {
  const r = await run();
  assert.equal(r.redirect, DEFAULT_TARGET);
  assert.ok(r.redirect.includes('lr_shell=1'), '必须带 lr_shell=1，否则 Web 页面不会接管阅读');
});

await check('入口页：?base= 最优先，并记住地址', async () => {
  const r = await run({ search: '?base=192.168.1.9:8998' });
  assert.equal(r.redirect, 'http://192.168.1.9:8998/?lr_shell=1#shelf');
  assert.equal(r.store.get('lr.base'), 'http://192.168.1.9:8998');
});

await check('入口页：记住的地址优先于默认 127.0.0.1', async () => {
  const r = await run({ storedBase: 'http://10.0.0.5:8998' });
  assert.equal(r.redirect, 'http://10.0.0.5:8998/?lr_shell=1#shelf');
});

await check('入口页：壳子里用 fm.req 探活（不受同源限制）', async () => {
  const asked = [];
  const fm = {
    req: async (url) => { asked.push(url); return { ok: true, status: 200 }; },
  };
  const r = await run({ fm, storedBase: 'http://192.168.1.20:8998' });
  assert.equal(r.redirect, 'http://192.168.1.20:8998/?lr_shell=1#shelf');
  assert.ok(asked.some((u) => u === 'http://192.168.1.20:8998/healthz'), '没探活：' + asked.join(','));
});

await check('入口页：连不上时给手填表单，不白屏', async () => {
  const r = await run({ fetchOk: false });
  assert.equal(r.redirect, null, '不该跳转');
  assert.equal(r.els.setup.classList.contains('hidden'), false, '表单没显示');
  assert.equal(r.els.booting.classList.contains('hidden'), true, '转圈没停');
  assert.ok(String(r.els.tip.textContent).includes('连不上'), '没有提示：' + r.els.tip.textContent);
  assert.equal(r.els.baseInput.value, 'http://127.0.0.1:8998', '输入框没带默认地址');
});

await check('入口页：?setup=1 直接给表单，不探测', async () => {
  const r = await run({ search: '?setup=1&base=http://192.168.1.30:8998' });
  assert.equal(r.redirect, null);
  assert.equal(r.pinged.length, 0, '不该探测');
  assert.equal(r.els.setup.classList.contains('hidden'), false);
  assert.equal(r.els.baseInput.value, 'http://192.168.1.30:8998');
});

await check('规则页：与入口页同源（生成物一致）', async () => {
  assert.ok(fs.existsSync(RULE), '规则页不存在，跑 node tools/build-rule-page.mjs');
  const rule = fs.readFileSync(RULE, 'utf8');
  const entry = fs.readFileSync(ENTRY, 'utf8');
  const expected = entry.replace('<title>阅读</title>', '<title>阅读书架</title>');
  assert.equal(rule, expected, '规则页跟入口页不同步，重跑 node tools/build-rule-page.mjs');
});

await check('规则页：只是一层入口，不再自带第二套八页界面', async () => {
  const rule = fs.readFileSync(RULE, 'utf8');
  assert.ok(rule.length < 20 * 1024, '规则页 ' + rule.length + ' 字节，又变成大页面了');
  assert.ok(rule.includes('lr_shell=1'), '规则页不带壳子标记');
  for (const dead of ['nav.tabs', 'pushIdx', 'pushChapter', '推送这一章']) {
    assert.ok(!rule.includes(dead), '规则页里还有旧的独立实现：' + dead);
  }
});

const failed = results.filter((r) => !r[1]);
for (const [name, ok, extra] of results) {
  console.log(`${ok ? '✓' : '✗'} ${name}${ok || !extra ? '' : '  —— ' + extra}`);
}
console.log(`\n${results.length - failed.length}/${results.length} 通过`);
process.exit(failed.length === 0 ? 0 : 1);