
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const pwModule = process.env.PLAYWRIGHT_MODULE || 'playwright';
let chromium = null;
try {
  ({ chromium } = require(pwModule));
} catch {
  console.log('跳过：没装 playwright');
  process.exit(0);
}

const ROOT = path.resolve(import.meta.dirname, '..');
const ENHANCE = fs.readFileSync(path.join(ROOT, 'web-dist/lr-enhance.js'), 'utf8');
const PORT = 8977;

const PAGE = `<!doctype html><html><head><meta charset="utf-8">
<style>
  body{margin:0;font:14px sans-serif}
  .explore-source-menu{position:absolute;top:40px;left:0;width:260px;background:#fff;border:1px solid #ccc}
  .explore-source-menu-list{display:flex;flex-direction:column;gap:4px;max-height:200px;overflow-y:auto}
  .explore-source-option{padding:10px;border:0;background:#f6f6f6;text-align:left}
  .explore-source-option.active{background:#ffe9c7;font-weight:700}
</style></head><body>
<div class="explore-source-dropdown">
  <button class="explore-source-trigger" aria-haspopup="listbox" aria-expanded="false">
    <span class="explore-source-trigger-name">当前源</span>
  </button>
</div>
<div id="host"></div>
<script>
  var open = false;
  var SELECTED = 29;             // 第 30 个是被选中的源
  var TOTAL = 60;
  var trigger = document.querySelector('.explore-source-trigger');
  function render() {
    var host = document.getElementById('host');
    if (!open) { host.innerHTML = ''; return; }
    var opts = '';
    for (var i = 0; i < TOTAL; i++) {
      opts += '<button type="button" role="option" aria-selected="' + (i === SELECTED) +
        '" class="explore-source-option' + (i === SELECTED ? ' active' : '') + '">书源 ' + (i + 1) + '</button>';
    }
    host.innerHTML = '<div class="explore-source-menu" role="listbox">' +
      '<div class="explore-source-menu-list">' + opts + '</div></div>';
  }
  // 模拟 React：点击后同步重渲染
  trigger.addEventListener('click', function () {
    open = !open;
    trigger.setAttribute('aria-expanded', String(open));
    render();
  });
</script>
<script src="/lr-enhance.js"></script>
</body></html>`;

const server = http.createServer((req, res) => {
  if (req.url === '/lr-enhance.js') {
    res.writeHead(200, { 'Content-Type': 'application/javascript' });
    return res.end(ENHANCE);
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(PAGE);
});
await new Promise((r) => server.listen(PORT, '127.0.0.1', r));

const LAUNCH = { args: ['--no-sandbox', '--disable-dev-shm-usage'] };
if (process.env.CHROMIUM_PATH) LAUNCH.executablePath = process.env.CHROMIUM_PATH;
const browser = await chromium.launch(LAUNCH);
const page = await browser.newPage({ viewport: { width: 420, height: 800 } });
await page.goto(`http://127.0.0.1:${PORT}/`, { waitUntil: 'load' });

const results = [];
const check = (name, ok, detail = '') => {
  results.push({ name, ok });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
};

await page.locator('.explore-source-trigger').click();
await page.waitForSelector('.explore-source-option.active');
await page.waitForTimeout(120);

const st = await page.evaluate(() => {
  const list = document.querySelector('.explore-source-menu-list');
  const active = document.querySelector('.explore-source-option.active');
  const lr = list.getBoundingClientRect();
  const ar = active.getBoundingClientRect();
  return {
    scrollTop: list.scrollTop,
    maxScroll: list.scrollHeight - list.clientHeight,
    offsetInView: ar.top - lr.top,
    listHeight: list.clientHeight,
    activeHeight: ar.height,
    visible: ar.top >= lr.top - 1 && ar.bottom <= lr.bottom + 1,
  };
});

check('列表确实滚动了', st.scrollTop > 0, `scrollTop=${Math.round(st.scrollTop)} / max=${Math.round(st.maxScroll)}`);
check('选中项在可视区内', st.visible === true);
const center = (st.listHeight - st.activeHeight) / 2;
check('选中项基本居中', Math.abs(st.offsetInView - center) < 12,
  `offset=${Math.round(st.offsetInView)} 期望≈${Math.round(center)}`);

await page.locator('.explore-source-trigger').click();
await page.waitForTimeout(60);
const closed = await page.locator('.explore-source-menu').count();
check('再次点击能关闭', closed === 0);
await page.locator('.explore-source-trigger').click();
await page.waitForTimeout(120);
const again = await page.evaluate(() => ({
  top: document.querySelector('.explore-source-menu-list').scrollTop,
  visible: (() => {
    const l = document.querySelector('.explore-source-menu-list').getBoundingClientRect();
    const a = document.querySelector('.explore-source-option.active').getBoundingClientRect();
    return a.top >= l.top - 1 && a.bottom <= l.bottom + 1;
  })(),
}));
check('重开后仍然定位', again.top > 0 && again.visible === true, `scrollTop=${Math.round(again.top)}`);

const pageScroll = await page.evaluate(() => window.scrollY);
check('页面未被带着滚走', pageScroll === 0, `scrollY=${pageScroll}`);

await browser.close();
server.close();

const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} 通过`);
process.exit(failed === 0 ? 0 : 1);
