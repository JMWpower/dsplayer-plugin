#!/usr/bin/env node

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const results = [];

function check(name, fn) {
  try {
    fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const exists = (rel) => fs.existsSync(path.join(root, rel));

function bundlePath() {
  const html = read('web-dist/index.html');
  const m = /<script[^>]+src="([^"]*\/assets\/index-[^"]+\.js)"/.exec(html);
  assert.ok(m, 'index.html 里找不到入口 bundle');
  return path.join('web-dist', m[1].replace(/^\//, ''));
}

function distFiles() {
  const out = [];
  for (const dir of ['dist', 'dist/routes']) {
    for (const f of fs.readdirSync(path.join(root, dir))) {
      if (f.endsWith('.js')) out.push(path.join(dir, f));
    }
  }
  return out;
}

check('后端：三个阅读/朗读模块已删除', () => {
  for (const f of ['dist/routes/tts.js', 'dist/routes/bookmarks.js', 'dist/edgeTts.js']) {
    assert.ok(!exists(f), f + ' 应该已经删掉');
  }
});

check('后端：代码里不再有朗读 / 书签的落点', () => {
  const needles = ['registerTtsRoutes', 'registerBookmarkRoutes', 'EdgeTtsService',
    'listHttpTts', 'saveHttpTts', 'saveBookmark', 'listBookmarks', 'listAllBookmarks',
    'http_tts', 'bookmark'];
  for (const file of distFiles()) {
    const code = read(file);
    for (const needle of needles) {
      assert.ok(!code.includes(needle), `${file} 里还有 ${needle}`);
    }
  }
});

check('后端：备份不再写书签与朗读引擎', () => {
  const code = read('dist/backup.js');
  for (const needle of ['bookmark.json', 'httpTTS.json', 'bookmarks:']) {
    assert.ok(!code.includes(needle), 'backup.js 里还有 ' + needle);
  }
});

check('后端：在线导入只剩书源 / RSS 源', () => {
  const code = read('dist/onlineImport.js');
  assert.ok(!code.includes("'httpTts'"), 'onlineImport 不该再认 httpTts');
  assert.ok(!code.includes('saveHttpTts'), 'onlineImport 不该再落库朗读引擎');
  assert.ok(code.includes("'bookSource'") && code.includes("'rssSource'"));
});

check('后端：dist 全量语法可解析', () => {
  for (const file of distFiles()) {
    const r = spawnSync(process.execPath, ['--check', path.join(root, file)], { encoding: 'utf8' });
    assert.equal(r.status, 0, `${file} 语法错误：${(r.stderr || '').split('\n')[0]}`);
  }
});

check('后端：阅读进度保留（书架「继续阅读」还要用）', () => {
  const app = read('dist/app.js');
  assert.ok(app.includes('/api/reading-progress'), 'reading-progress 被误删');
  const db = read('dist/database.js');
  assert.ok(db.includes('saveProgress') && db.includes('getProgress'));
});

check('后端：TVBox 取正文的两个接口还在', () => {
  const code = read('dist/routes/books.js');
  assert.ok(code.includes('/api/books/chapters') && code.includes('/api/books/content'));
});

check('前端：阅读器 / 朗读 / 书签代码已全部消失', () => {
  const code = read(bundlePath());
  const banned = [
    ['#reader', '阅读器路由'],
    ['legado-open-book-v1', '阅读器交接键'],
    ['header.bookmarks', '书签导航'],
    ['/api/tts/', 'TTS 接口'],
    ['/api/http-tts', 'HTTP TTS 接口'],
    ['/api/bookmarks', '书签接口'],
    ['function hS({', '正文阅读器'],
    ['function yS({', '漫画阅读器'],
    ['function AS({', '有声阅读器'],
    ['function oC({', '书签页'],
    ['jsx(dS,{', '阅读设置抽屉'],
    ['tts-settings-dialog', 'TTS 设置弹窗'],
    ['speechSynthesis', '浏览器语音合成'],
  ];
  for (const [needle, why] of banned) {
    assert.ok(!code.includes(needle), `产物里还有${why}（${needle}）`);
  }
});

check('前端：导航文案「书库」改成「搜索」', () => {
  const code = read(bundlePath());
  assert.ok(code.includes('library:"搜索"'), '导航文案没改成搜索');
  assert.ok(!code.includes('library:"书库"'), '旧的「书库」文案还在');
  assert.ok(code.includes('header.library'), '导航键名被误删');
});

check('前端：点书改成派发推送事件', () => {
  const code = read(bundlePath());
  assert.ok(code.includes('lr-push-book'), '没有推送事件');
  assert.ok(code.includes('new CustomEvent'), '没有用 CustomEvent 派发');
});

check('前端：书架标题行右侧放了导入按钮', () => {
  const code = read(bundlePath());
  assert.ok(code.includes('shelf-title-row'), '没有 shelf-title-row 容器');
  const i = code.indexOf('shelf-title-row');
  const seg = code.slice(i, i + 900);
  assert.ok(seg.includes('shelf-import-btn'), '标题行里没有导入按钮');
});

check('前端：发现页卡片宽度修复的样式在', () => {
  const css = read('web-dist/assets/index-hiHoGuoh.css');
  assert.ok(css.includes('minmax(min(290px,100%),1fr)'), '卡片轨道没有做 min() 收敛');
  assert.ok(css.includes('.explore-book-card{min-width:0;overflow:hidden}'), '卡片没有禁溢出');
  assert.ok(css.includes('.shelf-title-row{'), '书架标题行样式缺失');
});

check('壳子桥：改成监听推送事件', () => {
  const bridge = read('web-dist/lr-tvbox.js');
  assert.ok(bridge.includes('lr-push-book'), '桥没有监听推送事件');
  assert.ok(!bridge.includes('#reader'), '桥还在操作阅读器路由');
  assert.ok(!bridge.includes('legado-open-book-v1'), '桥还在用 sessionStorage 交接');
});

let failed = 0;
for (const [name, ok, detail] of results) {
  console.log(`${ok ? '✓' : '✗'} ${name}${ok ? '' : ' —— ' + detail}`);
  if (!ok) failed++;
}
console.log(`\n${results.length - failed}/${results.length} 通过`);
process.exit(failed === 0 ? 0 : 1);