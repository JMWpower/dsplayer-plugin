#!/usr/bin/env node

import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const results = [];

async function check(name, fn) {
  try {
    await fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

function html(body) {
  return `<!doctype html><html><body>${body}</body></html>`;
}

function bookItems(selector, items) {
  return items.map((it) => `<div class="${selector}">
    <a href="${it.url}"><h3>${it.name}</h3></a>
    <span class="author">${it.author}</span>
    <span class="intro">${it.intro}</span>
  </div>`).join('');
}

function tocItems(n) {
  return Array.from({ length: n }, (_v, i) => `<li class="chapter"><a href="/ch/${i + 1}">第${i + 1}章</a></li>`).join('');
}

function startUpstream() {
  const hits = new Map();
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');
    const route = url.pathname;
    hits.set(route, (hits.get(route) || 0) + 1);
    const send = (body, type = 'text/html; charset=utf-8') => {
      res.writeHead(200, { 'Content-Type': type });
      res.end(body);
    };
    if (route === '/explore') {
      return send(html(`<div class="list">${bookItems('book', [
        { name: '探索书一', author: '甲', intro: '简介一', url: '/book/1' },
        { name: '探索书二', author: '乙', intro: '简介二', url: '/book/2' },
      ])}</div>`));
    }
    if (route === '/search') {
      return send(html(`<div class="results">${bookItems('sbook', [
        { name: '搜索书', author: '丙', intro: '简介', url: '/book/1' },
      ])}</div>`));
    }
    if (route === '/book/1') {
      return send(html(`<h1>探索书一</h1><span class="author">甲</span><p class="intro">简介一</p>
        <a class="toc" href="/book/1/toc">目录</a>`));
    }
    if (route === '/book/1/toc') return send(html(`<ul>${tocItems(3)}</ul>`));
    if (route === '/book/2') return send(html('<h1>探索书二</h1>'));
    if (route === '/book/3') {

      return send(html(`<h1>书三</h1><ul>${tocItems(2)}</ul>`));
    }
    if (route === '/book/4') {
      return send(html(`<h1>书四</h1><a class="toc" href="/book/4/toc">目录</a>`));
    }
    if (route === '/book/4/toc') return send(html(`<ul>${tocItems(3)}</ul>`));
    if (route === '/book/5') return send(html('<h1>书五</h1><p>这个页面没有目录</p>'));
    if (route === '/book/5/toc') return send(html(`<ul>${tocItems(2)}</ul>`));
    if (route.startsWith('/ch/')) {
      const n = route.slice(4);
      const names = { 1: '一', 2: '二', 3: '三' };
      return send(html(`<div id="content"><p>正文${names[n] || n}</p></div>`));
    }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('not found');
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, port: server.address().port, hits });
    });
  });
}

function makeSources(base) {
  const common = {
    searchUrl: base + '/search?key={{key}}',
    ruleSearch: {
      bookList: '.sbook',
      name: 'h3@text',
      author: '.author@text',
      intro: '.intro@text',
      bookUrl: 'a@href',
    },
    ruleToc: { chapterList: 'li.chapter', chapterName: 'a@text', chapterUrl: 'a@href' },
    ruleContent: { content: '#content@html' },
    enabled: true,
  };
  const defs = [
    {
      suffix: 's1',
      name: '源一·裸地址分类',
      exploreUrl: '/explore',
      ruleExplore: { bookList: '.book', name: 'h3@text', author: '.author@text', intro: '.intro@text', bookUrl: 'a@href' },
      ruleBookInfo: { name: 'h1@text', author: '.author@text', intro: '.intro@text', tocUrl: 'a.toc@href' },
    },
    {
      suffix: 's2',
      name: '源二·ruleExplore 失效',
      exploreUrl: '/search?key=x',
      ruleExplore: { bookList: '.nothing-here', name: 'h3@text', bookUrl: 'a@href' },
      ruleBookInfo: { name: 'h1@text', tocUrl: 'a.toc@href' },
    },
    {
      suffix: 's3',
      name: '源三·没有详情规则',
      exploreUrl: '/explore',
      ruleExplore: { bookList: '.book', name: 'h3@text', bookUrl: 'a@href' },

    },
    {
      suffix: 's4',
      name: '源四·独立目录页',
      exploreUrl: '/explore',
      ruleExplore: { bookList: '.book', name: 'h3@text', bookUrl: 'a@href' },
      ruleBookInfo: { name: 'h1@text', tocUrl: 'a.toc@href' },
    },
    {
      suffix: 's5',
      name: '源五·只有 /toc 有目录',
      exploreUrl: '/explore',
      ruleExplore: { bookList: '.book', name: 'h3@text', bookUrl: 'a@href' },
      ruleBookInfo: { name: 'h1@text' },
    },
  ];
  return defs.map((def) => JSON.stringify({
    ...common,
    bookSourceName: def.name,

    bookSourceUrl: base + '/' + def.suffix,
    bookSourceGroup: '测试',
    exploreUrl: def.exploreUrl,
    ruleExplore: def.ruleExplore,
    ...(def.ruleBookInfo ? { ruleBookInfo: def.ruleBookInfo } : {}),
  }));
}

async function freePort() {
  return await new Promise((resolve) => {
    const s = http.createServer();
    s.listen(0, '127.0.0.1', () => {
      const port = s.address().port;
      s.close(() => resolve(port));
    });
  });
}

async function waitHealth(port, timeoutMs = 25000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/healthz`);
      if (res.ok) return true;
    } catch (e) {  }
    await new Promise((r) => setTimeout(r, 200));
  }
  return false;
}

async function api(port, method, pathname, body) {
  const res = await fetch(`http://127.0.0.1:${port}${pathname}`, {
    method,
    headers: body == null ? undefined : { 'Content-Type': 'application/json' },
    body: body == null ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = text;
  try { parsed = JSON.parse(text); } catch (e) {  }
  return { status: res.status, body: parsed };
}

const upstream = await startUpstream();
const base = `http://127.0.0.1:${upstream.port}`;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'legado-explore-'));
const port = await freePort();

const child = spawn(process.execPath, [path.join(root, 'dist/index.js')], {
  cwd: root,
  env: {
    ...process.env,
    LEGADO_DATA_DIR: tmp,
    LEGADO_HOST: '127.0.0.1',
    LEGADO_PORT: String(port),

    LEGADO_ALLOW_LOCAL_TARGETS: '1',
  },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let logs = '';
child.stdout.on('data', (d) => { logs += String(d); });
child.stderr.on('data', (d) => { logs += String(d); });

let exitCode = 1;
try {
  const up = await waitHealth(port);
  if (!up) throw new Error('后端没起来：\n' + logs);

  const imported = await api(port, 'POST', '/api/sources/import', { sources: makeSources(base) });
  assert.equal(imported.status, 200, '导入书源失败：' + JSON.stringify(imported.body));
  assert.equal(imported.body.skipped, 0, '有书源被跳过：' + JSON.stringify(imported.body.errors));

  const idOf = (suffix) => base + '/' + suffix;

  await check('发现页：exploreUrl 是裸地址时当成唯一分类', async () => {
    const cats = await api(port, 'GET', `/api/explore/categories?id=${encodeURIComponent(idOf('s1'))}`);
    assert.equal(cats.status, 200, JSON.stringify(cats.body));
    const list = Array.isArray(cats.body) ? cats.body : [];
    assert.equal(list.length, 1, '应该只有一个分类：' + JSON.stringify(list));
    assert.equal(list[0].url, '/explore');
    const books = await api(port, 'GET', `/api/explore/books?id=${encodeURIComponent(idOf('s1'))}&url=${encodeURIComponent(list[0].url)}&page=1`);
    assert.equal(books.status, 200, JSON.stringify(books.body));
    assert.equal(books.body.length, 2, '分类下应该出 2 本书');
    assert.equal(books.body[0].name, '探索书一');
    assert.equal(books.body[0].sourceId, idOf('s1'), '书籍必须记住是哪个源');
  });

  await check('发现页：ruleExplore 解析不出书时按 ruleSearch 兜底', async () => {
    const books = await api(port, 'GET', `/api/explore/books?id=${encodeURIComponent(idOf('s2'))}&url=${encodeURIComponent('/search?key=x')}&page=1`);
    assert.equal(books.status, 200, JSON.stringify(books.body));
    assert.equal(books.body.length, 1, '应回落到 ruleSearch 解析出 1 本：' + JSON.stringify(books.body));
    assert.equal(books.body[0].name, '搜索书');
  });

  await check('目录：没有 ruleBookInfo 也能从书页解析出目录', async () => {
    const chapters = await api(port, 'POST', '/api/books/chapters', {
      sourceId: idOf('s3'), bookUrl: base + '/book/3',
    });
    assert.equal(chapters.status, 200, JSON.stringify(chapters.body));
    assert.equal(chapters.body.length, 2, '应解析出 2 章：' + JSON.stringify(chapters.body));
    assert.equal(chapters.body[0].title, '第1章');
  });

  await check('目录：按详情给的 tocUrl 取，并且第二次命中缓存', async () => {
    const before = upstream.hits.get('/book/4/toc') || 0;
    const first = await api(port, 'POST', '/api/books/chapters', {
      sourceId: idOf('s4'), bookUrl: base + '/book/4',
    });
    assert.equal(first.status, 200, JSON.stringify(first.body));
    assert.equal(first.body.length, 3);
    assert.equal((upstream.hits.get('/book/4/toc') || 0) - before, 1, '第一次应该打一次目录页');

    const second = await api(port, 'POST', '/api/books/chapters', {
      sourceId: idOf('s4'), bookUrl: base + '/book/4',
    });
    assert.equal(second.status, 200);
    assert.equal(second.body.length, 3);
    assert.equal((upstream.hits.get('/book/4/toc') || 0) - before, 1, '第二次不该再打上游（缓存没命中）');
  });

  await check('目录：书页没目录时自动试 /toc 变体', async () => {
    const chapters = await api(port, 'POST', '/api/books/chapters', {
      sourceId: idOf('s5'), bookUrl: base + '/book/5',
    });
    assert.equal(chapters.status, 200, JSON.stringify(chapters.body));
    assert.equal(chapters.body.length, 2, '应通过 /book/5/toc 拿到 2 章：' + JSON.stringify(chapters.body));
  });

  await check('正文：目录里的章节地址能取到正文', async () => {
    const chapters = await api(port, 'POST', '/api/books/chapters', {
      sourceId: idOf('s1'), bookUrl: base + '/book/1',
    });
    assert.equal(chapters.status, 200, JSON.stringify(chapters.body));
    const chapterUrl = chapters.body[0].url;
    const content = await api(port, 'POST', '/api/books/content', {
      sourceId: idOf('s1'), bookUrl: base + '/book/1', chapterUrl,
    });
    assert.equal(content.status, 200, JSON.stringify(content.body));
    assert.ok(String(content.body.content).includes('正文一'), '正文不对：' + JSON.stringify(content.body));
  });

  await check('目录：手机端书架入口（按书页地址查）与 tvbox 入口一致', async () => {
    const viaApi = await api(port, 'POST', '/api/books/chapters', {
      sourceId: idOf('s4'), bookUrl: base + '/book/4',
    });
    const viaTvbox = await api(port, 'GET', `/api.php/provide/vod/?ac=detail&ids=${encodeURIComponent(Buffer.from(JSON.stringify({ s: idOf('s4'), b: base + '/book/4' }), 'utf8').toString('base64url'))}`);
    assert.equal(viaTvbox.status, 200);
    const item = (viaTvbox.body.list || [])[0];
    assert.ok(item, 'tvbox detail 应有结果：' + JSON.stringify(viaTvbox.body));
    assert.equal(item.vod_play_url.split('#').length, viaApi.body.length);
  });
} catch (e) {
  results.push(['准备阶段', false, e.message]);
} finally {
  child.kill('SIGTERM');
  await new Promise((r) => setTimeout(r, 300));
  upstream.server.close();
  try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {  }
}

let failed = 0;
for (const [name, ok, detail] of results) {
  console.log(`${ok ? '✓' : '✗'} ${name}${ok ? '' : ' —— ' + detail}`);
  if (!ok) failed++;
}
console.log(`\n${results.length - failed}/${results.length} 通过`);
if (failed > 0 && logs) console.log('\n--- 后端日志 ---\n' + logs.slice(-2000));
exitCode = failed === 0 ? 0 : 1;
process.exit(exitCode);