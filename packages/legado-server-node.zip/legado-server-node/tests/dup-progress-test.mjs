#!/usr/bin/env node

import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const results = [];

async function check(name, fn) {
  try {
    await fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

async function freePort() {
  return await new Promise((resolve) => {
    const s = http.createServer();
    s.listen(0, '127.0.0.1', () => {
      const port = s.address().port;
      s.close(() => resolve(port));
    });
  });
}

async function waitHealth(port, timeoutMs = 25000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/healthz`);
      if (res.ok) return true;
    } catch {  }
    await new Promise((r) => setTimeout(r, 200));
  }
  return false;
}

function makeApi(port) {
  return async function api(method, pathname, body) {
    const res = await fetch(`http://127.0.0.1:${port}${pathname}`, {
      method,
      headers: body == null ? undefined : { 'Content-Type': 'application/json' },
      body: body == null ? undefined : JSON.stringify(body),
    });
    const text = await res.text();
    let parsed = text;
    try { parsed = JSON.parse(text); } catch {  }
    return { status: res.status, body: parsed };
  };
}

async function startServer(dataDir) {
  const port = await freePort();
  const child = spawn(process.execPath, [path.join(root, 'dist/index.js')], {
    cwd: root,
    env: { ...process.env, LEGADO_DATA_DIR: dataDir, LEGADO_HOST: '127.0.0.1', LEGADO_PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const logs = { text: '' };
  child.stdout.on('data', (d) => { logs.text += String(d); });
  child.stderr.on('data', (d) => { logs.text += String(d); });
  const up = await waitHealth(port);
  return { port, child, logs, up, api: makeApi(port) };
}

const BOOK = [
  '第一章 起点',
  '正文一',
  '第二章 承上',
  '正文二',
  '第三章 转合',
  '正文三',
].join('\n');

async function importTxt(port, filename, text) {
  const form = new FormData();
  form.append('file', new Blob([Buffer.from(text, 'utf8')], { type: 'text/plain' }), filename);
  const res = await fetch(`http://127.0.0.1:${port}/api/bookshelf/import-local`, { method: 'POST', body: form });
  const body = await res.json();
  return { status: res.status, body };
}

const tmpFresh = fs.mkdtempSync(path.join(os.tmpdir(), 'legado-dup-'));
const fresh = await startServer(tmpFresh);
let exitCode = 1;
try {
  if (!fresh.up) throw new Error('后端没起来：\n' + fresh.logs.text);

  await check('同一本 TXT 导入两次只留一条书架记录', async () => {
    const first = await importTxt(fresh.port, '重复测试书.txt', BOOK);
    assert.equal(first.body.imported, 1, JSON.stringify(first.body));
    const firstUrl = first.body.results[0].bookUrl;
    const shelfA = await fresh.api('GET', '/api/bookshelf');
    assert.equal(shelfA.body.length, 1, '第一次导入后书架不是 1 本');

    const second = await importTxt(fresh.port, '重复测试书.txt', BOOK);
    assert.equal(second.body.imported, 1, JSON.stringify(second.body));
    assert.equal(second.body.results[0].bookUrl, firstUrl, '第二次导入生成了新的 local:// 地址');

    const shelfB = await fresh.api('GET', '/api/bookshelf');
    assert.equal(shelfB.body.length, 1, '重复导入后书架出现了重复书');
  });

  await check('不同文件名的书不会被误合并', async () => {
    const other = await importTxt(fresh.port, '另一本书.txt', BOOK);
    assert.equal(other.body.imported, 1, JSON.stringify(other.body));
    const shelf = await fresh.api('GET', '/api/bookshelf');
    assert.equal(shelf.body.length, 2, '不同书名被合并了');
  });

  await check('取第 3 章正文后进度落在第 3 章（本地书 /api/books/content）', async () => {
    const shelf = await fresh.api('GET', '/api/bookshelf');
    const book = shelf.body.find((b) => b.name === '重复测试书');
    assert.ok(book, '书不在书架里');
    const chapters = await fresh.api('POST', '/api/books/chapters', { sourceId: 'loc_book', bookUrl: book.bookUrl });
    assert.equal(chapters.body.length, 3, '章节数不是 3');
    const third = chapters.body[2];
    const content = await fresh.api('POST', '/api/books/content', {
      sourceId: 'loc_book', bookUrl: book.bookUrl, chapterUrl: third.url,
    });
    assert.equal(content.status, 200, JSON.stringify(content.body));
    const progress = await fresh.api('GET', `/api/reading-progress?sourceId=loc_book&bookUrl=${encodeURIComponent(book.bookUrl)}`);
    assert.equal(progress.status, 200, '没有写入阅读进度');
    assert.equal(progress.body.chapterIndex, 2, '进度没跟着正文走到第 3 章');
    assert.equal(progress.body.chapterUrl, third.url);
    assert.match(String(progress.body.chapterTitle), /第三章/);
  });

  await check('壳子取正文那条路（/api/tvbox/novel）也会写进度', async () => {
    const shelf = await fresh.api('GET', '/api/tvbox/vod?t=shelf_local');
    const item = (shelf.body.list || []).find((x) => x.vod_name === '重复测试书');
    assert.ok(item, '壳子列表里没有这本书');
    const detail = await fresh.api('GET', `/api.php/provide/vod/?ac=detail&ids=${encodeURIComponent(item.vod_id)}`);
    const vod = (detail.body.list || [])[0];
    assert.ok(vod && vod.vod_play_url, '详情没有播放地址');
    const episodes = String(vod.vod_play_url).split('#');
    assert.ok(episodes.length >= 2, '播放地址少于 2 集');
    const token = episodes[1].split('$')[1];
    assert.ok(token, '取不到第 2 集的 token');
    const novel = await fresh.api('GET', `/novel?f=${encodeURIComponent(token)}`);
    assert.equal(novel.body.code, 0, JSON.stringify(novel.body).slice(0, 200));
    assert.ok(String(novel.body.content).length > 0, '正文为空');

    const shelfNow = await fresh.api('GET', '/api/bookshelf');
    const book = shelfNow.body.find((b) => b.name === '重复测试书');
    const progress = await fresh.api('GET', `/api/reading-progress?sourceId=loc_book&bookUrl=${encodeURIComponent(book.bookUrl)}`);
    assert.equal(progress.status, 200);
    assert.equal(progress.body.chapterIndex, 1, '壳子翻章后进度没更新');
  });

  await check('同一章重复取正文不会把滚动位置清零', async () => {
    const shelf = await fresh.api('GET', '/api/bookshelf');
    const book = shelf.body.find((b) => b.name === '重复测试书');
    const chapters = await fresh.api('POST', '/api/books/chapters', { sourceId: 'loc_book', bookUrl: book.bookUrl });
    const second = chapters.body[1];
    await fresh.api('PUT', '/api/reading-progress', {
      sourceId: 'loc_book', bookUrl: book.bookUrl, chapterUrl: second.url, chapterIndex: 1, scrollPosition: 0.6,
    });
    await fresh.api('POST', '/api/books/content', { sourceId: 'loc_book', bookUrl: book.bookUrl, chapterUrl: second.url });
    const progress = await fresh.api('GET', `/api/reading-progress?sourceId=loc_book&bookUrl=${encodeURIComponent(book.bookUrl)}`);
    assert.equal(progress.body.chapterIndex, 1);
    assert.ok(Math.abs(Number(progress.body.scrollPosition) - 0.6) < 0.001, '同一章的滚动位置被清掉了');
  });

  exitCode = 0;
} catch (e) {
  console.log('\n运行失败：' + (e instanceof Error ? e.message : String(e)));
  console.log(fresh.logs.text.slice(-800));
} finally {
  fresh.child.kill('SIGTERM');
  fs.rmSync(tmpFresh, { recursive: true, force: true });
}

const tmpDup = fs.mkdtempSync(path.join(os.tmpdir(), 'legado-dup-old-'));
{
  const probe = await startServer(tmpDup);
  try {
    if (probe.up) {
      await importTxt(probe.port, '老重复书.txt', BOOK);
      await importTxt(probe.port, '老重复书.txt', BOOK);
    }
  } finally {
    probe.child.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 500));
  }

  const Database = (await import('better-sqlite3')).default;
  const dbFile = ['legado.sqlite', 'legado.db']
    .map((n) => path.join(tmpDup, n))
    .find((p) => fs.existsSync(p));
  const db = new Database(dbFile);
  const row = db.prepare("select book_url from book_shelf where name = '老重复书' limit 1").get();
  db.prepare("insert or replace into book_shelf(source_id, book_url, name, author, toc_url, last_read_at, completed, group_name, book_kind) values ('loc_book', 'local://dup-old-1', '老重复书', null, 'local://dup-old-1', 1, 0, null, 'local')").run();
  db.prepare("insert or replace into book_cache_status(source_id, book_url, total_chapters, cached_chapters, state, updated_at) values ('loc_book', 'local://dup-old-1', 3, 3, 'idle', 1)").run();
  db.prepare("insert or replace into book_cache_status(source_id, book_url, total_chapters, cached_chapters, state, updated_at) values ('loc_book', ?, 3, 3, 'idle', 1)").run(row.book_url);
  const before = db.prepare("select count(*) c from book_shelf where name = '老重复书'").get().c;
  db.close();

  const again = await startServer(tmpDup);
  try {
    await check('启动时清掉旧的重复本地书', async () => {
      assert.ok(before >= 2, '构造的重复数据不对：' + before);
      const shelf = await again.api('GET', '/api/bookshelf');
      const same = shelf.body.filter((b) => b.name === '老重复书');
      assert.equal(same.length, 1, `清理后仍剩 ${same.length} 条重复`);
      assert.match(again.logs.text, /已清理 \d+ 条重复的本地书/, '启动日志里没有清理记录');
    });
  } finally {
    again.child.kill('SIGTERM');
    fs.rmSync(tmpDup, { recursive: true, force: true });
  }
}

let failed = 0;
for (const [name, pass, msg] of results) {
  if (pass) console.log(`✓ ${name}`);
  else {
    failed++;
    console.log(`✗ ${name}\n    ${msg}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} 通过`);
process.exitCode = failed === 0 ? exitCode : 1;