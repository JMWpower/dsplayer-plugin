#!/usr/bin/env node

import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const bridgePath = path.join(root, 'web-dist/lr-tvbox.js');
const results = [];

async function check(name, fn) {
  try {
    await fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

const JPEG = Buffer.from([
  0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
  0x00, 0x01, 0x00, 0x00, 0xff, 0xd9,
]);

function startUpstream() {
  const seen = [];
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');
    const route = url.pathname;
    seen.push({ route, referer: req.headers.referer || '' });
    const send = (body, type = 'text/html; charset=utf-8') => {
      res.writeHead(200, { 'Content-Type': type });
      res.end(body);
    };
    if (route === '/book/1') {
      return send(`<!doctype html><html><body>
        <h1>测试漫画</h1>
        <div class="chapter_list">
          <a href="/ch/3">第03话</a>
          <a href="/ch/2">第02话</a>
          <a href="/ch/1">第01话</a>
        </div></body></html>`);
    }
    if (route.startsWith('/ch/')) {
      const n = route.slice(4);
      return send(`<!doctype html><html><body>
        <h1>第${n}话</h1>
        <div class="blog__details__content">
          <img src="http://127.0.0.1:${server.address().port}/img/${n}-1.jpg" alt="">
          <img src="http://127.0.0.1:${server.address().port}/img/${n}-2.jpg" alt="">
        </div></body></html>`);
    }
    if (route.startsWith('/img/')) {
      if (!req.headers.referer) {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('hotlink denied');
      }
      res.writeHead(200, { 'Content-Type': 'image/jpeg' });
      return res.end(JPEG);
    }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('not found');
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve({ server, port: server.address().port, seen }));
  });
}

function makeSource(base) {
  return JSON.stringify({
    bookSourceName: '测试漫画源',
    bookSourceUrl: base,
    bookSourceType: '2',
    enabled: true,
    enabledExplore: true,
    exploreUrl: '/book/1',
    ruleExplore: { bookList: 'h1', name: 'h1@text', bookUrl: '@href' },
    ruleBookInfo: { name: 'h1@text', tocUrl: '' },
    ruleToc: { chapterList: '-class.chapter_list@tag.a', chapterName: '@text', chapterUrl: '@href' },
    ruleContent: { content: 'class.blog__details__content@tag.img@html', imageStyle: 'FULL' },
  });
}

async function freePort() {
  return await new Promise((resolve) => {
    const s = http.createServer();
    s.listen(0, '127.0.0.1', () => {
      const port = s.address().port;
      s.close(() => resolve(port));
    });
  });
}

async function waitHealth(port, timeoutMs = 25000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/healthz`);
      if (res.ok)
        return true;
    }
    catch (e) {  }
    await new Promise((r) => setTimeout(r, 200));
  }
  return false;
}

async function api(port, method, pathname, body) {
  const res = await fetch(`http://127.0.0.1:${port}${pathname}`, {
    method,
    headers: body == null ? undefined : { 'Content-Type': 'application/json' },
    body: body == null ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = text;
  try { parsed = JSON.parse(text); } catch (e) {  }
  return { status: res.status, body: parsed };
}

function loadBridge(port, pushes) {
  const code = fs.readFileSync(bridgePath, 'utf8');
  const listeners = {};
  const store = new Map();
  const origin = `http://127.0.0.1:${port}`;
  const window = {
    location: { origin, protocol: 'http:', search: '?lr_shell=1', pathname: '/', href: origin + '/?lr_shell=1', hash: '' },
    localStorage: {
      getItem: (k) => (store.has(k) ? store.get(k) : null),
      setItem: (k, v) => store.set(k, String(v)),
      removeItem: (k) => store.delete(k),
    },
    addEventListener: (type, fn) => {
      (listeners[type] = listeners[type] || []).push(fn);
    },
    removeEventListener: () => { },
    fm: {
      vodInline: async (spec) => { pushes.push(spec); return { ok: true }; },
    },
    parent: null,
  };
  window.parent = window;
  const sandbox = {
    window,
    document: {
      addEventListener: () => { },
      visibilityState: 'visible',
    },
    console,
    fetch,
    URL,
    URLSearchParams,
    TextDecoder,
    TextEncoder,
    AbortController,
    setTimeout,
    clearTimeout,
    queueMicrotask,
    navigator: { userAgent: 'node' },
    location: window.location,
    localStorage: window.localStorage,
    atob: (s) => Buffer.from(s, 'base64').toString('binary'),
    btoa: (s) => Buffer.from(s, 'binary').toString('base64'),
  };
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: 'lr-tvbox.js' });
  const emit = (type, detail) => {
    for (const fn of listeners[type] || []) fn({ detail });
  };
  return { sandbox, window, emit, store };
}

const upstream = await startUpstream();
const base = `http://127.0.0.1:${upstream.port}`;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'legado-comic-'));
const port = await freePort();

const child = spawn(process.execPath, [path.join(root, 'dist/index.js')], {
  cwd: root,
  env: {
    ...process.env,
    LEGADO_DATA_DIR: tmp,
    LEGADO_HOST: '127.0.0.1',
    LEGADO_PORT: String(port),
    LEGADO_ALLOW_LOCAL_TARGETS: '1',
  },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let logs = '';
child.stdout.on('data', (d) => { logs += String(d); });
child.stderr.on('data', (d) => { logs += String(d); });

let exitCode = 1;
try {
  const up = await waitHealth(port);
  if (!up)
    throw new Error('后端没起来：\n' + logs);

  const imported = await api(port, 'POST', '/api/sources/import', { sources: [makeSource(base)] });
  assert.equal(imported.status, 200, JSON.stringify(imported.body));
  const sourceId = base;

  const details = await api(port, 'POST', '/api/books/details', { sourceId, bookUrl: base + '/book/1' });
  assert.equal(details.status, 200, JSON.stringify(details.body));

  const chapters = await api(port, 'POST', '/api/books/chapters', { sourceId, bookUrl: base + '/book/1' });
  const list = Array.isArray(chapters.body) ? chapters.body : [];

  await check('目录：前导 - 的列表规则按正序返回', async () => {
    assert.equal(list.length, 3, '应该解析出 3 话：' + JSON.stringify(chapters.body));
    assert.deepEqual(list.map((c) => c.title), ['第01话', '第02话', '第03话'], '章节顺序不对：' + JSON.stringify(list.map((c) => c.title)));
  });

  await check('正文：漫画章节解析出图片标签', async () => {
    const content = await api(port, 'POST', '/api/books/content', { sourceId, bookUrl: base + '/book/1', chapterUrl: list[0].url });
    assert.equal(content.status, 200, JSON.stringify(content.body));
    const html = String(content.body.content || '');
    const imgs = [...html.matchAll(/<img[^>]+src="([^"]+)"/g)].map((m) => m[1]);
    assert.equal(imgs.length, 2, '应解析出 2 张图：' + html.slice(0, 120));
  });

  await check('图片：直连防盗链地址被拒（说明必须走代理）', async () => {
    const raw = await fetch(`${base}/img/1-1.jpg`);
    assert.equal(raw.status, 403, '直连应该 403，实际 ' + raw.status);
  });

  await check('图片：代理补上 Referer 后能取到', async () => {
    const proxied = await fetch(`http://127.0.0.1:${port}/api/comic/image?sourceId=${encodeURIComponent(sourceId)}&url=${encodeURIComponent(base + '/img/1-1.jpg')}`);
    assert.equal(proxied.status, 200, '代理应 200，实际 ' + proxied.status);
    assert.match(String(proxied.headers.get('content-type')), /image\/jpeg/);
    const buf = Buffer.from(await proxied.arrayBuffer());
    assert.ok(buf.length > 4 && buf[0] === 0xff && buf[1] === 0xd8, '返回的不是 JPEG');
  });

  const pushes = [];
  const bridge = loadBridge(port, pushes);

  const book = {
    bookUrl: base + '/book/1',
    bookKind: 'comic',
    details: { sourceId, name: '测试漫画', author: '', coverUrl: '', tocUrl: base + '/book/1', bookKind: 'comic' },
    chapters: list,
  };

  await check('推送：漫画按 pics 格式推送整本目录', async () => {
    bridge.emit('lr-push-book', { book, index: 1 });
    await new Promise((r) => setTimeout(r, 300));
    assert.equal(pushes.length, 1, '应该推送一次，实际 ' + pushes.length);
    const spec = pushes[0];
    assert.equal(spec.format, 'pics', '漫画的 format 应为 pics，实际 ' + spec.format);
    assert.equal(spec.type_name, '漫画', '类型名应为漫画，实际 ' + spec.type_name);
    assert.equal(spec.episodes.length, 3);
    for (const ep of spec.episodes) assert.equal(ep.format, 'pics', '每集 format 也应是 pics');
    assert.equal(spec.mark, '第02话', 'mark 应指向点开的那一话，实际 ' + spec.mark);
    assert.equal(spec.markIndex, 1, 'markIndex 应为 1');
    assert.match(spec.vod_remarks, /3 话/);
  });

  await check('解析：壳子取一话返回 pics:// 且走图片代理', async () => {
    assert.equal(typeof bridge.window.DL?.resolveEpisode, 'function', '应装上 resolveEpisode');
    const url = pushes[0].episodes[1].url;
    const payload = await bridge.window.DL.resolveEpisode(url);
    assert.match(String(payload), /^pics:\/\//, '应返回 pics:// 开头，实际 ' + String(payload).slice(0, 80));
    const urls = String(payload).slice('pics://'.length).split('&&');
    assert.equal(urls.length, 2, '应包含 2 张图，实际 ' + urls.length);
    for (const u of urls) {
      assert.match(u, /\/api\/comic\/image\?/, '图片地址应走本机代理：' + u);
      const loaded = await fetch(u);
      assert.equal(loaded.status, 200, '代理图片加载失败：' + loaded.status + ' ' + u);
    }
  });

  await check('进度：一轮预取只记用户点开的那一话', async () => {
    const eps = pushes[0].episodes;
    await bridge.window.DL.resolveEpisode(eps[1].url);
    await bridge.window.DL.resolveEpisode(eps[2].url);
    await new Promise((r) => setTimeout(r, 3200));
    const prog = await api(port, 'GET', `/api/reading-progress?sourceId=${encodeURIComponent(sourceId)}&bookUrl=${encodeURIComponent(book.bookUrl)}`);
    assert.equal(prog.status, 200, JSON.stringify(prog.body));
    assert.equal(prog.body.chapterIndex, 1, '预取第 3 话不应把进度顶到 2，实际 ' + prog.body.chapterIndex);
    assert.equal(prog.body.chapterUrl, list[1].url, '进度章节地址应为第 2 话');
  });

  await check('进度：翻到下一话后进度跟着走', async () => {
    const eps = pushes[0].episodes;
    await bridge.window.DL.resolveEpisode(eps[2].url);
    await new Promise((r) => setTimeout(r, 3200));
    const prog = await api(port, 'GET', `/api/reading-progress?sourceId=${encodeURIComponent(sourceId)}&bookUrl=${encodeURIComponent(book.bookUrl)}`);
    assert.equal(prog.body.chapterIndex, 2, '应记到第 3 话，实际 ' + prog.body.chapterIndex);
  });

  exitCode = 0;
}
catch (e) {
  console.error('致命错误：' + e.message + '\n' + logs.slice(-800));
}
finally {
  child.kill();
  upstream.server.close();
  fs.rmSync(tmp, { recursive: true, force: true });
}

let failed = 0;
for (const [name, ok, detail] of results) {
  console.log(`${ok ? '✓' : '✗'} ${name}${ok ? '' : ' —— ' + detail}`);
  if (!ok) failed++;
}
console.log(`\n${results.length - failed}/${results.length} 通过`);
process.exit(failed === 0 ? exitCode : 1);