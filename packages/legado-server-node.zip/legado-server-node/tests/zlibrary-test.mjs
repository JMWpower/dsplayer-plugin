#!/usr/bin/env node

import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const results = [];
async function check(name, fn) {
  try {
    await fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const CHALLENGE_HTML = `<!doctype html><html><head><title>Checking your browser ...</title></head><body>
<script>
var s1 = {
  array: function (str) {
    // 占位实现：真正的循环会被 solver 注入的原生 sha1 顶掉
    var out = []; for (var i = 0; i < 20; i++) out.push(0);
    return out;
  }
};
window.onload = async function () {
  var probe = '_cookie_' + Date.now();
  document.cookie = probe + '=true; path=/';
  var ok = document.cookie.split('; ').some(function (f) { return f.indexOf(probe + '=') === 0; });
  document.cookie = probe + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/';
  if (!ok) { document.body.innerHTML = '<h1>Cookies are required</h1>'; return; }
  var c = 'A1B2C3D4E5';
  var i = 0;
  var start = performance.now();
  while (true) {
    var s = s1['array'](c + i);
    if (s[0] === 0x0f) {
      document.cookie = 'c_token=' + c + i + '; path=/';
      document.cookie = 'c_time=' + (performance.now() - start) / 1000 + '; path=/';
      window.location.reload();
      break;
    }
    i++;
    if (i % 50000 === 0) await new Promise(function (r) { setTimeout(r, 0); });
  }
};
</script>
<div class="message">Wait a moment, checking your browser ...</div>
</body></html>`;

const HOME_HTML = `<!doctype html><html><head><title>Z-Library</title></head><body>
<z-bookcard id="1" href="/book/aaa/三体" title="三体" language="chinese" extension="epub" filesize="2.1 MB">
  <img data-src="https://s3proxy-alp2-covers.cdn-zlib.sk/covers100/1.jpg">
  <span slot="title">三体</span><span slot="author">刘慈欣</span>
</z-bookcard>
<z-bookcard id="2" href="/book/bbb/流浪地球" title="流浪地球" language="chinese" extension="pdf" filesize="1.2 MB">
  <img data-src="https://s3proxy-alp2-covers.cdn-zlib.sk/covers100/2.jpg">
  <span slot="title">流浪地球</span><span slot="author">刘慈欣</span>
</z-bookcard>
<script>pagerOptions = { pagesTotal : 7, pageCurrent : 1 };</script>
</body></html>`;

const SITE = 'https://z-lib.by';
const DEAD_BASES = ['https://zh.z-lib.gd', 'https://zh.z-library.sk', 'https://z-lib.fm', 'https://z-lib.gs'];
const COVER = 'https://s3proxy-alp2-covers.cdn-zlib.sk/covers100/1.jpg';

const calls = [];
let challengeMode = 'solve';

function html(body, status = 200) {
  return new Response(body, { status, headers: { 'content-type': 'text/html; charset=utf-8' } });
}

globalThis.fetch = async (input, init = {}) => {
  const url = String(input);
  const cookie = new Headers(init.headers ?? {}).get('cookie') ?? '';
  calls.push({ url, cookie });
  if (DEAD_BASES.some((base) => url.startsWith(base))) {

    throw Object.assign(new TypeError('fetch failed'), { cause: { code: 'ENOTFOUND' } });
  }
  if (url === `${SITE}/`) return html('<html>ok</html>');
  if (url.startsWith(`${SITE}/s/`)) {
    if (challengeMode === 'plain503') return html('<html><body>Service Unavailable</body></html>', 503);
    if (!cookie.includes('c_token=')) return html(CHALLENGE_HTML, 503);
    return html(HOME_HTML);
  }
  if (url === COVER) return new Response(Buffer.from([0xff, 0xd8, 0xff, 0xd9]), { status: 200, headers: { 'content-type': 'image/jpeg' } });
  return html('<html>404</html>', 404);
};

const routes = new Map();
const app = {
  get(path, handler) { routes.set(path, handler); },
  post(path, handler) { routes.set(`POST ${path}`, handler); },
};
const db = { getSetting: () => '', setSetting: () => {} };

const { registerZLibraryRoutes } = await import('../dist/zlibrary.js');
registerZLibraryRoutes(app, { db });
await sleep(120);

function makeReply() {
  const out = { status: 200, headers: {}, body: undefined };
  const reply = {
    code(status) { out.status = status; return reply; },
    header(name, value) { out.headers[String(name).toLowerCase()] = value; return reply; },
    send(body) { out.body = body; return reply; },
  };
  return { reply, out };
}

async function call(path, request = {}, replyPair = makeReply()) {
  const handler = routes.get(path);
  assert.ok(handler, '没注册路由：' + path);
  const returned = await handler(request, replyPair.reply);
  return { returned, ...replyPair.out, out: replyPair.out };
}

await check('启动后按「谁通」排序：探得通的镜像排在第一位', async () => {
  const { returned } = await call('/api/zlibrary/status');
  assert.equal(returned.base, SITE, '当前镜像不是探通的那个：' + returned.base);
  const probed = calls.filter((c) => DEAD_BASES.some((b) => c.url === `${b}/`) || c.url === `${SITE}/`);
  assert.ok(probed.length >= 5, '没有把候选镜像都探一遍：' + probed.length);
});

await check('图书馆首页：503 挑战页能自己解，带着 c_token 重放拿到书', async () => {
  calls.length = 0;
  const { returned, status, body } = await call('/api/zlibrary/home', { query: {} });
  const data = returned ?? body;
  assert.equal(status, 200, '首页没成功：' + JSON.stringify(body));
  assert.ok(Array.isArray(data.popular) && data.popular.length === 2, '书籍条数不对：' + JSON.stringify(data).slice(0, 200));
  assert.equal(data.popular[0].title, '三体');

  const asked = calls.filter((c) => c.url.startsWith(`${SITE}/s/`));
  assert.equal(asked.length, 2, '应该是「先撞墙、再重放」两次请求，实际 ' + asked.length);
  assert.ok(!asked[0].cookie.includes('c_token='), '第一次不该带 c_token');
  assert.ok(asked[1].cookie.includes('c_token='), '重放必须带 c_token');

  const token = decodeURIComponent(asked[1].cookie.match(/c_token=([^;]+)/)[1]);
  const seed = token.slice(0, -String(token.match(/\d+$/)[0]).length);
  const index = token.slice(seed.length);
  const digest = createHash('sha1').update(seed + index).digest();
  assert.equal(digest[0], 0x0f, '解出来的 token 不满足页面条件：' + token);
});

await check('图书馆首页：探不通的镜像不会被真的拿请求去撞', async () => {
  for (const base of DEAD_BASES) {
    assert.ok(!calls.some((c) => c.url.startsWith(`${base}/s/`)), '还是去撞了死镜像：' + base);
  }
});

await check('封面代理：站外 CDN 地址不被拼回镜像域名', async () => {
  calls.length = 0;
  const { status, headers, body } = await call('/api/zlibrary/img', { query: { u: COVER } });
  assert.equal(status, 200, '封面没拿到：' + JSON.stringify(body));
  assert.equal(headers['content-type'], 'image/jpeg');
  assert.ok(calls.some((c) => c.url === COVER), '没有直接请求 CDN：' + calls.map((c) => c.url).join(' | '));
  assert.ok(!calls.some((c) => c.url.startsWith(`${SITE}/covers`)), '封面被拼到镜像域名上了');
});

await check('封面代理：非白名单域名仍然拒绝（不被当开放代理）', async () => {
  const { status, body } = await call('/api/zlibrary/img', { query: { u: 'https://evil.example.com/a.jpg' } });
  assert.equal(status, 400, '应该 400，实际 ' + status + ' ' + JSON.stringify(body));
});

await check('首页：认不出的 503 不硬解，如实报上游状态', async () => {
  challengeMode = 'plain503';
  try {
    const { status, body } = await call('/api/zlibrary/home', { query: {} });
    assert.equal(status, 502, '应该 502，实际 ' + status);
    assert.match(String(body.message), /HTTP 503/, '错误信息没带上游状态：' + JSON.stringify(body));
  } finally {
    challengeMode = 'solve';
  }
});

const failed = results.filter((r) => !r[1]);
for (const [name, ok, extra] of results) {
  console.log(`${ok ? '✓' : '✗'} ${name}${ok || !extra ? '' : '  —— ' + extra}`);
}
console.log(`\n${results.length - failed.length}/${results.length} 通过`);
process.exit(failed.length === 0 ? 0 : 1);