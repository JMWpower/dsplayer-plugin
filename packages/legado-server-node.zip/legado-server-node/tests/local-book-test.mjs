
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import AdmZip from 'adm-zip';
import {
  sanitizeFileName, splitTxtChapters, saveBookFile, listBookFiles, decodeText, parseEpub,
  importLocalBookBytes, saveAndImportBook,
} from '../dist/localBookImport.js';

const results = [];
function check(name, ok, detail = '') {
  results.push({ name, ok });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
}

check('路径穿越被拍平', (() => { const n = sanitizeFileName('../../etc/passwd'); return !n.includes('/') && !n.includes('\\') && !n.includes('..'); })(), sanitizeFileName('../../etc/passwd'));
check('非法字符替换', sanitizeFileName('a/b\\c:d*.txt') === 'a_b_c_d_.txt', sanitizeFileName('a/b\\c:d*.txt'));
check('空名有兜底', sanitizeFileName('   ') === 'book');
check('超长名保留扩展名', sanitizeFileName('x'.repeat(300) + '.epub').endsWith('.epub'));

const txt = [
  '书名：测试书', '作者：某人',
  '第一章 开端',
  '正文一。', '正文二。',
  '第2章 发展',
  '正文三。',
  '番外 小剧场',
  '正文四。',
].join('\n');
const chunks = splitTxtChapters(txt);
check('TXT 分出 3 章', chunks.length === 3, chunks.map((c) => c.title).join(' | '));
check('章节标题正确', chunks[0].title === '第一章 开端' && chunks[1].title === '第2章 发展');
check('章节正文正确', chunks[2].text.indexOf('正文四') >= 0);

const gbkBytes = Buffer.from([0xb5, 0xda, 0xd2, 0xbb, 0xd5, 0xc2]);
check('GBK 兜底解码', decodeText(gbkBytes) === '第一章', decodeText(gbkBytes));
check('UTF-8 正常解码', decodeText(Buffer.from('第一章', 'utf8')) === '第一章');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lrbook-'));
const a = saveBookFile(dir, '测试.txt', Buffer.from('hello'));
const b = saveBookFile(dir, '测试.txt', Buffer.from('hello'));
check('首次落盘新文件', a.reused === false && fs.existsSync(a.path));
check('同内容重复下载复用', b.reused === true && b.path === a.path);
const c = saveBookFile(dir, '测试.txt', Buffer.from('different'));
check('同内容不同才加序号', c.path !== a.path && / \(2\)\.txt$/.test(c.path), path.basename(c.path));
const files = listBookFiles(dir);
check('book 目录清单', files.length === 2 && files.every((f) => f.importable === true), `files=${files.length}`);
fs.writeFileSync(path.join(dir, 'nope.pdf'), 'x');
check('非解析格式标 stored', listBookFiles(dir).find((f) => f.fileName === 'nope.pdf').importable === false);

const zip = new AdmZip();
zip.addFile('META-INF/container.xml', Buffer.from(
  '<?xml version="1.0"?><container><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>'));
zip.addFile('OEBPS/content.opf', Buffer.from(`<?xml version="1.0"?>
<package><metadata><dc:title>测试 EPUB</dc:title><dc:creator>作者丙</dc:creator>
<meta name="cover" content="cover-img"/></metadata>
<manifest>
<item id="c1" href="c1.xhtml" media-type="application/xhtml+xml"/>
<item id="c2" href="c2.xhtml" media-type="application/xhtml+xml"/>
<item id="cover-img" href="cover.png" media-type="image/png"/>
</manifest>
<spine><itemref idref="c1"/><itemref idref="c2"/></spine></package>`));
zip.addFile('OEBPS/c1.xhtml', Buffer.from('<html><head><title>第一章</title></head><body><p>第一段。</p><p>第二段。</p></body></html>'));
zip.addFile('OEBPS/c2.xhtml', Buffer.from('<html><head><title>第二章</title></head><body><p>第三段。</p></body></html>'));
zip.addFile('OEBPS/cover.png', Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex'));

const epub = parseEpub(zip.toBuffer());
check('EPUB 标题', epub.title === '测试 EPUB', epub.title);
check('EPUB 作者', epub.author === '作者丙');
check('EPUB 章节数 2', epub.chapters.length === 2, String(epub.chapters.length));
check('EPUB 章节标题', epub.chapters[0].title === '第一章' && epub.chapters[1].title === '第二章');
check('EPUB 正文抽离', epub.chapters[0].text.indexOf('第一段') >= 0 && epub.chapters[0].text.indexOf('<') < 0);
check('EPUB 封面抠出', epub.cover != null && epub.cover.contentType === 'image/png');

function fakeDb() {
  const calls = { content: [], shelf: [], begin: 0, finish: 0, cleared: 0, toc: [] };
  const shelfRows = new Map();
  return {
    calls,
    db: {
      transaction: (fn) => fn,
      prepare: (sql) => ({
        get: (...args) => {
          const row = shelfRows.get(args[0]);
          if (row == null) return undefined;
          return sql.includes('group_name') ? { group_name: row.groupName ?? null } : row;
        },
        run: () => ({ changes: 1 }),
      }),
    },
    cacheBookContent: (s, b, u, c) => calls.content.push({ sourceId: s, bookUrl: b, chapterUrl: u, content: c.content }),
    beginBookCache: () => { calls.begin++; },
    updateBookCacheProgress: () => {},
    finishBookCache: () => { calls.finish++; },
    saveBookshelf: (row) => { calls.shelf.push(row); shelfRows.set(row.bookUrl, row); },
    listBookshelf: () => [...shelfRows.values()],
    findLocalShelfBookUrl: (name) => {
      for (const [url, row] of shelfRows)
        if (String(row.name ?? '').trim().toLowerCase() === String(name ?? '').trim().toLowerCase()) return url;
      return null;
    },
    clearBookCacheContent: () => { calls.cleared++; },
    saveTocCache: (s, b, chapters) => calls.toc.push({ sourceId: s, bookUrl: b, count: chapters.length }),
  };
}

const db1 = fakeDb();
const imported = importLocalBookBytes(db1, { put: () => ({ cacheKey: 'ck' }) }, Buffer.from(txt, 'utf8'), '我的书.txt');
check('TXT 上架章节数', imported.totalChapters === 3, String(imported.totalChapters));
check('TXT 正文全部落库', db1.calls.content.length === 3);
check('TXT 书架行正确', db1.calls.shelf[0].sourceId === 'loc_book' && db1.calls.shelf[0].name === '我的书');
check('TXT 缓存状态收尾', db1.calls.begin === 1 && db1.calls.finish === 1);
check('TXT 首次导入标记 reused=false', imported.reused === false);
check('TXT 首次导入写目录缓存', db1.calls.toc.length === 1 && db1.calls.toc[0].count === 3);

const again = importLocalBookBytes(db1, { put: () => ({ cacheKey: 'ck' }) }, Buffer.from(txt, 'utf8'), '我的书.txt');
check('同书再导入复用 bookUrl', again.bookUrl === imported.bookUrl, `${again.bookUrl} vs ${imported.bookUrl}`);
check('同书再导入标记 reused=true', again.reused === true);
check('同书再导入清旧正文缓存', db1.calls.cleared === 1);
check('同书再导入不新增书架行', db1.listBookshelf().length === 1, `rows=${db1.listBookshelf().length}`);

const other = importLocalBookBytes(db1, { put: () => ({ cacheKey: 'ck' }) }, Buffer.from(txt.replace('测试书', '另一本'), 'utf8'), '另一本.txt');
check('不同书生成新 bookUrl', other.bookUrl !== imported.bookUrl && other.reused === false);
check('不同书各自独立成行', db1.listBookshelf().length === 2, `rows=${db1.listBookshelf().length}`);

const db2 = fakeDb();
const epubImported = importLocalBookBytes(db2, { put: () => ({ cacheKey: 'ck2' }) }, zip.toBuffer(), 'x.epub');
check('EPUB 上架书名取元数据', epubImported.name === '测试 EPUB', epubImported.name);
check('EPUB 上架 2 章', epubImported.totalChapters === 2);
check('EPUB 封面键回传', epubImported.coverKey === 'ck2');
const epubAgain = importLocalBookBytes(db2, { put: () => ({ cacheKey: 'ck2' }) }, zip.toBuffer(), 'x.epub');
check('EPUB 同书再导入复用 bookUrl', epubAgain.bookUrl === epubImported.bookUrl && epubAgain.reused === true);

const dir2 = fs.mkdtempSync(path.join(os.tmpdir(), 'lrbook2-'));
const ctx = { db: fakeDb(), coverCache: { put: () => null }, config: { localBooksDirectory: dir2 } };
const pdf = saveAndImportBook(ctx, Buffer.from('%PDF-1.4'), '说明书.pdf');
check('PDF 只落盘不上架', pdf.storedOnly === true && pdf.book === null && fs.existsSync(pdf.saved.path));
const okTxt = saveAndImportBook(ctx, Buffer.from(txt, 'utf8'), '测试TXT.txt');
check('TXT 落盘 + 上架同时成立', okTxt.storedOnly === false && okTxt.book.totalChapters === 3 && fs.existsSync(okTxt.saved.path));
fs.rmSync(dir2, { recursive: true, force: true });

const realPath = path.join(os.tmpdir(), `lrdb-${Date.now()}.sqlite`);
const { Db } = await import('../dist/database.js');
const real = new Db(realPath);
real.initialize();
const addRow = (bookUrl, name, author, at) => real.saveBookshelf({
  sourceId: 'loc_book', bookUrl, name, author, tocUrl: bookUrl, coverUrl: null,
  alternateSources: null, groupName: null, bookKind: 'local',
}, null);
addRow('local://a', '重复书', '某人', 1000);
addRow('local://b', '重复书', '某人', 3000);
addRow('local://c', '重复书', '某人', 2000);
addRow('local://d', '独本', null, 1500);
real.db.prepare("update book_shelf set last_read_at = ? where book_url = ?").run(1000, 'local://a');
real.db.prepare("update book_shelf set last_read_at = ? where book_url = ?").run(3000, 'local://b');
real.db.prepare("update book_shelf set last_read_at = ? where book_url = ?").run(2000, 'local://c');
real.db.prepare("update book_shelf set last_read_at = ? where book_url = ?").run(1500, 'local://d');
const removed = real.dedupeLocalBooks();
const left = real.listBookshelf().filter((b) => b.sourceId === 'loc_book');
check('真库去重删掉重复行', removed === 2, `removed=${removed}`);
check('真库去重保留最近读的那条', left.length === 2 && left.some((b) => b.bookUrl === 'local://b'), left.map((b) => b.bookUrl).join(','));
check('真库去重不碰独本', left.some((b) => b.bookUrl === 'local://d'));
real.saveBookshelf({ sourceId: 'loc_book', bookUrl: 'local://b', name: '重复书', author: '某人', tocUrl: 'local://b', coverUrl: null, alternateSources: null, groupName: null, bookKind: 'local' }, null);
real.saveTocCache('loc_book', 'local://b', [
  { index: 0, title: '一', url: 'local://b/0' },
  { index: 1, title: '二', url: 'https://x.test/ch2' },
]);
check('章节序号可反查', real.chapterIndexOf('loc_book', 'local://b', 'local://b/1') === 1, String(real.chapterIndexOf('loc_book', 'local://b', 'local://b/1')));
check('目录缓存兜底查序号', real.chapterIndexOf('loc_book', 'local://b', 'https://x.test/ch2') === 1, String(real.chapterIndexOf('loc_book', 'local://b', 'https://x.test/ch2')));
check('查不到返回 null', real.chapterIndexOf('loc_book', 'local://b', 'https://nope.test/zz') === null);
real.noteReading('loc_book', 'local://b', 'https://x.test/ch2', '二');
const prog = real.getProgress('loc_book', 'local://b');
check('noteReading 写入进度', prog != null && prog.chapterIndex === 1, JSON.stringify(prog));
real.close();
for (const suffix of ['', '-wal', '-shm']) {
  try { fs.rmSync(realPath + suffix); } catch { }
}

fs.rmSync(dir, { recursive: true, force: true });

const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} 通过`);
process.exit(failed.length === 0 ? 0 : 1);