#!/usr/bin/env node

import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const results = [];

function check(name, fn) {
  try {
    fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

async function checkAsync(name, fn) {
  try {
    await fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

function bundlePath() {
  const html = fs.readFileSync(path.join(root, 'web-dist/index.html'), 'utf8');
  const m = html.match(/<script[^>]+src="\/assets\/(index-[^"]+\.js)"/);
  assert.ok(m, 'index.html 里没有入口 bundle');
  return path.join(root, 'web-dist/assets', m[1]);
}
function sha(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

check('补丁脚本：产物里就是 web-patches 的那两份正文', () => {
  const code = fs.readFileSync(bundlePath(), 'utf8');
  for (const file of ['explore.component.js', 'load-book.component.js']) {
    const patch = fs.readFileSync(path.join(root, 'tools/web-patches', file), 'utf8').trimEnd();
    assert.ok(code.includes(patch), '产物里没有 ' + file + ' 的正文');
  }
  assert.ok(!code.includes('__lrFallbackCat'), '旧版助手脚本没清掉');
});

check('补丁脚本：重复执行幂等（字节不变）', () => {
  const file = bundlePath();
  const before = sha(file);
  execFileSync(process.execPath, [path.join(root, 'tools/patch-web-assets.mjs')], { stdio: 'pipe' });
  assert.equal(sha(file), before, '第二次执行改动了产物');
  execFileSync(process.execPath, [path.join(root, 'tools/patch-web-assets.mjs'), '--check'], { stdio: 'pipe' });
});

check('补丁脚本：产物可解析', () => {
  new vm.Script(fs.readFileSync(bundlePath(), 'utf8'), { filename: 'bundle.js' });
});

check('入口页面：加载了壳子桥脚本', () => {
  const html = fs.readFileSync(path.join(root, 'web-dist/index.html'), 'utf8');
  const bridgeAt = html.indexOf('src="/lr-tvbox.js"');
  const entryAt = html.indexOf('src="/assets/index-');
  assert.ok(bridgeAt > 0, 'index.html 没引用 /lr-tvbox.js');
  assert.ok(bridgeAt < entryAt, '壳子桥必须在 app bundle 之前执行');
});

const t = {
  Fragment: Symbol('Fragment'),
  jsx: (type, props, key) => ({ type, props: props || {}, key }),
  jsxs: (type, props, key) => ({ type, props: props || {}, key }),
};

function sameDeps(a, b) {
  if (a == null || b == null) return false;
  if (a.length !== b.length) return false;
  return a.every((v, i) => Object.is(v, b[i]));
}

function createRenderer(component) {
  const hooks = [];
  let cursor = 0;
  let dirty = false;
  let effectQueue = [];
  let tree = null;

  const m = {
    useState(initial) {
      const i = cursor++;
      if (hooks[i] == null) hooks[i] = { type: 'state', value: typeof initial === 'function' ? initial() : initial };
      const hook = hooks[i];
      return [hook.value, (next) => {
        const value = typeof next === 'function' ? next(hook.value) : next;
        if (Object.is(value, hook.value)) return;
        hook.value = value;
        dirty = true;
      }];
    },
    useEffect(fn, deps) {
      const i = cursor++;
      const prev = hooks[i];
      const changed = prev == null || !sameDeps(prev.deps, deps);
      hooks[i] = {
        type: 'effect',
        deps: deps == null ? null : deps.slice(),
        fn,
        cleanup: prev ? prev.cleanup : undefined,
        changed,
      };
    },
    useMemo(fn, deps) {
      const i = cursor++;
      const prev = hooks[i];
      if (prev != null && sameDeps(prev.deps, deps)) return prev.value;
      const value = fn();
      hooks[i] = { type: 'memo', deps: deps == null ? null : deps.slice(), value };
      return value;
    },
    useRef(initial) {
      const i = cursor++;
      if (hooks[i] == null) hooks[i] = { type: 'ref', value: { current: initial } };
      return hooks[i].value;
    },
  };

  function render() {
    cursor = 0;
    dirty = false;
    tree = component();
    effectQueue = hooks.filter((h) => h && h.type === 'effect' && h.changed);
    for (const hook of effectQueue) hook.changed = false;
    for (const hook of effectQueue) {
      if (typeof hook.cleanup === 'function') hook.cleanup();
      const out = hook.fn();
      hook.cleanup = typeof out === 'function' ? out : undefined;
    }
    return tree;
  }

  async function flush(rounds = 30) {
    render();
    for (let i = 0; i < rounds; i++) {
      await new Promise((resolve) => setTimeout(resolve, 0));
      if (dirty) render();
    }
    if (dirty) render();
    return tree;
  }

  function unmount() {
    for (const hook of hooks) {
      if (hook && hook.type === 'effect' && typeof hook.cleanup === 'function') hook.cleanup();
    }
  }

  return { m, flush, unmount, getTree: () => tree, click };
}

function click(node, predicate) {
  const hit = findNode(node, predicate);
  assert.ok(hit, '没找到要点击的节点');
  const handler = hit.props && hit.props.onClick;
  assert.equal(typeof handler, 'function', '节点没有 onClick');
  return handler({ stopPropagation() { }, target: { style: {} }, preventDefault() { } });
}

function findNode(node, predicate) {
  if (node == null || typeof node !== 'object') return null;
  if (Array.isArray(node)) {
    for (const child of node) {
      const hit = findNode(child, predicate);
      if (hit) return hit;
    }
    return null;
  }
  if (predicate(node)) return node;
  const children = node.props && node.props.children;
  if (children == null) return null;
  if (Array.isArray(children)) {
    for (const child of children) {
      const hit = findNode(child, predicate);
      if (hit) return hit;
    }
    return null;
  }
  return findNode(children, predicate);
}

function textOf(node) {
  if (node == null) return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(textOf).join('');
  const children = node.props && node.props.children;
  return children == null ? '' : textOf(children);
}

function createStorage(seed = {}) {
  const map = new Map(Object.entries(seed));
  return {
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => { map.set(k, String(v)); },
    removeItem: (k) => { map.delete(k); },
    dump: () => Object.fromEntries(map),
  };
}

function createEnv(seedStorage = {}) {
  const messages = [];
  const storage = createStorage(seedStorage);
  const win = { localStorage: storage };

  globalThis.window = win;
  return {
    window: win,
    localStorage: storage,
    Y: {
      error: (msg) => messages.push(['error', msg]),
      success: (msg) => messages.push(['success', msg]),
      info: (msg) => messages.push(['info', msg]),
    },
    messages,
  };
}

function translate(key, arg) {
  if (typeof arg === 'string') return arg;
  if (arg && typeof arg === 'object' && typeof arg.defaultValue === 'string') return arg.defaultValue;
  return key;
}

function i18n() {
  return () => ({ t: translate });
}

const nt = { t: translate };

const icon = (props) => t.jsx('icon', props);

function loadExploreComponent() {
  const code = fs.readFileSync(path.join(root, 'tools/web-patches/explore.component.js'), 'utf8');
  const factory = new Function('m', 't', 'O', 'V', 'Y', 'at', 'Cd', code + '\nreturn lC;');
  return factory;
}

function loadBookComponent() {
  const code = fs.readFileSync(path.join(root, 'tools/web-patches/load-book.component.js'), 'utf8');
  const factory = new Function('V', 'nt', 'var Cd;\n' + code + '\nreturn Cd;');
  return factory;
}

function makeExploreApi(sources, catsBySource, booksByCat, calls) {
  return {
    exploreSources: async () => sources,
    bookshelf: async () => [],
    exploreCategories: async (id) => {
      calls.push(['categories', id]);
      return catsBySource[id] || [];
    },
    exploreBooks: async (id, url, page) => {
      calls.push(['books', id, url, page]);
      const entry = booksByCat[`${id}|${url}`];
      if (entry instanceof Error) throw entry;
      return Array.isArray(entry) ? entry : [];
    },
    details: async () => { throw new Error('发现页列表不该取详情'); },
    addToBookshelf: async () => ({}),
    chapters: async () => [],
    progress: async () => null,
  };
}

function makeBook(name, sourceId = 'src-a') {
  return {
    sourceId,
    bookUrl: `https://e.test/${encodeURIComponent(name)}`,
    name,
    author: '作者' + name,
    intro: '简介',
    coverUrl: '',
  };
}

function mountExplore(api, env, at, cd) {
  const renderer = createRenderer(() => {
    const factory = loadExploreComponent()(renderer.m, t, icon, api, env.Y, at, cd || (async () => {
      throw new Error('发现页列表不该走 Cd');
    }));
    return factory({ onOpen() { } });
  });
  return { renderer, flush: () => renderer.flush(), unmount: () => renderer.unmount() };
}

function currentSourceName(tree) {
  const trigger = findNode(tree, (n) => n.props && typeof n.props.className === 'string'
    && n.props.className.indexOf('explore-source-trigger') >= 0);
  return trigger ? textOf(trigger.props.children) : '';
}

function bookCards(tree) {
  const out = [];
  (function walk(node) {
    if (node == null || typeof node !== 'object') return;
    if (Array.isArray(node)) { node.forEach(walk); return; }
    if (node.props && node.props.className === 'explore-book-card') out.push(node);
    walk(node.props && node.props.children);
  })(tree);
  return out;
}

await checkAsync('发现页：离开再回来还记得上次选的书源', async () => {
  const sources = [
    { id: 'src-a', name: '书源甲', enabled: true },
    { id: 'src-b', name: '书源乙', enabled: true },
    { id: 'src-c', name: '书源丙', enabled: true },
  ];
  const cats = {
    'src-a': [{ title: '分类A', url: '/a' }],
    'src-b': [{ title: '分类B', url: '/b' }],
    'src-c': [{ title: '分类C', url: '/c' }],
  };
  const books = {
    'src-a|/a': [makeBook('A书', 'src-a')],
    'src-b|/b': [makeBook('B书', 'src-b')],
    'src-c|/c': [makeBook('C书', 'src-c')],
  };
  const calls = [];
  const api = makeExploreApi(sources, cats, books, calls);
  const env = createEnv();
  const at = i18n();

  const first = mountExplore(api, env, at);
  let tree = await first.flush();
  assert.equal(currentSourceName(tree), '书源甲', '首次进入应默认第一个源');

  click(tree, (n) => n.props && typeof n.props.className === 'string'
    && n.props.className.indexOf('explore-source-trigger') >= 0);
  tree = await first.flush();
  click(tree, (n) => n.props && n.props.role === 'option' && n.key === 'src-c');
  tree = await first.flush();
  assert.equal(currentSourceName(tree), '书源丙', '选择第三个源后应显示它');
  assert.equal(env.localStorage.getItem('lr.exploreSource'), 'src-c', '选中的源应写入 localStorage');

  first.unmount();
  const second = mountExplore(api, env, at);
  const tree2 = await second.flush();
  assert.equal(currentSourceName(tree2), '书源丙', '从别的页面回来应记得上次选的源');
  assert.equal(bookCards(tree2).length, 1, '应继续显示该源分类下的书');
});

await checkAsync('发现页：第一个分类空列表时自动顺延下一个分类', async () => {
  const sources = [{ id: 'src-a', name: '书源甲', enabled: true }];
  const cats = {
    'src-a': [
      { title: '空分类', url: '/empty' },
      { title: '坏分类', url: '/boom' },
      { title: '好分类', url: '/ok' },
    ],
  };
  const books = {
    'src-a|/empty': [],
    'src-a|/boom': new Error('HTTP 500'),
    'src-a|/ok': [makeBook('一'), makeBook('二')],
  };
  const calls = [];
  const env = createEnv();
  const at = i18n();
  const api = makeExploreApi(sources, cats, books, calls);
  const mounted = mountExplore(api, env, at);
  const tree = await mounted.flush();
  assert.equal(bookCards(tree).length, 2, '应显示好分类下的两本书');
  const tried = calls.filter((c) => c[0] === 'books').map((c) => c[2]);
  assert.deepEqual(tried, ['/empty', '/boom', '/ok'], '应按顺序试到出书为止：' + JSON.stringify(tried));
  const header = findNode(tree, (n) => n.props && n.props.className === 'explore-content-title-area');
  assert.ok(textOf(header).includes('好分类'), '标题应停在实际出书的分类上');
});

await checkAsync('发现页：记住上次看的分类', async () => {
  const sources = [{ id: 'src-a', name: '书源甲', enabled: true }];
  const cats = { 'src-a': [{ title: '分类一', url: '/1' }, { title: '分类二', url: '/2' }] };
  const books = { 'src-a|/1': [makeBook('甲')], 'src-a|/2': [makeBook('乙')] };
  const env = createEnv();
  const at = i18n();
  const api = makeExploreApi(sources, cats, books, []);
  const first = mountExplore(api, env, at);
  let tree = await first.flush();
  assert.deepEqual(bookCards(tree).map((c) => textOf(c)).length, 1);

  click(tree, (n) => n.props && typeof n.props.className === 'string'
    && n.props.className.indexOf('explore-category-tag') >= 0
    && textOf(n) === '分类二');
  tree = await first.flush();
  const remembered = JSON.parse(env.localStorage.getItem('lr.exploreCategories') || '{}');
  assert.equal(remembered['src-a'], '分类二', '选过的分类应被记住');

  first.unmount();
  const second = mountExplore(api, env, at);
  const tree2 = await second.flush();
  const header = findNode(tree2, (n) => n.props && n.props.className === 'explore-content-title-area');
  assert.ok(textOf(header).includes('分类二'), '回来后应停在上次看的分类');
});

await checkAsync('详情 + 目录：详情规则失败也能拿到目录', async () => {
  const calls = [];
  const chapters = [{ index: 0, title: '一', url: 'https://e.test/c1' }, { index: 1, title: '二', url: 'https://e.test/c2' }];
  const V = {
    details: async () => { throw new Error('该书源未配置 ruleBookInfo'); },
    chapters: async (sourceId, bookUrl) => { calls.push([sourceId, bookUrl]); return chapters; },
    progress: async () => null,
  };
  const Cd = loadBookComponent()(V, nt);
  const item = { sourceId: 'src-a', bookUrl: 'https://e.test/book/1', name: '某书', author: '某人' };
  const loaded = await Cd(item);
  assert.equal(loaded.details.name, '某书', '书名应回落到列表里的信息');
  assert.equal(loaded.chapters.length, 2);
  assert.deepEqual(calls[0], ['src-a', 'https://e.test/book/1'], '目录应按书页地址请求，而不是 tocUrl');
});

await checkAsync('详情 + 目录：先按书页失败后用 tocUrl 再试一次', async () => {
  const calls = [];
  const V = {
    details: async () => ({ sourceId: 'src-a', name: '某书', tocUrl: 'https://e.test/book/1/toc' }),
    chapters: async (sourceId, url) => {
      calls.push(url);
      if (url.includes('/toc')) return [{ index: 0, title: '第一章', url: 'https://e.test/c1' }];
      throw new Error('目录解析失败：目录页没有解析到章节');
    },
    progress: async () => null,
  };
  const Cd = loadBookComponent()(V, nt);
  const loaded = await Cd({ sourceId: 'src-a', bookUrl: 'https://e.test/book/1', name: '某书' });
  assert.equal(loaded.chapters.length, 1, '应回退到 tocUrl 拿到目录');
  assert.deepEqual(calls, ['https://e.test/book/1', 'https://e.test/book/1/toc']);
});

await checkAsync('详情 + 目录：两次都空时把后端原因抛出来', async () => {
  const V = {
    details: async () => ({ sourceId: 'src-a', name: '某书', tocUrl: 'https://e.test/book/1/toc' }),
    chapters: async () => { throw new Error('目录解析失败：ruleToc 未命中'); },
    progress: async () => null,
  };
  const Cd = loadBookComponent()(V, nt);
  await assert.rejects(() => Cd({ sourceId: 'src-a', bookUrl: 'https://e.test/book/1', name: '某书' }), /ruleToc 未命中/);
});

let failed = 0;
for (const [name, ok, detail] of results) {
  console.log(`${ok ? '✓' : '✗'} ${name}${ok ? '' : ' —— ' + detail}`);
  if (!ok) failed++;
}
console.log(`\n${results.length - failed}/${results.length} 通过`);
process.exit(failed === 0 ? 0 : 1);