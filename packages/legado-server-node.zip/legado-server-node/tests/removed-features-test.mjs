#!/usr/bin/env node

import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const results = [];

function check(name, fn) {
  try {
    fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const exists = (rel) => fs.existsSync(path.join(root, rel));
const distFiles = fs.readdirSync(path.join(root, 'dist')).filter((f) => f.endsWith('.js'))
  .map((f) => `dist/${f}`)
  .concat(fs.readdirSync(path.join(root, 'dist/routes')).filter((f) => f.endsWith('.js')).map((f) => `dist/routes/${f}`));

function bundlePath() {
  const html = read('web-dist/index.html');
  const m = html.match(/<script[^>]+src="\/assets\/(index-[^"]+\.js)"/);
  assert.ok(m != null, 'index.html 里没找到入口 bundle');
  return `web-dist/assets/${m[1]}`;
}

check('后端：订阅 / 替换规则的模块已删除', () => {
  for (const file of ['dist/subscriptionSync.js', 'dist/routes/replaceRules.js', 'dist/contentProcessor.js']) {
    assert.equal(exists(file), false, file + ' 还在');
  }
});

check('后端：没有任何文件再建这两张表或调用这两组方法', () => {
  const banned = ['source_subscription', 'replace_rule', 'getEnabledReplaceRules', 'listSubscriptions',
    'saveSubscription', 'recordSubscriptionSynced', 'saveReplaceRule', 'listReplaceRules', 'recleanBookCache'];
  const hits = [];
  for (const file of distFiles) {
    const text = read(file);
    for (const needle of banned) {
      if (text.includes(needle)) hits.push(`${file} :: ${needle}`);
    }
  }
  assert.deepEqual(hits, [], '残留：\n' + hits.join('\n'));
});

check('后端：路由注册表里没有这两条线的入口', () => {
  const app = read('dist/app.js');
  assert.ok(!app.includes('subscriptionSync'), 'app.js 还引着 subscriptionSync');
  assert.ok(!app.includes('replaceRules'), 'app.js 还引着 replaceRules 路由');
  assert.ok(!app.includes('/api/subscriptions'), 'app.js 里还有 subscriptions 路由');
});

check('后端：唯一保留的 replace 相关代码是书源 JS 的兼容存根', () => {
  const sandbox = read('dist/jsSandbox.js');
  assert.ok(sandbox.includes("book['setUseReplaceRule']"), '书源脚本兼容存根被误删（会让老书源报错）');
});

check('后端：所有文件语法正确', () => {
  for (const file of distFiles) {
    const r = spawnSync(process.execPath, ['--check', path.join(root, file)], { encoding: 'utf8' });
    assert.equal(r.status, 0, file + ' 语法错误：' + r.stderr);
  }
});

check('前端：入口页面仍然加载产物与壳子桥', () => {
  const html = read('web-dist/index.html');
  assert.ok(html.includes('src="/lr-tvbox.js"'), 'index.html 丢了壳子桥');
  bundlePath();
});

check('前端：没有这两个功能的 API 调用', () => {
  const code = read(bundlePath());
  for (const needle of ['/api/subscriptions', '/api/replace-rules', '/api/replace-rule-groups', '/api/bookshelf/reclean']) {
    assert.equal(code.includes(needle), false, '产物里还有 ' + needle);
  }
});

check('前端：导航 / 路由 / 页面分发里没有这两个入口', () => {
  const code = read(bundlePath());
  for (const needle of ['nav-secondary', 'subscription-page', 'onSourcesChange:P', 'reader.replaceRulesManage',
    'location.hash==="#subscriptions"', 'location.hash==="#rules"']) {
    assert.equal(code.includes(needle), false, '产物里还有 ' + needle);
  }
  assert.equal(/c\("subscriptions"\)/.test(code), false, '还有按钮能跳到订阅页');
  assert.equal(/c\("rules"\)/.test(code), false, '还有按钮能跳到规则页');
});

check('前端：其它功能与已有补丁都还在', () => {
  const code = read(bundlePath());
  for (const needle of ['#shelf', '#explore', '#zlibrary', '#sources',
    '/api/zlibrary/home', '/api/bookshelf', 'lr.exploreSource']) {
    assert.ok(code.includes(needle), '产物里丢了 ' + needle);
  }

  assert.ok(!code.includes('#bookmarks'), '书签路由不该再出现在产物里');
});

const failed = results.filter((r) => !r[1]);
for (const [name, ok, extra] of results) {
  console.log(`${ok ? '✓' : '✗'} ${name}${ok || !extra ? '' : '  —— ' + extra}`);
}
console.log(`\n${results.length - failed.length}/${results.length} 通过`);
process.exit(failed.length === 0 ? 0 : 1);