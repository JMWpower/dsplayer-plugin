#!/usr/bin/env node

import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');

const html = fs.readFileSync(path.join(root, 'web-dist/index.html'), 'utf8');
const entry = /<script[^>]+src="([^"]*\/assets\/index-[^"]+\.js)"/.exec(html);
assert.ok(entry, 'index.html 里找不到入口 bundle');
const bundlePath = path.join(root, 'web-dist', entry[1].replace(/^\//, ''));
assert.ok(fs.existsSync(bundlePath), '入口 bundle 不存在：' + bundlePath);

function makeEl(tag = 'div') {
  const el = {
    tagName: String(tag).toUpperCase(),
    nodeType: 1,
    id: '',
    className: '',
    style: new Proxy({}, { get: () => '', set: () => true }),
    dataset: {},
    attributes: {},
    childNodes: [],
    children: [],
    textContent: '',
    innerHTML: '',
    parentNode: null,
    ownerDocument: null,
    classList: { add() { }, remove() { }, toggle() { }, contains() { return false; } },
    addEventListener() { }, removeEventListener() { },
    appendChild(c) { el.childNodes.push(c); el.children.push(c); return c; },
    insertBefore(c) { el.childNodes.push(c); return c; },
    removeChild(c) { return c; },
    replaceChild(c) { return c; },
    setAttribute(k, v) { el.attributes[k] = v; },
    getAttribute(k) { return el.attributes[k] ?? null; },
    removeAttribute(k) { delete el.attributes[k]; },
    hasAttribute(k) { return k in el.attributes; },
    setPointerCapture() { }, releasePointerCapture() { },
    focus() { }, blur() { }, click() { }, scrollTo() { },
    getBoundingClientRect() { return { top: 0, left: 0, right: 0, bottom: 0, width: 0, height: 0, x: 0, y: 0 }; },
    getClientRects() { return []; },
    querySelector() { return null; },
    querySelectorAll() { return []; },
    closest() { return null; },
    contains() { return false; },
    cloneNode() { return makeEl(tag); },
    attachShadow() { return makeEl('shadow'); },
  };
  return el;
}

const rootEl = makeEl('div');
rootEl.id = 'root';

const documentStub = {
  nodeType: 9,
  documentElement: makeEl('html'),
  head: makeEl('head'),
  body: makeEl('body'),
  readyState: 'complete',
  visibilityState: 'visible',
  hidden: false,
  createElement: (t) => makeEl(t),
  createElementNS: (_ns, t) => makeEl(t),
  createTextNode: (t) => ({ nodeType: 3, textContent: t }),
  createDocumentFragment: () => makeEl('fragment'),
  createEvent: () => ({ initEvent() { }, preventDefault() { } }),
  getElementById: (id) => (id === 'root' ? rootEl : null),
  getElementsByTagName: () => [],
  querySelector: () => null,
  querySelectorAll: () => [],
  addEventListener() { }, removeEventListener() { },
  cookie: '',
  title: '阅读',
  fonts: { ready: Promise.resolve(), addEventListener() { } },
};

const storage = () => {
  const m = new Map();
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => m.set(k, String(v)),
    removeItem: (k) => m.delete(k),
    clear: () => m.clear(),
    key: (i) => [...m.keys()][i] ?? null,
    get length() { return m.size; },
  };
};

const locationStub = {
  href: 'http://127.0.0.1:8998/',
  origin: 'http://127.0.0.1:8998',
  protocol: 'http:',
  host: '127.0.0.1:8998',
  hostname: '127.0.0.1',
  port: '8998',
  pathname: '/',
  search: '',
  hash: '#shelf',
  assign() { }, replace() { }, reload() { },
  toString() { return locationStub.href; },
};

const win = {
  document: documentStub,
  location: locationStub,
  navigator: {
    userAgent: 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36',
    language: 'zh-CN', languages: ['zh-CN'], onLine: true, platform: 'Linux armv8l',
    serviceWorker: undefined, clipboard: undefined, sendBeacon: () => true,
  },
  localStorage: storage(),
  sessionStorage: storage(),
  matchMedia: () => ({ matches: false, media: '', addEventListener() { }, removeEventListener() { }, addListener() { }, removeListener() { } }),
  requestAnimationFrame: (fn) => setTimeout(() => fn(Date.now()), 0),
  cancelAnimationFrame: (id) => clearTimeout(id),
  setTimeout, clearTimeout, setInterval, clearInterval,
  innerWidth: 412, innerHeight: 915, devicePixelRatio: 2.6,
  scrollTo() { }, scrollY: 0, scrollX: 0, pageYOffset: 0, pageXOffset: 0,
  addEventListener() { }, removeEventListener() { }, dispatchEvent() { return true; },
  getComputedStyle: () => ({ getPropertyValue: () => '' }),
  fetch: async () => ({ ok: true, status: 200, json: async () => ({}), text: async () => '{}' }),
  CustomEvent: class CustomEvent {
    constructor(type, init) { this.type = type; this.detail = init?.detail; }
  },
  Event: class Event { constructor(type) { this.type = type; } },
  performance: { now: () => Date.now() },
  MutationObserver: class MutationObserver {
    observe() { } disconnect() { } takeRecords() { return []; }
  },
  IntersectionObserver: class IntersectionObserver {
    observe() { } unobserve() { } disconnect() { } takeRecords() { return []; }
  },
  ResizeObserver: class ResizeObserver {
    observe() { } unobserve() { } disconnect() { }
  },
  __lrBase: 'http://127.0.0.1:8998',
};
win.window = win;
win.self = win;
win.top = win;
win.parent = win;
win.globalThis = win;

for (const key of Object.keys(win)) {
  if (key === 'window' || key === 'self' || key === 'top' || key === 'parent' || key === 'globalThis') continue;
  try { globalThis[key] = win[key]; } catch {  }
}
globalThis.window = win;
globalThis.self = win;
globalThis.document = documentStub;
globalThis.location = locationStub;
try { Object.defineProperty(globalThis, 'navigator', { value: win.navigator, configurable: true }); } catch {  }
globalThis.localStorage = win.localStorage;
globalThis.sessionStorage = win.sessionStorage;
globalThis.matchMedia = win.matchMedia;
globalThis.requestAnimationFrame = win.requestAnimationFrame;
globalThis.cancelAnimationFrame = win.cancelAnimationFrame;
globalThis.getComputedStyle = win.getComputedStyle;
globalThis.CustomEvent = win.CustomEvent;

const realError = console.error;
console.error = () => { };

const probe = path.join(os.tmpdir(), 'lr-bundle-probe-' + Date.now() + '.mjs');
fs.copyFileSync(bundlePath, probe);

let failure = null;
try {
  await import(pathToFileURL(probe).href);
} catch (e) {
  failure = e;
} finally {
  try { fs.rmSync(probe, { force: true }); } catch {  }
  console.error = realError;
}

if (failure) {
  const name = failure.name || 'Error';
  const msg = failure.message || String(failure);
  const stack = (failure.stack || '').split('\n').slice(1, 3).join('\n');
  console.log('✗ 产物加载失败：' + name + ': ' + msg);
  console.log(stack);
  if (/is not defined|Cannot access .* before initialization/.test(msg)) {
    console.log('\n→ 这是「严格模式下给未声明变量赋值」一类的问题，浏览器里会整页白屏。');
  }
  process.exit(1);
}

console.log('✓ 产物能作为 ES module 加载（无模块级异常）');
console.log('\n1/1 通过');
process.exit(0);