#!/usr/bin/env node

import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const results = [];

async function check(name, fn) {
  try {
    await fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

const bundle = fs.readFileSync(path.join(root, 'web-dist/assets/index-68a2edd4.js'), 'utf8');
const styles = fs.readFileSync(path.join(root, 'web-dist/assets/index-hiHoGuoh.css'), 'utf8');
const appjs = fs.readFileSync(path.join(root, 'dist/app.js'), 'utf8');
const dbjs = fs.readFileSync(path.join(root, 'dist/database.js'), 'utf8');

await check('产物：API 客户端带 history()', async () => {
  assert.ok(bundle.includes('history:o=>ve("/api/history?limit="'), '缺少 history 方法');
});

await check('产物：书架有「历史」tab', async () => {
  assert.ok(bundle.includes('l("shelf.tabHistory","历史")'), '缺少历史 tab');
  assert.ok(bundle.includes('h==="__history__"'), '缺少历史分支条件');
  assert.ok(bundle.includes('function LrHist({items:hsItems'), '缺少历史列表组件');
  assert.ok(bundle.includes('h!=="__history__"&&t.jsx("div",{className:"shelf-subfilter-bar"'), '历史 tab 下状态筛选条没隐藏');
});

await check('产物：推送壳子时带书目元信息', async () => {
  assert.ok(bundle.includes('bookName:H.details&&H.details.name'), '推送没带书名');
  assert.ok(bundle.includes('tocUrl:H.details&&H.details.tocUrl'), '推送没带目录地址');
});

await check('产物：缓存面板只剩占用量 + 清理按钮', async () => {
  assert.ok(bundle.includes('cache-storage-card'), '缺少占用量卡片');
  assert.ok(!bundle.includes('lru-toggle-label'), 'LRU 开关还在');
  assert.ok(!bundle.includes('server-cache-section'), '服务端缓存区块还在');
  assert.ok(!bundle.includes('offline-book-row'), '离线书籍明细还在');
  assert.ok(bundle.includes('source.clearAllOffline'), '清空按钮被误删');
});

await check('样式：书架移动端适配 + 历史行 + 占用卡片', async () => {
  assert.ok(styles.includes('.shelf-page{gap:12px'), '缺少 1.6.0 样式块');
  assert.ok(/@media\(max-width:640px\)\{[^}]*\.shelf-page/.test(styles), '缺少移动端断点');
  assert.ok(styles.includes('.history-row{'), '缺少历史行样式');
  assert.ok(styles.includes('.cache-storage-card{'), '缺少占用卡片样式');
});

await check('样式：只保留简体中文（语言菜单已下线）', async () => {
  assert.ok(!styles.includes('.menu-lang-'), '语言菜单样式还在');
  assert.ok(!bundle.includes('legado-locale-v1'), '语言偏好存储键还在');
  assert.ok(!bundle.includes('getLocale'), 'getLocale 还在');
  assert.ok(bundle.includes('function er(){return"zh-CN"}'), 'er() 未固定为 zh-CN');
  assert.ok(!appjs.includes('/api/settings/locale'), '后端语言偏好路由还在');
});

await check('产物：历史行封面对空书名有兜底（不再崩在 slice）', async () => {
  assert.ok(!bundle.includes('children:l.slice(0,1)'), '封面组件还在直接对 name 取 slice');
  assert.ok(bundle.includes('children:(l||"书").slice(0,1)'), '封面组件缺少空书名兜底');
  assert.ok(!bundle.includes('o.details.name.slice(0,1)'), '详情页封面还在直接对 name 取 slice');
  assert.ok(!bundle.includes('ce.name.slice(0,1)'), '书架卡片封面还在直接对 name 取 slice');
});

await check('后端：book_history 表 + /api/history 路由', async () => {
  assert.ok(dbjs.includes('create table if not exists book_history'), '缺少 book_history 表');
  assert.ok(dbjs.includes('listHistory(limit = 300)'), '缺少 listHistory');
  assert.ok(appjs.includes("app.get('/api/history'"), '缺少 /api/history 路由');
});

async function freePort() {
  return await new Promise((resolve) => {
    const s = http.createServer();
    s.listen(0, '127.0.0.1', () => {
      const port = s.address().port;
      s.close(() => resolve(port));
    });
  });
}

async function waitHealth(port, timeoutMs = 25000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/healthz`);
      if (res.ok) return true;
    } catch {  }
    await new Promise((r) => setTimeout(r, 200));
  }
  return false;
}

async function api(port, method, pathname, body) {
  const res = await fetch(`http://127.0.0.1:${port}${pathname}`, {
    method,
    headers: body == null ? undefined : { 'Content-Type': 'application/json' },
    body: body == null ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = text;
  try { parsed = JSON.parse(text); } catch {  }
  return { status: res.status, body: parsed };
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'legado-history-'));
const port = await freePort();
const child = spawn(process.execPath, [path.join(root, 'dist/index.js')], {
  cwd: root,
  env: { ...process.env, LEGADO_DATA_DIR: tmp, LEGADO_HOST: '127.0.0.1', LEGADO_PORT: String(port) },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let logs = '';
child.stdout.on('data', (d) => { logs += String(d); });
child.stderr.on('data', (d) => { logs += String(d); });

let exitCode = 1;
try {
  if (!(await waitHealth(port))) throw new Error('后端没起来：\n' + logs);

  const sourceId = 'https://example.test';
  const inShelfUrl = `${sourceId}/book/1/`;
  const orphanUrl = `${sourceId}/book/2/`;

  await check('后端：入架的书能出现在历史里并标 inShelf', async () => {
    const added = await api(port, 'POST', '/api/bookshelf', {
      sourceId, bookUrl: inShelfUrl, name: '入架的书', tocUrl: inShelfUrl, author: '某作者',
    });
    assert.equal(added.status, 200, JSON.stringify(added.body));
    const put = await api(port, 'PUT', '/api/reading-progress', {
      sourceId, bookUrl: inShelfUrl, chapterUrl: inShelfUrl + '1.html', chapterIndex: 4,
      scrollPosition: 0.3, chapterTitle: '第5章',
    });
    assert.equal(put.status, 200, JSON.stringify(put.body));

    const list = await api(port, 'GET', '/api/history');
    assert.equal(list.status, 200, JSON.stringify(list.body));
    assert.ok(Array.isArray(list.body), '历史不是数组');
    const row = list.body.find((x) => x.bookUrl === inShelfUrl);
    assert.ok(row, '历史里没有这本书');
    assert.equal(row.name, '入架的书');
    assert.equal(row.inShelf, true, '入架的书 inShelf 应为 true');
    assert.equal(row.chapterIndex, 4);
    assert.equal(row.chapterTitle, '第5章');
  });

  await check('后端：没入架的书也能还原书名/封面（靠进度里的元信息）', async () => {
    const put = await api(port, 'PUT', '/api/reading-progress', {
      sourceId, bookUrl: orphanUrl, chapterUrl: '', chapterIndex: 1, scrollPosition: 0,
      bookName: '未入架的书', bookAuthor: '某某', coverUrl: 'https://example.test/c.jpg',
      tocUrl: orphanUrl, bookKind: 'novel',
    });
    assert.equal(put.status, 200, JSON.stringify(put.body));

    const list = await api(port, 'GET', '/api/history?limit=10');
    const row = list.body.find((x) => x.bookUrl === orphanUrl);
    assert.ok(row, '未入架的书没进历史');
    assert.equal(row.name, '未入架的书');
    assert.equal(row.author, '某某');
    assert.equal(row.coverUrl, 'https://example.test/c.jpg');
    assert.equal(row.inShelf, false, '未入架的书 inShelf 应为 false');
  });

  await check('后端：历史按最近阅读排序且 limit 生效', async () => {
    const list = await api(port, 'GET', '/api/history?limit=1');
    assert.equal(list.body.length, 1, 'limit=1 没生效');
    assert.equal(list.body[0].bookUrl, orphanUrl, '最近读的应排第一');
    const full = await api(port, 'GET', '/api/history');
    assert.ok(full.body.length >= 2);
    for (let i = 1; i < full.body.length; i++) {
      assert.ok(full.body[i - 1].lastReadAt >= full.body[i].lastReadAt, '排序不是最近优先');
    }
  });

  await check('后端：再读一次不会重复记两条', async () => {
    await api(port, 'PUT', '/api/reading-progress', {
      sourceId, bookUrl: orphanUrl, chapterUrl: '', chapterIndex: 2, scrollPosition: 0,
    });
    const list = await api(port, 'GET', '/api/history');
    const hits = list.body.filter((x) => x.bookUrl === orphanUrl);
    assert.equal(hits.length, 1, '同一本书出现了多条历史');
    assert.equal(hits[0].chapterIndex, 2);
    assert.equal(hits[0].name, '未入架的书', '再次阅读不该把已有书名清空');
  });

  await check('后端：进度里没有任何书名时，历史也不返回 null 书名', async () => {
    const bareUrl = `${sourceId}/book/3/`;
    const put = await api(port, 'PUT', '/api/reading-progress', {
      sourceId, bookUrl: bareUrl, chapterUrl: '', chapterIndex: 0, scrollPosition: 0,
    });
    assert.equal(put.status, 200, JSON.stringify(put.body));
    const list = await api(port, 'GET', '/api/history?limit=10');
    const row = list.body.find((x) => x.bookUrl === bareUrl);
    assert.ok(row, '没书名的记录没进历史');
    assert.equal(row.name, '未命名书籍', '空书名应兜底成「未命名书籍」，实际 ' + JSON.stringify(row.name));
    for (const item of list.body) {
      assert.ok(typeof item.name === 'string' && item.name !== '', '历史行书名不该为空：' + JSON.stringify(item.bookUrl));
    }
  });

  exitCode = 0;
} catch (e) {
  console.log('\n运行失败：' + (e instanceof Error ? e.message : String(e)));
  console.log(logs.slice(-800));
  exitCode = 1;
} finally {
  child.kill('SIGTERM');
  fs.rmSync(tmp, { recursive: true, force: true });
}

let failed = 0;
for (const [name, pass, msg] of results) {
  if (pass) console.log(`✓ ${name}`);
  else {
    failed++;
    console.log(`✗ ${name}\n    ${msg}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} 通过`);
process.exitCode = failed === 0 ? exitCode : 1;