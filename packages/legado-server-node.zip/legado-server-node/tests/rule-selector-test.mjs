
import { ruleCss, splitTopLevelCommas } from '../dist/ruleRunner.js';

const results = [];
const eq = (name, actual, expected) => results.push([actual === expected ? 'PASS' : 'FAIL', name, `${actual}${actual === expected ? '' : ' ≠ ' + expected}`]);

eq('顶层逗号切分', splitTopLevelCommas('a, b, c').join('|'), 'a|b|c');
eq('括号里的逗号不切', splitTopLevelCommas('a:not(.x, .y), b').join('|'), 'a:not(.x, .y)|b');
eq('方括号里的逗号不切', splitTopLevelCommas('a[title="x,y"], b').join('|'), 'a[title="x,y"]|b');
eq('属性选择器里的逗号', splitTopLevelCommas('[href^="/a,b"]').join('|'), '[href^="/a,b"]');

eq('普通链式', ruleCss('div.wrap@li@a'), 'div.wrap li a');
eq('最后一段多选带前缀', ruleCss('div.wrap.s-list@h3.catalog-title, li'),
  'div.wrap.s-list h3.catalog-title, div.wrap.s-list li');
eq('两段都多选', ruleCss('div.a, div.b@span, a'),
  'div.a span, div.a a, div.b span, div.b a');
eq('legado tag./class./id. 语法', ruleCss('class.book-list@tag.li@id.main'), '.book-list li #main');
eq('序号语法', ruleCss('class.list@li.0@a'), '.list li:nth-of-type(1) a');
eq('排除下标', ruleCss('li!0:2@text'.replace('@text', '')), 'li:not(:nth-child(1)):not(:nth-child(3))');
eq('取值段截断', ruleCss('div@a@href'), 'div a');

eq('恩施轻语 chapterList', ruleCss('#chapterList@a[data-title], p.non, summary'),
  '#chapterList a[data-title], #chapterList p.non, #chapterList summary');

console.log(results.map((r) => `${r[0]}  ${r[1]}  [${r[2]}]`).join('\n'));
const pass = results.filter((r) => r[0] === 'PASS').length;
console.log(`\n${pass}/${results.length} 通过`);
process.exit(pass === results.length ? 0 : 1);
