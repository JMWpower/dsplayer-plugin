#!/usr/bin/env node

import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const bridgeCode = fs.readFileSync(path.join(root, 'web-dist/lr-tvbox.js'), 'utf8');
const results = [];

async function check(name, fn) {
  try {
    await fn();
    results.push([name, true, '']);
  } catch (e) {
    results.push([name, false, e.message]);
  }
}

const sleep = (ms = 0) => new Promise((resolve) => setTimeout(resolve, ms));

function fakeElement(tag) {
  const el = {
    tagName: String(tag || 'div').toUpperCase(),
    id: '',
    textContent: '',
    innerHTML: '',
    style: { cssText: '' },
    listeners: {},
    children: [],
    addEventListener(type, fn) {
      (el.listeners[type] = el.listeners[type] || []).push(fn);
    },
    appendChild(child) {
      el.children.push(child);
      return child;
    },
    setAttribute() { },
    getAttribute() { return null; },
    closest() { return null; },
    remove() { },
  };
  return el;
}

function createSandbox(options = {}) {
  const listeners = {};
  const nodes = new Map();
  const calls = { fetch: [], pushes: [], messages: [] };

  class SandboxStorage {
    constructor(seed) {
      this.map = new Map(Object.entries(seed || {}));
    }
    getItem(key) {
      return this.map.has(key) ? this.map.get(key) : null;
    }
    setItem(key, value) {
      this.map.set(key, String(value));
    }
    removeItem(key) {
      this.map.delete(key);
    }
  }

  const location = {
    protocol: options.protocol || 'http:',
    origin: options.origin || 'http://127.0.0.1:5268',
    search: options.search || '',
    hash: options.hash || '#library',
    href: (options.origin || 'http://127.0.0.1:5268') + '/' + (options.search || ''),
    replaced: [],
    replace(target) { location.replaced.push(target); },
  };

  const body = fakeElement('body');
  const document = {
    readyState: 'complete',
    body,
    documentElement: fakeElement('html'),
    createElement(tag) { return fakeElement(tag); },
    getElementById(id) { return nodes.get(id) || null; },
    querySelector() { return null; },
    addEventListener() { },
  };
  body.appendChild = (child) => {
    if (child && child.id) nodes.set(child.id, child);
    body.children.push(child);
    return child;
  };

  const localStorage = new SandboxStorage(options.localStorage);
  const sessionStorage = new SandboxStorage(options.sessionStorage);

  const sandbox = {
    console,
    JSON,
    Math,
    Date,
    Promise,
    Map,
    Set,
    URLSearchParams,
    TextDecoder,
    Uint8Array,
    isFinite,
    atob,
    setTimeout,
    clearTimeout,
    requestAnimationFrame: (fn) => setTimeout(fn, 0),
    document,
    localStorage,
    sessionStorage,
    Storage: SandboxStorage,
    location,
    addEventListener(type, fn) {
      (listeners[type] = listeners[type] || []).push(fn);
    },
    removeEventListener(type, fn) {
      listeners[type] = (listeners[type] || []).filter((f) => f !== fn);
    },
    fetch: async (url, init) => {
      calls.fetch.push({ url, method: (init && init.method) || 'GET', body: init && init.body });
      const payload = (() => {
        if (url.includes('/api/tvbox/book-key/')) {
          const key = url.split('/').pop();
          return { key, s: 'https://src.test', b: 'https://src.test/book/1' };
        }
        if (url.endsWith('/api/tvbox/book-key')) return { ok: true };
        if (url.endsWith('/api/books/chapters')) return options.chapters || [];
        if (url.endsWith('/api/books/content')) {
          const body = JSON.parse((init && init.body) || '{}');
          return { title: '章节 ' + body.chapterUrl, content: '正文内容 ' + body.chapterUrl };
        }
        if (url.endsWith('/healthz')) return { status: 'ok' };
        return {};
      })();
      return {
        ok: true,
        status: 200,
        async text() { return JSON.stringify(payload); },
      };
    },
    __calls: calls,
  };
  sandbox.window = sandbox;
  sandbox.parent = sandbox;
  if (options.fm) {
    sandbox.fm = options.fm(calls);
    sandbox.window.fm = sandbox.fm;
  }
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  return { sandbox, calls, location, listeners, localStorage, sessionStorage };
}

function runBridge(sandbox) {
  vm.runInContext(bridgeCode, sandbox, { filename: 'lr-tvbox.js' });
}

function emitPush(env, detail) {
  const fns = env.listeners['lr-push-book'] || [];
  assert.ok(fns.length > 0, '桥没有监听 lr-push-book 事件');
  for (const fn of fns) fn({ type: 'lr-push-book', detail });
}

function toastText(env) {
  const el = env.sandbox.document.getElementById('lr-shell-toast');
  return el ? el.textContent : '';
}

function chaptersOf(count = 8) {
  return Array.from({ length: count }, (_v, i) => ({
    index: i,
    title: '第' + (i + 1) + '章',
    url: 'https://src.test/ch/' + (i + 1),
  }));
}

function bookPayload(bookUrl, chapters, index, bookKind = 'novel') {
  return {
    book: {
      details: {
        sourceId: 'https://src.test',
        name: '测试书',
        author: '作者',
        coverUrl: 'https://img.test/c.jpg',
        tocUrl: bookUrl + '/toc',
        bookKind,
      },
      bookUrl,
      chapters,
      bookKind,
    },
    index,
  };
}

await check('壳子模式：点开第 4 章也推送整本目录', async () => {
  const chapters = chaptersOf(8);
  const env = createSandbox({
    search: '?lr_shell=1',
    fm: (calls) => ({
      vodInline: async (spec) => {
        calls.pushes.push(spec);
        return { ok: true };
      },
    }),
  });
  runBridge(env.sandbox);
  await sleep(1);

  emitPush(env, bookPayload('https://src.test/book/1', chapters, 3));
  await sleep(20);

  assert.equal(env.calls.pushes.length, 1, '应该推送一次');
  const spec = env.calls.pushes[0];
  assert.equal(spec.format, 'novel');
  assert.equal(spec.vod_name, '测试书');
  assert.equal(spec.episodes.length, chapters.length, '目录要整本推送，不是只推当前章');
  assert.equal(spec.mark, '第4章', 'mark 应指向点开的那一章');
  assert.equal(typeof spec.vod_play_url, 'string', '老壳子要的 vod_play_url 也应带上');
  assert.equal(spec.vod_play_url.split('#').length, chapters.length);
  for (const [i, episode] of spec.episodes.entries()) {
    assert.match(episode.url, /^lr:\/\/b\/[a-z0-9]{12}\/\d+$/i, '第 ' + i + ' 集地址不是短键哨兵：' + episode.url);
    assert.equal(episode.url.split('/').pop(), String(i));
    assert.equal(episode.resolve, true);
    assert.equal(episode.format, 'novel');
  }
  const keyCall = env.calls.fetch.find((c) => c.url.endsWith('/api/tvbox/book-key'));
  assert.ok(keyCall, '应把短键登记到后端');
  assert.deepEqual(JSON.parse(keyCall.body), { sourceId: 'https://src.test', bookUrl: 'https://src.test/book/1' });
});

await check('壳子取章顺手回写阅读进度', async () => {
  const chapters = chaptersOf(6);
  const env = createSandbox({ search: '?lr_shell=1', chapters });
  runBridge(env.sandbox);
  await sleep(1);

  const index = 2;
  const keyCall = { url: 'lr://b/abc123def456/' + index };
  const text = await env.sandbox.window.DL.resolveEpisode(keyCall.url);
  await sleep(20);

  assert.match(text, /正文内容/, '应返回正文，实际：' + String(text).slice(0, 60));
  const put = env.calls.fetch.find((c) => c.url.endsWith('/api/reading-progress') && c.method === 'PUT');
  assert.ok(put, '取到正文后应回写阅读进度，实际请求：' + env.calls.fetch.map((c) => c.method + ' ' + c.url).join(' | '));
  const body = JSON.parse(put.body);
  assert.equal(body.chapterIndex, index, '回写的章节序号不对：' + body.chapterIndex);
  assert.equal(body.chapterUrl, chapters[index].url, '回写的章节地址不对：' + body.chapterUrl);
  assert.equal(body.bookUrl, 'https://src.test/book/1');
});

await check('壳子回写进度时带上书名/目录/封面（历史里不显示未命名）', async () => {
  const chapters = chaptersOf(6);
  const env = createSandbox({
    search: '?lr_shell=1',
    chapters,
    fm: (calls) => ({ vodInline: async (spec) => { calls.pushes.push(spec); } }),
  });
  runBridge(env.sandbox);
  await sleep(1);

  emitPush(env, bookPayload('https://src.test/book/9', chapters, 2));
  await sleep(20);
  assert.equal(env.calls.pushes.length, 1, '推动作没发生');
  await env.sandbox.window.DL.resolveEpisode(env.calls.pushes[0].episodes[2].url);
  await sleep(60);

  const puts = env.calls.fetch.filter((c) => c.url.endsWith('/api/reading-progress') && c.method === 'PUT');
  assert.equal(puts.length, 1, '应只回写一次进度，实际 ' + puts.length);
  const body = JSON.parse(puts[0].body);
  assert.equal(body.chapterIndex, 2);
  assert.equal(body.bookName, '测试书', '回写缺书名，实际 ' + JSON.stringify(body.bookName));
  assert.equal(body.tocUrl, 'https://src.test/book/9/toc');
  assert.equal(body.coverUrl, 'https://img.test/c.jpg');
  assert.equal(body.bookKind, 'novel');
});

await check('壳子预取后续章节不把进度顶上去', async () => {
  const chapters = chaptersOf(8);
  const env = createSandbox({ search: '?lr_shell=1', chapters });
  runBridge(env.sandbox);
  await sleep(1);

  await env.sandbox.window.DL.resolveEpisode('lr://b/abc123def456/3');
  await env.sandbox.window.DL.resolveEpisode('lr://b/abc123def456/4');
  await env.sandbox.window.DL.resolveEpisode('lr://b/abc123def456/5');
  await sleep(60);

  const puts = env.calls.fetch.filter((c) => c.url.endsWith('/api/reading-progress') && c.method === 'PUT');
  assert.equal(puts.length, 1, '一轮预取只应回写一次进度，实际 ' + puts.length + ' 次');
  const body = JSON.parse(puts[0].body);
  assert.equal(body.chapterIndex, 3, '应记用户点开的第 3 章，实际 ' + body.chapterIndex);
  assert.equal(body.chapterUrl, chapters[3].url);
});

await check('壳子模式：没带目录时自己去拉再推', async () => {
  const chapters = chaptersOf(5);
  const env = createSandbox({
    search: '?lr_shell=1',
    chapters,
    fm: (calls) => ({ vodInline: async (spec) => { calls.pushes.push(spec); } }),
  });
  runBridge(env.sandbox);
  await sleep(1);
  const payload = bookPayload('https://src.test/book/2', [], 2);
  emitPush(env, payload);
  await sleep(30);

  assert.equal(env.calls.pushes.length, 1);
  assert.equal(env.calls.pushes[0].episodes.length, 5, '应回源拉目录');
  assert.equal(env.calls.pushes[0].mark, '第3章');
});

await check('壳子模式：哨兵能按序号取回正文', async () => {
  const chapters = chaptersOf(8);
  const env = createSandbox({
    search: '?lr_shell=1',
    fm: (calls) => ({ vodInline: async (spec) => { calls.pushes.push(spec); } }),
  });
  runBridge(env.sandbox);
  await sleep(1);
  emitPush(env, bookPayload('https://src.test/book/1', chapters, 0));
  await sleep(20);

  const sentinel = env.calls.pushes[0].episodes[5].url;
  const payload = await env.sandbox.window.DL.resolveEpisode(sentinel);
  assert.ok(payload.startsWith('novel://'), '应返回 novel:// 负载');
  const parsed = JSON.parse(payload.slice('novel://'.length));
  assert.equal(parsed.title, '章节 https://src.test/ch/6');
  assert.ok(parsed.content.includes('https://src.test/ch/6'));
});

await check('壳子只有 fm.play 时退化成单章推送', async () => {
  const chapters = chaptersOf(3);
  const env = createSandbox({
    search: '?lr_shell=1',
    chapters,
    fm: (calls) => ({
      play: async (payload, title) => { calls.pushes.push({ payload, title }); },
    }),
  });
  runBridge(env.sandbox);
  await sleep(1);
  emitPush(env, bookPayload('https://src.test/book/1', chapters, 1));
  await sleep(30);

  assert.equal(env.calls.pushes.length, 1);
  assert.equal(env.calls.pushes[0].title, '章节 https://src.test/ch/2');
  assert.ok(String(env.calls.pushes[0].payload).startsWith('novel://'));
});

await check('壳子模式：任意一章点开都是整本目录（首 / 中 / 末）', async () => {
  const chapters = chaptersOf(12);
  for (const index of [0, 5, 11]) {
    const env = createSandbox({
      search: '?lr_shell=1',
      fm: (calls) => ({ vodInline: async (spec) => { calls.pushes.push(spec); } }),
    });
    runBridge(env.sandbox);
    await sleep(1);
    emitPush(env, bookPayload('https://src.test/book/1', chapters, index));
    await sleep(20);

    const label = '第 ' + (index + 1) + ' 章';
    assert.equal(env.calls.pushes.length, 1, label + '点开没有推送');
    const spec = env.calls.pushes[0];
    assert.equal(spec.episodes.length, chapters.length,
      label + '点开只推了 ' + spec.episodes.length + '/' + chapters.length + ' 章');
    assert.equal(spec.mark, '第' + (index + 1) + '章', label + '的 mark 不对：' + spec.mark);
  }
});

await check('漫画 / 有声书也走推送（网页阅读器已下线）', async () => {
  const chapters = chaptersOf(2);
  for (const kind of ['comic', 'audio']) {
    const env = createSandbox({
      search: '?lr_shell=1',
      fm: (calls) => ({ vodInline: async (spec) => { calls.pushes.push(spec); } }),
    });
    runBridge(env.sandbox);
    await sleep(1);
    emitPush(env, bookPayload('https://src.test/book/1', chapters, 0, kind));
    await sleep(20);
    assert.equal(env.calls.pushes.length, 1, kind + ' 应当也推给壳子');
    assert.equal(env.calls.pushes[0].episodes.length, 2);
  }
});

await check('普通浏览器：不推送，只提示去壳子里用', async () => {
  const env = createSandbox({ search: '', fm: null });
  runBridge(env.sandbox);
  await sleep(1);
  emitPush(env, bookPayload('https://src.test/book/1', chaptersOf(4), 2));
  await sleep(20);

  assert.equal(env.calls.pushes.length, 0, '没有壳子播放器时不该推送');
  assert.equal(env.calls.fetch.length, 0, '不该偷偷打后端接口');
  assert.match(toastText(env), /壳子/, '应提示用壳子打开，实际：' + toastText(env));
});

await check('桥脚本里不再有网页阅读器的退路', async () => {
  assert.ok(!bridgeCode.includes('legado-open-book-v1'), '不该再依赖 sessionStorage 交接键');
  assert.ok(!bridgeCode.includes('#reader'), '不该再操作 #reader 路由');
  assert.ok(!bridgeCode.includes('改用网页阅读'), '不该再有「改用网页阅读」按钮');
  assert.ok(bridgeCode.includes('lr-push-book'), '应监听推送事件');
});

let failed = 0;
for (const [name, ok, detail] of results) {
  console.log(`${ok ? '✓' : '✗'} ${name}${ok ? '' : ' —— ' + detail}`);
  if (!ok) failed++;
}
console.log(`\n${results.length - failed}/${results.length} 通过`);
process.exit(failed === 0 ? 0 : 1);