
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
let chromium = null;
const pwModule = process.env.PLAYWRIGHT_MODULE || 'playwright';
try {
  ({ chromium } = require(pwModule));
} catch {
  console.log('跳过：没装 playwright');
  process.exit(0);
}

const BASE = (process.env.BASE || 'http://127.0.0.1:5268').replace(/\/+$/, '');
const results = [];
const check = (name, cond, extra) => results.push([cond ? 'PASS' : 'FAIL', name, extra || '']);

await fetch(BASE + '/api/settings/locale', {
  method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ locale: 'zh-CN' }),
}).catch(() => { });

const sources = await (await fetch(BASE + '/api/explore/sources')).json();
if (!Array.isArray(sources) || sources.length < 2) {
  console.log('跳过：后端没有可用的发现页书源（先把书源导进去）');
  process.exit(0);
}

async function chainOk(src) {
  try {
    const cats = await (await fetch(`${BASE}/api/explore/categories?id=${encodeURIComponent(src.id)}`)).json();
    const flat = [];
    (function walk(list) {
      for (const c of list || []) {
        if (c.url && String(c.url).trim()) flat.push(c);
        if (c.subCategories) walk(c.subCategories);
      }
    })(Array.isArray(cats) ? cats : []);
    for (const c of flat.slice(0, 3)) {
      const r = await fetch(`${BASE}/api/explore/books?id=${encodeURIComponent(src.id)}&url=${encodeURIComponent(c.url)}&page=1`);
      if (!r.ok) continue;
      const books = await r.json();
      if (Array.isArray(books) && books.length) return { src, url: c.url };
    }
  } catch {  }
  return null;
}

const good = [];
for (const s of sources) {
  if (good.length >= 2) break;
  const hit = await chainOk(s);
  if (hit) good.push(hit);
}
if (good.length < 2) {
  console.log('跳过：找不到两个能出书的书源（当前网络对源站不友好），只做静态检查');
}
const [A, B] = good;

const LAUNCH = { args: ['--no-sandbox', '--disable-dev-shm-usage'] };
if (process.env.CHROMIUM_PATH) LAUNCH.executablePath = process.env.CHROMIUM_PATH;
const browser = await chromium.launch(LAUNCH);
const page = await browser.newPage({ viewport: { width: 1360, height: 900 } });
const reqs = [];
page.on('response', (r) => {
  const u = r.url();
  if (u.includes('/api/explore/books')) reqs.push({ url: u, status: r.status() });
});
const errs = [];
page.on('pageerror', (e) => errs.push(String(e).slice(0, 200)));

async function openExplore() {
  await page.getByRole('button', { name: /发现|Explore/ }).first().click();
  await page.waitForTimeout(1800);
}
async function pick(name) {
  await page.click('.explore-source-trigger');
  await page.waitForTimeout(300);
  await page.locator('.explore-source-option', { hasText: name }).first().click();
  const start = Date.now();
  while (Date.now() - start < 20000) {
    if (await page.locator('.explore-book-name').count() > 0) break;
    await page.waitForTimeout(400);
  }
}

await page.goto(BASE + '/', { waitUntil: 'networkidle', timeout: 90000 });
await openExplore();

if (good.length === 2) {
  await pick(A.src.name);
  const n1 = await page.locator('.explore-book-name').count();
  check('切到书源 A 能出书', n1 > 0, A.src.name + ' ' + n1 + ' 本');

  await pick(B.src.name);
  const n2 = await page.locator('.explore-book-name').count();
  check('切到书源 B 能出书', n2 > 0, B.src.name + ' ' + n2 + ' 本');

  const catCache = {};
  async function catsOf(id) {
    if (catCache[id]) return catCache[id];
    const cats = await (await fetch(`${BASE}/api/explore/categories?id=${encodeURIComponent(id)}`)).json();
    const set = new Set();
    (function walk(list) {
      for (const c of list || []) {
        if (c.url) set.add(String(c.url));
        if (c.subCategories) walk(c.subCategories);
      }
    })(Array.isArray(cats) ? cats : []);
    catCache[id] = set;
    return set;
  }
  let mismatched = 0;
  for (const r of reqs) {
    const u = new URL(r.url);
    const id = u.searchParams.get('id');
    const url = u.searchParams.get('url');
    if (!id || !url) continue;
    const set = await catsOf(id);
    if (set.size && !set.has(url)) mismatched++;
  }
  check('切换书源时没有拿旧分类地址去请求（无 404 根因）', mismatched === 0, mismatched + ' 次错配');

  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForTimeout(1500);
  await openExplore();
  const remembered = await page.locator('.explore-source-trigger-name').innerText();
  check('刷新后仍记得上次选的源', remembered === B.src.name, remembered + ' / 期望 ' + B.src.name);
} else {
  check('发现页能打开', (await page.locator('.explore-source-trigger').count()) === 1);
}

check('页面无 JS 异常', errs.length === 0, errs.join(' | '));

await browser.close();
console.log(results.map((r) => `${r[0]}  ${r[1]}${r[2] ? '  [' + r[2] + ']' : ''}`).join('\n'));
const pass = results.filter((r) => r[0] === 'PASS').length;
console.log(`\n${pass}/${results.length} 通过`);
process.exit(pass === results.length ? 0 : 1);
