
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const BASE = (process.env.BASE || 'http://127.0.0.1:5268').replace(/\/+$/, '');
const args = process.argv.slice(2);
function argOf(name, def) {
  const i = args.indexOf('--' + name);
  return i >= 0 && args[i + 1] ? args[i + 1] : def;
}
const SOURCES_FILE = argOf('sources', '');
const SUCCESS_GOAL = Number.parseInt(argOf('goal', '2'), 10) || 2;
const MAX_TRY = Number.parseInt(argOf('limit', '25'), 10) || 25;

const results = [];
function check(name, cond, extra) { results.push([cond ? 'PASS' : 'FAIL', name, extra || '']); }
function note(name, extra) { results.push(['INFO', name, extra || '']); }

async function req(pathname, opt = {}) {
  const res = await fetch(BASE + pathname, {
    method: opt.method || 'GET',
    headers: opt.body != null ? { 'content-type': 'application/json' } : undefined,
    body: opt.body != null ? JSON.stringify(opt.body) : undefined,
    signal: AbortSignal.timeout(opt.timeout || 60000),
  });
  const text = await res.text();
  let body = text;
  try { body = JSON.parse(text); } catch {  }
  return { ok: res.ok, status: res.status, body };
}

const health = await req('/healthz');
check('服务健康检查', health.ok && health.body.status === 'ok', JSON.stringify(health.body));

const page = await req('/tvbox.html');
const pageText = typeof page.body === 'string' ? page.body : '';

check('tvbox.html 是壳子入口（跳转到 Web 页面）', page.ok && pageText.includes('lr_shell=1'),
  pageText.length + ' 字节');
const bridge = await req('/lr-tvbox.js');
const bridgeText = typeof bridge.body === 'string' ? bridge.body : '';
check('壳子桥脚本可访问（哨兵解析 + 整本推送）',
  bridge.ok && bridgeText.includes('resolveEpisode') && bridgeText.includes('vodInline'),
  bridgeText.length + ' 字节');
const appPage = await req('/');
const appText = typeof appPage.body === 'string' ? appPage.body : '';
check('Web 页面加载了壳子桥（阅读推送到壳子）', appPage.ok && appText.includes('/lr-tvbox.js'));

if (SOURCES_FILE) {
  if (!fs.existsSync(SOURCES_FILE)) {
    check('书源文件存在', false, SOURCES_FILE);
  } else {
    const content = fs.readFileSync(SOURCES_FILE, 'utf8');
    const prev = await req('/api/sources/import-json/preview', { method: 'POST', body: { content, label: path.basename(SOURCES_FILE) } });
    check('书源预览解析', prev.ok && prev.body.total > 0, `总 ${prev.body.total} / 新增 ${prev.body.newCount} / 更新 ${prev.body.updateCount} / 无效 ${prev.body.invalidCount}`);
    const commit = await req('/api/sources/import-url/commit', { method: 'POST', body: { token: prev.body.token } });
    check('书源导入提交', commit.ok && (commit.body.imported + commit.body.updated) > 0,
      `新增 ${commit.body.imported} / 更新 ${commit.body.updated} / 错误 ${(commit.body.errors || []).length}`);
  }
}
const sources = await req('/api/sources');
check('书源列表可用', Array.isArray(sources.body) && sources.body.length > 0, (sources.body || []).length + ' 个');

const explore = await req('/api/explore/sources');
const exploreList = Array.isArray(explore.body) ? explore.body : [];
check('发现页书源列表', exploreList.length > 0, exploreList.length + ' 个支持发现页');

function firstCat(list) {
  for (const c of list || []) {
    if (c.url && String(c.url).trim()) return c;
    if (c.subCategories && c.subCategories.length) {
      const r = firstCat(c.subCategories);
      if (r) return r;
    }
  }
  return null;
}

let okChain = 0;
let tried = 0;
const failures = [];

function flatCats(list, out) {
  out = out || [];
  for (const c of list || []) {
    if (c.url && String(c.url).trim()) out.push(c);
    if (c.subCategories && c.subCategories.length) flatCats(c.subCategories, out);
  }
  return out;
}

for (const src of exploreList) {
  if (tried >= MAX_TRY || okChain >= SUCCESS_GOAL) break;
  tried++;
  try {
    const cats = await req(`/api/explore/categories?id=${encodeURIComponent(src.id)}`, { timeout: 50000 });
    if (!cats.ok || !Array.isArray(cats.body)) { failures.push(`${src.name}: 分类 ${cats.status}`); continue; }
    const catList = flatCats(cats.body).slice(0, 3);
    if (!catList.length) { failures.push(`${src.name}: 无可用分类`); continue; }

    let picked = null, books = null;
    for (const cat of catList) {
      const r = await req(`/api/explore/books?id=${encodeURIComponent(src.id)}&url=${encodeURIComponent(cat.url)}&page=1`, { timeout: 60000 });
      if (r.ok && Array.isArray(r.body) && r.body.length) { picked = cat; books = r.body; break; }
    }
    if (!picked) { failures.push(`${src.name}: 分类都取不到书`); continue; }

    const book = books[0];
    const details = await req('/api/books/details', { method: 'POST', body: { sourceId: book.sourceId, bookUrl: book.bookUrl }, timeout: 60000 });
    if (!details.ok) { failures.push(`${src.name}: 详情 ${details.status}`); continue; }
    const chapters = await req('/api/books/chapters', {
      method: 'POST',
      body: { sourceId: book.sourceId, bookUrl: book.bookUrl, tocUrl: details.body.tocUrl },
      timeout: 70000,
    });
    if (!chapters.ok || !Array.isArray(chapters.body) || chapters.body.length === 0) {
      failures.push(`${src.name}: 目录 ${chapters.status}`); continue;
    }
    const ch = chapters.body[0];
    const content = await req('/api/books/content', {
      method: 'POST',
      body: { sourceId: book.sourceId, bookUrl: book.bookUrl, chapterUrl: ch.url },
      timeout: 70000,
    });
    const chars = content.ok && content.body.content ? String(content.body.content).length : 0;
    if (chars < 100) { failures.push(`${src.name}: 正文 ${content.status} ${chars} 字`); continue; }
    okChain++;
    note(`链路 OK · ${src.name}`, `书源 ${cats.body.length} 分类 / ${books.length} 本 / 《${details.body.name}》/ 目录 ${chapters.body.length} 章 / 正文 ${chars} 字`);
  } catch (e) {
    failures.push(`${src.name}: ${e.message}`);
  }
}
check(`真实源全链路（试了 ${tried} 个，跑通 ${okChain} 个）`, okChain >= 1, `目标 ${SUCCESS_GOAL} 个`);
if (failures.length) note('抽样中失败的源（多为站方 403 / 域名失效）', failures.slice(0, 8).join('； '));

const localList = await req('/api/local-books');
const bookDir = localList.ok ? localList.body.dir : '';
check('拿到 book 文件夹', !!bookDir, bookDir);
if (bookDir) {
  const name = `链路测试-${Date.now()}.txt`;
  const file = path.join(bookDir, name);
  const lines = [];
  for (let i = 1; i <= 800; i++) {
    lines.push(`第${i}章 链路测试章节${i}`);
    lines.push('这是正文内容，用来验证目录与正文是不是都能取到。'.repeat(3));
  }
  fs.writeFileSync(file, lines.join('\n\n'), 'utf8');
  const imported = await req('/api/local-books/import', { method: 'POST', body: {}, timeout: 120000 });
  const hit = (imported.body.results || []).find((r) => r.fileName === name);
  check('本地 TXT 扫描导入', !!hit && hit.success, hit ? `${hit.name} ${hit.totalChapters} 章` : '没导入成功');
  if (hit && hit.success) {
    const chs = await req('/api/books/chapters', { method: 'POST', body: { sourceId: 'loc_book', bookUrl: hit.bookUrl }, timeout: 60000 });
    check('本地书目录完整（800 章）', Array.isArray(chs.body) && chs.body.length === 800, Array.isArray(chs.body) ? chs.body.length + ' 章' : JSON.stringify(chs.body).slice(0, 80));
    if (Array.isArray(chs.body) && chs.body.length) {
      const first = await req('/api/books/content', { method: 'POST', body: { sourceId: 'loc_book', bookUrl: hit.bookUrl, chapterUrl: chs.body[0].url } });
      const last = await req('/api/books/content', { method: 'POST', body: { sourceId: 'loc_book', bookUrl: hit.bookUrl, chapterUrl: chs.body[799].url } });
      check('本地书首章正文', first.ok && String(first.body.content || '').length > 20, String(first.body.title || ''));
      check('本地书末章正文', last.ok && String(last.body.content || '').length > 20, String(last.body.title || ''));
      note('本地书章节 URL 唯一性', new Set(chs.body.map((c) => c.url)).size === chs.body.length ? '唯一' : '有重复');
    }

    await req('/api/bookshelf', { method: 'DELETE', body: { sourceId: 'loc_book', bookUrl: hit.bookUrl } });
    try { fs.unlinkSync(file); } catch {  }
  }
}

const keyRes = await req('/api/tvbox/book-key', { method: 'POST', body: { sourceId: 'src://demo', bookUrl: 'http://example.com/book/1' } });
check('短书标识写入', keyRes.ok && typeof keyRes.body.key === 'string' && keyRes.body.key.length === 12, keyRes.body.key);
if (keyRes.ok && keyRes.body.key) {
  const back = await req('/api/tvbox/book-key/' + keyRes.body.key);
  check('短书标识回查', back.ok && back.body.b === 'http://example.com/book/1', JSON.stringify(back.body).slice(0, 90));
}
const miss = await req('/api/tvbox/book-key/aaaaaaaaaaaa');
check('未知短书标识返回 404', miss.status === 404, String(miss.status));

console.log(results.map((r) => `${r[0].padEnd(4)} ${r[1]}${r[2] ? '  [' + r[2] + ']' : ''}`).join('\n'));
const pass = results.filter((r) => r[0] === 'PASS').length;
const fail = results.filter((r) => r[0] === 'FAIL').length;
console.log(`\n${pass} 通过 / ${fail} 失败`);
process.exit(fail === 0 ? 0 : 1);