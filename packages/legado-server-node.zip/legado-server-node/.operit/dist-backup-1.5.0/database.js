import Database from 'better-sqlite3';
import { SourceCodec } from './sourceCodec.js';
/**
 * SQLite DDL —— 逐字保留 Kotlin 版 DatabaseSchema.SQLITE_DDL，
 * 保证 Node 版与 Kotlin 版可共用同一个数据目录（同一数据库文件、同一缓存布局）。
 */
export const SQLITE_DDL = `
create table if not exists source (
  id text primary key, name text not null, source_url text not null,
  source_group text, enabled integer not null, is_js integer not null,
  payload text not null, version integer not null, updated_at integer not null
);
create index if not exists source_name_idx on source(name);
create index if not exists idx_source_name_nocase on source(name collate nocase);
create table if not exists reading_progress (
  source_id text not null, book_url text not null, chapter_url text not null,
  chapter_index integer not null, updated_at integer not null,
  scroll_position real not null default 0,
  position_ms integer,
  chapter_title text,
  book_kind text,
  primary key (source_id, book_url)
);
create table if not exists cover_cache (
  cache_key text primary key, content_type text not null,
  file_path text not null default ''
);
create table if not exists app_setting (
  key text primary key, value text not null, updated_at integer not null
);
create table if not exists book_group (
  id integer primary key autoincrement,
  name text not null unique collate nocase,
  sort_order integer not null default 0,
  is_private integer not null default 0,
  created_at integer not null
);
create index if not exists idx_book_group_sort on book_group(sort_order asc, id asc);
create table if not exists bookmark (
  id integer primary key autoincrement,
  book_name text not null,
  book_author text,
  chapter_index integer not null default 0,
  chapter_name text,
  chapter_pos integer not null default 0,
  book_text text,
  content text,
  created_at integer not null,
  unique(book_name, book_author, chapter_index, chapter_pos)
);
create index if not exists idx_bookmark_book on bookmark(book_name, book_author);
create table if not exists book_cover (
  book_name text not null,
  book_author text not null default '',
  cover_key text,
  missing_attempts integer not null default 0,
  last_attempt_at integer not null default 0,
  updated_at integer not null default 0,
  primary key (book_name, book_author)
);
create table if not exists book_shelf (
  source_id text not null, book_url text not null, name text not null,
  author text, toc_url text not null, cover_url text, cover_key text,
  last_read_at integer not null, completed integer not null default 0,
  alternate_sources text, group_name text, book_kind text, variable text,
  primary key (source_id, book_url)
);
create index if not exists book_shelf_last_read_idx on book_shelf(last_read_at desc);
create table if not exists book_content_cache (
  source_id text not null, book_url text not null, chapter_url text not null,
  title text, content text not null, cached_at integer not null,
  raw_title text, raw_content text,
  primary key (source_id, book_url, chapter_url)
);
create index if not exists book_content_cache_book_idx on book_content_cache(source_id, book_url);
create table if not exists book_cache_status (
  source_id text not null, book_url text not null, total_chapters integer not null default 0,
  cached_chapters integer not null default 0, state text not null default 'idle',
  last_error text, updated_at integer not null,
  primary key (source_id, book_url)
);
create table if not exists rss_source (
  id text primary key, name text not null, icon text, source_group text,
  enabled integer not null default 1, single_url integer not null default 0,
  sort_url text, custom_order integer not null default 0,
  payload text not null, updated_at integer not null
);
create table if not exists book_toc_cache (
  source_id text not null, toc_url text not null, chapters_json text not null, updated_at integer not null,
  primary key (source_id, toc_url)
);
create table if not exists book_chapter_index (
  source_id text not null, book_url text not null, chapter_url text not null,
  chapter_index integer not null, title text not null,
  primary key (source_id, book_url, chapter_url)
);
create index if not exists book_chapter_index_title_idx on book_chapter_index(lower(title));
create index if not exists book_shelf_name_ci_idx on book_shelf(lower(name));
create index if not exists book_shelf_author_ci_idx on book_shelf(lower(coalesce(author, '')));
create table if not exists source_login_state (
  source_id text primary key,
  login_info text,
  login_header text,
  source_variable text,
  source_kv text,
  cookie_jar text,
  updated_at integer not null
);
create table if not exists http_tts (
  id integer primary key,
  name text not null,
  url text not null,
  header text,
  content_type text,
  concurrent_rate text,
  login_url text,
  login_check_js text,
  login_ui text,
  js_lib text,
  enabled_cookie_jar integer not null default 0,
  last_update_time integer not null
);
create index if not exists idx_http_tts_name on http_tts(name);
create table if not exists manga_chapter_cache (
  source_id     text not null,
  book_url      text not null,
  chapter_url   text not null,
  chapter_index integer not null default 0,
  pinned        integer not null default 0,
  images_json   text not null,
  total         integer not null default 0,
  ready         integer not null default 0,
  skipped       integer not null default 0,
  state         text not null default 'pending',
  last_error    text,
  created_at    integer not null,
  updated_at    integer not null,
  primary key (source_id, book_url, chapter_url)
);
create index if not exists idx_manga_chapter_state on manga_chapter_cache(source_id, book_url, state);
create index if not exists idx_manga_chapter_pinned on manga_chapter_cache(pinned);
create table if not exists manga_image_cache (
  url_hash       text primary key,
  cache_key      text not null default '',
  source_id      text not null,
  book_url       text not null,
  chapter_url    text not null,
  chapter_index  integer not null default 0,
  segment_index  integer not null default 0,
  upstream_url   text not null,
  content_type   text not null default '',
  byte_size      integer not null default 0,
  width          integer,
  height         integer,
  state          text not null default 'pending',
  last_error     text,
  created_at     integer not null,
  last_access_at integer not null,
  file_path      text not null default ''
);
create index if not exists idx_manga_image_key on manga_image_cache(cache_key);
create index if not exists idx_manga_image_book on manga_image_cache(source_id, book_url);
create index if not exists idx_manga_image_chapter on manga_image_cache(source_id, book_url, chapter_url, segment_index);
create index if not exists idx_manga_image_access on manga_image_cache(last_access_at asc);
create table if not exists audio_cache (
  cache_key      text primary key,
  source_id      text not null,
  book_url       text not null,
  chapter_url    text not null,
  chapter_index  integer not null default 0,
  segment_index  integer not null default 0,
  upstream_url   text not null,
  headers_json   text,
  content_type   text not null default '',
  byte_size      integer not null default 0,
  duration_ms    integer not null default 0,
  state          text not null default 'pending',
  last_error     text,
  pinned         integer not null default 0,
  listened       integer not null default 0,
  created_at     integer not null,
  last_access_at integer not null,
  file_path      text not null default ''
);
create index if not exists idx_audio_cache_segment on audio_cache(source_id, book_url, chapter_url, segment_index);
create index if not exists idx_audio_cache_book on audio_cache(source_id, book_url);
create index if not exists idx_audio_cache_state on audio_cache(state);
create index if not exists idx_audio_cache_access on audio_cache(last_access_at asc);
create index if not exists idx_audio_cache_pinned on audio_cache(pinned);
create table if not exists illustration_cache (
  url_hash       text primary key,
  source_id      text not null,
  book_url       text not null default '',
  chapter_url    text not null default '',
  chapter_index  integer not null default 0,
  segment_index  integer not null default 0,
  upstream_url   text not null,
  content_type   text not null default '',
  byte_size      integer not null default 0,
  cache_key      text not null default '',
  state          text not null default 'pending',
  created_at     integer not null,
  last_access_at integer not null,
  file_path      text not null default ''
);
create index if not exists idx_illustration_chapter on illustration_cache(source_id, book_url, chapter_url, segment_index);
create index if not exists idx_illustration_book on illustration_cache(source_id, book_url);
`;
export class VersionConflict extends Error {
}
export const CUSTOM_VARIABLE_KEY = 'custom';
function now() { return Date.now(); }
function rows(stmt, ...params) {
    return stmt.all(...params);
}
function jsonParse(text, fallback) {
    if (text == null || text.trim() === '')
        return fallback;
    try {
        return JSON.parse(text);
    }
    catch {
        return fallback;
    }
}
export class Db {
    databasePath;
    db;
    constructor(databasePath) {
        this.databasePath = databasePath;
        this.db = new Database(databasePath);
        this.db.pragma('journal_mode = WAL');
        this.db.pragma('busy_timeout = 5000');
        this.db.pragma('foreign_keys = ON');
    }
    initialize() {
        this.db.exec(SQLITE_DDL);
    }
    close() { this.db.close(); }
    // ---------------- 设置 ----------------
    getSetting(key) {
        const row = this.db.prepare('select value from app_setting where key = ?').get(key);
        return row?.value ?? null;
    }
    setSetting(key, value) {
        this.db.prepare('insert into app_setting(key, value, updated_at) values (?, ?, ?) on conflict(key) do update set value = excluded.value, updated_at = excluded.updated_at').run(key, value, now());
    }
    // ---------------- 书源 ----------------
    listSources(query) {
        const like = `%${(query ?? '').trim().toLowerCase()}%`;
        const sql = query && query.trim() !== ''
            ? `select id, name, source_url as url, source_group as "group", enabled, is_js, payload, version, updated_at
         from source where lower(name) like ? or lower(source_url) like ? or lower(coalesce(source_group, '')) like ? order by name collate nocase`
            : `select id, name, source_url as url, source_group as "group", enabled, is_js, payload, version, updated_at from source order by name collate nocase`;
        const params = query && query.trim() !== '' ? [like, like, like] : [];
        const raw = rows(this.db.prepare(sql), ...params);
        return raw.map((r) => this.toSourceSummary(r));
    }
    toSourceSummary(r) {
        const payload = r['payload'];
        const obj = jsonParse(payload, {});
        const hasLogin = (typeof obj['loginUi'] === 'string' && obj['loginUi'] !== '') ||
            (typeof obj['loginUrl'] === 'string' && obj['loginUrl'] !== '') ||
            (typeof obj['loginCheckJs'] === 'string' && obj['loginCheckJs'] !== '');
        return {
            id: r['id'],
            name: r['name'],
            url: r['url'],
            group: r['group'] ?? null,
            enabled: Number(r['enabled']) !== 0,
            isJsSource: Number(r['is_js']) !== 0,
            hasLogin,
            updatedAt: Number(r['updated_at']),
            version: Number(r['version']),
        };
    }
    searchSourcePicker(query, groups = []) {
        const items = this.listSources(query).filter((s) => {
            if (groups.length === 0)
                return true;
            if (groups.includes('__ungrouped__'))
                return s.group == null || s.group.trim() === '';
            return s.group != null && groups.includes(s.group);
        });
        return { items, total: items.length };
    }
    listExploreSources() {
        const raw = rows(this.db.prepare(`select id, name, source_group as "group", enabled, payload from source where enabled = 1 order by name collate nocase`));
        return raw.filter((r) => {
            const payload = jsonParse(r['payload'], {});
            const explore = (typeof payload['exploreUrl'] === 'string' ? payload['exploreUrl'] : '').trim();
            return explore !== '';
        }).map((r) => ({
            id: r['id'], name: r['name'],
            group: r['group'] ?? null, enabled: Number(r['enabled']) !== 0,
        }));
    }
    getSource(id) {
        const r = this.db.prepare('select id, payload as json, version, updated_at from source where id = ?').get(id);
        if (r == null)
            return null;
        return {
            id: r['id'],
            json: SourceCodec.withGroup(r['json'], this.sourceGroupOf(id)),
            version: Number(r['version']),
            updatedAt: Number(r['updated_at']),
        };
    }
    sourceGroupOf(id) {
        const r = this.db.prepare('select source_group from source where id = ?').get(id);
        return r?.source_group ?? null;
    }
    listSourceGroups() {
        return rows(this.db.prepare(`
      select source_group as name, count(*) as sourceCount, sum(case when enabled = 1 then 1 else 0 end) as enabledCount
      from source where source_group is not null and trim(source_group) != ''
      group by source_group order by source_group collate nocase
    `));
    }
    renameSourceGroup(from, to) {
        const count = rows(this.db.prepare('select count(*) as n from source where source_group = ?'), from)[0].n;
        this.db.prepare('update source set source_group = ?, updated_at = ? where source_group = ?').run(to, now(), from);
        return count;
    }
    clearSourceGroup(name) {
        const info = this.db.prepare('update source set source_group = null, updated_at = ? where source_group = ?').run(now(), name);
        return info.changes;
    }
    /** 搜索用的书源记录（enabled=1），可选限定 id 集合或分组。 */
    listSearchSourceRecords(sourceIds, group = null) {
        let sql = 'select id, payload as json, version, updated_at from source where enabled = 1';
        const params = [];
        if (sourceIds && sourceIds.length > 0) {
            sql += ` and id in (${sourceIds.map(() => '?').join(',')})`;
            params.push(...sourceIds);
        }
        if (group != null && group.trim() !== '') {
            if (group === '__ungrouped__') {
                sql += ` and (source_group is null or trim(source_group) = '')`;
            }
            else {
                sql += ' and source_group = ?';
                params.push(group);
            }
        }
        const raw = rows(this.db.prepare(sql + ' order by name collate nocase'), ...params);
        return raw.map((r) => ({ id: r['id'], json: r['json'], version: Number(r['version']), updatedAt: Number(r['updated_at']) }));
    }
    saveSource(parsed, expectedVersion) {
        const existing = this.db.prepare('select version from source where id = ?').get(parsed.id);
        const at = now();
        if (existing != null) {
            if (expectedVersion != null && existing.version !== expectedVersion)
                throw new VersionConflict();
            this.db.prepare(`update source set name = ?, source_url = ?, source_group = ?, enabled = ?, is_js = ?, payload = ?, version = version + 1, updated_at = ? where id = ?`)
                .run(parsed.name, parsed.url, parsed.group, parsed.enabled ? 1 : 0, parsed.isJs ? 1 : 0, parsed.json, at, parsed.id);
        }
        else {
            const version = expectedVersion ?? 1;
            this.db.prepare(`insert into source(id, name, source_url, source_group, enabled, is_js, payload, version, updated_at) values (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                .run(parsed.id, parsed.name, parsed.url, parsed.group, parsed.enabled ? 1 : 0, parsed.isJs ? 1 : 0, parsed.json, version, at);
        }
        const versionRow = this.db.prepare('select version from source where id = ?').get(parsed.id);
        return { id: parsed.id, json: parsed.json, version: versionRow.version, updatedAt: at };
    }
    deleteSource(id) {
        return this.db.prepare('delete from source where id = ?').run(id).changes === 1;
    }
    batchUpdateSources(ids, action, group = null) {
        if (ids.length === 0)
            return 0;
        const placeholders = ids.map(() => '?').join(',');
        const at = now();
        if (action === 'enable' || action === 'disable') {
            const info = this.db.prepare(`update source set enabled = ?, updated_at = ? where id in (${placeholders})`)
                .run(action === 'enable' ? 1 : 0, at, ...ids);
            return info.changes;
        }
        if (action === 'delete') {
            let affected = 0;
            for (const id of ids)
                affected += this.deleteSource(id) ? 1 : 0;
            return affected;
        }
        if (action === 'set_group') {
            const info = this.db.prepare(`update source set source_group = ?, updated_at = ? where id in (${placeholders})`)
                .run(group, at, ...ids);
            return info.changes;
        }
        return 0;
    }
    importSources(rawSources, applyGroups = false) {
        let imported = 0, updated = 0, skipped = 0;
        const errors = [];
        const groups = new Set();
        for (const raw of rawSources) {
            try {
                const parsed = SourceCodec.parse(raw, applyGroups);
                if (parsed.group && parsed.group.trim() !== '')
                    groups.add(parsed.group.trim());
                const exists = this.getSource(parsed.id) != null;
                const record = this.saveSource(parsed, null);
                if (exists)
                    updated++;
                else
                    imported++;
                void record;
            }
            catch (e) {
                skipped++;
                errors.push(e instanceof Error ? e.message : String(e));
            }
        }
        return { imported, updated, skipped, errors, sourceGroups: groups.size };
    }
    exportSources(ids) {
        const raw = ids == null
            ? rows(this.db.prepare('select payload as json from source order by id'))
            : ids.flatMap((id) => rows(this.db.prepare('select payload as json from source where id = ?'), id));
        return raw.map((r) => SourceCodec.withGroup(r.json, null));
    }
    // ---------------- 书源登录态 / Cookie / 变量 ----------------
    getSourceLoginState(sourceId) {
        const r = this.db.prepare('select * from source_login_state where source_id = ?').get(sourceId);
        if (r == null)
            return null;
        return {
            sourceId,
            loginInfo: jsonParse(r['login_info'], {}),
            loginHeader: r['login_header'] ?? null,
            sourceVariable: r['source_variable'] ?? null,
            sourceKv: jsonParse(r['source_kv'], {}),
            cookieJar: jsonParse(r['cookie_jar'], {}),
            updatedAt: Number(r['updated_at']),
        };
    }
    upsertLoginState(sourceId, mutate) {
        const existing = this.db.prepare('select * from source_login_state where source_id = ?').get(sourceId);
        const cols = existing
            ? {
                login_info: existing['login_info'],
                login_header: existing['login_header'],
                source_variable: existing['source_variable'],
                source_kv: existing['source_kv'],
                cookie_jar: existing['cookie_jar'],
            }
            : { login_info: null, login_header: null, source_variable: null, source_kv: null, cookie_jar: null };
        const merged = mutate(cols);
        this.db.prepare(`insert into source_login_state(source_id, login_info, login_header, source_variable, source_kv, cookie_jar, updated_at)
      values (?, ?, ?, ?, ?, ?, ?)
      on conflict(source_id) do update set login_info = excluded.login_info, login_header = excluded.login_header,
        source_variable = excluded.source_variable, source_kv = excluded.source_kv, cookie_jar = excluded.cookie_jar, updated_at = excluded.updated_at`)
            .run(sourceId, merged.login_info, merged.login_header, merged.source_variable, merged.source_kv, merged.cookie_jar, now());
    }
    saveSourceLoginInfo(sourceId, loginInfo) {
        this.upsertLoginState(sourceId, (c) => ({ ...c, login_info: JSON.stringify(loginInfo) }));
        return true;
    }
    saveSourceLoginHeader(sourceId, header) {
        this.upsertLoginState(sourceId, (c) => ({ ...c, login_header: header }));
        return true;
    }
    removeSourceLoginHeader(sourceId) {
        this.saveSourceLoginHeader(sourceId, null);
        return true;
    }
    removeSourceLoginInfo(sourceId) {
        this.upsertLoginState(sourceId, (c) => ({ ...c, login_info: null }));
        return true;
    }
    saveSourceVariable(sourceId, variable) {
        this.upsertLoginState(sourceId, (c) => ({ ...c, source_variable: variable }));
        return true;
    }
    getSourceVariable(sourceId) {
        return this.getSourceLoginState(sourceId)?.sourceVariable ?? null;
    }
    saveSourceKv(sourceId, key, value) {
        const state = this.getSourceLoginState(sourceId);
        const kv = { ...state?.sourceKv };
        if (value == null)
            delete kv[key];
        else
            kv[key] = value;
        this.upsertLoginState(sourceId, (c) => ({ ...c, source_kv: JSON.stringify(kv) }));
        return true;
    }
    getSourceKv(sourceId, key) {
        return this.getSourceLoginState(sourceId)?.sourceKv[key] ?? null;
    }
    saveSourceCookieJar(sourceId, cookies) {
        this.upsertLoginState(sourceId, (c) => ({ ...c, cookie_jar: JSON.stringify(cookies) }));
        return true;
    }
    getSourceCookieJar(sourceId) {
        return this.getSourceLoginState(sourceId)?.cookieJar ?? {};
    }
    static parseCookieString(cookieStr) {
        const result = {};
        for (const part of cookieStr.split(';')) {
            const trimmed = part.trim();
            const eq = trimmed.indexOf('=');
            if (eq > 0)
                result[trimmed.slice(0, eq).trim()] = trimmed.slice(eq + 1).trim();
        }
        return result;
    }
    /** 把 Set-Cookie 里的键值对剥离指令属性后入库（部落知识：整串入库会污染后续请求头）。 */
    static extractCookiePair(setCookieHeader) {
        const first = setCookieHeader.split(';')[0].trim();
        const eq = first.indexOf('=');
        if (eq <= 0)
            return null;
        const key = first.slice(0, eq).trim();
        const value = first.slice(eq + 1).trim();
        if (key === '' || /^(expires|max-age|path|domain|secure|httponly|samesite)$/i.test(key))
            return null;
        return [key, value];
    }
    setSourceCookieFromSetCookie(sourceId, url, setCookieHeader) {
        const pair = Db.extractCookiePair(setCookieHeader);
        if (pair == null)
            return false;
        const jar = { ...this.getSourceCookieJar(sourceId) };
        jar[pair[0]] = pair[1];
        return this.saveSourceCookieJar(sourceId, jar);
    }
    setSourceCookie(sourceId, _url, cookie) {
        const pairs = Db.parseCookieString(cookie);
        const jar = { ...this.getSourceCookieJar(sourceId), ...pairs };
        return this.saveSourceCookieJar(sourceId, jar);
    }
    removeSourceCookie(sourceId, _url) {
        return this.saveSourceCookieJar(sourceId, {});
    }
    getSourceCookie(sourceId, _url) {
        const jar = this.getSourceCookieJar(sourceId);
        const text = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
        return text === '' ? null : text;
    }
    clearSourceLoginState(sourceId) {
        return this.db.prepare('delete from source_login_state where source_id = ?').run(sourceId).changes > 0;
    }
    // ---------------- 书籍变量 ----------------
    getBookVariable(sourceId, bookUrl) {
        const row = this.db.prepare('select variable from book_shelf where source_id = ? and book_url = ?')
            .get(sourceId, bookUrl);
        return row?.variable ?? null;
    }
    getBookVariables(sourceId, bookUrl) {
        return jsonParse(this.getBookVariable(sourceId, bookUrl), {});
    }
    saveBookVariables(sourceId, bookUrl, variables) {
        const json = JSON.stringify(variables);
        const info = this.db.prepare('update book_shelf set variable = ? where source_id = ? and book_url = ?')
            .run(json, sourceId, bookUrl);
        return info.changes > 0;
    }
    saveBookVariable(sourceId, bookUrl, raw) {
        if (raw == null || raw.trim() === '')
            return this.saveBookVariables(sourceId, bookUrl, {});
        const parsed = jsonParse(raw, {});
        return this.saveBookVariables(sourceId, bookUrl, parsed);
    }
    saveCustomVariable(sourceId, bookUrl, value) {
        const vars = { ...this.getBookVariables(sourceId, bookUrl) };
        if (value == null) {
            delete vars[CUSTOM_VARIABLE_KEY];
        }
        else {
            vars[CUSTOM_VARIABLE_KEY] = value;
        }
        return this.saveBookVariables(sourceId, bookUrl, vars);
    }
    // ---------------- 阅读进度 ----------------
    saveProgress(progress) {
        this.db.prepare(`insert into reading_progress(source_id, book_url, chapter_url, chapter_index, updated_at, scroll_position, position_ms, chapter_title, book_kind)
      values (?, ?, ?, ?, ?, ?, ?, ?, ?)
      on conflict(source_id, book_url) do update set chapter_url = excluded.chapter_url, chapter_index = excluded.chapter_index,
        updated_at = excluded.updated_at, scroll_position = excluded.scroll_position, position_ms = excluded.position_ms,
        chapter_title = excluded.chapter_title, book_kind = excluded.book_kind`)
            .run(progress.sourceId, progress.bookUrl, progress.chapterUrl, progress.chapterIndex, now(), progress.scrollPosition ?? 0, progress.positionMs ?? null, progress.chapterTitle ?? null, progress.bookKind ?? null);
        this.db.prepare('update book_shelf set last_read_at = ? where source_id = ? and book_url = ?')
            .run(now(), progress.sourceId, progress.bookUrl);
        return this.getProgress(progress.sourceId, progress.bookUrl);
    }
    getProgress(sourceId, bookUrl) {
        const r = this.db.prepare('select * from reading_progress where source_id = ? and book_url = ?')
            .get(sourceId, bookUrl);
        if (r == null)
            return null;
        return {
            sourceId: r['source_id'],
            bookUrl: r['book_url'],
            chapterUrl: r['chapter_url'],
            chapterIndex: Number(r['chapter_index']),
            scrollPosition: Number(r['scroll_position'] ?? 0),
            updatedAt: Number(r['updated_at']),
            positionMs: r['position_ms'] == null ? null : Number(r['position_ms']),
            chapterTitle: r['chapter_title'] ?? null,
            bookKind: r['book_kind'] ?? null,
        };
    }
    // ---------------- 书架 ----------------
    getShelfBookByUrl(bookUrl) {
        const r = this.db.prepare('select * from book_shelf where book_url = ? order by last_read_at desc limit 1')
            .get(bookUrl);
        return r ? this.toShelfRow(r) : null;
    }
    toShelfRow(r) {
        return {
            sourceId: r['source_id'],
            bookUrl: r['book_url'],
            name: r['name'],
            author: r['author'] ?? null,
            tocUrl: r['toc_url'],
            coverUrl: r['cover_url'] ?? null,
            coverKey: r['cover_key'] ?? null,
            completed: Number(r['completed']) !== 0,
            groupName: r['group_name'] ?? null,
            bookKind: r['book_kind'] ?? null,
            variable: r['variable'] ?? null,
        };
    }
    shelfHasBook(sourceId, bookUrl) {
        return this.db.prepare('select 1 from book_shelf where source_id = ? and book_url = ?').get(sourceId, bookUrl) != null;
    }
    saveBookshelf(request, cover) {
        const at = now();
        const alternate = request.alternateSources && request.alternateSources.length > 0 ? JSON.stringify(request.alternateSources) : null;
        const bookKind = request.bookKind?.trim()?.toLowerCase() || null;
        this.db.prepare(`insert into book_shelf(source_id, book_url, name, author, toc_url, cover_url, cover_key, last_read_at, completed, alternate_sources, group_name, book_kind)
      values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      on conflict(source_id, book_url) do update set name = excluded.name, author = excluded.author, toc_url = excluded.toc_url,
        cover_url = excluded.cover_url, last_read_at = excluded.last_read_at, completed = excluded.completed,
        alternate_sources = excluded.alternate_sources, group_name = excluded.group_name,
        book_kind = coalesce(excluded.book_kind, book_shelf.book_kind)`)
            .run(request.sourceId, request.bookUrl, request.name, request.author ?? null, request.tocUrl, request.coverUrl ?? null, cover?.cacheKey ?? null, at, 0, alternate, request.groupName ?? null, bookKind);
        return this.listBookshelf().find((b) => b.sourceId === request.sourceId && b.bookUrl === request.bookUrl);
    }
    listBookshelf() {
        const shelfRows = rows(this.db.prepare('select * from book_shelf order by last_read_at desc'));
        const result = [];
        for (const r of shelfRows) {
            const sourceId = r['source_id'];
            const bookUrl = r['book_url'];
            const progress = this.getProgress(sourceId, bookUrl);
            const cacheRow = this.db.prepare('select total_chapters, cached_chapters, state, last_error from book_cache_status where source_id = ? and book_url = ?')
                .get(sourceId, bookUrl);
            const alternate = jsonParse(r['alternate_sources'], []);
            result.push({
                sourceId,
                bookUrl,
                name: r['name'],
                author: r['author'] ?? null,
                tocUrl: r['toc_url'],
                coverKey: r['cover_key'] ?? null,
                coverUrl: r['cover_url'] ?? null,
                chapterIndex: progress?.chapterIndex ?? null,
                scrollPosition: progress != null && progress.bookKind !== 'audio' ? progress.scrollPosition ?? 0 : null,
                lastReadAt: Number(r['last_read_at']),
                cachedChapters: cacheRow ? Number(cacheRow['cached_chapters']) : 0,
                totalChapters: cacheRow ? Number(cacheRow['total_chapters']) : 0,
                cacheState: cacheRow?.['state'] ?? 'idle',
                cacheError: cacheRow?.['last_error'] ?? null,
                completed: Number(r['completed']) !== 0,
                alternateSources: alternate,
                groupName: r['group_name'] ?? null,
                bookKind: r['book_kind']?.toLowerCase() ?? 'novel',
                positionMs: progress != null && progress.bookKind === 'audio' ? progress.positionMs ?? null : null,
                variable: r['variable'] ?? null,
            });
        }
        return result;
    }
    setBookKindSilently(sourceId, bookUrl, kind = 'comic') {
        this.db.prepare('update book_shelf set book_kind = ? where source_id = ? and book_url = ?').run(kind, sourceId, bookUrl);
    }
    getBookKind(sourceId, bookUrl) {
        const r = this.db.prepare('select book_kind from book_shelf where source_id = ? and book_url = ?')
            .get(sourceId, bookUrl);
        return r?.book_kind?.toLowerCase() ?? 'novel';
    }
    setBookshelfCompleted(sourceId, bookUrl, completed) {
        const info = this.db.prepare('update book_shelf set completed = ? where source_id = ? and book_url = ?')
            .run(completed ? 1 : 0, sourceId, bookUrl);
        if (info.changes === 0)
            return null;
        return this.listBookshelf().find((b) => b.sourceId === sourceId && b.bookUrl === bookUrl) ?? null;
    }
    updateBookshelfInfo(request, cover) {
        const at = now();
        const vars = { ...this.getBookVariables(request.sourceId, request.bookUrl) };
        if (request.customVariable != null)
            vars[CUSTOM_VARIABLE_KEY] = request.customVariable;
        const alternate = request.alternateSources && request.alternateSources.length > 0 ? JSON.stringify(request.alternateSources) : null;
        const info = this.db.prepare(`update book_shelf set name = ?, author = ?, cover_url = ?, cover_key = ?, group_name = ?,
      alternate_sources = ?, variable = ? where source_id = ? and book_url = ?`)
            .run(request.name, request.author ?? null, request.coverUrl ?? null, cover != null ? cover.cacheKey : request.coverKey ?? null, request.groupName ?? null, alternate, Object.keys(vars).length > 0 ? JSON.stringify(vars) : null, request.sourceId, request.bookUrl);
        if (info.changes === 0)
            return null;
        void at;
        return this.listBookshelf().find((b) => b.sourceId === request.sourceId && b.bookUrl === request.bookUrl) ?? null;
    }
    removeBookshelf(sourceId, bookUrl) {
        const row = this.db.prepare('select cover_key from book_shelf where source_id = ? and book_url = ?')
            .get(sourceId, bookUrl);
        // ⚠️ 部落知识：可空列 NULL 不等于行不存在 —— 严禁 Elvis 误判。
        if (row == null)
            return null;
        this.db.prepare('delete from book_shelf where source_id = ? and book_url = ?').run(sourceId, bookUrl);
        return row.cover_key;
    }
    switchBookshelf(oldSourceId, oldBookUrl, request, cover) {
        const removedCoverKey = this.removeBookshelf(oldSourceId, oldBookUrl);
        const item = this.saveBookshelf(request, cover);
        return { item, removedCoverKey };
    }
    updateBookGroup(sourceId, bookUrl, groupName) {
        const info = this.db.prepare('update book_shelf set group_name = ? where source_id = ? and book_url = ?')
            .run(groupName, sourceId, bookUrl);
        if (info.changes === 0)
            return null;
        return this.listBookshelf().find((b) => b.sourceId === sourceId && b.bookUrl === bookUrl) ?? null;
    }
    batchBookshelfOperation(request, onRemoveCover) {
        let affected = 0;
        for (const item of request.items) {
            if (request.action === 'delete') {
                const coverKey = this.removeBookshelf(item.sourceId, item.bookUrl);
                if (coverKey != null)
                    onRemoveCover(coverKey);
                affected++;
            }
            else if (request.action === 'mark_completed') {
                affected += this.db.prepare('update book_shelf set completed = ? where source_id = ? and book_url = ?')
                    .run(request.completed ? 1 : 0, item.sourceId, item.bookUrl).changes;
            }
            else if (request.action === 'move_group') {
                affected += this.db.prepare('update book_shelf set group_name = ? where source_id = ? and book_url = ?')
                    .run(request.targetGroup ?? null, item.sourceId, item.bookUrl).changes;
            }
        }
        return affected;
    }
    // ---------------- 书架分组 ----------------
    listBookGroups() {
        const groupRows = rows(this.db.prepare('select name, id, sort_order, is_private from book_group order by sort_order asc, id asc'));
        const counts = new Map();
        for (const r of rows(this.db.prepare('select group_name from book_shelf where group_name is not null'))) {
            counts.set(r.group_name, (counts.get(r.group_name) ?? 0) + 1);
        }
        return groupRows.map((g) => ({
            id: g.id, name: g.name, sortOrder: g.sort_order,
            bookCount: counts.get(g.name) ?? 0, isPrivate: Number(g.is_private) !== 0,
        }));
    }
    getBookGroup(name) {
        const g = this.db.prepare('select name, id, sort_order, is_private from book_group where name = ?').get(name);
        if (g == null)
            return null;
        return { id: g.id, name: g.name, sortOrder: g.sort_order, isPrivate: Number(g.is_private) !== 0 };
    }
    createBookGroup(name, isPrivate = false) {
        this.db.prepare('insert into book_group(name, sort_order, is_private, created_at) values (?, ?, ?, ?)')
            .run(name, 0, isPrivate ? 1 : 0, now());
        return this.getBookGroup(name);
    }
    updateBookGroupPrivacy(name, isPrivate) {
        this.db.prepare('update book_group set is_private = ? where name = ?').run(isPrivate ? 1 : 0, name);
        return this.getBookGroup(name);
    }
    renameBookGroup(oldName, newName) {
        this.db.prepare('update book_group set name = ? where name = ?').run(newName, oldName);
        this.db.prepare('update book_shelf set group_name = ? where group_name = ?').run(newName, oldName);
        return this.getBookGroup(newName);
    }
    deleteBookGroup(name) {
        this.db.prepare('update book_shelf set group_name = null where group_name = ?').run(name);
        return this.db.prepare('delete from book_group where name = ?').run(name).changes > 0;
    }
    updateBookGroupsOrder(groupNames) {
        groupNames.forEach((name, index) => {
            this.db.prepare('update book_group set sort_order = ? where name = ?').run(index, name);
        });
        return this.listBookGroups();
    }
    // ---------------- 目录缓存 / 章节索引 ----------------
    getTocCache(sourceId, tocUrl) {
        const r = this.db.prepare('select chapters_json from book_toc_cache where source_id = ? and toc_url = ?')
            .get(sourceId, tocUrl);
        if (r == null)
            return null;
        const parsed = jsonParse(r.chapters_json, null);
        return Array.isArray(parsed) ? parsed : null;
    }
    saveTocCache(sourceId, tocUrl, chapters) {
        this.db.prepare(`insert into book_toc_cache(source_id, toc_url, chapters_json, updated_at) values (?, ?, ?, ?)
      on conflict(source_id, toc_url) do update set chapters_json = excluded.chapters_json, updated_at = excluded.updated_at`)
            .run(sourceId, tocUrl, JSON.stringify(chapters), now());
        // 摊平章节索引（一行一章，供全局搜索用）。book_url 取书架的 book_url（与 Kotlin 版一致）。
        const shelf = rows(this.db.prepare('select book_url from book_shelf where source_id = ? order by last_read_at desc'), sourceId);
        const bookUrl = shelf[0]?.book_url;
        if (bookUrl != null) {
            const del = this.db.prepare('delete from book_chapter_index where source_id = ? and book_url = ?');
            const ins = this.db.prepare('insert or replace into book_chapter_index(source_id, book_url, chapter_url, chapter_index, title) values (?, ?, ?, ?, ?)');
            const tx = this.db.transaction(() => {
                del.run(sourceId, bookUrl);
                for (const ch of chapters)
                    ins.run(sourceId, bookUrl, ch.url, ch.index, ch.title);
            });
            tx();
        }
    }
    getChapterTitle(sourceId, bookUrl, chapterUrl) {
        const r = this.db.prepare('select title from book_chapter_index where source_id = ? and book_url = ? and chapter_url = ?')
            .get(sourceId, bookUrl, chapterUrl);
        return r?.title ?? null;
    }
    getCachedChaptersFallback(sourceId, bookUrl) {
        const tocRows = rows(this.db.prepare('select toc_url from book_toc_cache where source_id = ?'), sourceId)
            .filter(() => true);
        void tocRows;
        // 直接从内容缓存行还原可读章节清单（含标题）
        const contentRows = rows(this.db.prepare('select chapter_url, title from book_content_cache where source_id = ? and book_url = ?'), sourceId, bookUrl);
        return contentRows.map((r, i) => ({ index: i, title: r.title ?? `第 ${i + 1} 章`, url: r.chapter_url }));
    }
    cachedContent(sourceId, bookUrl, chapterUrl) {
        const r = this.db.prepare('select title, content, raw_title, raw_content from book_content_cache where source_id = ? and book_url = ? and chapter_url = ?')
            .get(sourceId, bookUrl, chapterUrl);
        if (r == null)
            return null;
        return {
            title: r['title'] ?? null,
            content: r['content'],
            rawTitle: r['raw_title'] ?? null,
            rawContent: r['raw_content'] ?? null,
        };
    }
    cachedChapterUrls(sourceId, bookUrl) {
        const r = rows(this.db.prepare('select chapter_url from book_content_cache where source_id = ? and book_url = ?'), sourceId, bookUrl);
        return new Set(r.map((x) => x.chapter_url));
    }
    cachedChaptersResponse(sourceId, bookUrl) {
        const urls = [...this.cachedChapterUrls(sourceId, bookUrl)].sort();
        const totalRow = this.db.prepare('select total_chapters from book_cache_status where source_id = ? and book_url = ?')
            .get(sourceId, bookUrl);
        return {
            sourceId, bookUrl, cachedChapterUrls: urls, cachedCount: urls.length,
            totalChapters: totalRow ? Number(totalRow.total_chapters) : 0,
        };
    }
    clearBookCacheContent(sourceId, bookUrl) {
        let removed = this.db.prepare('delete from book_content_cache where source_id = ? and book_url = ?').run(sourceId, bookUrl).changes;
        removed += this.db.prepare('delete from book_cache_status where source_id = ? and book_url = ?').run(sourceId, bookUrl).changes;
        return removed;
    }
    cacheBookContent(sourceId, bookUrl, chapterUrl, content) {
        this.db.prepare(`insert into book_content_cache(source_id, book_url, chapter_url, title, content, cached_at, raw_title, raw_content)
      values (?, ?, ?, ?, ?, ?, ?, ?)
      on conflict(source_id, book_url, chapter_url) do update set title = excluded.title, content = excluded.content,
        cached_at = excluded.cached_at, raw_title = excluded.raw_title, raw_content = excluded.raw_content`)
            .run(sourceId, bookUrl, chapterUrl, content.title, content.content, now(), content.rawTitle, content.rawContent);
        const cached = this.db.prepare('select count(*) as n from book_content_cache where source_id = ? and book_url = ?')
            .get(sourceId, bookUrl);
        this.db.prepare(`insert into book_cache_status(source_id, book_url, total_chapters, cached_chapters, state, last_error, updated_at)
      values (?, ?, 0, ?, 'running', null, ?)
      on conflict(source_id, book_url) do update set cached_chapters = excluded.cached_chapters, updated_at = excluded.updated_at`)
            .run(sourceId, bookUrl, cached.n, now());
    }
    updateBookCacheProgress(sourceId, bookUrl, cachedCount) {
        this.db.prepare('update book_cache_status set cached_chapters = ?, updated_at = ? where source_id = ? and book_url = ?')
            .run(cachedCount, now(), sourceId, bookUrl);
    }
    beginBookCache(sourceId, bookUrl, total) {
        this.db.prepare(`insert into book_cache_status(source_id, book_url, total_chapters, cached_chapters, state, last_error, updated_at)
      values (?, ?, ?, 0, 'running', null, ?)
      on conflict(source_id, book_url) do update set total_chapters = excluded.total_chapters, cached_chapters = 0,
        state = excluded.state, last_error = null, updated_at = excluded.updated_at`)
            .run(sourceId, bookUrl, total, now());
    }
    finishBookCache(sourceId, bookUrl, error = null) {
        this.db.prepare(`update book_cache_status set state = ?, last_error = ?, updated_at = ? where source_id = ? and book_url = ?`)
            .run(error == null ? 'idle' : 'error', error, now(), sourceId, bookUrl);
    }
    // ---------------- 全局搜索（本地库：书架 / 目录 / 正文） ----------------
    searchShelf(query, limit) {
        const like = `%${query.toLowerCase()}%`;
        const r = rows(this.db.prepare(`select * from book_shelf where lower(name) like ? or lower(coalesce(author, '')) like ? order by last_read_at desc limit ?`), like, like, limit + 1);
        return r.map((row) => ({
            kind: 'shelf',
            sourceId: row['source_id'],
            bookUrl: row['book_url'],
            bookName: row['name'],
            bookAuthor: row['author'] ?? null,
            coverKey: row['cover_key'] ?? null,
            chapterIndex: null, chapterTitle: null, chapterUrl: null, snippet: null,
        }));
    }
    searchToc(query, limit, sourceId = null, bookUrl = null) {
        const like = `%${query.toLowerCase()}%`;
        let sql = `select i.source_id, i.book_url, i.chapter_url, i.chapter_index, i.title, s.name, s.author, s.cover_key
      from book_chapter_index i join book_shelf s on s.source_id = i.source_id and s.book_url = i.book_url
      where lower(i.title) like ?`;
        const params = [like];
        if (sourceId != null) {
            sql += ' and i.source_id = ?';
            params.push(sourceId);
        }
        if (bookUrl != null) {
            sql += ' and i.book_url = ?';
            params.push(bookUrl);
        }
        sql += ' limit ?';
        params.push(limit + 1);
        const r = rows(this.db.prepare(sql), ...params);
        return r.map((row) => ({
            kind: 'toc',
            sourceId: row['source_id'],
            bookUrl: row['book_url'],
            bookName: row['name'],
            bookAuthor: row['author'] ?? null,
            coverKey: row['cover_key'] ?? null,
            chapterIndex: Number(row['chapter_index']),
            chapterTitle: row['title'],
            chapterUrl: row['chapter_url'],
            snippet: null,
        }));
    }
    searchContent(query, limit, sourceId = null, bookUrl = null) {
        const like = `%${query.toLowerCase()}%`;
        let sql = `select c.source_id, c.book_url, c.chapter_url, c.content, s.name, s.author, s.cover_key
      from book_content_cache c join book_shelf s on s.source_id = c.source_id and s.book_url = c.book_url
      where lower(c.content) like ?`;
        const params = [like];
        if (sourceId != null) {
            sql += ' and c.source_id = ?';
            params.push(sourceId);
        }
        if (bookUrl != null) {
            sql += ' and c.book_url = ?';
            params.push(bookUrl);
        }
        sql += ' limit ?';
        params.push(limit + 1);
        const r = rows(this.db.prepare(sql), ...params);
        const radius = 40;
        return r.map((row) => {
            const content = row['content'].toLowerCase();
            const at = content.indexOf(query.toLowerCase());
            let snippet = at < 0 ? null
                : row['content'].slice(Math.max(0, at - radius), Math.min(row['content'].length, at + query.length + radius));
            if (snippet != null)
                snippet = `…${snippet}…`;
            return {
                kind: 'content',
                sourceId: row['source_id'],
                bookUrl: row['book_url'],
                bookName: row['name'],
                bookAuthor: row['author'] ?? null,
                coverKey: row['cover_key'] ?? null,
                chapterIndex: null,
                chapterTitle: this.getChapterTitle(row['source_id'], row['book_url'], row['chapter_url']),
                chapterUrl: row['chapter_url'],
                snippet,
            };
        });
    }
    purgeOrphanTextCaches() {
        const contentRows = this.db.prepare(`delete from book_content_cache where not exists (
      select 1 from book_shelf s where s.source_id = book_content_cache.source_id and s.book_url = book_content_cache.book_url)`).run().changes;
        const tocRows = this.db.prepare(`delete from book_toc_cache where not exists (
      select 1 from book_shelf s where s.source_id = book_toc_cache.source_id)`).run().changes;
        const chapterIndexRows = this.db.prepare(`delete from book_chapter_index where not exists (
      select 1 from book_shelf s where s.source_id = book_chapter_index.source_id and s.book_url = book_chapter_index.book_url)`).run().changes;
        return { contentRows, tocRows, chapterIndexRows, total: contentRows + tocRows + chapterIndexRows };
    }
    // ---------------- 书签 ----------------
    listBookmarks(bookName, bookAuthor) {
        return rows(this.db.prepare('select * from bookmark where book_name = ? and (book_author = ? or (book_author is null and ? is null)) order by chapter_index asc, chapter_pos asc'), bookName, bookAuthor, bookAuthor).map(Db.toBookmark);
    }
    static toBookmark(r) {
        return {
            id: Number(r['id']),
            bookName: r['book_name'],
            bookAuthor: r['book_author'] ?? null,
            chapterIndex: Number(r['chapter_index']),
            chapterName: r['chapter_name'] ?? null,
            chapterPos: Number(r['chapter_pos']),
            bookText: r['book_text'] ?? null,
            content: r['content'] ?? null,
            createdAt: Number(r['created_at']),
        };
    }
    saveBookmark(request) {
        const existing = this.db.prepare('select * from bookmark where book_name = ? and book_author is ? and chapter_index = ? and chapter_pos = ?')
            .get(request.bookName, request.bookAuthor ?? null, request.chapterIndex, request.chapterPos ?? 0);
        if (existing != null) {
            this.db.prepare('update bookmark set book_text = ?, content = ?, chapter_name = ? where id = ?')
                .run(request.bookText ?? null, request.content ?? null, request.chapterName ?? null, existing['id']);
            return Db.toBookmark({ ...existing, book_text: request.bookText ?? null, content: request.content ?? null });
        }
        const info = this.db.prepare(`insert into bookmark(book_name, book_author, chapter_index, chapter_name, chapter_pos, book_text, content, created_at)
      values (?, ?, ?, ?, ?, ?, ?, ?)`)
            .run(request.bookName, request.bookAuthor ?? null, request.chapterIndex, request.chapterName ?? null, request.chapterPos ?? 0, request.bookText ?? null, request.content ?? null, now());
        return this.getBookmark(Number(info.lastInsertRowid));
    }
    getBookmark(id) {
        const r = this.db.prepare('select * from bookmark where id = ?').get(id);
        return r ? Db.toBookmark(r) : null;
    }
    /** 全部书签（备份导出用，按创建时间升序保证输出稳定）。 */
    listAllBookmarks() {
        const list = rows(this.db.prepare('select * from bookmark order by created_at asc'));
        return list.map(Db.toBookmark);
    }
    updateBookmark(id, request) {
        const existing = this.getBookmark(id);
        if (existing == null)
            return null;
        this.db.prepare('update bookmark set book_text = ?, content = ? where id = ?')
            .run(request.bookText ?? existing.bookText, request.content ?? existing.content, id);
        return this.getBookmark(id);
    }
    deleteBookmark(id) {
        return this.db.prepare('delete from bookmark where id = ?').run(id).changes === 1;
    }
    deleteBookmarks(ids) {
        if (ids.length === 0)
            return 0;
        return this.db.prepare(`delete from bookmark where id in (${ids.map(() => '?').join(',')})`).run(...ids).changes;
    }
    deleteBookmarksByBooks(books) {
        let deleted = 0;
        for (const b of books) {
            deleted += this.db.prepare('delete from bookmark where book_name = ? and (book_author = ? or (book_author is null and ? is null))')
                .run(b.bookName, b.bookAuthor ?? null, b.bookAuthor ?? null).changes;
        }
        return deleted;
    }
    listBookmarkBooks() {
        const groups = rows(this.db.prepare(`select book_name, book_author, count(*) as count, max(created_at) as lastCreatedAt
      from bookmark group by book_name, book_author order by lastCreatedAt desc`));
        return groups.map((g) => {
            const bookName = g['book_name'];
            const bookAuthor = g['book_author'] ?? null;
            const shelf = this.db.prepare('select cover_key, cover_url from book_shelf where name = ? and (author = ? or (author is null and ? is null)) limit 1')
                .get(bookName, bookAuthor, bookAuthor);
            const cover = this.getBookCover(bookName, bookAuthor);
            return {
                bookName,
                bookAuthor,
                count: Number(g['count']),
                lastCreatedAt: Number(g['lastCreatedAt']),
                coverKey: shelf?.cover_key ?? cover?.coverKey ?? null,
                coverUrl: shelf?.cover_url ?? null,
                coverMissing: (cover?.missingAttempts ?? 0) >= 5,
                coverAttempts: cover?.missingAttempts ?? 0,
            };
        });
    }
    getBookCover(bookName, bookAuthor) {
        const r = this.db.prepare('select * from book_cover where book_name = ? and book_author = ?')
            .get(bookName, bookAuthor ?? '');
        if (r == null)
            return null;
        return {
            bookName: r['book_name'],
            bookAuthor: r['book_author'],
            coverKey: r['cover_key'] ?? null,
            missingAttempts: Number(r['missing_attempts']),
            lastAttemptAt: Number(r['last_attempt_at']),
            updatedAt: Number(r['updated_at']),
        };
    }
    saveBookCover(bookName, bookAuthor, coverKey) {
        const at = now();
        this.db.prepare(`insert into book_cover(book_name, book_author, cover_key, missing_attempts, last_attempt_at, updated_at)
      values (?, ?, ?, 0, 0, ?)
      on conflict(book_name, book_author) do update set cover_key = excluded.cover_key,
        missing_attempts = 0, last_attempt_at = 0, updated_at = excluded.updated_at`)
            .run(bookName, bookAuthor ?? '', coverKey, at);
        return this.getBookCover(bookName, bookAuthor);
    }
    recordCoverMiss(bookName, bookAuthor) {
        const at = now();
        this.db.prepare(`insert into book_cover(book_name, book_author, cover_key, missing_attempts, last_attempt_at, updated_at)
      values (?, ?, null, 1, ?, ?)
      on conflict(book_name, book_author) do update set missing_attempts = missing_attempts + 1, last_attempt_at = excluded.last_attempt_at, updated_at = excluded.updated_at`)
            .run(bookName, bookAuthor ?? '', at, at);
        return this.getBookCover(bookName, bookAuthor)?.missingAttempts ?? 0;
    }
    // ---------------- RSS 源 ----------------
    listRssSources() {
        return rows(this.db.prepare('select id, name, icon, source_group as "group", enabled, single_url, sort_url, custom_order, updated_at from rss_source order by name'))
            .map((r) => ({
            id: r['id'],
            name: r['name'],
            icon: r['icon'] ?? null,
            group: r['group'] ?? null,
            enabled: Number(r['enabled']) !== 0,
            singleUrl: Number(r['single_url']) !== 0,
            openUrl: r['id'].startsWith('http') ? r['id'] : null,
            customOrder: Number(r['custom_order']),
            updatedAt: Number(r['updated_at']),
        }));
    }
    getRssSourcePayload(id) {
        const r = this.db.prepare('select payload from rss_source where id = ?').get(id);
        return r?.payload ?? null;
    }
    setRssSourceEnabled(id, enabled) {
        return this.db.prepare('update rss_source set enabled = ?, updated_at = ? where id = ?').run(enabled ? 1 : 0, now(), id).changes > 0;
    }
    deleteRssSource(id) {
        return this.db.prepare('delete from rss_source where id = ?').run(id).changes > 0;
    }
    importRssSources(rawSources) {
        let imported = 0, skipped = 0;
        const errors = [];
        for (const raw of rawSources) {
            try {
                const clean = raw.trim().replace(/^\uFEFF/, '');
                const obj = jsonParse(clean, null);
                if (obj == null || typeof obj !== 'object')
                    throw new Error('订阅源必须是 JSON 对象');
                const url = (typeof obj['sourceUrl'] === 'string' ? obj['sourceUrl'] : typeof obj['url'] === 'string' ? obj['url'] : '')?.trim();
                if (url === '')
                    throw new Error('缺少 sourceUrl');
                const name = (typeof obj['sourceName'] === 'string' && obj['sourceName'] !== '' ? obj['sourceName'] : typeof obj['name'] === 'string' ? obj['name'] : '') || url;
                const icon = typeof obj['sourceIcon'] === 'string' ? obj['sourceIcon'] : typeof obj['icon'] === 'string' ? obj['icon'] : null;
                const group = typeof obj['sourceGroup'] === 'string' ? obj['sourceGroup'] : null;
                const enabled = obj['enabled'] !== false && obj['enable'] !== false;
                const sortUrl = typeof obj['sortUrl'] === 'string' ? obj['sortUrl'] : null;
                const singleUrl = obj['singleUrl'] === true;
                this.db.prepare(`insert into rss_source(id, name, icon, source_group, enabled, single_url, sort_url, custom_order, payload, updated_at)
          values (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
          on conflict(id) do update set name = excluded.name, icon = excluded.icon, source_group = excluded.source_group,
            payload = excluded.payload, updated_at = excluded.updated_at`)
                    .run(url, name, icon, group, enabled ? 1 : 0, singleUrl ? 1 : 0, sortUrl, clean, now());
                imported++;
            }
            catch (e) {
                skipped++;
                errors.push(e instanceof Error ? e.message : String(e));
            }
        }
        return { imported, skipped, errors };
    }
    exportRssSources() {
        return rows(this.db.prepare('select payload from rss_source order by id')).map((r) => r.payload);
    }
    // ---------------- HTTP TTS ----------------
    listHttpTts() {
        return rows(this.db.prepare('select * from http_tts order by id')).map(Db.toHttpTts);
    }
    static toHttpTts(r) {
        return {
            id: Number(r['id']),
            name: r['name'],
            url: r['url'],
            header: r['header'] ?? null,
            contentType: r['content_type'] ?? null,
            concurrentRate: r['concurrent_rate'] ?? null,
            loginUrl: r['login_url'] ?? null,
            loginCheckJs: r['login_check_js'] ?? null,
            loginUi: r['login_ui'] ?? null,
            jsLib: r['js_lib'] ?? null,
            enabledCookieJar: Number(r['enabled_cookie_jar']) !== 0,
            lastUpdateTime: Number(r['last_update_time']),
        };
    }
    getHttpTts(id) {
        const r = this.db.prepare('select * from http_tts where id = ?').get(id);
        return r ? Db.toHttpTts(r) : null;
    }
    saveHttpTts(tts) {
        const at = now();
        if (tts.id == null || tts.id === 0) {
            const info = this.db.prepare(`insert into http_tts(name, url, header, content_type, concurrent_rate, login_url, login_check_js, login_ui, js_lib, enabled_cookie_jar, last_update_time)
        values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                .run(tts.name ?? '', tts.url ?? '', tts.header ?? null, tts.contentType ?? null, tts.concurrentRate ?? null, tts.loginUrl ?? null, tts.loginCheckJs ?? null, tts.loginUi ?? null, tts.jsLib ?? null, tts.enabledCookieJar ? 1 : 0, at);
            return this.getHttpTts(Number(info.lastInsertRowid));
        }
        this.db.prepare(`update http_tts set name = ?, url = ?, header = ?, content_type = ?, concurrent_rate = ?,
      login_url = ?, login_check_js = ?, login_ui = ?, js_lib = ?, enabled_cookie_jar = ?, last_update_time = ? where id = ?`)
            .run(tts.name ?? '', tts.url ?? '', tts.header ?? null, tts.contentType ?? null, tts.concurrentRate ?? null, tts.loginUrl ?? null, tts.loginCheckJs ?? null, tts.loginUi ?? null, tts.jsLib ?? null, tts.enabledCookieJar ? 1 : 0, at, tts.id);
        return this.getHttpTts(tts.id);
    }
    deleteHttpTts(id) {
        return this.db.prepare('delete from http_tts where id = ?').run(id).changes === 1;
    }
    // ---------------- 封面缓存登记 ----------------
    recordCoverCache(coverKey, contentType = 'image/*', filePath = null) {
        this.db.prepare(`insert into cover_cache(cache_key, content_type, file_path) values (?, ?, ?)
      on conflict(cache_key) do update set content_type = excluded.content_type, file_path = excluded.file_path`)
            .run(coverKey, contentType, filePath ?? '');
    }
    coverFilePath(coverKey) {
        const r = this.db.prepare('select file_path from cover_cache where cache_key = ?').get(coverKey);
        return r?.file_path ?? null;
    }
    coverContentType(coverKey) {
        const r = this.db.prepare('select content_type from cover_cache where cache_key = ?').get(coverKey);
        return r?.content_type ?? null;
    }
    updateCoverFilePath(coverKey, filePath) {
        this.db.prepare('update cover_cache set file_path = ? where cache_key = ?').run(filePath, coverKey);
    }
    clearCoverFilePath(coverKey) {
        this.db.prepare("update cover_cache set file_path = '' where cache_key = ?").run(coverKey);
    }
    isCoverKeyReferenced(coverKey) {
        const shelf = this.db.prepare('select 1 from book_shelf where cover_key = ? limit 1').get(coverKey);
        const cover = this.db.prepare('select 1 from book_cover where cover_key = ? limit 1').get(coverKey);
        return shelf != null || cover != null;
    }
}
