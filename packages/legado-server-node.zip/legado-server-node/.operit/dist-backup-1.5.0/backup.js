import AdmZip from 'adm-zip';
const LEGADO_TYPE_TEXT = 8;
const LEGADO_TYPE_AUDIO = 32;
const LEGADO_TYPE_IMAGE = 64;
const LEGADO_TYPE_LOCAL = 256 | LEGADO_TYPE_TEXT;
export function exportBackup(db, today = new Date()) {
    const shelf = db.listBookshelf();
    const groups = db.listBookGroups();
    const bookmarks = db.listAllBookmarks();
    const sourcePayloads = db.exportSources(null);
    const ttsList = db.listHttpTts();
    const rssPayloads = db.exportRssSources();
    const groupIdByName = new Map(groups.map((group) => [group.name.toLowerCase(), group.id]));
    const sourceNameById = new Map();
    const sourceObjects = [];
    for (const payload of sourcePayloads) {
        try {
            const object = JSON.parse(payload);
            sourceObjects.push(object);
            const id = typeof object['bookSourceUrl'] === 'string' ? object['bookSourceUrl'] : null;
            const name = typeof object['bookSourceName'] === 'string' ? object['bookSourceName'] : id;
            if (id != null)
                sourceNameById.set(id, name ?? id);
        }
        catch {
            // 单条书源损坏不影响其它条目导出
        }
    }
    const entries = {
        'bookSource.json': sourceObjects,
        'bookGroup.json': groups.map((group) => ({
            bookSort: -1,
            enableRefresh: true,
            groupId: group.id,
            groupName: group.name,
            order: group.sortOrder,
            show: !group.isPrivate,
            isPrivate: group.isPrivate,
        })),
        'bookshelf.json': shelf.map((book, index) => {
            const entry = {
                bookUrl: book.bookUrl,
                canUpdate: true,
                durChapterIndex: book.chapterIndex ?? 0,
                // 有声书写毫秒；文本/漫画的服务端进度是 0..1 比例，不能冒充字符偏移
                durChapterPos: book.bookKind === 'audio' ? book.positionMs ?? 0 : 0,
                durChapterTime: book.lastReadAt,
                group: groupIdByName.get((book.groupName ?? '').toLowerCase()) ?? 0,
                kind: book.completed ? '已完结' : '连载中',
                lastCheckCount: 0,
                lastCheckTime: 0,
                latestChapterTime: 0,
                name: book.name,
                order: -(index + 1),
                origin: book.sourceId,
                originOrder: 0,
                syncTime: book.lastReadAt,
                tocUrl: book.tocUrl,
                totalChapterNum: book.totalChapters,
                type: legadoType(book.bookKind),
            };
            if (book.author)
                entry['author'] = book.author;
            if (book.coverUrl)
                entry['coverUrl'] = book.coverUrl;
            const sourceName = sourceNameById.get(book.sourceId);
            if (sourceName)
                entry['originName'] = sourceName;
            if (book.variable)
                entry['variable'] = book.variable;
            return entry;
        }),
        'bookmark.json': bookmarks.map((mark) => {
            const entry = {
                bookName: mark.bookName,
                chapterIndex: mark.chapterIndex,
                chapterPos: mark.chapterPos,
                content: mark.content ?? '',
                time: mark.createdAt,
            };
            if (mark.bookAuthor)
                entry['bookAuthor'] = mark.bookAuthor;
            if (mark.bookText)
                entry['bookText'] = mark.bookText;
            if (mark.chapterName)
                entry['chapterName'] = mark.chapterName;
            return entry;
        }),
        'httpTTS.json': ttsList.map((tts) => ({
            id: tts.id,
            name: tts.name ?? '',
            url: tts.url ?? '',
            header: tts.header ?? '',
            contentType: tts.contentType ?? '',
            concurrentRate: tts.concurrentRate ?? '',
            loginUrl: tts.loginUrl ?? '',
            loginCheckJs: tts.loginCheckJs ?? '',
            loginUi: tts.loginUi ?? '',
            jsLib: tts.jsLib ?? '',
            enabledCookieJar: tts.enabledCookieJar ?? false,
            lastUpdateTime: tts.lastUpdateTime ?? 0,
        })),
        'rssSources.json': rssPayloads.flatMap((payload) => {
            try {
                return [JSON.parse(payload)];
            }
            catch {
                return [];
            }
        }),
    };
    const zip = new AdmZip();
    for (const name of Object.keys(entries).sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()))) {
        zip.addFile(name, Buffer.from(JSON.stringify(entries[name], null, 2), 'utf8'));
    }
    const date = today.toISOString().slice(0, 10);
    return {
        fileName: `backup${date}-web.zip`,
        bytes: zip.toBuffer(),
        books: shelf.length,
        sources: sourcePayloads.length,
        bookmarks: bookmarks.length,
        groups: groups.length,
    };
}
export function importBackup(db, bytes) {
    if (bytes.length === 0)
        throw new Error('备份文件为空');
    let zip;
    try {
        zip = new AdmZip(bytes);
    }
    catch {
        throw new Error('备份文件不是有效的 zip');
    }
    const entries = new Map();
    for (const entry of zip.getEntries()) {
        if (!entry.isDirectory)
            entries.set(entry.entryName.toLowerCase(), entry);
    }
    const readArray = (name) => {
        const entry = entries.get(name.toLowerCase());
        if (entry == null)
            return [];
        try {
            const parsed = JSON.parse(entry.getData().toString('utf8'));
            return Array.isArray(parsed) ? parsed.filter((item) => item != null && typeof item === 'object') : [];
        }
        catch {
            throw new Error(`备份条目 ${name} 不是有效的 JSON`);
        }
    };
    const sourceObjects = readArray('bookSource.json');
    const groupObjects = readArray('bookGroup.json');
    const shelfObjects = readArray('bookshelf.json');
    const bookmarkObjects = readArray('bookmark.json');
    const ttsObjects = readArray('httpTTS.json');
    const rssObjects = readArray('rssSources.json');
    if (sourceObjects.length === 0 && shelfObjects.length === 0) {
        throw new Error('不是 Legado 备份包：未找到 bookSource.json / bookshelf.json');
    }
    const sourceResult = db.importSources(sourceObjects.map((item) => JSON.stringify(item)), true);
    for (const raw of ttsObjects) {
        if (typeof raw['url'] !== 'string' || raw['url'] === '')
            continue;
        db.saveHttpTts(toHttpTts(raw));
    }
    if (rssObjects.length > 0) {
        db.importRssSources(rssObjects.map((item) => JSON.stringify(item)));
    }
    const groupNameById = new Map();
    for (const group of groupObjects) {
        const id = Number(group['groupId']);
        const name = typeof group['groupName'] === 'string' ? group['groupName'] : '';
        if (Number.isFinite(id) && name !== '')
            groupNameById.set(id, name);
    }
    let books = 0;
    let booksUpdated = 0;
    let progress = 0;
    let skippedLocal = 0;
    for (const raw of shelfObjects) {
        const bookUrl = typeof raw['bookUrl'] === 'string' ? raw['bookUrl'] : '';
        const sourceId = typeof raw['origin'] === 'string' ? raw['origin'] : '';
        if (bookUrl === '' || sourceId === '')
            continue;
        const kind = kindFromLegadoType(raw['type']);
        if (kind == null) {
            skippedLocal++;
            continue;
        }
        const existed = db.shelfHasBook(sourceId, bookUrl);
        const groupRaw = raw['group'];
        const groupName = typeof groupRaw === 'number' ? groupNameById.get(groupRaw) ?? null
            : typeof groupRaw === 'string' && groupRaw !== '' ? groupNameById.get(Number(groupRaw)) ?? groupRaw : null;
        const name = typeof raw['name'] === 'string' && raw['name'] !== '' ? raw['name'] : bookUrl;
        db.saveBookshelf({
            sourceId,
            bookUrl,
            name,
            author: typeof raw['author'] === 'string' ? raw['author'] : null,
            tocUrl: typeof raw['tocUrl'] === 'string' && raw['tocUrl'] !== '' ? raw['tocUrl'] : bookUrl,
            coverUrl: typeof raw['coverUrl'] === 'string' ? raw['coverUrl'] : null,
            groupName,
            bookKind: kind,
        }, null);
        const chapterIndex = Number(raw['durChapterIndex']);
        const durChapterTime = Number(raw['durChapterTime']);
        const completed = raw['kind'] === '已完结';
        const variable = typeof raw['variable'] === 'string' ? raw['variable'] : null;
        db.db.prepare(`update book_shelf set last_read_at = ?, completed = ?, variable = ?
      where source_id = ? and book_url = ?`)
            .run(Number.isFinite(durChapterTime) && durChapterTime > 0 ? durChapterTime : Date.now(), completed ? 1 : 0, variable, sourceId, bookUrl);
        if (Number.isFinite(chapterIndex) && chapterIndex >= 0) {
            const positionMs = kind === 'audio' ? Number(raw['durChapterPos']) : null;
            db.saveProgress({
                sourceId,
                bookUrl,
                chapterUrl: '',
                chapterIndex,
                scrollPosition: 0,
                chapterTitle: typeof raw['durChapterTitle'] === 'string' ? raw['durChapterTitle'] : null,
                positionMs: Number.isFinite(positionMs ?? NaN) ? positionMs : null,
                bookKind: kind,
            });
            progress++;
        }
        if (existed)
            booksUpdated++;
        else
            books++;
    }
    let bookmarks = 0;
    for (const raw of bookmarkObjects) {
        const bookName = typeof raw['bookName'] === 'string' ? raw['bookName'] : '';
        if (bookName === '')
            continue;
        db.saveBookmark({
            bookName,
            bookAuthor: typeof raw['bookAuthor'] === 'string' ? raw['bookAuthor'] : null,
            chapterIndex: Number(raw['chapterIndex']) || 0,
            chapterName: typeof raw['chapterName'] === 'string' ? raw['chapterName'] : null,
            chapterPos: Number(raw['chapterPos']) || 0,
            bookText: typeof raw['bookText'] === 'string' ? raw['bookText'] : null,
            content: typeof raw['content'] === 'string' ? raw['content'] : null,
        });
        bookmarks++;
    }
    return {
        sources: sourceResult.imported,
        sourcesUpdated: sourceResult.updated ?? 0,
        books,
        booksUpdated,
        progress,
        skippedLocal,
        bookmarks,
        sourceGroups: sourceResult.sourceGroups ?? 0,
    };
}
function legadoType(bookKind) {
    const kind = (bookKind || '').toLowerCase();
    if (kind === 'audio')
        return LEGADO_TYPE_AUDIO;
    if (kind === 'comic')
        return LEGADO_TYPE_IMAGE;
    if (kind === 'local')
        return LEGADO_TYPE_LOCAL;
    return LEGADO_TYPE_TEXT;
}
/** `null` 表示本地图书（服务端读不到手机本机文件，导入时跳过）。 */
function kindFromLegadoType(raw) {
    const type = Number(raw) || 0;
    if ((type & 256) !== 0)
        return null;
    if ((type & LEGADO_TYPE_AUDIO) !== 0)
        return 'audio';
    if ((type & LEGADO_TYPE_IMAGE) !== 0)
        return 'comic';
    return 'novel';
}
function toHttpTts(raw) {
    const id = Number(raw['id']);
    return {
        id: Number.isFinite(id) && id > 0 ? id : undefined,
        name: typeof raw['name'] === 'string' ? raw['name'] : '',
        url: String(raw['url'] ?? ''),
        header: typeof raw['header'] === 'string' ? raw['header'] : null,
        contentType: typeof raw['contentType'] === 'string' ? raw['contentType'] : null,
        concurrentRate: typeof raw['concurrentRate'] === 'string' ? raw['concurrentRate'] : null,
        loginUrl: typeof raw['loginUrl'] === 'string' ? raw['loginUrl'] : null,
        loginCheckJs: typeof raw['loginCheckJs'] === 'string' ? raw['loginCheckJs'] : null,
        loginUi: typeof raw['loginUi'] === 'string' ? raw['loginUi'] : null,
        jsLib: typeof raw['jsLib'] === 'string' ? raw['jsLib'] : null,
        enabledCookieJar: raw['enabledCookieJar'] === true,
        lastUpdateTime: Number(raw['lastUpdateTime']) || 0,
    };
}
