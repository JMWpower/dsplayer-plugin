import { apiError, respondCatchingAsync } from '../app.js';
import { detectImportKind, importOnline, parseImportItems } from '../onlineImport.js';
/** 搜索路由：全网搜索（流式 SSE + 聚合）与本地库全局搜索。 */
export function registerSearchRoutes(app, ctx) {
    const { db } = ctx;
    function resolveSourceScope(body) {
        const sourceIds = body.sourceIds ?? null;
        const groups = body.groups ?? [];
        const group = body.group ?? null;
        if (groups.length > 1) {
            // 多分组：分别查询后合并（保持顺序与去重）
            const seen = new Set();
            const records = [];
            for (const g of groups) {
                for (const record of db.listSearchSourceRecords(sourceIds, g)) {
                    if (!seen.has(record.id)) {
                        seen.add(record.id);
                        records.push(record);
                    }
                }
            }
            return records;
        }
        return db.listSearchSourceRecords(sourceIds, groups[0] ?? group ?? null);
    }
    app.post('/api/search/local', async (request, reply) => {
        const body = request.body;
        const query = (body?.query ?? '').trim();
        const limit = Math.min(Math.max(body?.limit ?? 50, 1), 200);
        if (query === '')
            return apiError(reply, 400, 'invalid_request', '缺少搜索关键词');
        const mode = body?.mode ?? 'shelf';
        let items;
        switch (mode) {
            case 'toc':
                items = db.searchToc(query, limit, body?.sourceId ?? null, body?.bookUrl ?? null);
                break;
            case 'content':
                items = db.searchContent(query, limit, body?.sourceId ?? null, body?.bookUrl ?? null);
                break;
            default:
                items = db.searchShelf(query, limit);
                break;
        }
        const truncated = items.length > limit;
        return { items: items.slice(0, limit), total: items.length, truncated };
    });
    app.post('/api/search', async (request, reply) => {
        const body = request.body;
        const keyword = (body?.keyword ?? body?.query ?? '').trim();
        if (keyword === '')
            return apiError(reply, 400, 'invalid_request', '缺少搜索关键词');
        const sources = resolveSourceScope({ sourceIds: body?.sourceIds ?? null, groups: body?.groups ?? [], group: body?.group ?? null });
        // maxSources：只打前 N 个源（HTML 规则 / TVBox 这类一次性等结果的调用方用，避免 140 个源全跑一遍）
        const maxSources = Math.min(Math.max(Number.parseInt(String(body?.maxSources ?? '0'), 10) || 0, 0), 200);
        const picked = maxSources > 0 ? sources.slice(0, maxSources) : sources;
        await respondCatchingAsync(reply, async () => {
            const all = [];
            let failedSources = 0;
            await Promise.all(picked.map(async (source) => {
                try {
                    const results = await ctx.pool.run('search', { sourceJson: source.json, keyword });
                    all.push(...results);
                }
                catch {
                    failedSources++;
                }
            }));
            void failedSources;
            return { items: all, total: all.length, truncated: false };
        });
    });
    /** 流式搜索的公共实现：SSE 与 WebSocket 共用同一套事件与计数口径。 */
    async function runStreamSearch(keyword, sources, send) {
        let completedSources = 0, matchedSources = 0, emptySources = 0, failedSources = 0, resultCount = 0;
        const totalSources = sources.length;
        send({ type: 'start', totalSources });
        const tasks = sources.map(async (source) => {
            try {
                const results = await ctx.pool.run('search', { sourceJson: source.json, keyword });
                completedSources++;
                if (results.length > 0) {
                    matchedSources++;
                    resultCount += results.length;
                    send({
                        type: 'results', totalSources, completedSources, matchedSources, emptySources, failedSources,
                        resultCount, results,
                    });
                }
                else {
                    emptySources++;
                }
            }
            catch {
                completedSources++;
                failedSources++;
            }
            send({
                type: 'progress', totalSources, completedSources, matchedSources, emptySources, failedSources, resultCount,
            });
        });
        await Promise.all(tasks);
        send({ type: 'end', totalSources, completedSources, matchedSources, emptySources, failedSources, resultCount });
    }
    // 流式全网搜索：WebSocket（与 Web 前端 streamSearch 的报文契约一致）
    app.get('/api/search/stream', { websocket: true }, (socket) => {
        socket.on('message', (raw) => {
            void (async () => {
                let body;
                try {
                    body = JSON.parse(raw.toString());
                }
                catch {
                    socket.send(JSON.stringify({ type: 'error', message: '搜索请求格式无效' }));
                    socket.close();
                    return;
                }
                const keyword = (body.keyword ?? body.query ?? '').trim();
                if (keyword === '') {
                    socket.send(JSON.stringify({ type: 'error', message: '缺少搜索关键词' }));
                    socket.close();
                    return;
                }
                const sources = resolveSourceScope({ sourceIds: body.sourceIds ?? null, groups: body.groups ?? [], group: body.group ?? null });
                await runStreamSearch(keyword, sources, (event) => {
                    if (socket.readyState === socket.OPEN)
                        socket.send(JSON.stringify(event));
                });
                socket.close();
            })();
        });
    });
    // 流式全网搜索：SSE（保留给非 WebSocket 客户端）
    app.post('/api/search/stream', async (request, reply) => {
        const body = request.body;
        const keyword = (body?.keyword ?? body?.query ?? '').trim();
        if (keyword === '')
            return apiError(reply, 400, 'invalid_request', '缺少搜索关键词');
        const sources = resolveSourceScope({ sourceIds: body?.sourceIds ?? null, groups: body?.groups ?? [], group: body?.group ?? null });
        reply.raw.writeHead(200, {
            'Content-Type': 'text/event-stream; charset=utf-8',
            'Cache-Control': 'no-cache, no-transform',
            'X-Accel-Buffering': 'no',
            Connection: 'keep-alive',
        });
        await runStreamSearch(keyword, sources, (event) => {
            reply.raw.write(`data: ${JSON.stringify(event)}\n\n`);
        });
        reply.raw.end();
    });
    // 一键导入（legado://import/… 链接目标）
    app.post('/api/online-import', async (request, reply) => {
        const body = request.body;
        if (body == null || (body.url ?? '') === '')
            return apiError(reply, 400, 'invalid_request', '缺少地址');
        await respondCatchingAsync(reply, async () => {
            const response = await fetch(body.url, { redirect: 'follow' });
            if (!response.ok)
                throw new Error(`拉取失败：HTTP ${response.status}`);
            const text = await response.text();
            const supported = ['bookSource', 'rssSource', 'httpTts'];
            const requested = body.kind;
            if (requested != null && requested !== '' && requested !== 'auto' && !supported.includes(requested)) {
                throw new Error(`暂不支持导入该类型：${requested}`);
            }
            const kind = requested != null && requested !== '' && requested !== 'auto'
                ? requested
                : detectImportKind(parseImportItems(text));
            return importOnline(db, kind, text, body.dryRun === true);
        });
    });
}
