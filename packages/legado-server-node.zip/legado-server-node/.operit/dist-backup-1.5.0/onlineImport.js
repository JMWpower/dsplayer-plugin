import crypto from 'node:crypto';
import { SourceCodec } from './sourceCodec.js';
/** 拆订阅 / 导入内容：数组、{data|sources|bookSources|list|items}、单对象、JSONL。 */
export function parseImportItems(text) {
    const clean = text.trim().replace(/^\uFEFF/, '');
    try {
        const parsed = JSON.parse(clean);
        if (Array.isArray(parsed))
            return parsed;
        if (parsed != null && typeof parsed === 'object') {
            const obj = parsed;
            const key = ['data', 'sources', 'bookSources', 'list', 'items'].find((k) => Array.isArray(obj[k]));
            if (key != null)
                return obj[key];
            return [obj];
        }
    }
    catch { /* 退回 JSONL */ }
    const items = [];
    for (const line of clean.split(/\r?\n/)) {
        const trimmed = line.trim();
        if (trimmed === '')
            continue;
        try {
            const parsed = JSON.parse(trimmed);
            if (parsed != null && typeof parsed === 'object')
                items.push(parsed);
        }
        catch { /* 非 JSON 行跳过 */ }
    }
    return items;
}
/** 按内容形态判别导入类型（开源阅读 auto 链接用）。 */
export function detectImportKind(items) {
    const objs = items.filter((i) => i != null && typeof i === 'object');
    if (objs.some((o) => typeof o['bookSourceUrl'] === 'string'))
        return 'bookSource';
    if (objs.some((o) => typeof o['sourceUrl'] === 'string' || typeof o['sourceName'] === 'string'))
        return 'rssSource';
    if (objs.some((o) => typeof o['url'] === 'string' && (o['contentType'] != null || o['concurrentRate'] != null)))
        return 'httpTts';
    return 'bookSource';
}
/** 统一导入：书源 / 订阅源 / 朗读引擎；dryRun 只统计不落库。 */
export function importOnline(db, kind, text, dryRun) {
    const items = parseImportItems(text);
    const objects = items.filter((i) => i != null && typeof i === 'object');
    const result = {
        kind, total: items.length, imported: 0, updated: 0, skipped: 0, errors: [], names: [],
    };
    if (items.length === 0)
        throw new Error('内容不是有效的导入数据');
    if (kind === 'bookSource') {
        for (const o of objects) {
            try {
                result.names.push(SourceCodec.parse(JSON.stringify(o), false).name);
            }
            catch { /* 无效条目交给落库阶段计数 */ }
        }
        if (dryRun)
            return result;
        const imported = db.importSources(objects.map((o) => JSON.stringify(o)), false);
        return { ...result, imported: imported.imported, updated: imported.updated ?? 0, skipped: imported.skipped, errors: imported.errors ?? [] };
    }
    if (kind === 'rssSource') {
        const urls = objects.map((o) => (typeof o['sourceUrl'] === 'string' ? o['sourceUrl'] : typeof o['url'] === 'string' ? o['url'] : '')).filter((u) => u !== '');
        result.names = objects.map((o, i) => String(o['sourceName'] ?? o['name'] ?? urls[i] ?? `第 ${i + 1} 条`));
        const existing = new Set(db.listRssSources().map((s) => s.id));
        const updated = urls.filter((u) => existing.has(u)).length;
        if (dryRun)
            return { ...result, updated };
        const imported = db.importRssSources(objects.map((o) => JSON.stringify(o)));
        return { ...result, imported: Math.max(0, imported.imported - updated), updated, skipped: imported.skipped, errors: imported.errors };
    }
    // httpTts
    result.names = objects.map((o, i) => String(o['name'] ?? `第 ${i + 1} 条`));
    if (dryRun)
        return result;
    for (const obj of objects) {
        try {
            db.saveHttpTts({
                name: String(obj['name'] ?? ''),
                url: String(obj['url'] ?? ''),
                header: typeof obj['header'] === 'string' ? obj['header'] : null,
                contentType: typeof obj['contentType'] === 'string' ? obj['contentType'] : null,
                concurrentRate: typeof obj['concurrentRate'] === 'string' ? obj['concurrentRate'] : null,
                loginUrl: typeof obj['loginUrl'] === 'string' ? obj['loginUrl'] : null,
                loginCheckJs: typeof obj['loginCheckJs'] === 'string' ? obj['loginCheckJs'] : null,
                loginUi: typeof obj['loginUi'] === 'string' ? obj['loginUi'] : null,
                jsLib: typeof obj['jsLib'] === 'string' ? obj['jsLib'] : null,
                enabledCookieJar: obj['enabledCookieJar'] === true,
                lastUpdateTime: Date.now(),
            });
            result.imported++;
        }
        catch (e) {
            result.skipped++;
            result.errors.push(e instanceof Error ? e.message : String(e));
        }
    }
    return result;
}
