import Fastify from 'fastify';
import fastifyStatic from '@fastify/static';
import multipart from '@fastify/multipart';
import websocket from '@fastify/websocket';
import fs from 'node:fs';
import path from 'node:path';
import { Db, VersionConflict } from './database.js';
import { RulePool } from './rulePool.js';
import { CoverCache } from './coverCache.js';
import { EdgeTtsService } from './edgeTts.js';
import { RuleRunner, RuleExecutionError } from './ruleRunner.js';
import { SyncNet } from './syncNet.js';
import { registerTtsRoutes } from './routes/tts.js';
import { registerBookshelfRoutes } from './routes/bookshelf.js';
import { registerSourceRoutes } from './routes/sources.js';
import { registerSearchRoutes } from './routes/search.js';
import { registerBookRoutes } from './routes/books.js';
import { registerBookmarkRoutes } from './routes/bookmarks.js';
import { registerMiscRoutes } from './routes/misc.js';
import { registerBackupRoutes } from './routes/backup.js';
import { registerZLibraryRoutes } from './zlibrary.js';
import { registerTvboxRoutes } from './tvbox.js';
export function apiError(reply, status, code, message) {
    void reply.code(status);
    reply.send({ code, message });
    return reply;
}
export function respondCatching(reply, produce) {
    try {
        const result = produce();
        reply.send(result);
    }
    catch (e) {
        if (e instanceof VersionConflict) {
            apiError(reply, 409, 'version_conflict', '书源已被其他客户端修改，请刷新后重试');
        }
        else if (e instanceof RuleExecutionError) {
            apiError(reply, 502, 'rule_execution_failed', e.message);
        }
        else {
            apiError(reply, 500, 'internal_error', e instanceof Error ? e.message : '服务器内部错误');
        }
    }
}
export async function respondCatchingAsync(reply, produce) {
    try {
        const result = await produce();
        reply.send(result);
    }
    catch (e) {
        if (e instanceof VersionConflict) {
            apiError(reply, 409, 'version_conflict', '书源已被其他客户端修改，请刷新后重试');
        }
        else if (e instanceof RuleExecutionError) {
            apiError(reply, 502, 'rule_execution_failed', e.message);
        }
        else {
            apiError(reply, 500, 'internal_error', e instanceof Error ? e.message : '服务器内部错误');
        }
    }
}
export async function buildApp(config) {
    const app = Fastify({
        logger: false,
        bodyLimit: 64 * 1024 * 1024,
    });
    await app.register(multipart, { limits: { fileSize: 32 * 1024 * 1024, files: 20 } });
    await app.register(websocket);
    const db = new Db(config.databasePath);
    db.initialize();
    const pool = new RulePool(config.databasePath, 6);
    const coverCache = new CoverCache(config.coverCacheDirectory, db);
    const edgeTts = new EdgeTtsService();
    // 主线程的 RuleRunner：封面代抓等轻量同步取数用它（正文/目录走线程池）。
    const mainNet = new SyncNet();
    const mainRunner = new RuleRunner(db, mainNet);
    const ctx = {
        config, db, pool, coverCache, edgeTts,
        sourceImportTokenCache: new Map(),
    };
    app.setNotFoundHandler((request, reply) => {
        if (request.url.startsWith('/api/')) {
            void reply.code(404).send({ code: 'not_found', message: '接口不存在' });
            return;
        }
        // SPA 回退：非 API 路径全部回 index.html
        const indexPath = path.join(config.staticWebDirectory, 'index.html');
        if (fs.existsSync(indexPath)) {
            reply.type('text/html; charset=utf-8').send(fs.createReadStream(indexPath));
        }
        else {
            void reply.code(404).send({ code: 'not_found', message: '资源不存在' });
        }
    });
    app.setErrorHandler((error, request, reply) => {
        if (error.validation != null) {
            void reply.code(400).send({ code: 'bad_request', message: error.message });
            return;
        }
        request.log.error(error);
        void reply.code(500).send({ code: 'internal_error', message: '服务器内部错误' });
    });
    app.get('/healthz', async () => ({ status: 'ok' }));
    // ---------------- 语言偏好 ----------------
    app.get('/api/settings/locale', async (request, reply) => {
        return { locale: db.getSetting('locale') };
    });
    app.put('/api/settings/locale', async (request, reply) => {
        const body = request.body;
        db.setSetting('locale', (body?.locale ?? '').trim());
        return { locale: body?.locale ?? null };
    });
    // ---------------- 封面 ----------------
    app.get('/api/covers/:key', async (request, reply) => {
        const { key } = request.params;
        const cover = coverCache.get(key);
        if (cover == null)
            return apiError(reply, 404, 'not_found', '封面不存在');
        reply.header('Cache-Control', 'public, max-age=604800');
        return reply.type(cover.contentType).send(cover.bytes);
    });
    app.post('/api/covers/upload', async (request, reply) => {
        const parts = request.parts();
        let bytes = null;
        const meta = {};
        for await (const part of parts) {
            if (part.type === 'file') {
                bytes = Buffer.from(await part.toBuffer());
            }
            else if (part.type === 'field') {
                if (part.fieldname === 'bookName' || part.fieldname === 'bookUrl') {
                    meta[part.fieldname] = (await part.value);
                }
            }
        }
        if (bytes == null)
            return apiError(reply, 400, 'invalid_request', '缺少封面文件');
        const stored = coverCache.put(bytes, meta.bookName ?? null, meta.bookUrl ?? null);
        if (stored == null)
            return apiError(reply, 400, 'invalid_cover', '封面格式不支持或超过 8 MiB');
        return { coverKey: stored.cacheKey, contentType: stored.contentType, url: `/api/covers/${stored.cacheKey}` };
    });
    // ---------------- 书源分组 ----------------
    app.get('/api/source-groups', async (request, reply) => {
        return db.listSourceGroups();
    });
    app.put('/api/source-groups/rename', async (request, reply) => {
        const body = request.body;
        if (body == null || (body.from ?? '').trim() === '' || (body.to ?? '').trim() === '') {
            return apiError(reply, 400, 'invalid_request', '分组名不能为空');
        }
        const affected = db.renameSourceGroup(body.from, body.to);
        return { ok: true, affected, message: `已重命名分组：${body.from} → ${body.to}` };
    });
    app.delete('/api/source-groups', async (request, reply) => {
        const body = request.body;
        const name = (body?.name ?? '').trim();
        if (name === '')
            return apiError(reply, 400, 'invalid_request', '分组名不能为空');
        const affected = db.clearSourceGroup(name);
        return { ok: true, affected, message: `已清空 ${affected} 个书源的分组` };
    });
    app.put('/api/covers/book', async (request, reply) => {
        const body = request.body;
        const bookName = (body?.bookName ?? '').trim();
        if (bookName === '')
            return apiError(reply, 400, 'invalid_request', '缺少书名');
        const bookAuthor = body?.bookAuthor ?? null;
        const bookUrl = body?.bookUrl ?? null;
        if (body?.remove === true) {
            const existing = db.getBookCover(bookName, bookAuthor);
            if (existing?.coverKey != null)
                coverCache.delete(existing.coverKey);
            db.saveBookCover(bookName, bookAuthor, null);
            return { bookName, bookAuthor, coverKey: null, coverMissing: false, coverAttempts: 0 };
        }
        let coverKey = body?.coverKey ?? null;
        if (coverKey == null && body?.coverUrl != null && body.coverUrl !== '') {
            try {
                const sourceJson = body.sourceId != null ? db.getSource(body.sourceId)?.json ?? null : null;
                const headers = sourceJson != null ? mainRunner.mediaHeaders(sourceJson, body.sourceId ?? undefined) : {};
                const response = await fetch(body.coverUrl, { headers, redirect: 'follow' });
                if (response.ok) {
                    const bytes = Buffer.from(await response.arrayBuffer());
                    const stored = coverCache.put(bytes, bookName, bookUrl);
                    if (stored != null)
                        coverKey = stored.cacheKey;
                }
            }
            catch { /* 代下失败走 miss 登记分支 */ }
        }
        if (coverKey == null) {
            db.recordCoverMiss(bookName, bookAuthor);
        }
        else {
            db.saveBookCover(bookName, bookAuthor, coverKey);
            attachCoverToShelfRowsLocal(db, bookName, bookAuthor, coverKey);
        }
        const state = db.getBookCover(bookName, bookAuthor);
        return {
            bookName,
            bookAuthor,
            coverKey: state?.coverKey ?? coverKey,
            coverMissing: (state?.missingAttempts ?? 0) >= 5,
            coverAttempts: state?.missingAttempts ?? 0,
        };
    });
    // ---------------- 阅读进度 ----------------
    app.get('/api/reading-progress', async (request, reply) => {
        const query = request.query;
        if (query.sourceId == null || query.bookUrl == null)
            return apiError(reply, 400, 'invalid_request', '缺少书源或书籍地址');
        const progress = db.getProgress(query.sourceId, query.bookUrl);
        if (progress == null)
            return apiError(reply, 404, 'not_found', '暂无阅读进度');
        return progress;
    });
    app.put('/api/reading-progress', async (request, reply) => {
        const body = request.body;
        if (body == null || body.sourceId == null || body.sourceId === '' || body.bookUrl == null || body.bookUrl === '') {
            return apiError(reply, 400, 'invalid_request', '缺少书源或书籍地址');
        }
        const scrollPosition = body.scrollPosition ?? 0;
        if (scrollPosition < 0 || scrollPosition > 1)
            return apiError(reply, 400, 'invalid_request', '阅读位置必须在 0~1 之间');
        const progress = {
            sourceId: body.sourceId,
            bookUrl: body.bookUrl,
            chapterUrl: body.chapterUrl ?? '',
            chapterIndex: body.chapterIndex ?? 0,
            scrollPosition,
            chapterTitle: body.chapterTitle ?? null,
            positionMs: body.positionMs ?? null,
            bookKind: body.bookKind ?? null,
        };
        return db.saveProgress(progress);
    });
    // ---------------- 路由模块 ----------------
    registerSourceRoutes(app, ctx, mainRunner);
    registerSearchRoutes(app, ctx);
    registerBookRoutes(app, ctx, mainRunner);
    registerBookshelfRoutes(app, ctx, mainRunner);
    registerBookmarkRoutes(app, ctx);
    registerMiscRoutes(app, ctx);
    registerBackupRoutes(app, ctx);
    registerTtsRoutes(app, ctx);
    registerZLibraryRoutes(app, ctx);
    registerTvboxRoutes(app, ctx, mainRunner);
    // ---------------- 静态 Web ----------------
    if (fs.existsSync(path.join(config.staticWebDirectory, 'index.html'))) {
        await app.register(fastifyStatic, {
            root: config.staticWebDirectory,
            prefix: '/',
            // 必须开 wildcard：为 false 时不注册通配路由，`/assets/*.js` 会一路掉到
            // setNotFoundHandler 的 SPA 回退，返回 index.html（MIME text/html）⇒ 前端白屏。
            wildcard: true,
            decorateReply: true,
        });
    }
    app.addHook('onClose', async () => {
        pool.close();
        mainNet.close();
        db.close();
    });
    return app;
}
/** 把书签页的封面挂到书架行（按书名+作者匹配的所有书）。 */
function attachCoverToShelfRowsLocal(db, bookName, bookAuthor, coverKey) {
    const info = db.db.prepare('update book_shelf set cover_key = ? where name = ? and (author = ? or (author is null and ? is null))')
        .run(coverKey, bookName, bookAuthor, bookAuthor);
    void info;
}
