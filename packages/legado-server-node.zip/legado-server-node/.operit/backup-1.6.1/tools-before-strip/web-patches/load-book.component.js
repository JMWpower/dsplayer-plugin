Cd=async(o,n)=>{

const alt=Array.isArray(n)?n:[];
const firstText=(...vals)=>{
  for(const v of vals){
    if(typeof v==="string"&&v.trim()!=="")return v.trim();
  }
  return undefined;
};
let det=null;
try{
  det=await V.details(o.sourceId,o.bookUrl);
}catch(e){
  det=null;
}
const raw=det&&typeof det==="object"?det:{};
const name=firstText(raw.name,o.name,...alt.map(x=>x&&x.name))||nt.t("common.unknownBook","未知书名");
const author=firstText(raw.author,o.author,...alt.map(x=>x&&x.author));
const coverUrl=firstText(raw.coverUrl,o.coverUrl,...alt.map(x=>x&&x.coverUrl));
const intro=firstText(raw.intro,o.intro,...alt.map(x=>x&&x.intro));
const bookKind=raw.bookKind||o.bookKind;
const details={
  ...raw,
  sourceId:raw.sourceId||o.sourceId,
  name:name,
  author:author,
  coverUrl:coverUrl,
  intro:intro,
  bookKind:bookKind,
  tocUrl:firstText(raw.tocUrl,o.tocUrl,o.bookUrl),
  alternateSources:alt.filter(x=>!!x&&(x.sourceId!==o.sourceId||x.bookUrl!==o.bookUrl))
};
let chapters=null;
let firstError=null;
try{
  chapters=await V.chapters(details.sourceId,o.bookUrl);
}catch(e){
  firstError=e;
}
if(!Array.isArray(chapters)||chapters.length===0){
  const retryUrl=firstText(details.tocUrl);
  if(retryUrl&&retryUrl!==o.bookUrl){
    try{
      const again=await V.chapters(details.sourceId,retryUrl);
      if(Array.isArray(again)&&again.length>0)chapters=again;
    }catch(e){
      if(!firstError)firstError=e;
    }
  }
}
if(!Array.isArray(chapters))chapters=[];
if(chapters.length===0&&firstError){
  const reason=(firstError&&firstError.message)||String(firstError);
  throw new Error(reason);
}
const progress=await V.progress(details.sourceId,o.bookUrl).catch(()=>null);
return{details:details,bookUrl:o.bookUrl,chapters:chapters,progress:progress,bookKind:bookKind};
}