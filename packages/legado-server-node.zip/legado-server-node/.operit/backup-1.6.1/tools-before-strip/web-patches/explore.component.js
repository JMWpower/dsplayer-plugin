function lC({onOpen:o}){

const {t:n}=at();
const [srcList,setSrcList]=m.useState([]);
const [srcId,setSrcId]=m.useState("");
const [kw,setKw]=m.useState("");
const [open,setOpen]=m.useState(false);
const [pickerOpen,setPickerOpen]=m.useState(false);
const [cats,setCats]=m.useState([]);
const [cat,setCat]=m.useState(null);
const [books,setBooks]=m.useState([]);
const [page,setPage]=m.useState(1);
const [hasMore,setHasMore]=m.useState(true);
const [srcLoading,setSrcLoading]=m.useState(false);
const [catLoading,setCatLoading]=m.useState(false);
const [bookLoading,setBookLoading]=m.useState(false);
const [moreLoading,setMoreLoading]=m.useState(false);
const [opening,setOpening]=m.useState(null);
const [shelf,setShelf]=m.useState([]);
const [adding,setAdding]=m.useState({});
const srcRef=m.useRef("");
srcRef.current=srcId;

const readStore=k=>{try{return window.localStorage.getItem(k)}catch(e){return null}};
const writeStore=(k,v)=>{try{window.localStorage.setItem(k,v)}catch(e){}};
const CAT_KEY="lr.exploreCategories";
const catMap=()=>{try{const raw=readStore(CAT_KEY);const obj=raw?JSON.parse(raw):null;return obj&&typeof obj=="object"?obj:{}}catch(e){return {}}};
const rememberCat=(id,title)=>{if(!id||!title)return;const all=catMap();all[id]=title;writeStore(CAT_KEY,JSON.stringify(all))};
const flattenCats=(list,out)=>{out=out||[];(list||[]).forEach(c=>{if(!c)return;if(c.url&&String(c.url).trim()!=="")out.push(c);if(c.subCategories&&c.subCategories.length)flattenCats(c.subCategories,out)});return out};

m.useEffect(()=>{
  let alive=true;
  setSrcLoading(true);
  Promise.all([V.exploreSources(),V.bookshelf().catch(()=>[])]).then(([srcs,shelfRows])=>{
    if(!alive)return;
    const list=Array.isArray(srcs)?srcs:[];
    setSrcList(list);
    setShelf(Array.isArray(shelfRows)?shelfRows:[]);
    if(list.length===0)return;
    const saved=readStore("lr.exploreSource");
    const hit=(saved&&list.find(s=>s.id===saved))||list.find(s=>s.enabled)||list[0];
    if(hit)setSrcId(hit.id);
  }).catch(e=>{
    if(alive)Y.error((e&&e.message)||n("explore.noExploreSources","暂无支持发现页的书源"));
  }).finally(()=>{
    if(alive)setSrcLoading(false);
  });
  return ()=>{alive=false};
},[]);

m.useEffect(()=>{
  if(!srcId){
    setCats([]);setCat(null);setBooks([]);
    return undefined;
  }
  writeStore("lr.exploreSource",srcId);
  let alive=true;
  const mine=srcId;
  const isStale=()=>!alive||srcRef.current!==mine;
  setCat(null);setCats([]);setBooks([]);setPage(1);setHasMore(true);
  setCatLoading(true);setBookLoading(true);
  (async()=>{
    let list;
    try{
      list=await V.exploreCategories(mine);
    }catch(e){
      if(isStale())return;
      Y.error((e&&e.message)||n("explore.noCategories","该书源未配置有效分类"));
      return;
    }
    if(isStale())return;
    const all=Array.isArray(list)?list:[];
    setCats(all);
    const flat=flattenCats(all);
    if(flat.length===0){setBookLoading(false);return}
    const remembered=(catMap()[mine])||"";
    let start=flat.findIndex(c=>c.title===remembered);
    if(start<0)start=0;
    const limit=Math.min(flat.length,6);
    let lastError=null;
    let stopped=flat[start];
    for(let k=0;k<limit;k++){
      if(isStale())return;
      const cand=flat[(start+k)%flat.length];
      stopped=cand;
      setCat(cand);setBooks([]);setPage(1);setHasMore(true);
      let rows=null;
      try{
        rows=await V.exploreBooks(mine,cand.url,1);
      }catch(e){
        lastError=e;
        continue;
      }
      if(isStale())return;
      const got=Array.isArray(rows)?rows:[];
      if(got.length>0){
        setBooks(got);setHasMore(true);rememberCat(mine,cand.title);
        setBookLoading(false);setCatLoading(false);
        return;
      }
    }
    if(isStale())return;
    if(stopped)setCat(stopped);
    setBooks([]);setHasMore(false);setBookLoading(false);setCatLoading(false);
    if(lastError)Y.error((lastError&&lastError.message)||n("explore.noBooks","该分类下暂无书籍"));
  })().finally(()=>{
    if(isStale())return;
    setCatLoading(false);setBookLoading(false);
  });
  return ()=>{alive=false};
},[srcId]);

const current=srcList.find(s=>s.id===srcId)||null;
const filteredSrc=m.useMemo(()=>{
  const key=kw.trim().toLowerCase();
  return key?srcList.filter(s=>s.name.toLowerCase().includes(key)||(s.group&&s.group.toLowerCase().includes(key))):srcList;
},[srcList,kw]);
const switchSource=id=>{setSrcId(id);setOpen(false);setKw("")};

const pickCategory=c=>{
  if(!c||!c.url)return;
  const mine=srcId;
  setPickerOpen(false);setCat(c);setBooks([]);setPage(1);setHasMore(true);setBookLoading(true);
  V.exploreBooks(mine,c.url,1).then(rows=>{
    if(srcRef.current!==mine)return;
    const got=Array.isArray(rows)?rows:[];
    setBooks(got);
    setHasMore(got.length>0);
    if(got.length>0)rememberCat(mine,c.title);
  }).catch(e=>{
    if(srcRef.current!==mine)return;
    setBooks([]);setHasMore(false);
    Y.error((e&&e.message)||n("explore.noBooks","该分类下暂无书籍"));
  }).finally(()=>{
    if(srcRef.current!==mine)return;
    setBookLoading(false);
  });
};

const loadMore=async()=>{
  if(!cat||!cat.url||moreLoading||!hasMore||bookLoading)return;
  const mine=srcId;
  const next=page+1;
  setMoreLoading(true);
  try{
    const rows=await V.exploreBooks(mine,cat.url,next);
    if(srcRef.current!==mine)return;
    const got=Array.isArray(rows)?rows:[];
    if(got.length===0){
      setHasMore(false);
      Y.info(n("explore.noMoreBooks","没有更多书籍了"));
    }else{
      setBooks(prev=>prev.concat(got));
      setPage(next);
    }
  }catch(e){
    if(srcRef.current===mine)Y.error((e&&e.message)||n("explore.loadMore","加载更多"));
  }finally{
    if(srcRef.current===mine)setMoreLoading(false);
  }
};

const inShelf=item=>shelf.some(b=>b.name===item.name&&(!item.author||b.author===item.author));
const addToShelf=async item=>{
  const key=`${item.sourceId}::${item.bookUrl}`;
  if(adding[key]||inShelf(item))return;
  setAdding(prev=>({...prev,[key]:true}));
  try{
    let detail=null;
    try{detail=await V.details(item.sourceId,item.bookUrl)}catch(e){detail=null}
    const saved=await V.addToBookshelf({
      sourceId:item.sourceId,bookUrl:item.bookUrl,
      name:(detail&&detail.name)||item.name,
      author:(detail&&detail.author)||item.author,
      tocUrl:(detail&&detail.tocUrl)||item.bookUrl,
      coverUrl:(detail&&detail.coverUrl)||item.coverUrl
    });
    setShelf(prev=>prev.concat(saved?[saved]:[]));
    Y.success(n("shelf.addedToShelfToast",{name:item.name,defaultValue:`《${item.name}》已加入书架`}));
  }catch(e){
    Y.error((e&&e.message)||n("common.failed","操作失败"));
  }finally{
    setAdding(prev=>{const next={...prev};delete next[key];return next});
  }
};

const openBook=async item=>{
  if(opening)return;
  const mine=srcId;
  setOpening(item.bookUrl);
  try{
    const loaded=await Cd(item);
    if(srcRef.current!==mine)return;
    const total=Array.isArray(loaded.chapters)?loaded.chapters.length:0;
    const resume=loaded.progress?Math.min(Math.max(loaded.progress.chapterIndex,0),Math.max(0,total-1)):0;
    o(loaded,resume);
  }catch(e){
    Y.error((e&&e.message)||n("common.failed","操作失败"));
  }finally{
    setOpening(null);
  }
};

const renderCatTags=list=>list.map((c,i)=>t.jsx("button",{
  type:"button",
  className:`explore-category-tag ${cat===c?"active":""}`,
  onClick:()=>pickCategory(c),
  children:c.title
},`${c.title}-${i}`));

const renderCatTree=()=>{
  const groups=cats.filter(c=>c.subCategories&&c.subCategories.length>0);
  const standalone=cats.filter(c=>!(c.subCategories&&c.subCategories.length>0));
  return t.jsxs("div",{className:"explore-category-tree",children:[
    groups.map((g,gi)=>t.jsxs("div",{className:"explore-category-group",children:[
      t.jsx("div",{className:"explore-category-group-title",children:g.title}),
      t.jsx("div",{className:"explore-category-tags",children:renderCatTags(g.subCategories||[])})
    ]},`${g.title}-${gi}`)),
    standalone.length>0&&t.jsx("div",{className:"explore-category-standalone-list",children:standalone.map((c,i)=>t.jsx("button",{
      type:"button",
      className:`explore-category-tag standalone ${cat===c?"active":""}`,
      onClick:()=>pickCategory(c),
      children:c.title
    },`${c.title}-${i}`))})
  ]});
};

return t.jsxs("main",{className:"explore-page",children:[
  t.jsxs("aside",{className:"explore-sidebar",children:[
    t.jsxs("div",{className:"explore-sidebar-section",children:[
      t.jsxs("div",{className:"explore-source-select-header",children:[
        t.jsx("h3",{children:n("explore.selectSource","选择书源")}),
        t.jsx("span",{className:"explore-source-count-badge",children:filteredSrc.length})
      ]}),
      t.jsxs("div",{className:"explore-source-dropdown",children:[
        t.jsxs("button",{
          type:"button",
          className:`explore-source-trigger ${open?"open":""}`,
          "aria-haspopup":"listbox",
          "aria-expanded":open,
          onClick:()=>setOpen(v=>!v),
          children:[
            t.jsx("span",{className:"explore-source-trigger-name",children:(current&&current.name)||n("explore.selectSource","选择书源")}),
            t.jsx(O,{name:"chevronDown",width:16,height:16})
          ]
        }),
        open&&t.jsxs(t.Fragment,{children:[
          t.jsx("div",{className:"explore-dropdown-backdrop",onClick:()=>setOpen(false)}),
          t.jsxs("div",{className:"explore-source-menu",role:"listbox",children:[
            t.jsx("input",{
              type:"text",value:kw,onChange:e=>setKw(e.target.value),
              placeholder:n("explore.searchSourcePlaceholder","搜索书源..."),
              className:"explore-source-filter-input",autoFocus:!0
            }),
            t.jsx("div",{className:"explore-source-menu-list",children:
              srcLoading?t.jsx("div",{className:"explore-loading-hint",children:n("explore.loadingCategories","正在加载...")})
              :filteredSrc.length===0?t.jsx("div",{className:"explore-empty-hint",children:n("explore.noExploreSources","暂无支持发现页的书源")})
              :filteredSrc.map(s=>t.jsxs("button",{
                type:"button",role:"option","aria-selected":s.id===srcId,
                className:`explore-source-option ${s.id===srcId?"active":""}`,
                onClick:()=>switchSource(s.id),
                children:[
                  t.jsx("span",{className:"explore-source-option-name",children:s.name}),
                  s.group&&t.jsx("span",{className:"explore-source-group-tag",children:s.group})
                ]
              },s.id))})
          ]})
        ]})
      ]})
    ]}),
    t.jsxs("div",{className:"explore-sidebar-section explore-categories-section",children:[
      t.jsxs("div",{className:"explore-category-header",children:[
        t.jsx("h3",{children:(current&&current.name)||n("explore.title","发现")}),
        t.jsx("button",{
          type:"button",className:"explore-category-picker-btn",
          title:n("explore.allCategories","全部分类"),"aria-label":n("explore.allCategories","全部分类"),
          onClick:()=>setPickerOpen(true),disabled:cats.length===0,
          children:t.jsx(O,{name:"list",width:16,height:16})
        })
      ]}),
      catLoading?t.jsx("div",{className:"explore-loading-hint",children:n("explore.loadingCategories","正在加载分类...")})
      :cats.length===0?t.jsx("div",{className:"explore-empty-hint",children:n("explore.noCategories","该书源未配置有效分类")})
      :renderCatTree()
    ]})
  ]}),
  t.jsxs("section",{className:"explore-content",children:[
    t.jsxs("header",{className:"explore-content-header",children:[
      t.jsxs("div",{className:"explore-content-title-area",children:[
        t.jsx("h2",{children:(cat&&cat.title)||n("explore.title","发现")}),
        current&&t.jsx("span",{className:"explore-content-source-name",children:current.name})
      ]}),
      books.length>0&&t.jsx("span",{className:"explore-content-count",children:n("library.statResultCount",{count:books.length,defaultValue:`结果 ${books.length}`})})
    ]}),
    bookLoading?t.jsxs("div",{className:"explore-loading-books",children:[
      t.jsx("div",{className:"explore-spinner"}),
      t.jsx("p",{children:n("explore.loadingBooks","正在加载书籍...")})
    ]})
    :books.length===0?t.jsxs("div",{className:"explore-empty-books",children:[
      t.jsx(O,{name:"search",width:48,height:48,className:"explore-empty-icon"}),
      t.jsx("p",{children:n("explore.noBooks","该分类下暂无书籍")})
    ]})
    :t.jsxs(t.Fragment,{children:[
      t.jsx("div",{className:"explore-book-grid",children:books.map((item,index)=>{
        const already=inShelf(item);
        const key=`${item.sourceId}::${item.bookUrl}`;
        const busy=!!adding[key];
        const isOpening=opening===item.bookUrl;
        return t.jsxs("article",{className:"explore-book-card",children:[
          t.jsxs("div",{className:"explore-book-cover-wrapper",children:[
            item.coverUrl?t.jsx("img",{
              src:item.coverUrl,alt:item.name,className:"explore-book-cover",loading:"lazy",
              onError:e=>{e.currentTarget.style.display="none"}
            }):null,
            t.jsx("div",{className:"explore-book-cover-placeholder",children:t.jsx("span",{className:"explore-cover-text",children:String(item.name||"").slice(0,4)})})
          ]}),
          t.jsxs("div",{className:"explore-book-info",children:[
            t.jsx("h4",{className:"explore-book-name",title:item.name,children:item.name}),
            item.author&&t.jsx("div",{className:"explore-book-author",children:t.jsx("span",{children:item.author})}),
            item.intro&&t.jsx("p",{className:"explore-book-intro",title:item.intro,children:item.intro}),
            t.jsxs("div",{className:"explore-book-actions",children:[
              t.jsxs("button",{
                type:"button",
                className:`explore-action-btn ${already?"in-shelf":"add-shelf"}`,
                onClick:()=>addToShelf(item),
                disabled:already||busy,
                title:already?n("explore.inShelf","已在书架"):n("explore.addToShelf","加入书架"),
                children:[
                  t.jsx(O,{name:already?"check":"plus",width:14,height:14}),
                  t.jsx("span",{children:busy?n("explore.addingToShelf","加入中..."):already?n("explore.inShelf","已在书架"):n("explore.addToShelf","加入书架")})
                ]
              }),
              t.jsxs("button",{
                type:"button",className:"explore-action-btn primary",
                onClick:()=>openBook(item),disabled:isOpening,
                title:n("explore.readNow","立即阅读"),
                children:[
                  t.jsx(O,{name:"book",width:14,height:14}),
                  t.jsx("span",{children:isOpening?n("library.reading","正在打开..."):n("explore.readNow","立即阅读")})
                ]
              })
            ]})
          ]})
        ]},`${item.bookUrl}-${index}`);
      })}),
      hasMore?t.jsx("div",{className:"explore-load-more-wrap",children:t.jsx("button",{
        type:"button",className:"explore-load-more-btn",onClick:loadMore,disabled:moreLoading,
        children:moreLoading?n("explore.loadingMore","加载中..."):n("explore.loadMore","加载更多")
      })}):t.jsx("div",{className:"explore-no-more",children:n("explore.noMoreBooks","没有更多书籍了")})
    ]})
  ]}),
  pickerOpen&&t.jsx("div",{className:"modal-backdrop",onClick:()=>setPickerOpen(false),children:
    t.jsxs("div",{
      className:"explore-category-picker",role:"dialog","aria-modal":"true",
      onClick:e=>e.stopPropagation(),
      children:[
        t.jsxs("header",{className:"explore-category-picker-header",children:[
          t.jsx("h3",{children:n("explore.allCategories","全部分类")}),
          t.jsx("button",{
            type:"button",className:"network-import-more-btn",
            "aria-label":n("common.close","关闭"),onClick:()=>setPickerOpen(false),
            children:t.jsx(O,{name:"close"})
          })
        ]}),
        t.jsxs("div",{className:"explore-category-picker-body",children:[
          cats.filter(c=>c.subCategories&&c.subCategories.length>0).map((g,gi)=>t.jsxs("div",{className:"explore-category-picker-group",children:[
            t.jsx("div",{className:"explore-category-group-title",children:g.title}),
            t.jsx("div",{className:"explore-category-tags",children:renderCatTags(g.subCategories||[])})
          ]},`${g.title}-${gi}`)),
          cats.filter(c=>!(c.subCategories&&c.subCategories.length>0)).map((c,i)=>t.jsx("button",{
            type:"button",
            className:`explore-category-tag standalone ${cat===c?"active":""}`,
            onClick:()=>pickCategory(c),
            children:c.title
          },`${c.title}-standalone-${i}`))
        ]})
      ]
    })})
]});
}