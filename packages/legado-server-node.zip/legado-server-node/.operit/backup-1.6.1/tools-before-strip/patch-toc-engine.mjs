#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const ROOT = path.resolve(import.meta.dirname, '..');
const RUNNER = path.join(ROOT, 'dist/ruleRunner.js');
const SANDBOX = path.join(ROOT, 'dist/jsSandbox.js');
const checkOnly = process.argv.includes('--check');

const edits = [];

function syntaxOk(code, name) {
  const tmp = path.join(os.tmpdir(), 'lr-syntax-' + Date.now() + '-' + name + '.mjs');
  fs.writeFileSync(tmp, code);
  try {
    execFileSync(process.execPath, ['--check', tmp], { stdio: 'pipe' });
    return null;
  } catch (e) {
    return String(e.stderr || e.message).slice(0, 400);
  } finally {
    fs.rmSync(tmp, { force: true });
  }
}

function backup(file) {
  const dir = path.join(ROOT, '.operit/backup-1.6.0');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  fs.copyFileSync(file, path.join(dir, path.basename(file) + '.before-toc-engine.' + stamp + '.bak'));
}

{
  let s = fs.readFileSync(RUNNER, 'utf8');
  const before = s;

  if (!s.includes('if (hasOrdinalSegment(rule)) {')) {
    if (!s.includes('function hasOrdinalSegment(rule) {')) {
      const anchor = `function nodes(body, rule) {
    if (rule.startsWith('$')) {`;
      if (!s.includes(anchor)) throw new Error('nodes() 锚点没找到');
      const addition = `/** 规则链里是否含「第 N 个匹配」的序号段（class.X.N / tag.X.N / X.N）。 */
function hasOrdinalSegment(rule) {
    if (rule.includes('<js>') || rule.includes('@js:'))
        return false;
    return rule.split('@').some((seg) => /^(?:class\\.[A-Za-z][\\w-]*|tag\\.[A-Za-z][\\w-]*|[A-Za-z][\\w-]*)\\.\\d+$/.test(seg.trim()));
}
${anchor}`;
      s = s.replace(anchor, () => addition);
      edits.push('新增 hasOrdinalSegment()');
    }

    const insertAfter = `    const $ = cheerio.load(body);
    const selected = $.root().find(ruleCss(rule));`;
    if (!s.includes(insertAfter)) throw new Error('nodes() 里 cheerio 段锚点没找到');
    const ordinalPath = `    /* 1.6.0：序号段（class.X.N）在 CSS 里没有等价写法 —— :nth-of-type 数的是同类兄弟，
       不是匹配集合下标。这类链改成逐段选择，序号段用 .eq(N) 取。 */
    if (hasOrdinalSegment(rule)) {
        const $ord = cheerio.load(body);
        let set = $ord.root();
        for (const seg of rule.split('@')) {
            if (seg.trim() === '')
                continue;
            set = selectAllLegado(set, seg);
        }
        return set.toArray().map((el) => NodeValue.html(WRAP$(el)));
    }
${insertAfter}`;
    s = s.replace(insertAfter, () => ordinalPath);
    edits.push('nodes()：序号段改走逐段选择');
  }

  if (!s.includes("String(item).trimStart().startsWith('<')")) {
    const oldFirst = `        return parsed.map((item) => NodeValue.json(item));`;
    if (!s.includes(oldFirst)) throw new Error('jsListNodes 的 map 锚点没找到');
    const newFirst = `        return parsed.map((item) => {
            /* 1.6.0：书源里常见 org.jsoup...select() 返回元素列表，序列化后是 outerHTML 字符串数组，
               这些「看起来是 HTML」的条目要当节点用，否则 chapterName/chapterUrl 取不到值。 */
            if (typeof item === 'string' && String(item).trimStart().startsWith('<')) {
                const $item = cheerio.load(String(item));
                const el = $item('body').children().first();
                return NodeValue.html(el.length > 0 ? el : $item.root());
            }
            return NodeValue.json(item);
        });`;
    s = s.replace(oldFirst, () => newFirst);
    edits.push('jsListNodes()：HTML 字符串条目转成节点');
  }

  if (s !== before) {
    const err = syntaxOk(s, 'ruleRunner');
    if (err) throw new Error('ruleRunner 语法不通过：' + err);
    if (!checkOnly) {
      backup(RUNNER);
      fs.writeFileSync(RUNNER, s);
    }
  }
}

{
  let s = fs.readFileSync(SANDBOX, 'utf8');
  const before = s;

  if (!s.includes("sandbox['org']")) {
    if (!s.includes("import { NodeValue } from './ruleRunner.js';")) throw new Error('jsSandbox 头部锚点没找到');
    s = s.replace(
      "import { NodeValue } from './ruleRunner.js';",
      () => "import * as cheerio from 'cheerio';\nimport { NodeValue } from './ruleRunner.js';"
    );

    const javaAnchor = "        sandbox['java'] = this.createJavaBridge(context);";
    if (!s.includes(javaAnchor)) throw new Error('java 桥锚点没找到');
    s = s.replace(javaAnchor, () => `        const jsoupBridge = this.createJsoupBridge();
        sandbox['org'] = jsoupBridge.org;
        sandbox['Packages'] = jsoupBridge.packages;
${javaAnchor}`);

    const methodAnchor = '    createChapterBridge(execContext) {';
    if (!s.includes(methodAnchor)) throw new Error('createChapterBridge 锚点没找到');
    const method = `    /**
     * 1.6.0：书源脚本里的 org.jsoup.Jsoup / Packages.java.util.ArrayList 兼容层。
     *
     * 很多 Legado 源（哔哩小说就是）用
     *   var doc = org.jsoup.Jsoup.parse(body);
     *   var els = doc.select('div.module-row-info');
     *   var list = new Packages.java.util.ArrayList();
     *   for (var i = 0; i < els.size(); i++) list.add(els.get(i));
     *   return list;
     * 来返回元素列表；以前沙箱没有这两个名字，求值直接抛错、目录 0 章。
     * 这里用 cheerio 顶上：元素的 toJSON 给 outerHTML，序列化后正好是 JSON 字符串数组，
     * 再由 ruleRunner.jsListNodes() 还原成节点。
     */
    createJsoupBridge() {
        /* 空 cheerio 实例当包装器：\`$(el)\` 包住已有节点，\`$.html(el)\` 取 outerHTML。
           cheerio 顶层没有 \`html()\`，必须走实例。 */
        const $wrap = cheerio.load('<html><body></body></html>');
        const outerOf = (el) => {
            try {
                return $wrap.html(el) ?? '';
            }
            catch {
                return '';
            }
        };
        const elementShim = (el) => ({
            text: () => $wrap(el).text(),
            html: () => $wrap(el).html() ?? '',
            outerHtml: () => outerOf(el),
            attr: (name) => $wrap(el).attr(name) ?? '',
            select: (css) => listShim($wrap(el).find(css).toArray()),
            getElementsByTag: (tag) => listShim($wrap(el).find(tag).toArray()),
            toJSON: () => outerOf(el),
        });
        const listShim = (arr) => {
            const list = arr.map((el) => elementShim(el));
            list.add = (x) => { list.push(x); return true; };
            list.size = () => list.length;
            list.get = (i) => list[i];
            list.toArray = () => list.slice();
            list.toJSON = () => list.slice();
            return list;
        };
        const documentShim = (html) => {
            const $ = cheerio.load(String(html ?? ''));
            return {
                select: (css) => listShim($(css).toArray()),
                selectFirst: (css) => { const e = $(css); return e.length > 0 ? elementShim(e[0]) : null; },
                getElementsByTag: (tag) => listShim($(tag).toArray()),
                text: () => $.root().text(),
                html: () => $.html(),
                body: () => elementShim($('body')[0] ?? $.root()[0]),
                toJSON: () => $.html(),
            };
        };
        const ArrayList = function ArrayList() {
            return listShim([]);
        };
        return {
            org: {
                jsoup: {
                    Jsoup: {
                        parse: (html) => documentShim(html),
                        connect: () => { throw new Error('org.jsoup.Jsoup.connect 不支持，请用 java.ajax'); },
                    },
                },
            },
            packages: {
                java: {
                    util: { ArrayList, List: ArrayList },
                },
            },
        };
    }
${methodAnchor}`;
    s = s.replace(methodAnchor, () => method);
    edits.push('jsSandbox：补 org.jsoup / Packages.java.util.ArrayList 兼容桥');
  }

  if (s !== before) {
    const err = syntaxOk(s, 'jsSandbox');
    if (err) throw new Error('jsSandbox 语法不通过：' + err);
    if (!checkOnly) {
      backup(SANDBOX);
      fs.writeFileSync(SANDBOX, s);
    }
  }
}

if (edits.length === 0) console.log('补丁已在，跳过');
else {
  console.log(checkOnly ? '--check：以下改动待写入' : '已写入：');
  for (const e of edits) console.log('  ·', e);
}