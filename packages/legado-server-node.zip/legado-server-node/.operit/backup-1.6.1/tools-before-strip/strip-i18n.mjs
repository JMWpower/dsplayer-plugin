#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const ROOT = path.resolve(import.meta.dirname, '..');
const BUNDLE = path.join(ROOT, 'web-dist/assets/index-68a2edd4.js');
const CSS = path.join(ROOT, 'web-dist/assets/index-hiHoGuoh.css');
const APP = path.join(ROOT, 'dist/app.js');

const checkOnly = process.argv.includes('--check');

function skipString(t, i) {
  const q = t[i];
  i++;
  while (i < t.length) {
    if (t[i] === '\\') { i += 2; continue; }
    if (t[i] === q) return i + 1;
    i++;
  }
  return i;
}
function skipTemplate(t, i) {
  i++;
  while (i < t.length) {
    if (t[i] === '\\') { i += 2; continue; }
    if (t[i] === '`') return i + 1;
    if (t[i] === '$' && t[i + 1] === '{') { i = matchBrace(t, i + 1, '{', '}'); continue; }
    i++;
  }
  return i;
}
function matchBrace(t, i, open, close) {
  let depth = 0;
  while (i < t.length) {
    const c = t[i];
    if (c === '"' || c === "'") { i = skipString(t, i); continue; }
    if (c === '`') { i = skipTemplate(t, i); continue; }
    if (c === open) { depth++; i++; continue; }
    if (c === close) { depth--; i++; if (depth === 0) return i; continue; }
    i++;
  }
  return -1;
}

function parseChain(text, start) {
  const out = [];
  let i = start + 'const '.length;
  for (let guard = 0; guard < 500; guard++) {
    const m = /^([A-Za-z_$][\w$]*)\s*=\s*/.exec(text.slice(i, i + 80));
    if (!m) return null;
    const name = m[1];
    let j = i + m[0].length;
    const first = text[j];
    if (first === '{' || first === '[' || first === '(') {
      j = matchBrace(text, j, first, first === '{' ? '}' : first === '[' ? ']' : ')');
      if (j < 0) return null;
    } else {

      let depth = 0;
      while (j < text.length) {
        const ch = text[j];
        if (ch === '"' || ch === "'") { j = skipString(text, j); continue; }
        if (ch === '`') { j = skipTemplate(text, j); continue; }
        if (ch === '(' || ch === '[' || ch === '{') { depth++; j++; continue; }
        if (ch === ')' || ch === ']' || ch === '}') { depth--; j++; continue; }
        if (depth === 0 && (ch === ',' || ch === ';')) break;
        j++;
      }
    }
    out.push({ name, start: i, end: j, text: text.slice(i, j) });
    if (text[j] === ',') { i = j + 1; continue; }
    if (text[j] === ';') return { members: out, end: j + 1 };
    return null;
  }
  return null;
}

function findLangChain(text) {
  const anchor = text.indexOf('Jk={');
  if (anchor < 0) return null;
  for (let p = text.lastIndexOf('const ', anchor); p >= 0; p = text.lastIndexOf('const ', p - 1)) {
    const r = parseChain(text, p);
    if (!r) continue;
    const names = new Set(r.members.map((m) => m.name));
    if (!(names.has('Jk') && names.has('My') && names.has('hf') && names.has('Nl'))) continue;
    let q = p - 1;
    while (q >= 0 && /\s/.test(text[q])) q--;
    if (q >= 0 && text[q] !== ';' && text[q] !== '}') continue;
    return { start: p, end: r.end, members: r.members };
  }
  return null;
}

function callEnd(text, callStart) {
  const open = text.indexOf('(', callStart);
  if (open < 0) return -1;
  const brace = text.indexOf('{', open);
  if (brace < 0) return -1;
  const after = matchBrace(text, brace, '{', '}');
  if (after < 0) return -1;
  let j = after;
  while (j < text.length && /\s/.test(text[j])) j++;
  if (text[j] === ')') return j + 1;
  return -1;
}

const original = fs.readFileSync(BUNDLE, 'utf8');
if (!original.includes('"zh-TW"') && !original.includes('"ja-JP"')) {
  console.log('已经处理过（只保留简体中文），跳过');

  if (!checkOnly) {
    stripLangCss();
    stripLocaleRoutes();
  }
  if (checkOnly) {
    verifyAll(original);
    console.log('--check 通过');
  }
  process.exit(0);
}

let text = original;
const report = [];
function cut(from, to, label) {
  if (from < 0 || to < 0 || to <= from) throw new Error('区间非法：' + label + ' ' + from + '..' + to);
  report.push(label + '（删 ' + (to - from) + 'B）');
  text = text.slice(0, from) + text.slice(to);
}
function replaceOnce(before, after, label) {
  const n = text.split(before).length - 1;
  if (n !== 1) throw new Error('锚点必须唯一（实际 ' + n + ' 处）：' + label);
  text = text.replace(before, after);
  report.push(label);
}

const chain = findLangChain(text);
if (!chain) throw new Error('没找到语言链');
const keep = ['Nl'];
const kept = chain.members.filter((m, idx) => {
  const isZh = idx <= chain.members.findIndex((x) => x.name === 'My');
  if (isZh) return true;
  return keep.includes(m.name);
});
const droppedMembers = chain.members.filter((m) => !kept.includes(m));
const rebuilt = 'const ' + kept.map((m) => m.text).join(',') + ';';
report.push(
  '语言链：保留 ' + kept.length + ' 个成员，删除 ' + droppedMembers.length + ' 个（' +
  (chain.end - chain.start - rebuilt.length) + 'B）'
);
text = text.slice(0, chain.start) + rebuilt + text.slice(chain.end);

{
  const anchor = 'const Vv=[';
  if (text.includes(anchor)) {
    const start = text.indexOf(anchor);
    if (text.split(anchor).length - 1 !== 1) throw new Error('Vv 锚点不唯一');
    const vOpen = text.indexOf('[', start);
    const vEnd = matchBrace(text, vOpen, '[', ']');
    if (vEnd < 0) throw new Error('Vv 数组不配对');
    if (!text.startsWith(',qv=[', vEnd)) throw new Error('Vv 之后不是 qv=' + JSON.stringify(text.slice(vEnd, vEnd + 12)));
    const qOpen = text.indexOf('[', vEnd);
    const qEnd = matchBrace(text, qOpen, '[', ']');
    if (qEnd < 0) throw new Error('qv 数组不配对');
    if (text.slice(qEnd, qEnd + 4) !== ',pg=') throw new Error('qv 之后不是 pg，实际：' + JSON.stringify(text.slice(qEnd, qEnd + 12)));
    report.push('删除 1.5.0 遗留的 TTS 音色/语速表（Vv、qv，删 ' + (qEnd + 1 - start) + 'B）');
    text = text.slice(0, start) + 'const ' + text.slice(qEnd + 1);
  } else {
    report.push('TTS 音色表已不存在，跳过');
  }
}

{
  const start = text.indexOf('function wl(o){');
  if (start < 0) throw new Error('没找到 wl 定义');
  const tailAnchor = 'react:{useSuspense:!1}});';
  const tIdx = text.indexOf(tailAnchor, start);
  if (tIdx < 0) throw new Error('没找到 i18n init 结尾');
  const end = tIdx + tailAnchor.length;
  const replacement =
    'const Xk={"zh-CN":{translation:My}},sg=Nl;' +
    'typeof document<"u"&&document.documentElement&&(document.documentElement.lang=Nl);' +
    'nt.use(Fx).init({resources:Xk,lng:Nl,fallbackLng:Nl,supportedLngs:[Nl],' +
    'interpolation:{escapeValue:!1},react:{useSuspense:!1}});';
  report.push('i18n 初始化固定 zh-CN（删 ' + (end - start) + 'B，写回 ' + replacement.length + 'B）');
  text = text.slice(0, start) + replacement + text.slice(end);
}

replaceOnce('function er(){return wl(nt.language)}', 'function er(){return"zh-CN"}', 'er() 固定 zh-CN');
{
  const start = text.indexOf('async function og(o){');
  if (start < 0) throw new Error('没找到 og 定义');
  const erPos = text.indexOf('function er(){', start);
  if (erPos < 0) throw new Error('没找到 er 定义（og 之后）');
  cut(start, erPos, '删除 og()（切换语言）');
}

{
  const marker = ',w=async $=>{await og($);';
  const start = text.indexOf(marker);
  if (start < 0) throw new Error('没找到语言切换回调');
  const arrowBrace = text.indexOf('{', text.indexOf('=>', start));
  const after = matchBrace(text, arrowBrace, '{', '}');
  if (after < 0) throw new Error('回调大括号不配对');
  cut(start, after, '删除菜单里的语言切换回调');
}
{
  const label = ',t.jsx("div",{className:"menu-divider"}),t.jsxs("div",{className:"menu-section",children:[t.jsx("div",{className:"menu-section-label",children:b("header.language")})';
  const start = text.indexOf(label);
  if (start < 0) throw new Error('没找到「语言」菜单区块');

  const callStart = text.indexOf('t.jsxs(', start);
  const end = callEnd(text, callStart);
  if (end < 0) throw new Error('「语言」区块结束位置没找到');
  cut(start, end, '删除菜单里的「语言」区块');
}

replaceOnce(
  ',V.getLocale().then(H=>{if(H!=null&&H.locale)return og(wl(H.locale))}).catch(()=>{})',
  '',
  '删除启动时读语言偏好的副作用'
);

replaceOnce(
  'getLocale:()=>ve("/api/settings/locale"),setLocale:o=>ve("/api/settings/locale",{method:"PUT",body:JSON.stringify({locale:o})}),',
  '',
  '删除 API 客户端 getLocale/setLocale'
);

verifyAll(text, true);

if (checkOnly) {
  console.log('--check：以下改动待写入');
  for (const line of report) console.log('  ·', line);
  process.exit(0);
}

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const backupDir = path.join(ROOT, '.operit/backup-1.6.0');
fs.mkdirSync(backupDir, { recursive: true });
fs.writeFileSync(path.join(backupDir, 'index-before-i18n-' + stamp + '.js'), original);
fs.writeFileSync(BUNDLE, text);

stripLangCss();

stripLocaleRoutes();

console.log('已只保留简体中文：');
for (const line of report) console.log('  ·', line);
console.log('产物：' + original.length + ' → ' + text.length + ' 字符（' +
  fs.statSync(BUNDLE).size + ' 字节）');
console.log('备份：' + path.relative(ROOT, backupDir));

function verifyAll(code, throwOnError = false) {
  const problems = [];

  try {
    new vm.Script(code, { filename: 'bundle.js' });
  } catch (e) {
    problems.push('语法错误：' + e.message);
  }

  for (const bad of ['"zh-TW"', '"en-US"', '"ja-JP"', 'menu-lang', 'legado-locale-v1', 'getLocale', 'setLocale', '/api/settings/locale']) {
    if (!code.includes(bad)) continue;
    problems.push('仍有残留：' + bad);
    if (process.argv.includes('--debug')) {
      let i = -1, n = 0;
      while ((i = code.indexOf(bad, i + 1)) >= 0 && n < 3) {
        n++;
        console.log('    [' + bad + '] …' + code.slice(Math.max(0, i - 90), i + 60).replace(/\n/g, '\\n'));
      }
    }
  }

  for (const must of ['translation:My', 'const ly=', 'lng:Nl', 'fallbackLng:Nl', 'supportedLngs:[Nl]', 'function er(){return"zh-CN"}']) {
    if (!code.includes(must)) problems.push('被误删：' + must);
  }

  if (!code.includes('我的书架') || !code.includes('书源管理')) problems.push('被误删：中文文案表');
  if (problems.length) {
    const msg = '校验失败：\n  - ' + problems.join('\n  - ');
    if (throwOnError) throw new Error(msg);
    console.log(msg);
    return false;
  }
  return true;
}

function stripLangCss() {
  let css = fs.readFileSync(CSS, 'utf8');
  const before = css.length;
  let removed = 0;

  css = css.replace(/(^|[}{;])\s*\.menu-lang-(?:grid|btn)[^{]*\{[^}]*\}/g, (m, lead) => {
    removed++;
    return lead;
  });
  if (removed === 0) {
    console.log('CSS 里没找到 .menu-lang-* 规则（可能已被移除）');
    return;
  }
  fs.writeFileSync(CSS, css);
  console.log('CSS：删除 ' + removed + ' 条 .menu-lang-* 规则（' + before + ' → ' + css.length + 'B）');
}

function stripLocaleRoutes() {
  let js = fs.readFileSync(APP, 'utf8');
  if (!js.includes('/api/settings/locale')) {
    console.log('后端已无 /api/settings/locale，跳过');
    return;
  }
  const startAnchor = '    // ---------------- 语言偏好 ----------------\n';
  const endAnchor = '    // ---------------- 封面 ----------------\n';
  const start = js.indexOf(startAnchor);
  const end = js.indexOf(endAnchor, start);
  if (start < 0 || end < 0) throw new Error('后端语言路由区块锚点没找到');
  js = js.slice(0, start) + js.slice(end);
  fs.writeFileSync(APP, js);
  console.log('后端：删除 /api/settings/locale 的 GET + PUT');
}