#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const DRY = process.argv.includes('--dry');
const ROOT = path.resolve(import.meta.dirname, '..');

const TARGETS = [
  { dir: 'dist', exts: ['.js', '.mjs', '.cjs'] },
  { dir: 'tools', exts: ['.js', '.mjs', '.cjs'] },
  { dir: 'tests', exts: ['.js', '.mjs', '.cjs'] },
  { dir: 'web-dist', exts: ['.js', '.mjs', '.cjs', '.css', '.html'] },
  { dir: '.', exts: ['.html'], topOnly: true },
];

const KEYWORDS_BEFORE_REGEX = new Set([
  'return', 'typeof', 'instanceof', 'in', 'of', 'new', 'delete', 'void', 'throw',
  'case', 'do', 'else', 'yield', 'await',
]);

function skipQuoted(src, i, quote) {
  let j = i + 1;
  while (j < src.length) {
    const c = src[j];
    if (c === '\\') { j += 2; continue; }
    if (c === quote) return j + 1;
    j++;
  }
  return j;
}

function skipBraced(src, j) {
  let depth = 1;
  while (j < src.length) {
    const c = src[j];
    if (c === '"' || c === "'") { j = skipQuoted(src, j, c); continue; }
    if (c === '`') { j = skipTemplate(src, j); continue; }
    if (c === '/' && src[j + 1] === '/') { while (j < src.length && src[j] !== '\n') j++; continue; }
    if (c === '/' && src[j + 1] === '*') { const e = src.indexOf('*/', j + 2); j = e < 0 ? src.length : e + 2; continue; }
    if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) return j + 1; }
    j++;
  }
  return j;
}

function skipTemplate(src, i) {
  let j = i + 1;
  while (j < src.length) {
    const c = src[j];
    if (c === '\\') { j += 2; continue; }
    if (c === '`') return j + 1;
    if (c === '$' && src[j + 1] === '{') { j = skipBraced(src, j + 2); continue; }
    j++;
  }
  return j;
}

function skipRegex(src, i) {
  let j = i + 1;
  let inClass = false;
  while (j < src.length) {
    const c = src[j];
    if (c === '\\') { j += 2; continue; }
    if (c === '\n') return -1;
    if (inClass) { if (c === ']') inClass = false; j++; continue; }
    if (c === '[') { inClass = true; j++; continue; }
    if (c === '/') {
      let k = j + 1;
      while (k < src.length && /[a-z]/i.test(src[k])) k++;
      const body = src.slice(i + 1, j);
      try {
        new RegExp(body);
      } catch {
        return -1;
      }
      return k;
    }
    j++;
  }
  return -1;
}

function stripJs(src) {
  let out = '';
  let i = 0;
  if (src.startsWith('#!')) {
    const nl = src.indexOf('\n');
    if (nl < 0) return '';
    out = src.slice(0, nl + 1);
    i = nl + 1;
  }
  let prev = '';
  let word = '';
  let removed = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === '/' && src[i + 1] === '/') {
      while (i < src.length && src[i] !== '\n') i++;
      removed++;
      continue;
    }
    if (c === '/' && src[i + 1] === '*') {
      const end = src.indexOf('*/', i + 2);
      i = end < 0 ? src.length : end + 2;
      removed++;
      if (out.length > 0 && !/\s$/.test(out)) out += ' ';
      continue;
    }
    if (c === '"' || c === "'") {
      const j = skipQuoted(src, i, c);
      out += src.slice(i, j);
      prev = c;
      word = '';
      i = j;
      continue;
    }
    if (c === '`') {
      const j = skipTemplate(src, i);
      out += src.slice(i, j);
      prev = '`';
      word = '';
      i = j;
      continue;
    }
    if (c === '/') {
      const allowed = prev === '' || !/[\w$)\]]/.test(prev) || KEYWORDS_BEFORE_REGEX.has(word);
      if (allowed) {
        const j = skipRegex(src, i);
        if (j > 0) {
          out += src.slice(i, j);
          prev = '/';
          word = '';
          i = j;
          continue;
        }
      }
    }
    out += c;
    if (!/\s/.test(c)) {
      prev = c;
      if (/[\w$]/.test(c)) word += c;
      else word = '';
    }
    i++;
  }
  return out.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
}

function stripCss(src) {
  let out = '';
  let i = 0;
  let removed = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === '"' || c === "'") {
      const j = skipQuoted(src, i, c);
      out += src.slice(i, j);
      i = j;
      continue;
    }
    if (c === '/' && src[i + 1] === '*') {
      const end = src.indexOf('*/', i + 2);
      i = end < 0 ? src.length : end + 2;
      removed++;
      if (out.length > 0 && !/\s$/.test(out)) out += ' ';
      continue;
    }
    out += c;
    i++;
  }
  return out.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
}

function stripHtml(src) {
  let out = '';
  let i = 0;
  let removed = 0;
  while (i < src.length) {
    if (src.startsWith('<!--', i)) {
      const end = src.indexOf('-->', i + 4);
      i = end < 0 ? src.length : end + 3;
      removed++;
      continue;
    }
    if (src.startsWith('<script', i)) {
      const openEnd = src.indexOf('>', i);
      const close = src.indexOf('</script>', openEnd);
      if (openEnd < 0 || close < 0) { out += src.slice(i); break; }
      out += src.slice(i, openEnd + 1) + stripJs(src.slice(openEnd + 1, close));
      i = close;
      continue;
    }
    if (src.startsWith('<style', i)) {
      const openEnd = src.indexOf('>', i);
      const close = src.indexOf('</style>', openEnd);
      if (openEnd < 0 || close < 0) { out += src.slice(i); break; }
      out += src.slice(i, openEnd + 1) + stripCss(src.slice(openEnd + 1, close));
      i = close;
      continue;
    }
    out += src[i];
    i++;
  }
  return out.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
}

function syntaxCheck(file, code) {
  const tmp = path.join(os.tmpdir(), 'lr-comment-check-' + Date.now() + '.mjs');
  fs.writeFileSync(tmp, code);
  try {
    execFileSync(process.execPath, ['--check', tmp], { stdio: 'pipe' });
    return null;
  } catch (e) {
    return String(e.stderr || e.message).slice(0, 500);
  } finally {
    try { fs.unlinkSync(tmp); } catch {  }
  }
}

function collect(dir, exts, topOnly) {
  const full = path.join(ROOT, dir);
  if (!fs.existsSync(full)) return [];
  const out = [];
  if (topOnly) {
    for (const name of fs.readdirSync(full)) {
      const p = path.join(full, name);
      if (fs.statSync(p).isFile() && exts.includes(path.extname(name).toLowerCase())) out.push(p);
    }
    return out;
  }
  for (const name of fs.readdirSync(full)) {
    if (name === 'node_modules' || name === '.git') continue;
    const p = path.join(full, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) out.push(...collect(path.relative(ROOT, p), exts, false));
    else if (exts.includes(path.extname(name).toLowerCase())) out.push(p);
  }
  return out;
}

const files = [...new Set(TARGETS.flatMap((t) => collect(t.dir, t.exts, t.topOnly)))].sort();
const report = [];
const failed = [];

for (const file of files) {
  const ext = path.extname(file).toLowerCase();
  const src = fs.readFileSync(file, 'utf8');
  const stripped = ext === '.css' ? stripCss(src) : ext === '.html' ? stripHtml(src) : stripJs(src);
  if (stripped === src) continue;
  if (/\.(js|mjs|cjs)$/.test(ext)) {
    const err = syntaxCheck(file, stripped);
    if (err != null) {
      failed.push(`${path.relative(ROOT, file)}：${err}`);
      continue;
    }
  }
  const delta = src.length - stripped.length;
  report.push(`${path.relative(ROOT, file)}：-${delta} 字符`);
  if (!DRY) fs.writeFileSync(file, stripped, 'utf8');
}

for (const line of report) console.log('· ' + line);
console.log(`${DRY ? '（--dry 不落盘）' : ''}处理 ${report.length} 个文件，共减 ${report.reduce((n, l) => n + Number(/-(\d+)/.exec(l)[1]), 0)} 字符`);
if (failed.length > 0) {
  console.error('语法校验失败（这些文件没动）：');
  for (const f of failed) console.error('  · ' + f);
  process.exitCode = 1;
}