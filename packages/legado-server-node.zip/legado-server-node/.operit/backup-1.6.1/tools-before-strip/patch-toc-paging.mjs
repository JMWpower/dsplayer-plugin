#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const ROOT = path.resolve(import.meta.dirname, '..');
const RUNNER = path.join(ROOT, 'dist/ruleRunner.js');
const BOOKS = path.join(ROOT, 'dist/routes/books.js');
const checkOnly = process.argv.includes('--check');

const edits = [];

function syntaxOk(code, name) {
  const tmp = path.join(os.tmpdir(), 'lr-syn-' + Date.now() + '-' + name + '.mjs');
  fs.writeFileSync(tmp, code);
  try {
    execFileSync(process.execPath, ['--check', tmp], { stdio: 'pipe' });
    return null;
  } catch (e) {
    return String(e.stderr || e.message).slice(0, 400);
  } finally {
    fs.rmSync(tmp, { force: true });
  }
}
function backup(file) {
  const dir = path.join(ROOT, '.operit/backup-1.6.0');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  fs.copyFileSync(file, path.join(dir, path.basename(file) + '.before-paging.' + stamp + '.bak'));
}

{
  let s = fs.readFileSync(RUNNER, 'utf8');
  const before = s;

  if (!s.includes('const textSelector = trimmed.match(')) {
    const anchor = '        const classIndexed = trimmed.match(';
    if (!s.includes(anchor)) throw new Error('selectAllLegado 的 classIndexed 锚点没找到');
    const addition = `        /* 1.6.0：\`text.下一页\` —— 按节点文字找。目录分页的 nextTocUrl 几乎都是这种写法。 */
        const textSelector = trimmed.match(/^text\\.(.+)$/);
        if (textSelector) {
            const want = textSelector[1].trim();
            const pool = element.find('a,button,span,li,p');
            const hit = pool.filter((_i, el) => WRAP$(el).text().trim() === want);
            if (hit.length > 0)
                return hit;
            return element.find('*').filter((_i, el) => WRAP$(el).text().trim() === want);
        }
${anchor}`;
    s = s.replace(anchor, () => addition);
    edits.push('selectAllLegado：支持 text.xxx 文字选择器');
  }

  if (!s.includes('MAX_TOC_PAGES')) {
    const start = s.indexOf('    chapters(sourceJson, tocUrl, book = null) {');
    if (start < 0) throw new Error('chapters() 起点没找到');
    const endMark = '    content(sourceJson, chapterUrl';
    const end = s.indexOf(endMark, start);
    if (end < 0) throw new Error('chapters() 终点没找到');
    const newChapters = `    chapters(sourceJson, tocUrl, book = null) {
        const source = parseObject(sourceJson);
        const mainJs = plainString(source['mainJs']);
        if (mainJs != null && mainJs !== '')
            return new JsSourceRunner(this, source).chapters(tocUrl, book);
        const sourceKey = this.sourceId(source);
        const sourceUrl = this.sourceBaseUrl(source);
        return this.jsSandbox.withSourceContext(this.sourceContext(source, sourceKey, book), () => {
            const rule = objectValue(source['ruleToc']);
            if (rule == null)
                throw new RuleExecutionError('该书源未配置 ruleToc');
            const listRule = plainString(rule['chapterList']);
            if (listRule == null)
                throw new RuleExecutionError('缺少 ruleToc.chapterList');
            const chapterUrlRule = plainString(rule['chapterUrl']);
            const chapterNameRule = plainString(rule['chapterName']);
            const nextRule = plainString(rule['nextTocUrl']);
            const sourceHeaders = parseSourceHeaders(source, sourceUrl, this.database);
            /* 1.6.0：目录分页。WAP 站的目录常常一页 50 章，只取第一页会「能读但不全」，
               用户看到的就是「目录只有 50 章」。按 ruleToc.nextTocUrl 一页页翻。 */
            const MAX_TOC_PAGES = 60;
            const MAX_TOC_CHAPTERS = 20000;
            const chapters = [];
            const seen = new Set();
            const visited = new Set();
            let pageUrl = tocUrl;
            for (let page = 0; page < MAX_TOC_PAGES; page++) {
                if (pageUrl == null || visited.has(pageUrl))
                    break;
                visited.add(pageUrl);
                const dataPayload = dataUrlPayload(pageUrl);
                let body;
                let chapterNodes;
                if (dataPayload != null) {
                    body = dataPayload;
                    chapterNodes = jsListNodes(NodeValue.json(dataPayload), listRule, body, pageUrl, this.jsSandbox);
                }
                else {
                    const [url, options] = splitUrlOptions(pageUrl);
                    const merged = mergeOptions(sourceHeaders, options);
                    body = this.fetchUrl(url, merged, null, sourceUrl, this.database);
                    const baseDoc = NodeValue.document(body);
                    chapterNodes = isJsRule(listRule) ? jsListNodes(baseDoc, listRule, body, pageUrl, this.jsSandbox) : nodes(body, listRule);
                }
                for (const node of chapterNodes) {
                    const chUrlRaw = node.value(chapterUrlRule, this.jsSandbox, body, pageUrl);
                    if (chUrlRaw == null)
                        continue;
                    const chUrl = absoluteUrl(chUrlRaw, pageUrl);
                    if (seen.has(chUrl))
                        continue;
                    seen.add(chUrl);
                    const title = node.value(chapterNameRule, this.jsSandbox, body, pageUrl) ?? \`第 \${chapters.length + 1} 章\`;
                    chapters.push({ index: chapters.length, title, url: chUrl });
                    if (chapters.length >= MAX_TOC_CHAPTERS)
                        return chapters;
                }
                if (nextRule == null || nextRule === '' || dataPayload != null)
                    break;
                let nextUrl = null;
                try {
                    const nextRaw = NodeValue.document(body).value(nextRule, this.jsSandbox, body, pageUrl);
                    if (nextRaw != null && String(nextRaw).trim() !== '')
                        nextUrl = absoluteUrl(String(nextRaw).trim(), pageUrl);
                }
                catch (e) {
                    nextUrl = null;
                }
                if (nextUrl == null || nextUrl === pageUrl)
                    break;
                pageUrl = nextUrl;
            }
            return chapters;
        });
    }
`;
    s = s.slice(0, start) + newChapters + s.slice(end);
    edits.push('chapters()：按 nextTocUrl 翻页取全目录');
  }

  if (s !== before) {
    const err = syntaxOk(s, 'ruleRunner');
    if (err) throw new Error('ruleRunner 语法不通过：' + err);
    if (!checkOnly) {
      backup(RUNNER);
      fs.writeFileSync(RUNNER, s);
    }
  }
}

{
  let s = fs.readFileSync(BOOKS, 'utf8');
  const before = s;

  if (!s.includes('function tocCandidates(')) {
    const helperAnchor = `    app.post('/api/books/chapters', async (request, reply) => {`;
    if (!s.includes(helperAnchor)) throw new Error('chapters 路由锚点没找到');
    const helper = `/**
 * 目录地址候选：详情里的 tocUrl、书页本身，以及两种常见变体。
 * 1.6.0：以前只试 \`<书页>/toc\`，而 WAP 站（哔哩小说等）的目录是 \`<书页去掉 .html>/catalog\`，
 * 试不到就只剩书页顶部的「最新章节」那十来条。
 */
function tocCandidates(bookUrl) {
    const out = [];
    const push = (v) => {
        const u = (v ?? '').trim();
        if (u !== '' && !out.includes(u))
            out.push(u);
    };
    push(bookUrl);
    push(bookUrl.replace(/\\/toc$/, '') + '/toc');
    if (/\\.html?$/i.test(bookUrl))
        push(bookUrl.replace(/\\.html?$/i, '') + '/catalog');
    push(bookUrl.replace(/\\/+$/, '') + '/catalog');
    return out;
}
${helperAnchor}`;
    s = s.replace(helperAnchor, () => helper);
    edits.push('新增 tocCandidates()');
  }

  if (!s.includes('取最长的那份')) {
    const start = s.indexOf('            const candidates = [bookUrl];');
    if (start < 0) throw new Error('目录候选段落没找到');
    const endMark = '            if (fallbackFromContent.length > 0)';
    const end = s.indexOf(endMark, start);
    if (end < 0) throw new Error('目录候选段落终点没找到');
    const replacement = `            const candidates = [];
            const addCandidate = (u) => {
                const v = (u ?? '').trim();
                if (v !== '' && !candidates.includes(v))
                    candidates.push(v);
            };
            let detailsError = null;
            try {
                const details = await ctx.pool.run('details', { sourceId, bookUrl, sourceJson: source.json });
                addCandidate(details?.tocUrl);
            }
            catch (e) {
                detailsError = e;
            }
            for (const candidate of tocCandidates(bookUrl))
                addCandidate(candidate);
            let lastError = null;
            let best = null;
            let bestUrl = null;
            for (const tocUrl of candidates) {
                try {
                    const chapters = await ctx.pool.run('chapters', { sourceId, bookUrl, sourceJson: source.json, tocUrl });
                    if (chapters.length === 0)
                        continue;
                    /* 1.6.0：取最长的那份。书页上的「最新章节」只有十来条，真正的目录页有几百上千条；
                       以前「第一个非空就返回」，于是一本书永远只拿到那十几章。 */
                    if (best == null || chapters.length > best.length) {
                        best = chapters;
                        bestUrl = tocUrl;
                    }
                }
                catch (e) {
                    lastError = e;
                }
            }
            if (best != null) {
                db.saveTocCache(sourceId, bestUrl, best);
                if (bestUrl !== bookUrl) {
                    const existing = db.getTocCache(sourceId, bookUrl);
                    if (existing == null || existing.length < best.length)
                        db.saveTocCache(sourceId, bookUrl, best);
                }
                return best;
            }
`;
    s = s.slice(0, start) + replacement + s.slice(end);
    edits.push('目录候选：全跑一遍并取最长（含 /catalog 变体）');
  }

  if (s !== before) {
    const err = syntaxOk(s, 'books');
    if (err) throw new Error('routes/books.js 语法不通过：' + err);
    if (!checkOnly) {
      backup(BOOKS);
      fs.writeFileSync(BOOKS, s);
    }
  }
}

if (edits.length === 0) console.log('补丁已在，跳过');
else {
  console.log(checkOnly ? '--check：以下改动待写入' : '已写入：');
  for (const e of edits) console.log('  ·', e);
}