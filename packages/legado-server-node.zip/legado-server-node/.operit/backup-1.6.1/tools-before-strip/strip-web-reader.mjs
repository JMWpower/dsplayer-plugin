
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const ROOT = process.cwd();
const checkOnly = process.argv.includes('--check');

const html = fs.readFileSync(path.join(ROOT, 'web-dist/index.html'), 'utf8');
const entry = /<script[^>]+src="([^"]*\/assets\/index-[^"]+\.js)"/.exec(html);
if (!entry) {
  console.error('没能从 index.html 里找到入口 bundle');
  process.exit(1);
}
const bundlePath = path.join(ROOT, 'web-dist', entry[1].replace(/^\//, ''));
const source = fs.readFileSync(bundlePath, 'utf8');

if (!source.includes('legado-open-book-v1') && !source.includes('SS_SHELL_OFF')) {
  console.log(`已经剥过了，跳过：${path.relative(ROOT, bundlePath)}`);
  process.exit(0);
}

function matchParen(src, openIdx) {
  let depth = 0, mode = 0;
  for (let j = openIdx; j < src.length; j++) {
    const c = src[j];
    if (mode === 0) {
      if (c === "'") mode = 1;
      else if (c === '"') mode = 2;
      else if (c === '`') mode = 3;
      else if (c === '/' && j > openIdx) {
        let k = j - 1;
        while (k >= 0 && /\s/.test(src[k])) k--;
        if ('(,=:[!&|?{};'.includes(src[k] || '')) mode = 4;
      } else if (c === '(' || c === '[' || c === '{') depth++;
      else if (c === ')' || c === ']' || c === '}') { depth--; if (depth === 0) return j + 1; }
    } else if (mode === 1) { if (c === '\\') j++; else if (c === "'") mode = 0; }
    else if (mode === 2) { if (c === '\\') j++; else if (c === '"') mode = 0; }
    else if (mode === 3) { if (c === '\\') j++; else if (c === '`') mode = 0; }
    else if (mode === 4) { if (c === '\\') j++; else if (c === '/') mode = 0; }
  }
  return -1;
}

function matchBrace(src, openIdx) {
  let depth = 0, mode = 0;
  for (let j = openIdx; j < src.length; j++) {
    const c = src[j];
    if (mode === 0) {
      if (c === "'") mode = 1;
      else if (c === '"') mode = 2;
      else if (c === '`') mode = 3;
      else if (c === '/' && j > openIdx) {
        let k = j - 1;
        while (k >= 0 && /\s/.test(src[k])) k--;
        if ('(,=:[!&|?{};'.includes(src[k] || '')) mode = 4;
      } else if (c === '{') depth++;
      else if (c === '}') { depth--; if (depth === 0) return j + 1; }
    } else if (mode === 1) { if (c === '\\') j++; else if (c === "'") mode = 0; }
    else if (mode === 2) { if (c === '\\') j++; else if (c === '"') mode = 0; }
    else if (mode === 3) { if (c === '\\') j++; else if (c === '`') mode = 0; }
    else if (mode === 4) { if (c === '\\') j++; else if (c === '/') mode = 0; }
  }
  return -1;
}

let text = source;
const problems = [];
const cuts = [];
const notes = [];

function count(hay, needle) {
  let n = 0, i = -1;
  while ((i = hay.indexOf(needle, i + 1)) >= 0) n++;
  return n;
}

function kill(start, end, label) {
  if (start < 0 || end < 0 || end <= start) { problems.push(`${label}：区间非法`); return; }
  cuts.push({ start, end, label });
}

function declSpan(label, opener) {
  const idx = text.indexOf(opener);
  if (idx < 0) { problems.push(`${label}：找不到 ${opener}`); return null; }
  if (count(text, opener) > 1) { problems.push(`${label}：${opener} 不唯一`); return null; }
  let start, end;
  if (opener.startsWith('function')) {
    const p = text.indexOf('(', idx);
    const afterParams = matchParen(text, p);
    let b = afterParams;
    while (b < text.length && /\s/.test(text[b])) b++;
    if (text[b] !== '{') { problems.push(`${label}：函数体定位失败`); return null; }
    start = idx;
    end = matchBrace(text, b);
  } else if (opener.startsWith('class')) {
    const b = text.indexOf('{', idx);
    start = idx;
    end = matchBrace(text, b);
  } else {

    const arrow = text.indexOf('=>', idx);
    if (arrow < 0) { problems.push(`${label}：找不到箭头`); return null; }
    let b = text.indexOf('{', arrow);
    start = idx;
    end = matchBrace(text, b);

    if (text[end] === ';') end += 1;
  }
  if (end < 0) { problems.push(`${label}：括号配对失败`); return null; }
  return { start, end };
}

function cutDecl(label, opener) {
  const span = declSpan(label, opener);
  if (span) kill(span.start, span.end, label);
}

cutDecl('正文阅读器 hS', 'function hS({openBook:');
cutDecl('漫画阅读器 yS', 'function yS({openBook:');
cutDecl('有声阅读器 AS', 'function AS({openBook:');
cutDecl('阅读器书签浮层 sv', 'function sv({bookName:');
cutDecl('阅读设置抽屉 dS', 'function dS({settings:');
cutDecl('书签页 oC', 'function oC({onOpenBookmark:');
cutDecl('TTS 播放器 Gv', 'class Gv{');
cutDecl('Web Speech 朗读器 zv', 'class zv{');

{
  const startAnchor = 'const $v=({onClose:';
  const tailAnchor = '_v=({tts:';
  if (count(text, startAnchor) !== 1) problems.push('httpTTS 弹窗：起点异常');
  else if (count(text, tailAnchor) !== 1) problems.push('httpTTS 表单：起点异常');
  else {
    const start = text.indexOf(startAnchor) + 'const '.length;
    const tail = text.indexOf(tailAnchor);
    const arrow = text.indexOf('=>', tail);
    const body = text.indexOf('{', arrow);
    let end = matchBrace(text, body);
    if (end < 0) problems.push('httpTTS 表单：括号配对失败');
    else {

      if (text[end] === ',' || text[end] === ';') end += 1;
      cuts.push({ start, end, label: 'httpTTS 管理弹窗 + 引擎表单' });
      notes.push('httpTTS 管理弹窗 / 引擎表单');
    }
  }
}

function cutChainMember(label, anchor) {
  if (count(text, anchor) !== 1) { problems.push(`${label}：锚点异常`); return; }
  const start0 = text.indexOf(anchor);
  const arrow = text.indexOf('=>', start0);
  const body = text.indexOf('{', arrow);
  const end0 = matchBrace(text, body);
  if (end0 < 0) { problems.push(`${label}：括号配对失败`); return; }
  let start = start0;
  let end = end0;
  if (text[end] === ',') end += 1;
  else if (text[start - 1] === ',') start -= 1;
  cuts.push({ start, end, label });
  notes.push(label);
}

cutChainMember('TTS 朗读设置面板 Kv', 'Kv=({settings:');
cutChainMember('TTS 播放条 Jv', 'Jv=({playState:');

const edits = [];
function edit(find, replacement, label, { all = false } = {}) {
  const n = count(text, find);
  if (n === 0) { problems.push(`${label}：找不到锚点`); return; }
  if (!all && n > 1) { problems.push(`${label}：锚点不唯一（${n} 处）`); return; }
  edits.push({ find, replacement, label, all });
  notes.push(`${label}${all ? `（${n} 处）` : ''}`);
}

edit(
  'const Pf="legado-open-book-v1",Hf=()=>location.hash==="#sources"?"sources":location.hash==="#shelf"?"shelf":location.hash==="#reader"?"reader":location.hash==="#explore"?"explore":location.hash==="#bookmarks"?"bookmarks":location.hash==="#zlibrary"?"zlibrary":"library";',
  'const Hf=()=>location.hash==="#sources"?"sources":location.hash==="#shelf"?"shelf":location.hash==="#explore"?"explore":location.hash==="#zlibrary"?"zlibrary":"library";',
  'Hf 路由去掉 reader / bookmarks'
);

edit(
  'const I=H=>{H==="reader"&&!y||(location.hash=`#${H}`,c(H))},',
  'const I=H=>{location.hash="#"+H,c(H)},',
  '切换页面不再拦 reader'
);

edit(
  'S=(H,Q,oe="library",U)=>{v(U?{book:H,index:Q,bookmark:U}:{book:H,index:Q}),f(oe),sessionStorage.setItem(Pf,JSON.stringify({book:H,index:Q})),location.hash="#reader",c("reader")},',
  'S=(H,Q)=>{try{const z=H&&H.details&&H.details.sourceId;z&&H.bookUrl&&fetch("/api/reading-progress",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sourceId:z,bookUrl:H.bookUrl,chapterUrl:"",chapterIndex:Number.isFinite(Q)?Q:0,scrollPosition:0})}).catch(()=>{})}catch(z){}try{window.dispatchEvent(new CustomEvent("lr-push-book",{detail:{book:H,index:Number.isFinite(Q)?Q:0}}))}catch(z){}},',
  'S 改为推送整本到壳子'
);

edit(
  '[y,v]=m.useState(()=>{try{return JSON.parse(sessionStorage.getItem(Pf)??"null")}catch{return null}}),',
  '',
  '去掉「当前打开的书」状态'
);

const qStart = 'q=async H=>{const Q=oe=>';
const qEnd = 'o("common.failed","操作失败"))}};';
{
  const i = text.indexOf(qStart);
  if (i < 0) problems.push('书签跳转 q：找不到');
  else {
    const j = text.indexOf(qEnd, i);
    if (j < 0) problems.push('书签跳转 q：终点缺失');
    else {
      const start = text[i - 1] === ',' ? i - 1 : i;
      cuts.push({ start, end: j + qEnd.length, label: '书签跳转 q', replacement: ';' });
      notes.push('书签跳转 q');
    }
  }
}

{
  const startAnchor = 'if(i==="reader"&&y){const H=()=>{I(d)};return';
  const endAnchor = 't.jsx(hS,{openBook:y.book,startIndex:y.index,startBookmark:y.bookmark,settings:n,onSettingsChange:l,onClose:H})]})}';
  if (count(text, startAnchor) !== 1) problems.push('阅读器分支：起点不唯一或缺失');
  else if (count(text, endAnchor) !== 1) problems.push('阅读器分支：终点不唯一或缺失');
  else {
    const i = text.indexOf(startAnchor);
    const j = text.indexOf(endAnchor, i) + endAnchor.length;
    cuts.push({ start: i, end: j, label: '阅读器分支' });
    notes.push('阅读器分支');
  }
}

edit(
  't.jsx("button",{type:"button",className:o==="bookmarks"?"active":"",onClick:()=>c("bookmarks"),children:b("header.bookmarks","书签")}),',
  '',
  '导航去掉「书签」'
);
edit(',,]})', ']})', '清掉导航里的空占位');
edit(':i==="bookmarks"?t.jsx(oC,{onOpenBookmark:H=>void q(H)})', '', '页面分发去掉书签页');

edit(',cy={shelf:"书架",library:"书库",', ',cy={shelf:"书架",library:"搜索",', '导航文案 书库→搜索');
edit('heroKicker:"在线书库"', 'heroKicker:"在线搜索"', '首页 kicker 在线书库→在线搜索', { all: true });
edit('emptyDesc:"前往「书库」搜索想看的小说，或者从 WebDAV 导入本地图书"', 'emptyDesc:"前往「搜索」找想看的小说，或者直接从 WebDAV 导入本地图书"', '书架空态文案');
edit('goSearch:"前往书库搜书"', 'goSearch:"前往搜索找书"', '空态按钮文案');
edit(
  'l("shelf.emptyDesc","在书库检索添加在线小说，或直接导入本地 TXT / EPUB 文件。")',
  'l("shelf.emptyDesc","在「搜索」里检索添加在线小说，或直接导入本地 TXT / EPUB 文件。")',
  '书架空态内联文案'
);

edit(',zS=["bookSource","rssSource","replaceRule","httpTts"]', ',zS=["bookSource","rssSource"]', '在线导入只剩书源/RSS');

{
  const from = 'getTtsVoices:()=>ve("/api/tts/voices"),';
  const to = 'getLocale:()=>ve("/api/settings/locale"),';
  if (count(text, from) !== 1) problems.push('API：TTS 段起点异常');
  else if (count(text, to) !== 1) problems.push('API：TTS 段终点异常');
  else {
    const i = text.indexOf(from);
    const j = text.indexOf(to, i);
    cuts.push({ start: i, end: j, label: 'API TTS 与 httpTTS' });
    notes.push('API TTS / httpTTS');
  }
}
{

  const from = 'bookmarks:(o,n)=>ve(`/api/bookmarks';
  const to = 'refreshBookCovers:o=>ve("/api';
  if (count(text, from) !== 1) problems.push('API：书签段起点异常');
  else if (count(text, to) !== 1) problems.push('API：书签段终点异常');
  else {
    const i = text.indexOf(from);
    const j = text.indexOf(to, i);
    cuts.push({ start: i, end: j, label: 'API 书签方法' });
    notes.push('API 书签方法');
  }
}

{
  const importBtn =
    't.jsx("input",{ref:oe,type:"file",multiple:!0,accept:".txt,.epub,.text,application/epub+zip,text/plain",style:{display:"none"},onChange:G=>{G.target.files&&G.target.files.length>0&&(xe(G.target.files),G.target.value="")}}),t.jsxs("button",{type:"button",className:"shelf-import-btn",disabled:q,onClick:()=>{var G;return(G=oe.current)==null?void 0:G.click()},title:l("shelf.importBook","导入本地图书"),children:[t.jsx(O,{name:"upload"}),t.jsx("span",{children:q?l("common.loading","导入中..."):l("shelf.importBook","导入本地")})]}),';
  if (count(text, importBtn) !== 1) problems.push('书架：导入按钮锚点异常');
  else edits.push({ find: importBtn, replacement: '', label: '书架：从右侧动作区移除导入按钮', all: false });

  const h1 = 't.jsx("h1",{children:l("header.shelf","书架")}),';
  if (count(text, h1) !== 1) problems.push('书架：h1 锚点异常');
  else {
    edits.push({
      find: h1,
      replacement:
        't.jsxs("div",{className:"shelf-title-row",children:[' +
        't.jsx("h1",{children:l("header.shelf","书架")}),' +
        importBtn +
        ']}),',
      label: '书架：标题行右侧放导入按钮',
      all: false,
    });
  }
  notes.push('书架头部重排');
}

if (problems.length > 0) {
  console.error('中止，以下锚点有问题：');
  for (const p of problems) console.error('  · ' + p);
  process.exit(1);
}

const ordered = edits
  .map((e) => {

    const positions = [];
    let i = -1;
    while ((i = text.indexOf(e.find, i + 1)) >= 0) positions.push(i);
    return { ...e, positions };
  })
  .flatMap((e) => e.positions.map((p) => ({ start: p, end: p + e.find.length, replacement: e.replacement, label: e.label })));

const allEdits = [...cuts, ...ordered].sort((a, b) => b.start - a.start);

for (let i = 1; i < allEdits.length; i++) {
  if (allEdits[i].end > allEdits[i - 1].start) {
    console.error(`切除区间重叠：${allEdits[i].label} 与 ${allEdits[i - 1].label}`);
    process.exit(1);
  }
}

if (process.argv.includes('--debug')) {
  const asc = [...allEdits].sort((a, b) => a.start - b.start);
  let acc = text;
  let offset = 0;
  for (const e of asc) {
    const s = e.start + offset;
    const en = e.end + offset;
    const next = acc.slice(0, s) + (e.replacement ?? '') + acc.slice(en);
    try {
      new vm.Script(next, { filename: 'dbg.js' });
    } catch (err) {
      console.log(`第一个出问题的操作：${e.label}（原位置 ${e.start}-${e.end}）`);
      console.log('上下文：' + JSON.stringify(text.slice(Math.max(0, e.start - 120), e.start)));
      console.log('   >>> ' + JSON.stringify(e.replacement ?? '(删除)') + ' <<<');
      console.log('后续：' + JSON.stringify(text.slice(e.end, e.end + 120)));
      console.log('错误：' + err.message);
      break;
    }
    acc = next;
    offset += (e.replacement ?? '').length - (e.end - e.start);
  }
  process.exit(0);
}

let out = text;
for (const e of allEdits) {
  out = out.slice(0, e.start) + (e.replacement ?? '') + out.slice(e.end);
}

const before = Buffer.byteLength(source, 'utf8');
const after = Buffer.byteLength(out, 'utf8');

try {
  new vm.Script(out, { filename: 'index-stripped.js' });
} catch (err) {
  console.error('切除后语法不合法：' + err.message);
  fs.writeFileSync('/tmp/index-stripped.broken.js', out);
  console.error('坏产物已写到 /tmp/index-stripped.broken.js');
  process.exit(1);
}

const forbidden = [
  ['#reader', 'location.hash==="#reader"'],
  ['legado-open-book-v1', 'sessionStorage 交接键'],
  ['header.bookmarks', '导航书签文案'],
  ['/api/tts/', 'TTS 接口'],
  ['/api/http-tts', 'HTTP TTS 接口'],
  ['/api/bookmarks', '书签接口'],
  ['getTtsVoices', 'TTS 客户端方法'],
  ['controlTtsSession', 'TTS 会话控制'],
  ['deleteBookmarksBatch', '书签批量删除'],
  ['function hS({', '正文阅读器'],
  ['function yS({', '漫画阅读器'],
  ['function AS({', '有声阅读器'],
  ['className:"tts-settings-dialog', 'TTS 设置弹窗'],
  ['speechSynthesis', '浏览器语音合成'],
  ['jsx(dS,{', '阅读设置抽屉'],
  ['jsx(Gv', 'TTS 播放器'],
  ['jsx(sv,{', '书签浮层'],
  ['jsx(oC,{', '书签页'],
];
const stillThere = forbidden.filter(([needle]) => out.includes(needle)).map(([needle, why]) => `${why}（${needle}）`);

const mustKeep = [
  'function lC({', 'function zC({', 'function YC({', 'function IS({', 'function XC(){',
  'lr.exploreSource', 'unknownBook',
  'lr-push-book', '/api/books/chapters', '/api/books/content', '/api/reading-progress',
  'shelf-title-row', 'header.library',
];
const missing = mustKeep.filter((k) => !out.includes(k));

if (stillThere.length > 0 || missing.length > 0) {
  console.error('校验未通过：');
  for (const s of stillThere) console.error('  · 仍有残留：' + s);
  for (const s of missing) console.error('  · 被误删：' + s);
  fs.writeFileSync('/tmp/index-stripped.broken.js', out);
  process.exit(1);
}

if (checkOnly) {
  console.log('产物里仍含网页阅读器代码（未落盘，--check 模式）');
  process.exit(1);
}

fs.writeFileSync(bundlePath, out);
console.log(`已切除 ${allEdits.length} 段：${path.relative(ROOT, bundlePath)}（${before} → ${Buffer.byteLength(out, 'utf8')} 字节）`);
for (const n of notes) console.log('  · ' + n);