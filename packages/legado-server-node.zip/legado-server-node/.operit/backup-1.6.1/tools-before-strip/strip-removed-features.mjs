#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const WEB = path.join(root, 'web-dist');

function entryBundle() {
  const html = fs.readFileSync(path.join(WEB, 'index.html'), 'utf8');
  const m = html.match(/<script[^>]+src="\/assets\/(index-[^"]+\.js)"/);
  if (m == null) throw new Error('index.html 里没找到 /assets/index-*.js 入口');
  return path.join(WEB, 'assets', m[1]);
}

function functionSpan(src, head) {
  const start = src.indexOf(head);
  if (start < 0) return null;
  let i = src.indexOf('{', start + head.lastIndexOf(')') >= 0 ? start + head.lastIndexOf(')') : start);
  if (i < 0) i = src.indexOf('{', start);
  let depth = 0;
  let quote = null;
  let esc = false;
  let regex = false;
  for (; i < src.length; i++) {
    const ch = src[i];
    if (quote != null) {
      if (esc) esc = false;
      else if (ch === '\\') esc = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (regex) {
      if (esc) esc = false;
      else if (ch === '\\') esc = true;
      else if (ch === '[') {  }
      else if (ch === ']') {  }
      else if (ch === '/') regex = false;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '/') {
      const prev = src.slice(0, i).trimEnd().slice(-1);
      if ('(,=:[!&|?{};+-*%~^'.includes(prev)) { regex = true; continue; }
      continue;
    }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return { start, end: i + 1 };
    }
  }
  return null;
}

const SPANS = [

  ['t.jsxs("button",{type:"button",className:"menu-item-btn menu-item-mobile-only",role:"menuitem",onClick:()=>{y(!1),c("subscriptions")}',
    'children:b("header.subscriptions")})]}),'],
  ['t.jsxs("button",{type:"button",className:"menu-item-btn menu-item-mobile-only",role:"menuitem",onClick:()=>{y(!1),c("rules")}',
    'children:b("header.rules")})]}),'],

  ['t.jsx("button",{type:"button",className:`nav-secondary ${o==="subscriptions"?"active":""}`',
    'children:b("header.subscriptions")})'],
  ['t.jsx("button",{type:"button",className:`nav-secondary ${o==="rules"?"active":""}`',
    'children:b("header.rules")})'],

  ['l&&t.jsxs("section",{className:"setting-section",children:[t.jsx("span",{className:"setting-label",children:i("reader.contentPurify","内容净化")}),',
    'children:i("reader.replaceRulesHint","针对当前书籍/书源过滤广告与特定字符")})]}),'],

  ['t.jsxs("button",{className:`manage-action-row ${L?"is-loading":""}`,disabled:L,"aria-busy":L,onClick:async()=>{N(!0);try{const M=await V.recleanBookCache(',
    'L?t.jsx(Nt,{size:14}):t.jsx(O,{name:"arrowRight"})]}),'],

  ['subscriptions:()=>ve("/api/subscriptions")',
    'markSubscriptionSynced:(o,n)=>ve(`/api/subscriptions/${o}/synced`,{method:"POST",body:JSON.stringify({imported:n})}),'],

  ['getReplaceRules:o=>{',
    'previewReplaceRule:o=>ve("/api/replace-rules/preview",{method:"POST",body:JSON.stringify(o)}),'],

  ['recleanBookCache:(o,n)=>ve("/api/bookshelf/reclean"',
    'batchRecleanBookCache:o=>ve("/api/bookshelf/batch-reclean",{method:"POST",body:JSON.stringify({books:o})}),'],

  ['removeSubscription:o=>ve(`/api/subscriptions/${o}`,{method:"DELETE"})',
    'updateSubscriptions:()=>ve("/api/subscriptions/update",{method:"POST"}),'],
];

const LITERALS = [

  'location.hash==="#subscriptions"?"subscriptions":location.hash==="#rules"?"rules":',

  'i==="subscriptions"?t.jsx(JS,{onSourcesChange:P}):i==="rules"?t.jsx(eC,{}):',
];

const FUNCTIONS = ['function JS({onSourcesChange:o}){', 'function eC(){'];

const bundle = entryBundle();
let code = fs.readFileSync(bundle, 'utf8');
const original = code;

if (!code.includes('/api/subscriptions') && !code.includes('className:"subscription-page"')) {
  console.log('已经剥过了，跳过。');
  process.exit(0);
}

const cuts = [];
const problems = [];

for (const [startAnchor, endAnchor] of SPANS) {
  const s = code.indexOf(startAnchor);
  if (s < 0) { problems.push(`缺起点：${startAnchor.slice(0, 50)}`); continue; }
  if (code.indexOf(startAnchor, s + 1) >= 0) { problems.push(`起点不唯一：${startAnchor.slice(0, 50)}`); continue; }
  const e = code.indexOf(endAnchor, s);
  if (e < 0) { problems.push(`缺终点：${endAnchor.slice(0, 50)}`); continue; }
  cuts.push({ start: s, end: e + endAnchor.length });
}
for (const literal of LITERALS) {
  const s = code.indexOf(literal);
  if (s < 0) problems.push(`缺字面量：${literal.slice(0, 50)}`);
  else if (code.indexOf(literal, s + 1) >= 0) problems.push(`字面量不唯一：${literal.slice(0, 50)}`);
  else cuts.push({ start: s, end: s + literal.length });
}
for (const head of FUNCTIONS) {
  const span = functionSpan(code, head);
  if (span == null) problems.push(`切不出函数：${head}`);
  else cuts.push(span);
}

cuts.sort((a, b) => a.start - b.start);
for (let i = 1; i < cuts.length; i++) {
  if (cuts[i].start < cuts[i - 1].end) problems.push(`切除区间重叠：${cuts[i - 1].end} / ${cuts[i].start}`);
}
if (problems.length > 0) {
  console.error(problems.join('\n'));
  process.exit(1);
}

for (let i = cuts.length - 1; i >= 0; i--) {
  code = code.slice(0, cuts[i].start) + code.slice(cuts[i].end);
}

try {
  new vm.Script(code, { filename: path.basename(bundle) });
} catch (e) {
  console.error(`切除后语法不过：${e.message}`);
  process.exit(1);
}

const FORBIDDEN = ['/api/subscriptions', '/api/replace-rules', '/api/replace-rule-groups', '/api/bookshelf/reclean',
  'recleanBookCache', 'onSourcesChange:P', 'className:"subscription-page"', 'reader.replaceRulesManage'];
const leftovers = FORBIDDEN.filter((needle) => code.includes(needle));
if (leftovers.length > 0) {
  console.error('还有残留引用：' + leftovers.join(', '));
  process.exit(1);
}

fs.writeFileSync(bundle, code);
console.log(`已切除 ${cuts.length} 段：${path.relative(root, bundle)}（${original.length} → ${code.length} 字节）`);