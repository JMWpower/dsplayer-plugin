#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const webDir = path.join(root, 'web-dist');

function entryBundle() {
  const html = fs.readFileSync(path.join(webDir, 'index.html'), 'utf8');
  const m = html.match(/<script[^>]+src="\/assets\/(index-[^"]+\.js)"/);
  if (m == null) throw new Error('index.html 里没找到 /assets/index-*.js 入口');
  const file = path.join(webDir, 'assets', m[1]);
  if (!fs.existsSync(file)) throw new Error(`入口产物不存在：${file}`);
  return file;
}

function sliceFrom(src, head) {
  const start = src.indexOf(head);
  if (start < 0) return null;
  let i = src.indexOf('{', src.indexOf(')', start));
  if (i < 0) return null;
  let depth = 0;
  let quote = null;
  let esc = false;
  for (; i < src.length; i++) {
    const ch = src[i];
    if (quote != null) {
      if (esc) esc = false;
      else if (ch === '\\') esc = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return { start, end: i + 1 };
    }
  }
  return null;
}

function assertParses(code, label) {
  try {
    new vm.Script(code, { filename: label });
  } catch (e) {
    throw new Error(`${label} 语法检查失败：${e.message}`);
  }
}

const PATCHES = [
  { name: 'explore', head: 'function lC({onOpen:o}){', file: 'explore.component.js' },
  { name: 'loadbook', head: 'Cd=async(o,n)=>{', file: 'load-book.component.js' },
];

const checkOnly = process.argv.includes('--check');
const bundlePath = entryBundle();
let code = fs.readFileSync(bundlePath, 'utf8');
const before = code.length;
const report = [];
let pending = 0;

if (code.startsWith('function __lrFallbackCat(')) {
  const nl = code.indexOf('\n');
  code = code.slice(nl + 1);
  report.push('移除旧版 __lrFallbackCat 前导助手');
}

for (const patch of PATCHES) {
  const replacement = fs.readFileSync(path.join(here, 'web-patches', patch.file), 'utf8').trimEnd();
  const span = sliceFrom(code, patch.head);
  if (span == null) throw new Error(`产物里没找到 ${patch.head}（版本可能已变，检查 dist 是否被替换）`);
  const current = code.slice(span.start, span.end);
  if (current === replacement) {
    report.push(`${patch.name}: 已是最新`);
    continue;
  }
  if (checkOnly) {
    report.push(`${patch.name}: 未应用（${current.length} → ${replacement.length} 字节）`);
    pending++;
    continue;
  }
  code = code.slice(0, span.start) + replacement + code.slice(span.end);
  report.push(`${patch.name}: 已写入（${current.length} → ${replacement.length} 字节）`);
}

if (!checkOnly && code !== fs.readFileSync(bundlePath, 'utf8')) assertParses(code, path.basename(bundlePath));

for (const line of report) console.log('- ' + line);
console.log(`入口产物：${path.relative(root, bundlePath)}（${before} → ${code.length} 字节）`);

if (checkOnly) {
  if (pending > 0) {
    console.error(`有 ${pending} 处补丁未应用`);
    process.exit(1);
  }
  console.log('补丁均已应用。');
  process.exit(0);
}

fs.writeFileSync(bundlePath, code);
console.log('完成。');
