
(function () {
  'use strict';

  var TRIGGER = '.explore-source-trigger';
  var MENU = '.explore-source-menu';
  var LIST = '.explore-source-menu-list';
  var ACTIVE = '.explore-source-option.active, [role="option"][aria-selected="true"]';

  function activeOption(list) {

    var el = list.querySelector('.explore-source-option.active');
    if (el) return el;
    var options = list.querySelectorAll('[role="option"]');
    for (var i = 0; i < options.length; i++) {
      if (options[i].getAttribute('aria-selected') === 'true') return options[i];
    }
    return null;
  }

  function centerOnActive() {
    var menu = document.querySelector(MENU);
    if (!menu) return false;
    var list = menu.querySelector(LIST) || menu;
    var active = activeOption(list);
    if (!active) return false;

    var listRect = list.getBoundingClientRect();
    var activeRect = active.getBoundingClientRect();
    var canScroll = list.scrollHeight > list.clientHeight + 1;

    if (canScroll) {

      var target = (activeRect.top - listRect.top) - (list.clientHeight - activeRect.height) / 2;
      list.scrollTop = Math.max(0, list.scrollTop + target);
    } else if (activeRect.top < listRect.top || activeRect.bottom > listRect.bottom) {

      if (typeof active.scrollIntoView === 'function') active.scrollIntoView({ block: 'nearest' });
    }
    return true;
  }

  function schedule() {

    setTimeout(function () {
      if (centerOnActive()) return;
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(function () { centerOnActive(); });
      }
    }, 0);
  }

  document.addEventListener('click', function (ev) {
    var el = ev.target;
    if (!el || typeof el.closest !== 'function') return;
    if (el.closest(TRIGGER)) schedule();
  }, true);

  document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter' && ev.key !== ' ' && ev.key !== 'Spacebar') return;
    var el = document.activeElement;
    if (el && el.classList && el.classList.contains(TRIGGER.slice(1))) schedule();
  }, true);
})();
