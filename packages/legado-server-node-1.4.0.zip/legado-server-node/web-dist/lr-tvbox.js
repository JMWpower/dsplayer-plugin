
(function () {
  'use strict';

  var PUSH_EVENT = 'lr-push-book';
  var LS_BASE = 'lr.base';
  var LS_BOOK_KEYS = 'lr.bookKeys';
  var SENTINEL_RE = /^lr:\/\/b\/([a-z0-9]+)\/(\d+)$/i;

  var isFrame = false;
  try { isFrame = !!(window.parent && window.parent !== window); } catch (e) { isFrame = true; }

  function nativeBridge() { return window.fm || window.ds || null; }

  function canPush() {
    var f = nativeBridge();
    return !!(f && (typeof f.vodInline === 'function' || typeof f.openVod === 'function' || typeof f.play === 'function'));
  }

  function queryShellFlag() {
    try {
      var v = new URLSearchParams(window.location.search || '').get('lr_shell');
      return v === '1' || v === 'on' || v === 'true';
    } catch (e) {
      return false;
    }
  }

  function shellOff() {

    try { window.sessionStorage.removeItem('lr.shell.off'); } catch (e) {  }
    return false;
  }

  function shellMode() {
    if (shellOff()) return false;
    if (queryShellFlag()) return true;
    if (window.__lrShellMode === true) return true;
    return canPush();
  }

  function canHijack() { return shellMode() && (canPush() || isFrame); }

  function baseUrl() {
    try {
      if (/^https?:/i.test(window.location.protocol)) return window.location.origin;
    } catch (e) {  }
    try {
      var saved = window.localStorage.getItem(LS_BASE);
      if (saved) return String(saved).replace(/\/+$/, '');
    } catch (e) {  }
    return typeof window.__lrBase === 'string' ? String(window.__lrBase).replace(/\/+$/, '') : '';
  }

  function readJson(storage, key) {
    try {
      var raw = storage.getItem(key);
      var parsed = raw ? JSON.parse(raw) : null;
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (e) {
      return {};
    }
  }

  function writeJson(storage, key, value) {
    try { storage.setItem(key, JSON.stringify(value)); } catch (e) {  }
  }

  function message(e) { return (e && e.message) ? e.message : String(e || '未知错误'); }

  function toast(text) {
    try {
      var el = document.getElementById('lr-shell-toast');
      if (!el) {
        el = document.createElement('div');
        el.id = 'lr-shell-toast';
        el.style.cssText = [
          'position:fixed', 'left:50%', 'bottom:calc(28px + env(safe-area-inset-bottom,0px))',
          'transform:translateX(-50%) translateY(12px)', 'background:rgba(20,26,22,.94)', 'color:#fff',
          'font:13.5px/1.55 -apple-system,"PingFang SC","Microsoft YaHei",system-ui,sans-serif',
          'padding:10px 18px', 'border-radius:12px', 'max-width:86vw', 'text-align:center',
          'z-index:2147483000', 'opacity:0', 'transition:opacity .18s ease,transform .18s ease',
          'pointer-events:none', 'box-shadow:0 12px 30px rgba(0,0,0,.28)'
        ].join(';') + ';';
        document.body.appendChild(el);
      }
      el.textContent = text;
      requestAnimationFrame(function () {
        el.style.opacity = '1';
        el.style.transform = 'translateX(-50%) translateY(0)';
      });
      clearTimeout(toast.timer);
      toast.timer = setTimeout(function () {
        el.style.opacity = '0';
        el.style.transform = 'translateX(-50%) translateY(12px)';
      }, 2600);
    } catch (e) {  }
  }

  async function rawReq(url, opt) {
    opt = opt || {};
    var f = nativeBridge();
    var sameOrigin = false;
    try { sameOrigin = url.indexOf(window.location.origin) === 0; } catch (e) { sameOrigin = false; }
    if (!sameOrigin && f && typeof f.req === 'function') {
      var r = await f.req(url, {
        method: opt.method || 'GET',
        headers: opt.headers || {},
        body: opt.body,
        responseType: 'text',
        timeout: opt.timeout || 30
      });
      var body = r && r.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch (e) {  }
      }
      return { ok: !!(r && r.ok), status: (r && r.status) || 0, body: body };
    }
    var res = await fetch(url, {
      method: opt.method || 'GET',
      headers: opt.headers || {},
      body: opt.body
    });
    var text = await res.text();
    var parsed = text;
    try { parsed = JSON.parse(text); } catch (e) {  }
    return { ok: res.ok, status: res.status, body: parsed };
  }

  async function api(path, opt) {
    opt = opt || {};
    var base = baseUrl();
    var headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
    if (opt.headers) for (var k in opt.headers) headers[k] = opt.headers[k];
    var r = await rawReq(base + path, {
      method: opt.method || 'GET',
      headers: headers,
      body: opt.body != null ? JSON.stringify(opt.body) : undefined,
      timeout: opt.timeout || 30
    });
    if (!r || !r.ok) {
      var text = (r && r.body && (r.body.message || r.body.msg)) || ('HTTP ' + ((r && r.status) || '?'));
      throw new Error(text);
    }
    return r.body;
  }

  async function loadChapters(sourceId, bookUrl, tocUrl) {
    var body = { sourceId: sourceId, bookUrl: bookUrl };
    if (tocUrl) body.tocUrl = tocUrl;
    var list = await api('/api/books/chapters', {
      method: 'POST',
      body: body,
      timeout: 90
    });
    return Array.isArray(list) ? list : [];
  }

  async function fetchContent(sourceId, bookUrl, chapterUrl, silent) {
    var body = { sourceId: sourceId, bookUrl: bookUrl, chapterUrl: chapterUrl };
    if (silent) body.silent = true;
    var data = await api('/api/books/content', {
      method: 'POST',
      body: body,
      timeout: 90
    });
    if (!data || !String(data.content || '').trim()) throw new Error('后端没有返回正文');
    return data;
  }

  function toText(content) {
    return String(content || '').split(/\r?\n+/)
      .map(function (line) { return line.trim(); })
      .filter(function (line) { return line !== ''; })
      .map(function (line) { return '\u3000\u3000' + line; })
      .join('\n');
  }

  function imageUrlsIn(content, base) {
    var raw = String(content || '');
    var urls = [];
    var seen = {};
    var re = /<img[^>]+(?:data-original|data-src|data-lazy-src|src)\s*=\s*["']([^"']+)["']/gi;
    var m;
    while ((m = re.exec(raw))) {
      var u = String(m[1] || '').trim();
      if (u === '' || u.indexOf('data:') === 0) continue;
      if (seen[u]) continue;
      seen[u] = 1;
      urls.push(absoluteImageUrl(u, base));
    }
    if (urls.length === 0) {
      var lines = raw.split(/\s+/);
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (!/^https?:\/\//i.test(line) || seen[line]) continue;
        if (!/\.(?:jpe?g|png|webp|gif|avif|bmp)(?:\?|#|$)/i.test(line)) continue;
        seen[line] = 1;
        urls.push(line);
      }
    }
    return urls;
  }

  function absoluteImageUrl(url, base) {
    if (/^https?:\/\//i.test(url)) return url;
    if (url.indexOf('//') === 0) return 'https:' + url;
    try {
      return new URL(url, base || baseUrl()).toString();
    } catch (e) {
      return url;
    }
  }

  function proxyImageUrl(sourceId, url) {
    return baseUrl() + '/api/comic/image?sourceId=' + encodeURIComponent(sourceId || '') +
      '&url=' + encodeURIComponent(url);
  }

  function picsPayload(sourceId, urls) {
    var proxied = urls.map(function (u) { return proxyImageUrl(sourceId, u); });
    return 'pics' + '://' + proxied.join('&&');
  }

  function looksLikeComic(content) {
    var raw = String(content || '');
    var imgs = raw.match(/<img\b/gi);
    if (imgs != null && imgs.length >= 2) {
      var text = raw.replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<[^>]*>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      return text.length <= 200;
    }
    var lines = raw.split(/\r?\n+/).map(function (s) { return s.trim(); }).filter(function (s) { return s !== ''; });
    if (lines.length < 2) return false;
    var imageLines = lines.filter(function (s) { return /^https?:\/\/\S+\.(?:jpe?g|png|webp|gif|avif|bmp)(?:\?\S*)?$/i.test(s); });
    return imageLines.length === lines.length;
  }

  function novelPayload(title, content) {
    return 'novel' + '://' + JSON.stringify({ title: title || '正文', content: content || '' });
  }

  function bookKeyOf(sourceId, bookUrl) {
    var str = String(sourceId) + '\n' + String(bookUrl);
    var h1 = 5381, h2 = 52711;
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      h1 = ((h1 << 5) + h1) ^ c;
      h2 = ((h2 << 5) - h2) ^ c;
      h1 >>>= 0; h2 >>>= 0;
    }
    return (h1.toString(36) + h2.toString(36)).slice(0, 12);
  }

  function sentinel(key, index) { return 'lr' + '://b/' + key + '/' + index; }

  function cleanName(name) { return String(name || '').replace(/[$#]/g, ' ').trim(); }

  function coverOf(details, base) {
    details = details || {};
    if (details.coverKey) return base + '/api/covers/' + encodeURIComponent(details.coverKey);
    var url = details.coverUrl || '';
    if (!url) return '';
    if (url.indexOf('data:') === 0) return url;
    if (!/^https?:\/\//i.test(url)) return base + (url.charAt(0) === '/' ? url : '/' + url);
    try {
      var f = nativeBridge();
      if (f && typeof f.res === 'function') return f.res(url);
    } catch (e) {  }
    return url;
  }

  var state = { key: '', sourceId: '', bookUrl: '', chapters: [], tocUrl: '' };
  var lastProgressKey = '';
  var lastProgressAt = 0;
  var PROGRESS_GAP_MS = 2500;

  function flushOnLeave() {
    lastProgressAt = 0;
  }
  try {
    if (typeof window !== 'undefined' && window.addEventListener) {
      window.addEventListener('pagehide', flushOnLeave);
      window.addEventListener('beforeunload', flushOnLeave);
      if (typeof document !== 'undefined' && document.addEventListener) {
        document.addEventListener('visibilitychange', function () {
          if (document.visibilityState === 'hidden') flushOnLeave();
        });
      }
    }
  } catch (e) {  }

  function rememberBookKey(key, sourceId, bookUrl, kind, tocUrl, name, coverUrl) {
    var map = readJson(window.localStorage, LS_BOOK_KEYS);
    var prev = map[key] || {};
    map[key] = {
      s: sourceId, b: bookUrl,
      k: kind || prev.k || '',
      t: tocUrl || prev.t || '',
      n: name || prev.n || '',
      c: coverUrl || prev.c || ''
    };
    var keys = Object.keys(map);
    while (keys.length > 200) delete map[keys.shift()];
    writeJson(window.localStorage, LS_BOOK_KEYS, map);
  }

  function kindOfKey(key) {
    var entry = readJson(window.localStorage, LS_BOOK_KEYS)[key];
    return entry && entry.k ? String(entry.k) : '';
  }

  function tocOfKey(key) {
    var entry = readJson(window.localStorage, LS_BOOK_KEYS)[key];
    return entry && entry.t ? String(entry.t) : '';
  }

  function buildSpec(book, index) {
    var details = (book && book.details) || {};
    var base = baseUrl();
    var sourceId = details.sourceId || (book && book.sourceId) || '';
    var bookUrl = (book && book.bookUrl) || '';
    var chapters = (book && Array.isArray(book.chapters)) ? book.chapters : [];
    var key = bookKeyOf(sourceId, bookUrl);
    var kind = String((book && book.bookKind) || details.bookKind || '');
    var comic = kind === 'comic';
    var unit = comic ? '话' : '章';
    var epFormat = comic ? 'pics' : 'novel';
    var eps = chapters.map(function (c, i) {
      return {
        name: cleanName(c && c.title) || ('第 ' + (i + 1) + ' ' + unit),
        url: sentinel(key, i),
        resolve: true,
        format: epFormat
      };
    });
    var startIndex = Math.max(0, Math.min(index || 0, Math.max(0, eps.length - 1)));
    var local = kind === 'local';
    var kindLabel = comic ? '漫画' : (local ? '本地书' : '小说');
    var spec = {
      vod_id: 'lr_' + key,
      vod_name: details.name || (book && book.name) || '阅读',
      vod_pic: coverOf(details, base),
      vod_remarks: '共 ' + chapters.length + ' ' + unit,
      vod_type: kindLabel,
      type_name: kindLabel,
      vod_play_from: '阅读',
      mark: eps.length ? eps[startIndex].name : '',
      markIndex: startIndex,
      vod_play_index: startIndex,
      vod_content: (details.author ? '作者：' + details.author + '\n' : '') +
        (comic
          ? '共 ' + chapters.length + ' 话（点哪一话就取哪一话的图片）'
          : '共 ' + chapters.length + ' 章（目录已全部推送，点章按需加载正文）'),
      episodes: eps,
      format: epFormat
    };

    if (eps.length <= 500) {
      spec.vod_play_url = eps.map(function (e) { return e.name + '$' + e.url; }).join('#');
    }
    rememberBookKey(key, sourceId, bookUrl, kind, details.tocUrl || '', details.name || (book && book.name) || '', details.coverUrl || '');
    return { spec: spec, key: key, sourceId: sourceId, bookUrl: bookUrl, count: eps.length, startIndex: startIndex, comic: comic };
  }

  async function deliver(built) {
    var f = nativeBridge();
    if (f && typeof f.vodInline === 'function') {
      await f.vodInline(built.spec);
      return 'native';
    }
    if (f && typeof f.openVod === 'function') {
      await f.openVod(built.spec);
      return 'native';
    }
    if (isFrame) {

      window.parent.postMessage({
        __lrTvboxPush: built.spec,
        book: { key: built.key, sourceId: built.sourceId, bookUrl: built.bookUrl }
      }, '*');
      return 'parent';
    }

    if (f && typeof f.play === 'function') {
      var chapter = state.chapters[built.startIndex];
      if (!chapter) throw new Error('章节不存在');
      var data = await fetchContent(built.sourceId, built.bookUrl, chapter.url);
      await f.play(novelPayload(data.title || chapter.title, toText(data.content)), data.title || chapter.title, {
        pic: built.spec.vod_pic
      });
      return 'chapter';
    }
    throw new Error('壳子不支持整本推送（缺 vodInline / openVod）');
  }

  async function pushBook(book, index) {
    var details = (book && book.details) || {};
    var sourceId = details.sourceId || (book && book.sourceId) || '';
    var bookUrl = (book && book.bookUrl) || '';
    if (!sourceId || !bookUrl) throw new Error('缺少书源或书籍地址');
    var chapters = (book && Array.isArray(book.chapters)) ? book.chapters.slice() : [];
    if (chapters.length === 0) chapters = await loadChapters(sourceId, bookUrl);
    if (chapters.length === 0) throw new Error('目录还是空的，稍后再试');
    var key = bookKeyOf(sourceId, bookUrl);
    state = { key: key, sourceId: sourceId, bookUrl: bookUrl, chapters: chapters };
    rememberBookKey(key, sourceId, bookUrl);
    var built = buildSpec({ details: details, bookUrl: bookUrl, chapters: chapters, bookKind: book && book.bookKind }, index);

    api('/api/tvbox/book-key', {
      method: 'POST',
      body: { sourceId: sourceId, bookUrl: bookUrl }
    }).catch(function () {  });
    built.way = await deliver(built);
    return built;
  }

  async function resolveSentinel(url) {
    var raw = String(url || '').trim();
    var m = SENTINEL_RE.exec(raw);
    if (!m) {

      var legacy = /^lr:\/\/ch\/([A-Za-z0-9_-]+)\/(\d+)$/.exec(raw);
      if (!legacy) return '';
      try {
        var decoded = JSON.parse(decodeB64Url(legacy[1]));
        return await chapterPayload(decoded.s, decoded.b, parseInt(legacy[2], 10) || 0);
      } catch (e) {
        return '';
      }
    }
    var key = m[1];
    var index = parseInt(m[2], 10) || 0;
    if (state.key === key && state.chapters.length > 0) {
      return await safeChapterPayload(state.sourceId, state.bookUrl, index, state.chapters, state.tocUrl);
    }
    var local = readJson(window.localStorage, LS_BOOK_KEYS)[key];
    if (local && local.s && local.b) {
      return await safeChapterPayload(local.s, local.b, index, null, local.t || '');
    }
    var got = await api('/api/tvbox/book-key/' + encodeURIComponent(key)).catch(function () { return null; });
    if (!got || !got.s) return '';
    rememberBookKey(key, got.s, got.b, '', tocOfKey(key));
    return await safeChapterPayload(got.s, got.b, index, null, tocOfKey(key));
  }

  function reportProgress(sourceId, bookUrl, chapterUrl, index, chapterTitle) {
    if (!sourceId || !bookUrl || !chapterUrl) return;
    var key = sourceId + '\u0000' + bookUrl;
    var now = Date.now();
    var meta = readJson(window.localStorage, LS_BOOK_KEYS)[bookKeyOf(sourceId, bookUrl)] || {};
    if (key === lastProgressKey && now - lastProgressAt < PROGRESS_GAP_MS) return;
    lastProgressKey = key;
    lastProgressAt = now;
    try {
      api('/api/reading-progress', {
        method: 'PUT',
        body: {
          sourceId: sourceId,
          bookUrl: bookUrl,
          chapterUrl: chapterUrl,
          chapterIndex: index,
          scrollPosition: 0,
          chapterTitle: chapterTitle || null,
          bookName: meta.n || null,
          tocUrl: meta.t || null,
          coverUrl: meta.c || null,
          bookKind: meta.k || null
        },
        timeout: 15
      }).catch(function () {  });
    } catch (e) {  }
  }

  async function chapterPayload(sourceId, bookUrl, index, chapters, tocUrl) {
    if (!sourceId || !bookUrl) return '';
    var list = chapters && chapters.length ? chapters : await loadChapters(sourceId, bookUrl, tocUrl);
    var chapter = list[index];
    if (!chapter) return '';
    var data = await fetchContent(sourceId, bookUrl, chapter.url, true);
    state = {
      key: bookKeyOf(sourceId, bookUrl), sourceId: sourceId, bookUrl: bookUrl,
      chapters: list, tocUrl: tocUrl || ''
    };
    reportProgress(sourceId, bookUrl, chapter.url, index, data.title || chapter.title);
    var kind = data.bookKind || kindOfKey(state.key) || '';
    if (kind !== '') rememberBookKey(state.key, sourceId, bookUrl, kind, tocUrl || '');
    var comic = kind === 'comic' || (kind === '' && looksLikeComic(data.content));
    if (comic) {
      var urls = Array.isArray(data.images) && data.images.length > 0
        ? data.images.map(function (u) { return absoluteImageUrl(String(u), chapter.url); })
        : imageUrlsIn(data.content, chapter.url);
      if (urls.length === 0) throw new Error('这一话没有解析到图片（站点用脚本加载图片，静态抓取拿不到）');
      return picsPayload(sourceId, urls);
    }
    return novelPayload(data.title || chapter.title, toText(data.content));
  }

  async function safeChapterPayload(sourceId, bookUrl, index, chapters, tocUrl) {
    try {
      return await chapterPayload(sourceId, bookUrl, index, chapters, tocUrl);
    } catch (e) {
      try {
        console.warn('[lr-tvbox] 取章失败：' + ((e && e.message) || e));
      } catch (_) {  }
      return '';
    }
  }

  function decodeB64Url(str) {
    var s = String(str || '').replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    var bin = atob(s);
    var bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  }

  function installResolver() {
    try {
      window.DL = window.DL || {};
      window.DL.resolveEpisode = resolveSentinel;
      window.__fmWebHomeInlineResolver = function (ep) {
        return resolveSentinel(typeof ep === 'string' ? ep : ((ep && ep.url) || ''));
      };
      var f = nativeBridge();
      if (f && typeof f.resolveEpisode !== 'function') {
        try { f.resolveEpisode = resolveSentinel; } catch (e) {  }
      }
    } catch (e) {  }
  }

  function onPushRequest(payload) {
    var book = (payload && payload.book) || null;
    if (!book || typeof book !== 'object') return;
    if (!canHijack()) {
      toast('当前不在壳子里：请用 TVBox / DsPlayer 打开本页再点阅读');
      return;
    }
    var index = parseInt(payload.index, 10);
    if (!isFinite(index) || index < 0) index = 0;
    pushBook(book, index).then(function (built) {
      toast('已推送整本目录（' + built.count + ' 章）到阅读器');
    }).catch(function (e) {
      toast('推送失败：' + message(e));
    });
  }

  function hookPush() {
    try {
      window.addEventListener(PUSH_EVENT, function (ev) {
        onPushRequest(ev && ev.detail);
      });
    } catch (e) {  }
  }

  function boot() {
    hookPush();
    if (!shellMode()) return;
    installResolver();
  }

  boot();
})();