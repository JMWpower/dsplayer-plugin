# -*- coding: utf-8 -*-
"""
阅读书架 · TVBox 配套源（Legado Server Node 后端）

  服务: 本机 / 局域网上的「Legado Server (Node)」阅读后端，默认 http://127.0.0.1:8998
  内容: 小说（novel://）。分类 = 书架视图，书 = 书架条目，章节 = 剧集，正文 = novel:// 的 JSON 负载。
  本源重点：把后端书架里的「本地书架」（用户导入的 TXT / EPUB）完整搬进 TVBox 阅读，
            正文由后端从本地缓存直出，不依赖外网；同时也支持网络书、书源搜索与分组。

配置（在 TVBox / DsPlayer 里给这个源填 ext，三种写法都行）：
  1) 只填地址：   http://192.168.1.10:8998
  2) 填 JSON（推荐）：
       {"base":"http://192.168.1.10:8998","play_base":"http://192.168.1.10:8998","mode":"novel","timeout":25}
  3) 不填：依次用环境变量 LEGADO_SERVER_BASE、DEFAULT_BASE、FALLBACK_BASES 探测

ext 可用键：
  base        服务地址（必须能被 TVBox 所在设备访问到）
  play_base   写进正文/封面地址的地址，默认等于 base
  mode        出正文方式：novel（默认，novel:// 契约）/ webview（HTML 阅读页）/ direct（纯文本）
  timeout     单次请求超时秒数，默认 25
  hide        要隐藏的分类 type_id 列表，如 ["shelf_online"]
  max_ep      详情里最多返回多少章，0 = 全部（默认 0）
  shelf       首页默认分类，默认 shelf_local（本地书架）
  scope       分类范围过滤：local / online / 空

依赖：后端需开启 /api.php/provide/vod/ 等 TVBox 接口（Legado Server Node 自带）；
      直接用 TVBox 订阅而不装本源时，把 http://IP:8998/sub 填进订阅地址亦可。
"""

import json
import os
import sys
import time
from urllib.parse import urlencode, quote, urlsplit

try:
    from base.spider import Spider as BaseSpider
except Exception:
    class BaseSpider(object):
        def fetch(self, *a, **k):
            return None

        def post(self, *a, **k):
            return None

try:
    import requests
except Exception:
    requests = None


def _abs_url(base, path):
    path = str(path or '').strip()
    if not path:
        return base
    if path.lower().startswith(('http://', 'https://')):
        return path
    if not path.startswith('/'):
        path = '/' + path
    return base.rstrip('/') + path


class Spider(BaseSpider):

    DEFAULT_BASE = 'http://127.0.0.1:8998'
    FALLBACK_BASES = ('http://host.docker.internal:8998', 'http://127.0.0.1:8999')
    TIMEOUT = 25
    PING_TIMEOUT = 4
    PLAY_MODE = 'novel'
    LIST_TTL = 60
    DETAIL_TTL = 600
    TXT_TTL = 1800
    PAGE_SIZE = 20
    CMS = '/api.php/provide/vod/'

    def __init__(self):
        self._base = ''
        self._play_base = ''
        self._mode = self.PLAY_MODE
        self._timeout = self.TIMEOUT
        self._ext_raw = ''
        self._hide = set()
        self._max_ep = 0
        self._shelf = 'shelf_local'
        self._scope = ''
        self._cache = {}
        self._base_checked_at = 0
        self._name = '阅读书架'

    # ---------- 框架入口 ----------

    def getName(self):
        return self._name

    def getDependence(self):
        return []

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        return False

    def setExtendInfo(self, extend):
        self._apply_extend(extend)
        return None

    def init(self, extend=''):
        self._apply_extend(extend)
        return None

    def init_api(self, extend=''):
        return self.init(extend)

    def destroy(self):
        try:
            self._cache.clear()
            self._base_checked_at = 0
        except Exception:
            pass
        return None

    # ---------- 配置 ----------

    def _apply_extend(self, extend):
        if extend is None:
            return
        ext = str(extend).strip()
        if not ext or ext == self._ext_raw:
            return
        self._ext_raw = ext
        if ext.startswith('{'):
            try:
                cfg = json.loads(ext)
            except Exception:
                cfg = {}
            if not isinstance(cfg, dict):
                return
            base = str(cfg.get('base') or cfg.get('api') or cfg.get('host') or '').strip()
            if base:
                self._base = self._norm_base(base)
                if not self._play_base:
                    self._play_base = self._base
            pb = str(cfg.get('play_base') or cfg.get('playBase') or '').strip()
            if pb:
                self._play_base = self._norm_base(pb)
            mode = str(cfg.get('mode') or '').strip().lower()
            if mode in ('novel', 'webview', 'direct'):
                self._mode = mode
            try:
                if cfg.get('timeout'):
                    self._timeout = max(5, int(cfg.get('timeout')))
            except Exception:
                pass
            hide = cfg.get('hide')
            if isinstance(hide, (list, tuple)):
                self._hide = set(str(x) for x in hide)
            elif hide not in (None, ''):
                self._hide = set(x.strip() for x in str(hide).split(',') if x.strip())
            try:
                self._max_ep = max(0, int(cfg.get('max_ep') or cfg.get('maxEp') or 0))
            except Exception:
                pass
            shelf = str(cfg.get('shelf') or '').strip()
            if shelf:
                self._shelf = shelf
            scope = str(cfg.get('scope') or '').strip().lower()
            if scope in ('local', 'online'):
                self._scope = scope
        elif ext.lower().startswith(('http://', 'https://')):
            self._base = self._norm_base(ext)
            if not self._play_base:
                self._play_base = self._base

    @staticmethod
    def _norm_base(url):
        url = str(url or '').strip().rstrip('/')
        if url and not url.lower().startswith(('http://', 'https://')):
            url = 'http://' + url
        return url

    def _candidates(self):
        out, seen = [], set()

        def add(u):
            u = self._norm_base(u)
            if u and u not in seen:
                seen.add(u)
                out.append(u)

        add(self._base)
        add(os.environ.get('LEGADO_SERVER_BASE', ''))
        add(self.DEFAULT_BASE)
        for u in self.FALLBACK_BASES:
            add(u)
        return out

    def _pick_base(self):
        now = time.time()
        if self._base and self._alive(self._base):
            return self._base
        if self._base and now - self._base_checked_at < 30:
            return self._base
        self._base_checked_at = now
        for cand in self._candidates():
            if self._alive(cand):
                self._base = cand
                if not self._play_base:
                    self._play_base = cand
                return cand
        if not self._base:
            self._base = self._candidates()[0]
        return self._base

    def _alive(self, base):
        try:
            txt = self._http(base + '/ping', timeout=self.PING_TIMEOUT)
            return bool(json.loads(txt).get('ok'))
        except Exception:
            return False

    def _playbase(self):
        if not self._play_base:
            self._play_base = self._pick_base()
        return self._play_base

    # ---------- 网络 ----------

    @staticmethod
    def _headers():
        return {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36',
            'Accept': 'application/json,text/plain,*/*',
        }

    @staticmethod
    def _resp_text(resp):
        if resp is None:
            return ''
        if isinstance(resp, bytes):
            return resp.decode('utf-8', 'replace')
        if isinstance(resp, str):
            return resp
        for attr in ('text', 'content', 'body'):
            val = getattr(resp, attr, None)
            if isinstance(val, bytes):
                return val.decode('utf-8', 'replace')
            if isinstance(val, str):
                return val
        try:
            return json.dumps(resp, ensure_ascii=False)
        except Exception:
            return ''

    def _http(self, url, timeout=None):
        timeout = timeout or self._timeout
        hdr = self._headers()
        fetcher = getattr(self, 'fetch', None)
        if callable(fetcher):
            for call in (
                lambda: fetcher(url, headers=hdr, timeout=timeout),
                lambda: fetcher(url, hdr),
                lambda: fetcher(url),
            ):
                try:
                    txt = self._resp_text(call())
                    if txt:
                        return txt
                except TypeError:
                    continue
                except Exception:
                    break
        if requests is not None:
            try:
                r = requests.get(url, headers=hdr, timeout=timeout)
                r.encoding = 'utf-8'
                if r.text:
                    return r.text
            except Exception:
                pass
        import urllib.request
        req = urllib.request.Request(url, headers=hdr)
        with urllib.request.urlopen(req, timeout=timeout) as f:
            return f.read().decode('utf-8', 'replace')

    def _url(self, path, params=None):
        url = _abs_url(self._pick_base(), path)
        if params:
            url += ('&' if '?' in url else '?') + urlencode(params)
        return url

    def _get_json(self, path, params=None, ttl=0):
        url = self._url(path, params)
        now = time.time()
        if ttl:
            hit = self._cache.get(url)
            if hit and now - hit[0] < hit[1]:
                return hit[2]
        txt = self._http(url)
        try:
            data = json.loads(txt)
        except Exception:
            raise RuntimeError('接口返回不是 JSON：' + txt[:120])
        if ttl:
            self._cache[url] = (now, ttl, data)
            if len(self._cache) > 200:
                for k in list(self._cache)[:80]:
                    self._cache.pop(k, None)
        return data

    # ---------- 字段整理 ----------

    def _norm_class(self, classes):
        out = []
        for c in classes or []:
            if not isinstance(c, dict):
                continue
            tid = c.get('type_id', c.get('tid', ''))
            name = str(c.get('type_name') or c.get('name') or '').strip()
            if tid is None or tid == '':
                continue
            if self._hide and str(tid) in self._hide:
                continue
            out.append({'type_id': str(tid), 'type_name': name or ('分类' + str(tid))})
        return out

    def _fix_pic(self, pic):
        """封面绝对地址改成 play_base 的 host，保证 TVBox 与服务不同机时也能加载。"""
        pic = str(pic or '').strip()
        if not pic:
            return ''
        parts = urlsplit(pic)
        if parts.path.startswith('/api/covers/'):
            return self._playbase() + parts.path
        if parts.scheme in ('http', 'https'):
            return pic
        return _abs_url(self._playbase(), pic)

    def _norm_item(self, it, tid='', tname=''):
        if not isinstance(it, dict):
            it = {}
        return {
            'vod_id': str(it.get('vod_id') or ''),
            'vod_name': str(it.get('vod_name') or '').strip(),
            'vod_pic': self._fix_pic(it.get('vod_pic')),
            'vod_remarks': str(it.get('vod_remarks') or ''),
            'vod_actor': str(it.get('vod_actor') or ''),
            'vod_director': str(it.get('vod_director') or ''),
            'vod_area': str(it.get('vod_area') or ''),
            'vod_year': str(it.get('vod_year') or ''),
            'vod_lang': str(it.get('vod_lang') or ''),
            'type_id': str(it.get('type_id') or tid or ''),
            'type_name': str(it.get('type_name') or tname or ''),
            'vod_content': str(it.get('vod_content') or ''),
        }

    @staticmethod
    def _clean_play_name(name):
        return str(name or '').replace('$', ' ').replace('#', ' ').strip()

    def _classes(self):
        try:
            d = self._get_json(self.CMS, {'ac': 'list'}, self.LIST_TTL)
            return self._norm_class(d.get('class'))
        except Exception:
            return []

    def _filters(self):
        try:
            d = self._get_json('/filters', None, self.LIST_TTL)
            f = d.get('filters') if isinstance(d, dict) else None
            return f if isinstance(f, dict) else {}
        except Exception:
            return {}

    # ---------- 首页 ----------

    def homeContent(self, filter=False):
        classes, items, filters = [], [], {}
        try:
            params = {'ac': 'list', 't': self._shelf, 'pg': 1}
            if self._scope:
                params['scope'] = self._scope
            d = self._get_json(self.CMS, params, self.LIST_TTL)
            classes = self._norm_class(d.get('class'))
            filters = d.get('filters') if isinstance(d.get('filters'), dict) else {}
            for x in (d.get('list') or [])[:60]:
                items.append(self._norm_item(x, self._shelf, '本地书架'))
        except Exception:
            classes = self._classes()
        if not filters:
            filters = self._filters()
        return {'class': classes, 'filters': filters, 'list': items}

    def getHomeContent(self, filter=False):
        return self.homeContent(filter)

    def homeVideoContent(self):
        try:
            params = {'ac': 'list', 't': self._shelf, 'pg': 1}
            if self._scope:
                params['scope'] = self._scope
            d = self._get_json(self.CMS, params, self.LIST_TTL)
            return {'list': [self._norm_item(x, self._shelf, '本地书架')
                             for x in (d.get('list') or [])[:60]]}
        except Exception:
            return {'list': []}

    # ---------- 分类 ----------

    def categoryContent(self, tid, pg=1, filter=False, extend='', *args, **kwargs):
        tid = str(tid if tid not in (None, '') else self._shelf)
        try:
            pg = max(1, int(str(pg)))
        except Exception:
            pg = 1

        scope = self._scope
        ext = extend
        if isinstance(ext, dict):
            scope = str(ext.get('scope') or scope or '').strip().lower()
        elif ext:
            s = str(ext).strip()
            if s.startswith('{'):
                try:
                    obj = json.loads(s)
                    if isinstance(obj, dict):
                        scope = str(obj.get('scope') or scope or '').strip().lower()
                except Exception:
                    pass
            elif '=' not in s and s.lower() in ('local', 'online'):
                scope = s.lower()

        name = ''
        for c in self._classes():
            if c['type_id'] == tid:
                name = c['type_name']
                break

        items, pagecount, total = [], 1, 0
        try:
            params = {'ac': 'list', 't': tid, 'pg': pg}
            if scope in ('local', 'online'):
                params['scope'] = scope
            d = self._get_json(self.CMS, params, self.LIST_TTL)
            items = [self._norm_item(x, tid, name) for x in (d.get('list') or [])]
            try:
                pagecount = max(1, int(d.get('pagecount') or 1))
            except Exception:
                pagecount = 1
            try:
                total = int(d.get('total') or len(items))
            except Exception:
                total = len(items)
            if not items and pg > 1:
                pagecount = pg
            if pagecount < pg:
                pagecount = pg
        except Exception:
            items, pagecount, total = [], 1, 0

        return {
            'list': items,
            'page': pg,
            'pagecount': pagecount,
            'limit': self.PAGE_SIZE,
            'total': total if total >= len(items) else len(items),
        }

    # ---------- 搜索 ----------

    def searchContent(self, key, quick=False, pg='1', *args, **kwargs):
        key = str(key or '').strip()
        if not key:
            return {'list': [], 'page': 1, 'pagecount': 1, 'total': 0}
        try:
            params = {'ac': 'detail', 'wd': key}
            d = self._get_json(self.CMS, params, self.LIST_TTL)
            seen, items = set(), []
            for x in (d.get('list') or []):
                it = self._norm_item(x)
                k = it['vod_id'] or it['vod_name']
                if not k or k in seen:
                    continue
                seen.add(k)
                items.append(it)
        except Exception:
            items = []
        return {'list': items, 'page': 1, 'pagecount': 1, 'total': len(items)}

    # ---------- 详情 + 章节 ----------

    def detailContent(self, ids):
        if isinstance(ids, (list, tuple, set)):
            id_list = [str(x) for x in ids if x]
        else:
            id_list = [x for x in str(ids or '').split(',') if x]
        if not id_list:
            return {'list': []}

        out = []
        for id in id_list:
            try:
                d = self._get_json(self.CMS, {'ac': 'detail', 'ids': id}, self.DETAIL_TTL)
                rows = d.get('list') or []
                if not rows:
                    continue
                x = rows[0]
                vod = self._norm_item(x)
                vod['vod_content'] = str(x.get('vod_content') or '')
                vod['vod_play_from'] = str(x.get('vod_play_from') or '阅读')

                plays = []
                for piece in str(x.get('vod_play_url') or '').split('#'):
                    piece = piece.strip()
                    if not piece:
                        continue
                    if '$' in piece:
                        cname, cid = piece.split('$', 1)
                    else:
                        cname, cid = '正文', piece
                    cname = self._clean_play_name(cname) or ('第%d章' % (len(plays) + 1))
                    if not cid:
                        continue
                    plays.append('%s$%s' % (cname, cid))

                if self._max_ep and len(plays) > self._max_ep:
                    plays = plays[:self._max_ep]

                remarks = str(vod.get('vod_remarks') or '').strip()
                if plays and not ('共' in remarks and '章' in remarks):
                    tail = '共%d章' % len(plays)
                    remarks = (remarks + ' | ' if remarks else '') + tail
                vod['vod_remarks'] = remarks
                vod['vod_play_url'] = '#'.join(plays)
                out.append(vod)
            except Exception:
                continue
        return {'list': out}

    # ---------- 播放（正文）----------

    def playerContent(self, flag, id, vipFlags=None):
        raw = str(id or '').strip() or str(flag or '').strip()
        if '$' in raw and not raw.lower().startswith(('http://', 'https://')):
            raw = raw.split('$', 1)[1]
        if not raw:
            return {'parse': 0, 'url': '', 'header': self._headers()}

        base = self._playbase()

        if self._mode == 'novel':
            chapter = self._fetch_chapter(raw)
            payload = json.dumps(chapter, ensure_ascii=False)
            return {'parse': 0, 'url': 'novel://' + payload, 'header': self._headers()}

        if self._mode == 'direct':
            return {'parse': 0, 'url': base + '/txt?f=' + quote(raw, safe=''), 'header': self._headers()}

        return {
            'parse': 0,
            'url': base + '/txt?f=' + quote(raw, safe='') + '&fmt=html',
            'header': self._headers(),
        }

    def _fetch_chapter(self, token):
        cache_key = 'ch:' + token
        now = time.time()
        hit = self._cache.get(cache_key)
        if hit and now - hit[0] < hit[1]:
            return hit[2]

        title, content = '', ''
        try:
            d = self._get_json('/novel', {'f': token}, self.TXT_TTL)
            title = str(d.get('title') or '')
            content = str(d.get('content') or '')
        except Exception:
            try:
                content = self._http(self._url('/txt', {'f': token}))
            except Exception:
                content = ''

        if not content:
            content = '正文获取失败，请稍后重试（或检查阅读后端服务是否在运行）'
        chapter = {'title': title, 'content': content}
        self._cache[cache_key] = (now, self.TXT_TTL, chapter)
        return chapter


# ─────────────── 单独跑一遍自检 ───────────────
# python3 阅读书架TVBox.py                    # 用默认地址
# python3 阅读书架TVBox.py http://IP:8998     # 指定服务地址
if __name__ == '__main__':
    ext = sys.argv[1] if len(sys.argv) > 1 else ''
    sp = Spider()
    sp.init(ext)
    print('名称     :', sp.getName())
    home = sp.homeContent(True)
    print('分类     :', len(home.get('class') or []), '个')
    for c in (home.get('class') or [])[:5]:
        print('           ', c['type_id'], c['type_name'])
    print('首页     :', len(home.get('list') or []), '本')
    first = (home.get('class') or [{}])[0]
    if first.get('type_id') is not None:
        cat = sp.categoryContent(first['type_id'], 1, True, '')
        print('分类内容 :', len(cat.get('list') or []), '条')
        if cat.get('list'):
            print('           例:', cat['list'][0]['vod_name'])
            det = sp.detailContent([cat['list'][0]['vod_id']])
            if det.get('list'):
                v = det['list'][0]
                eps = [x for x in (v['vod_play_url'] or '').split('#') if x]
                print('详情     :', v['vod_name'], '/', len(eps), '章')
                if eps:
                    play = sp.playerContent(v['vod_play_from'], eps[0].split('$', 1)[1], None)
                    print('正文     :', play.get('url', '')[:40], '... 长度', len(play.get('url') or ''))
    sr = sp.searchContent('平凡', False, '1')
    print('搜索     :', len(sr.get('list') or []), '条')
