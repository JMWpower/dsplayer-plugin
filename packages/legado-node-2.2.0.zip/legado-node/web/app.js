'use strict';
/* 管理面板前端：纯原生 JS，无构建步骤 */

const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.prototype.slice.call((root || document).querySelectorAll(sel));

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));

const state = {
  tab: 'browse',
  base: '',
  sources: [],
  repos: [],
  browse: { t: '0', pg: 1, ch: '', key: '' },
  repo: { id: 'yiove', pg: 1, key: '' },
};

/* ── 网络 ── */
async function api(path, body) {
  const opts = body === undefined ? {} : {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
  const res = await fetch(path, opts);
  let json;
  try { json = await res.json(); } catch (e) { throw new Error('服务返回异常 (HTTP ' + res.status + ')'); }
  if (!json.ok) throw new Error(json.error || ('请求失败 (HTTP ' + res.status + ')'));
  return json.data;
}

let toastTimer = 0;
function toast(msg, kind) {
  const el = $('#toast');
  el.textContent = msg;
  el.className = 'toast show' + (kind ? ' ' + kind : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = 'toast'; }, 3200);
}

function busy(el, on) {
  if (!el) return;
  el.classList.toggle('loading', !!on);
  el.disabled = !!on;
}

/* ── 状态 ── */
async function refreshState() {
  const data = await api('/api/state');
  state.base = data.base || '';
  state.sources = data.sources || [];
  state.repos = data.repos || [];
  $('#brand-sub').textContent = data.engine && data.engine.error
    ? '书源加载失败：' + data.engine.error
    : 'HTML 规则书源 · ' + data.total + ' 个书源 / 启用 ' + data.enabled;
  $('#stats').innerHTML =
    '<span class="stat"><b>' + data.total + '</b> 书源</span>'
    + '<span class="stat"><b>' + data.enabled + '</b> 启用</span>'
    + '<span class="stat">引擎 <b>' + (data.engine ? data.engine.count : 0) + '</b></span>';
  $('#manage-json').href = '/legado_html.json';
  if (state.repos.length) renderRepoCards();
  return data;
}

/* ── 浏览 ── */
function renderBrowseControls(data) {
  const sel = $('#browse-source');
  const list = data.sources || [];
  sel.innerHTML = list.map((s) =>
    '<option value="' + s.index + '"' + (String(s.index) === String(state.browse.t) ? ' selected' : '') + '>'
    + esc(s.name) + '</option>').join('') || '<option>（无书源）</option>';
  const chSel = $('#browse-channel');
  const chs = data.channels || [];
  chSel.innerHTML = '<option value="">全部</option>' + chs.map((c) =>
    '<option value="' + esc(c.url) + '"' + (c.url === state.browse.ch ? ' selected' : '') + '>'
    + esc(c.title) + '</option>').join('');
  $('#browse-channel-wrap').hidden = !chs.length;
}

function coverHtml(src, name) {
  if (!src) return '<div class="cover placeholder">' + esc((name || '?').slice(0, 1)) + '</div>';
  return '<img class="cover" src="' + esc(src) + '" alt="" loading="lazy" referrerpolicy="no-referrer"'
    + ' onerror="this.className=\'cover placeholder\';this.removeAttribute(\'src\')">';
}

function cardHtml(b) {
  return '<a class="card" href="' + esc(b.link) + '" target="_blank" rel="noopener">'
    + coverHtml(b.cover, b.name)
    + '<div class="card-body">'
    + '<div class="card-name">' + esc(b.name) + '</div>'
    + (b.author ? '<div class="card-meta">' + esc(b.author) + '</div>' : '')
    + (b.kind ? '<div class="card-meta">' + esc(b.kind) + '</div>' : '')
    + (b.last ? '<div class="card-last">' + esc(b.last) + '</div>' : '')
    + (b.intro ? '<div class="card-intro">' + esc(b.intro) + '</div>' : '')
    + '</div></a>';
}

function renderPager(el, page, pagecount, go) {
  el.innerHTML = '';
  if (!pagecount || pagecount <= 1) return;
  const mk = (label, to, disabled) => {
    const b = document.createElement('button');
    b.className = 'btn sm';
    b.textContent = label;
    b.disabled = !!disabled;
    b.onclick = () => go(to);
    return b;
  };
  el.appendChild(mk('上一页', page - 1, page <= 1));
  const info = document.createElement('span');
  info.className = 'page-info';
  info.textContent = page + ' / ' + pagecount;
  el.appendChild(info);
  el.appendChild(mk('下一页', page + 1, page >= pagecount));
}

async function loadBrowse() {
  const listEl = $('#browse-list');
  listEl.innerHTML = '<div class="empty">加载中…</div>';
  const q = new URLSearchParams({ t: state.browse.t, pg: String(state.browse.pg) });
  if (state.browse.ch) q.set('ch', state.browse.ch);
  if (state.browse.key) q.set('key', state.browse.key);
  try {
    const data = await api('/api/browse?' + q.toString());
    renderBrowseControls(data);
    state.browse.pg = data.page || state.browse.pg;
    if (data.mode !== 'search' && typeof data.index === 'number' && data.index !== state.browse.t) {
      // 服务端可能替我们挑了个有内容的源，下拉框跟着变
      state.browse.t = data.index;
      const sel = $('#browse-source');
      if (sel) sel.value = String(data.index);
    }
    const items = data.list || [];
    $('#browse-hint').textContent = data.mode === 'search'
      ? '搜索「' + data.key + '」：' + items.length + ' 条结果'
      : '书源「' + (data.name || '') + '」第 ' + (data.page || 1) + ' 页';
    listEl.innerHTML = items.length ? items.map(cardHtml).join('')
      : noticeHtml(data);
    renderPager($('#browse-pager'), data.page || 1, data.pagecount || 1, (p) => {
      state.browse.pg = p;
      loadBrowse();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  } catch (err) {
    listEl.innerHTML = '<div class="empty">' + esc(err.message) + '</div>';
    $('#browse-hint').textContent = '';
    $('#browse-pager').innerHTML = '';
  }
}

/** 列表为空时把原因说清楚：JS 源 / 失效 / 规则过期 */
function noticeHtml(data) {
  if (data.mode === 'search') {
    return '<div class="notice"><b>没有搜到结果</b><br>'
      + '换一个关键词试试。有些源已经失效，去「源管理」点「检测全部」能看到哪些还有内容。</div>';
  }
  const msg = data.msg || '这个源没有返回任何条目';
  return '<div class="notice"><b>「' + esc(data.name || '该书源') + '」没有内容</b><br>' + esc(msg)
    + '<br><span class="notice-act">换个书源看，或者去「源管理」检测一下哪些源还能用。</span></div>';
}

/* ── 源管理 ── */
function badge(text, kind) {
  return '<span class="badge ' + (kind || '') + '">' + esc(text) + '</span>';
}

/** store 里的下标 ≠ 引擎里的下标（引擎只装启用的），按地址换算 */
function engineIndex(info) {
  if (!info) return -1;
  const enabled = (state.sources || []).filter((s) => s.enabled !== false && s.host);
  return enabled.findIndex((s) => s.host === info.host);
}

const STATE_BADGE = {
  ok: ['可用', 'on'],
  empty: ['无内容', 'warn'],
  error: ['抓取失败', 'danger'],
  timeout: ['超时', 'danger'],
  unknown: ['未检测', ''],
  disabled: ['停用', 'off'],
};

function renderManage(data) {
  const list = data.sources || [];
  $('#manage-hint').textContent = list.length
    ? '共 ' + data.total + ' 个书源，其中 ' + data.enabled + ' 个启用'
      + (data.broken ? '，' + data.broken + ' 个最近抓到空内容/失败（标红）' : '')
      + '。点书源名可以看它的 HTML 页面；点「检测全部」逐个源抓一次分类页。'
    : '还没有任何书源，去「源仓库」导入几个吧。';
  const rows = list.map((s) => {
    const st = STATE_BADGE[s.state] || STATE_BADGE.unknown;
    const badges = [
      s.enabled ? badge('启用', 'on') : badge('停用', 'off'),
      '<span class="badge ' + st[1] + '" title="' + esc(s.msg || '') + '">' + st[0] + '</span>',
      s.searchable ? badge('可搜索') : '',
      s.channels.length ? badge(s.channels.length + ' 频道') : '',
      s.group ? badge(s.group) : '',
    ].join('');
    return '<div class="row' + (s.enabled ? '' : ' dim') + '">'
      + '<div class="row-main">'
      + '<a class="row-name" href="/hs/source?i=' + s.index + '" target="_blank" rel="noopener">' + esc(s.name) + '</a>'
      + '<div class="row-meta">' + esc(s.host) + '</div>'
      + '</div>'
      + '<div class="row-badges">' + badges + '</div>'
      + '<div class="row-acts">'
      + '<button class="btn sm" data-act="toggle" data-i="' + s.index + '" data-on="' + (s.enabled ? '1' : '0') + '">'
      + (s.enabled ? '停用' : '启用') + '</button>'
      + '<button class="btn sm" data-act="probe" data-i="' + s.index + '">浏览</button>'
      + '<button class="btn sm" data-act="test" data-i="' + s.index + '">搜索</button>'
      + '<button class="btn sm" data-act="json" data-i="' + s.index + '">JSON</button>'
      + '<button class="btn sm" data-act="up" data-i="' + s.index + '">↑</button>'
      + '<button class="btn sm" data-act="down" data-i="' + s.index + '">↓</button>'
      + '<button class="btn sm danger" data-act="remove" data-i="' + s.index + '">删除</button>'
      + '</div></div>';
  }).join('');
  $('#manage-list').innerHTML = rows || '<div class="empty">暂无书源</div>';
}

async function loadManage() {
  const data = await refreshState();
  renderManage(data);
}

async function sourceAction(act, index, extra) {
  if (act === 'json') {
    const raw = await api('/api/source?i=' + index);
    showJson(raw);
    return;
  }
  if (act === 'probe') {
    toast('正在抓一次分类页…');
    const r = await api('/api/health', { index: engineIndex((state.sources || [])[index]) });
    const t = (r.list || [])[0] || {};
    await loadManage();
    toast(t.count
      ? '「' + t.name + '」有内容：' + t.count + ' 本，' + t.ms + 'ms'
      : '「' + (t.name || '') + '」没有内容：' + (t.msg || '未知原因'), t.count ? 'ok' : 'warn');
    return;
  }
  if (act === 'test') {
    toast('正在测试搜索…');
    const r = await api('/api/source/test', { index });
    toast('「' + r.key + '」' + r.count + ' 条，耗时 ' + r.ms + 'ms'
      + (r.sample && r.sample.length ? '：' + r.sample.join('、') : ''), r.count ? 'ok' : 'warn');
    return;
  }
  if (act === 'remove') {
    if (!confirm('确定删除这个书源？')) return;
    await api('/api/source/remove', { index });
    toast('已删除', 'ok');
  } else if (act === 'toggle') {
    const on = extra === '1';
    await api('/api/source/toggle', { index, enabled: !on });
    toast(on ? '已停用' : '已启用', 'ok');
  } else if (act === 'up' || act === 'down') {
    await api('/api/source/move', { index, delta: act === 'up' ? -1 : 1 });
  }
  await loadManage();
}

/* ── JSON 弹层 ── */
function showJson(raw) {
  const mask = document.createElement('div');
  mask.className = 'mask';
  mask.innerHTML = '<div class="dialog"><div class="dialog-head"><b>' + esc(raw.bookSourceName || '书源 JSON')
    + '</b><button class="btn sm" data-close="1">关闭</button></div>'
    + '<pre>' + esc(JSON.stringify(raw, null, 2)) + '</pre></div>';
  mask.addEventListener('click', (e) => {
    if (e.target === mask || e.target.dataset.close) mask.remove();
  });
  document.body.appendChild(mask);
}

/* ── 源仓库 ── */
function renderRepoCards() {
  const local = '<button class="repo-card local" id="local-import">'
    + '<div class="repo-name">📁 本地 JSON 导入</div>'
    + '<div class="repo-home">选一个 .json 文件，或把它拖到页面上</div>'
    + '<div class="repo-note">支持乐读书源数组、{"sources":[...]}、阅读备份里的 bookSource.json</div>'
    + '</button>';
  $('#repo-cards').innerHTML = state.repos.map((r) =>
    '<button class="repo-card' + (r.id === state.repo.id ? ' active' : '') + '" data-repo="' + esc(r.id) + '">'
    + '<div class="repo-name">' + esc(r.name) + '</div>'
    + '<div class="repo-home">' + esc(r.home) + '</div>'
    + '<div class="repo-note">' + esc(r.note) + '</div>'
    + '</button>').join('') + local;
  $('#repo-toolbar').hidden = false;
}

/** 本地书源 JSON 导入：读文本 → 交给服务端解析（数组 / {sources:[]} / 阅读备份） */
async function importLocalFile(file) {
  if (!file) return;
  if (file.size > 16 * 1024 * 1024) { toast('文件太大（上限 16MB）', 'err'); return; }
  toast('正在导入「' + file.name + '」…');
  try {
    const text = await file.text();
    const r = await api('/api/import-file', { text, name: file.name });
    const parts = [];
    if (r.added.length) parts.push('新增 ' + r.added.length);
    if (r.updated.length) parts.push('更新 ' + r.updated.length);
    if (r.invalid) parts.push('跳过 ' + r.invalid + ' 个无效');
    let msg = '「' + file.name + '」解析 ' + r.parsed + ' 条：' + (parts.join('，') || '没有变化')
      + '，现有 ' + r.total + ' 个书源';
    const tests = r.tests || [];
    const good = tests.filter((t) => t.count > 0);
    const bad = tests.filter((t) => !t.count);
    if (good.length) msg += '；可用：' + good.map((t) => '「' + t.name + '」' + t.count + ' 本').join('、');
    if (bad.length) msg += '；暂无内容：' + bad.map((t) => '「' + t.name + '」' + (t.msg || '未知原因')).join('、');
    toast(msg, bad.length ? 'warn' : 'ok');
    await refreshState();
    if (state.tab === 'manage') await loadManage();
  } catch (err) {
    toast('导入失败：' + err.message, 'err');
  }
}

function pickLocalFile() {
  const input = $('#file-input');
  input.value = '';
  input.click();
}

async function loadRepo() {
  renderRepoCards();
  const cur = state.repos.find((r) => r.id === state.repo.id);
  $('#repo-title').textContent = cur ? cur.name : '';
  const listEl = $('#repo-list');
  listEl.innerHTML = '<div class="empty">加载中…</div>';
  const q = new URLSearchParams({ r: state.repo.id, pg: String(state.repo.pg) });
  if (state.repo.key) q.set('key', state.repo.key);
  try {
    const data = await api('/api/repo?' + q.toString());
    const items = data.items || [];
    listEl.innerHTML = items.length ? items.map((it) => {
      const meta = [
        it.author ? '作者 ' + it.author : '',
        it.views ? it.views + ' 次下载' : '',
        it.extra || '',
        it.time ? new Date(it.time).toLocaleDateString('zh-CN') : '',
      ].filter(Boolean).map(esc).join(' · ');
      return '<div class="row">'
        + '<div class="row-main"><div class="row-name">' + esc(it.name) + '</div>'
        + (it.url ? '<div class="row-meta">' + esc(it.url) + '</div>' : '')
        + (it.desc ? '<div class="row-desc">' + esc(it.desc) + '</div>' : '')
        + (meta ? '<div class="row-meta">' + meta + '</div>' : '')
        + '</div>'
        + '<div class="row-acts"><button class="btn sm primary" data-import="' + esc(it.id) + '">导入</button></div>'
        + '</div>';
    }).join('') : '<div class="empty">这个仓库没有数据</div>';
    $('#repo-pager').innerHTML = '';
    renderPager($('#repo-pager'), data.page || 1, data.pages || 1, (p) => {
      state.repo.pg = p;
      loadRepo();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  } catch (err) {
    listEl.innerHTML = '<div class="empty">' + esc(err.message) + '</div>';
    $('#repo-pager').innerHTML = '';
  }
}

async function importSource(id, btn) {
  busy(btn, true);
  btn.textContent = '导入中';
  try {
    const r = await api('/api/import', { repo: state.repo.id, id });
    const parts = [];
    if (r.added.length) parts.push('新增 ' + r.added.length);
    if (r.updated.length) parts.push('更新 ' + r.updated.length);
    if (r.invalid) parts.push(r.invalid + ' 个无效');
    const tests = r.tests || [];
    const good = tests.filter((t) => t.count > 0);
    const bad = tests.filter((t) => !t.count);
    let msg = '已导入「' + (r.name || id) + '」（' + (parts.join('，') || '无变化') + '），现有 ' + r.total + ' 个书源';
    if (tests.length) {
      msg += good.length ? '，' + good.map((t) => '「' + t.name + '」可用（' + t.count + ' 本）').join('、') : '';
      if (bad.length) msg += '；' + bad.map((t) => '「' + t.name + '」暂无内容：' + (t.msg || '未知原因')).join('；');
    }
    toast(msg, bad.length ? 'warn' : 'ok');
    btn.textContent = '已导入';
    await refreshState();
    if (state.tab === 'manage') await loadManage();
  } catch (err) {
    toast('导入失败：' + err.message, 'err');
    btn.textContent = '导入';
  } finally {
    busy(btn, false);
  }
}

/* ── 事件 ── */
const TABS = ['browse', 'manage', 'repos'];

function switchTab(name, silent) {
  if (!TABS.includes(name)) name = 'browse';
  state.tab = name;
  $$('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  $$('.panel').forEach((p) => p.classList.toggle('active', p.id === 'panel-' + name));
  if (!silent && location.hash !== '#' + name) location.hash = name;
  if (name === 'manage') loadManage().catch((e) => toast(e.message, 'err'));
  if (name === 'repos') {
    renderRepoCards();
    loadRepo().catch((e) => toast(e.message, 'err'));
  }
  if (name === 'browse' && !$('#browse-list').children.length) loadBrowse();
}

$('#tabs').addEventListener('click', (e) => {
  const t = e.target.closest('.tab');
  if (t) switchTab(t.dataset.tab);
});

window.addEventListener('hashchange', () => {
  const name = location.hash.replace(/^#/, '');
  if (name && name !== state.tab) switchTab(name, true);
});

$('#browse-source').addEventListener('change', (e) => {
  state.browse.t = e.target.value;
  state.browse.pg = 1;
  state.browse.ch = '';
  loadBrowse();
});

$('#browse-channel').addEventListener('change', (e) => {
  state.browse.ch = e.target.value;
  state.browse.pg = 1;
  loadBrowse();
});

$('#browse-go').addEventListener('click', () => {
  state.browse.key = $('#browse-key').value.trim();
  state.browse.pg = 1;
  loadBrowse();
});

$('#browse-key').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('#browse-go').click();
});

$('#browse-reset').addEventListener('click', () => {
  $('#browse-key').value = '';
  state.browse.key = '';
  state.browse.pg = 1;
  state.browse.ch = '';
  loadBrowse();
});

$('#manage-list').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-act]');
  if (!b) return;
  sourceAction(b.dataset.act, parseInt(b.dataset.i, 10), b.dataset.on).catch((err) => toast(err.message, 'err'));
});

$('#manage-refresh').addEventListener('click', () => loadManage().catch((e) => toast(e.message, 'err')));

$('#manage-enable-all').addEventListener('click', async () => {
  await api('/api/source/all', { enabled: true });
  toast('已全部启用', 'ok');
  await loadManage();
});

$('#manage-disable-all').addEventListener('click', async () => {
  await api('/api/source/all', { enabled: false });
  toast('已全部停用', 'ok');
  await loadManage();
});

$('#manage-check').addEventListener('click', async (ev) => {
  const btn = ev.currentTarget;
  busy(btn, true);
  toast('正在逐个书源抓分类页，稍等…');
  try {
    const r = await api('/api/health', {});
    const okNames = (r.list || []).filter((x) => x.count > 0).map((x) => x.name);
    const badNames = (r.list || []).filter((x) => !x.count).map((x) => x.name + '（' + (x.msg || '无内容') + '）');
    await loadManage();
    toast('检测完成：' + r.summary.ok + '/' + r.summary.total + ' 个源有内容，用时 ' + r.summary.ms + 'ms'
      + (badNames.length ? '\n无内容：' + badNames.slice(0, 6).join('；') + (badNames.length > 6 ? ' 等' : '') : ''), badNames.length ? 'warn' : 'ok');
    if (okNames.length) console.log('[检测] 可用书源：', okNames.join('、'));
  } catch (err) {
    toast('检测失败：' + err.message, 'err');
  } finally {
    busy(btn, false);
  }
});

$('#manage-copy').addEventListener('click', async () => {
  const url = state.base + '/legado_html.json';
  try {
    await navigator.clipboard.writeText(url);
    toast('已复制：' + url, 'ok');
  } catch (e) {
    toast(url, 'warn');
  }
});

$('#repo-cards').addEventListener('click', (e) => {
  if (e.target.closest('#local-import')) { pickLocalFile(); return; }
  const c = e.target.closest('[data-repo]');
  if (!c) return;
  state.repo.id = c.dataset.repo;
  state.repo.pg = 1;
  state.repo.key = '';
  $('#repo-key').value = '';
  loadRepo();
});

$('#repo-go').addEventListener('click', () => {
  state.repo.key = $('#repo-key').value.trim();
  state.repo.pg = 1;
  loadRepo();
});

$('#repo-key').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('#repo-go').click();
});

$('#repo-list').addEventListener('click', (e) => {
  const b = e.target.closest('[data-import]');
  if (b) importSource(b.dataset.import, b);
});

/* ── 本地 JSON 导入：按钮 / 文件选择 / 拖拽 ── */
$('#manage-import').addEventListener('click', pickLocalFile);

$('#file-input').addEventListener('change', (e) => {
  const f = e.target.files && e.target.files[0];
  if (f) importLocalFile(f);
});

let dragDepth = 0;
const hasFiles = (e) => e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0;

window.addEventListener('dragenter', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth += 1;
  $('#drop-mask').classList.add('show');
});

window.addEventListener('dragover', (e) => {
  if (hasFiles(e)) e.preventDefault();
});

window.addEventListener('dragleave', (e) => {
  if (!hasFiles(e)) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) $('#drop-mask').classList.remove('show');
});

window.addEventListener('drop', (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  dragDepth = 0;
  $('#drop-mask').classList.remove('show');
  const f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (f) importLocalFile(f);
});

/* ── 启动 ── */
(async function boot() {
  // 支持 ?t=3&ch=xxx 直接把书库定位到某个书源/频道（方便分享与排查）
  const qs = new URLSearchParams(location.search);
  if (qs.has('t')) state.browse.t = qs.get('t') || '0';
  if (qs.has('ch')) state.browse.ch = qs.get('ch') || '';
  if (qs.has('key')) state.browse.key = qs.get('key') || '';
  const want = location.hash.replace(/^#/, '');
  if (TABS.includes(want)) switchTab(want, true);
  try {
    await refreshState();
    if (!state.sources.length) switchTab('repos', true);
    else if (TABS.includes(want) && want !== 'browse') switchTab(want, true);
    else loadBrowse();
  } catch (err) {
    toast('连接服务失败：' + err.message, 'err');
  }
}());
