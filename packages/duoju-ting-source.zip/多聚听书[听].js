/*
@header({
  searchable: 1,
  filterable: 1,
  quickSearch: 0,
  title: '多聚听书',
  author: 'JMWpower',
  '类型': '听书',
  version: '1.9.0',
  lang: 'ds',
})
*/

var API_BASE = 'http://127.0.0.1:8999';

var PLATS = [
    ['kw', '酷我听书'],
    ['bookan', '博看听书'],
    ['lrts', '懒人听书'],
    ['bili', '哔哩有声'],
    ['podcast', '播客'],
    ['yuntu', '云图有声'],
    ['ty', '听友'],
    ['xm', '喜马拉雅'],
    ['syfm', '书音FM'],
    ['tsw', '听书网'],
    ['faloo', '飞卢听书'],
    ['tyfm', '听友听书'],
    ['ytba', '悦听吧'],
    ['leting', '乐听网'],
    ['qdysw', '起点有声'],
];

var CATS = {};

function platName(key) {
    for (var i = 0; i < PLATS.length; i++) {
        if (PLATS[i][0] === key) return PLATS[i][1];
    }
    return key;
}

async function getJson(api) {
    var res = JSON.parse(await request(api));
    if (res && res.code === 200 && res.data) return res.data;
    return null;
}

async function ensureCats(plat) {
    if (CATS[plat]) return CATS[plat];
    var d = await getJson(API_BASE + '/api/cats?plat=' + encodeURIComponent(plat));
    var cats = (d && d.cats) || [];
    if (cats.length && cats[0].id === '' && cats.length > 1) cats = cats.slice(1);
    CATS[plat] = cats;
    return cats;
}

function cleanTitle(t) {
    return String(t || '').replace(/[$#]/g, ' ').trim() || '未知';
}

function bookToken(plat, id) {
    return 'B__' + plat + '__' + encodeURIComponent(id);
}

function parseBookToken(input) {
    var raw = String(input || '');
    var m = raw.match(/^B__([a-z]+)__([\s\S]+)$/);
    if (!m) return null;
    try { return { plat: m[1], id: decodeURIComponent(m[2]) }; } catch (e) { return { plat: m[1], id: m[2] }; }
}

function trackToken(plat, ref) {
    return 'T__' + plat + '__' + encodeURIComponent(ref);
}

function parseTrackToken(input) {
    var raw = String(input || '');
    if (raw.indexOf('T__') !== 0) return null;
    var rest = raw.slice(3);
    var sep = rest.indexOf('__');
    if (sep < 0) return null;
    var plat = rest.slice(0, sep);
    try { return { plat: plat, ref: decodeURIComponent(rest.slice(sep + 2)) }; }
    catch (e) { return { plat: plat, ref: rest.slice(sep + 2) }; }
}

var rule = {
    title: '多聚听书',
    类型: '听书',
    host: API_BASE,
    homeUrl: '',
    searchUrl: '',
    url: '',
    headers: { 'User-Agent': 'MOBILE_UA' },
    timeout: 15000,
    multi: 1,
    searchable: 1,
    filterable: 1,
    play_parse: true,

    class_parse: async function () {
        var classList = [];
        var filters = {};
        var d = await getJson(API_BASE + '/api/platform');
        var plats = (d && d.platforms) || [];
        var list = plats.length ? plats : PLATS.map(function (p) { return { key: p[0], name: p[1] }; });
        for (var i = 0; i < list.length; i++) {
            var p = list[i];
            var key = p.key || p[0];
            var name = p.name || p[1];
            classList.push({ type_id: key, type_name: name });
            try {
                var cats = await ensureCats(key);
                if (cats.length) {
                    filters[key] = [{
                        key: 'cat', name: '分类',
                        value: cats.map(function (c) { return { n: c.name, v: c.id }; }),
                    }];
                }
            } catch (e) { }
        }
        return { class: classList, filters: filters };
    },

    一级: async function () {
        var plat = this.MY_CATE || 'kw';
        var page = parseInt(this.MY_PAGE) || 1;
        var ext = this.extend || arguments[3] || {};
        if (typeof ext === 'string') { try { ext = JSON.parse(ext); } catch (e) { ext = {}; } }
        ext = ext || {};
        var d = [];
        try {
            var cat = ext.cat || '';
            if (!cat) {
                var cats = await ensureCats(plat);
                cat = cats.length ? cats[0].id : '';
            }
            var data = await getJson(API_BASE + '/api/category?plat=' + encodeURIComponent(plat) +
                '&cat=' + encodeURIComponent(cat) + '&page=' + page);
            var list = (data && data.list) || [];
            for (var i = 0; i < list.length; i++) {
                var c = list[i] || {};
                if (!c.vod_id) continue;
                d.push({
                    title: cleanTitle(c.vod_name),
                    img: c.vod_pic || '',
                    desc: [c.vod_remarks, c.vod_director].filter(Boolean).join(' · '),
                    url: bookToken(plat, c.vod_id),
                });
            }
        } catch (e) { }
        return setResult(d);
    },

    推荐: async function () {
        var d = [];
        var pool = PLATS.slice();
        for (var i = pool.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var t = pool[i]; pool[i] = pool[j]; pool[j] = t;
        }
        var picks = pool.slice(0, 3);
        var results = await Promise.all(picks.map(function (p) {
            var plat = p[0];
            return getJson(API_BASE + '/api/category?plat=' + encodeURIComponent(plat) +
                '&cat=&page=' + (1 + Math.floor(Math.random() * 2)))
                .then(function (data) {
                    var out = [];
                    var list = (data && data.list) || [];
                    for (var i = 0; i < list.length; i++) {
                        var c = list[i] || {};
                        if (!c.vod_id) continue;
                        out.push({
                            title: cleanTitle(c.vod_name),
                            img: c.vod_pic || '',
                            desc: [c.vod_remarks, platName(plat)].filter(Boolean).join(' · '),
                            url: bookToken(plat, c.vod_id),
                        });
                    }
                    return out;
                })
                .catch(function () { return []; });
        }));
        var idx = 0;
        while (d.length < 24) {
            var added = false;
            for (var r = 0; r < results.length; r++) {
                var it = results[r][idx];
                if (it) { added = true; d.push(it); }
            }
            if (!added) break;
            idx++;
        }
        return setResult(d);
    },

    搜索: async function () {
        var KEY = this.KEY || '';
        var page = parseInt(this.MY_PAGE) || 1;
        var kw = (KEY || '').trim();
        var d = [];
        if (!kw || page > 3) return setResult(d);
        // 后端聚合搜索：一次请求并发全源并交错合并（vod_plat 标记来源），设备端更稳
        function mapCard(c, platFallback) {
            if (!c || !c.vod_id) return null;
            var plat = c.vod_plat || platFallback || '';
            return {
                title: cleanTitle(c.vod_name),
                img: c.vod_pic || '',
                desc: [c.vod_remarks, platName(plat)].filter(Boolean).join(' · '),
                url: bookToken(plat, c.vod_id),
            };
        }
        try {
            var data = await getJson(API_BASE + '/api/search?wd=' + encodeURIComponent(kw) + '&page=' + page);
            var list = (data && data.list) || [];
            for (var i = 0; i < list.length && d.length < 60; i++) {
                var it = mapCard(list[i]);
                if (it) d.push(it);
            }
        } catch (e) { /* 聚合失败降级单源 */ }
        if (!d.length) {
            // 降级：逐个可靠源串行拉，避免并发把弱网打挂
            var order = ['kw', 'lrts', 'tyfm', 'xm', 'syfm'];
            for (var j = 0; j < order.length && d.length < 30; j++) {
                try {
                    var dd = await getJson(API_BASE + '/api/search?plat=' + order[j] +
                        '&wd=' + encodeURIComponent(kw) + '&page=' + page);
                    var ll = (dd && dd.list) || [];
                    for (var k2 = 0; k2 < ll.length && d.length < 30; k2++) {
                        var it2 = mapCard(ll[k2], order[j]);
                        if (it2) d.push(it2);
                    }
                } catch (e2) { }
            }
        }
        return setResult(d);
    },

    二级: async function () {
        var id = String(this.orId || this.vid || this.input || '');
        var t = parseBookToken(id);
        var title = '未知', pic = '', from = '多聚听书', remarks = '', playUrl = '';
        if (t) {
            try {
                var data = await getJson(API_BASE + '/api/detail?plat=' + encodeURIComponent(t.plat) +
                    '&id=' + encodeURIComponent(t.id));
                if (data) {
                    title = cleanTitle(data.vod_name);
                    pic = data.vod_pic || '';
                    from = platName(t.plat);
                    remarks = data.vod_remarks || '';
                    var chapters = data.chapters || [];
                    var entries = [];
                    for (var i = 0; i < chapters.length; i++) {
                        var ch = chapters[i] || {};
                        if (!ch.url) continue;
                        entries.push(cleanTitle(ch.name) + '$' + trackToken(t.plat, ch.url));
                    }
                    playUrl = entries.join('#');
                    if (!remarks) remarks = entries.length ? '共' + entries.length + '集' : '暂无章节';
                }
            } catch (e) {
                remarks = '详情获取失败';
            }
        }
        return {
            vod_name: title,
            vod_pic: pic,
            vod_remarks: remarks,
            vod_content: '多聚听书 · 本地听书服务(' + API_BASE.replace('http://', '') + ')',
            vod_play_from: from,
            vod_play_url: playUrl,
        };
    },

    lazy: async function () {
        var input = String(this.input || '');
        var t = parseTrackToken(input);
        if (!t) return { parse: 0, url: input };
        try {
            var data = await getJson(API_BASE + '/api/play?plat=' + encodeURIComponent(t.plat) +
                '&url=' + encodeURIComponent(t.ref));
            var url = (data && (data.url || data.src)) || '';
            if (!url) return { parse: 0, url: 'toast://音频解析失败' };
            if (url.indexOf('/') === 0) url = API_BASE + url;
            return { parse: 0, url: url };
        } catch (e) {
            return { parse: 0, url: 'toast://播放获取失败: ' + (e && e.message ? e.message : '服务未响应') };
        }
    },
};
