(function () {
  'use strict';

  var TOKEN_KEY = 'dsui_mcptoken';
  var GW_FALLBACK = 'http://127.0.0.1:9978';
  var PIC_FILL = true;
  var PIC_CAP = 15;
  var PIC_CONC = 5;
  var PIC_BUDGET = 4500;

  var PORT_OVERRIDE = 0;

  function dsFrom(w) {
    try { return (w && w.ds) ? w.ds : null; } catch (e) { return null; }
  }
  function frames() {
    var a = [];
    try { a.push(window); } catch (e) {}
    try { if (window.parent && window.parent !== window) a.push(window.parent); } catch (e) {}
    try { if (window.top && window.top !== window && window.top !== window.parent) a.push(window.top); } catch (e) {}
    return a;
  }
  function gwPort() {
    if (PORT_OVERRIDE) return PORT_OVERRIDE;
    try {
      var m = /[?&]gw=(\d+)/.exec(String(location.search || ''));
      if (m) return m[1];
    } catch (e) {}
    var ws = frames();
    for (var i = 0; i < ws.length; i++) {
      var d = dsFrom(ws[i]);
      try { if (d && d.env && d.env.gwPort) return d.env.gwPort; } catch (e) {}
    }
    return 0;
  }

  function gwOrigin() {
    var p = gwPort();
    if (p) return 'http://127.0.0.1:' + p;
    try {
      var o = String(location.origin || '');
      if (/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(o)) return o.replace(/\/+$/, '');
    } catch (e) {}
    return GW_FALLBACK;
  }

  function mcpUrl() { return gwOrigin() + '/mcp'; }

  var TOKEN_CACHE = null;
  var TOKEN_COOL = 0;

  function extractToken(t) {
    var s = '';
    if (typeof t === 'string') s = t;
    else if (t && typeof t.text === 'string') s = t.text;
    else if (t) { try { s = JSON.stringify(t); } catch (e) { s = ''; } }
    var m = /Bearer\s+(mcp_[A-Za-z0-9_\-]+)/.exec(s);
    if (!m) {
      var all = s.match(/mcp_[A-Za-z0-9_\-]{12,}/g) || [];
      for (var i = 0; i < all.length; i++) {
        if (!/^mcp_[xX]+$/.test(all[i]) && !/^mcp_[-_]+$/.test(all[i])) return all[i];
      }
      return '';
    }
    return m[1];
  }

  function envToken() {
    var ws = frames();
    for (var i = 0; i < ws.length; i++) {
      var d = dsFrom(ws[i]);
      try {
        if (!d || !d.env) continue;
        var t = d.env.mcpToken || d.env.token || d.env.gwToken || '';
        if (t) return String(t).replace(/^Bearer\s+/, '');
      } catch (e) {}
    }
    return '';
  }

  function digToken(r) {
    if (r == null) return Promise.resolve('');
    if (typeof r === 'string') return Promise.resolve(extractToken(r));
    if (typeof r.then === 'function') {
      return Promise.resolve(r).then(digToken, function () { return ''; });
    }
    if (typeof r.text === 'function') {
      try { return Promise.resolve(r.text()).then(digToken, function () { return ''; }); }
      catch (e) { return Promise.resolve(''); }
    }
    var keys = ['content', 'body', 'text', 'data', 'result', 'html', 'raw', 'response', 'responseText'];
    for (var i = 0; i < keys.length; i++) {
      var v = r[keys[i]];
      if (!v) continue;
      var hit = extractToken(v);
      if (hit) return Promise.resolve(hit);
    }
    return Promise.resolve(extractToken(r));
  }

  function tryReq(win, url) {
    var out = [];
    var d = dsFrom(win);
    if (d && typeof d.req === 'function') {
      out.push(function () { return d.req(url, { timeout: 8 }); });
    }
    var f = null;
    try { f = win.fm; } catch (e) {}
    if (f && typeof f.req === 'function') {
      out.push(function () { return f.req(url, { timeout: 8 }); });
    }
    return out;
  }

  function nativeGet(url) {
    var ws = frames();
    var reqs = [];
    for (var i = 0; i < ws.length; i++) {
      var part = tryReq(ws[i], url);
      for (var j = 0; j < part.length; j++) reqs.push(part[j]);
    }
    var idx = -1;
    function next() {
      idx++;
      if (idx >= reqs.length) return Promise.resolve('');
      return Promise.resolve().then(reqs[idx]).then(digToken, function () { return ''; })
        .then(function (tk) { return tk || next(); });
    }
    return next();
  }

  function askParentEnv() {
    return new Promise(function (resolve) {
      var done = false;
      var timer = null;
      function onMsg(ev) {
        var d = ev && ev.data;
        if (!d || d.t !== 'dsui:env') return;
        if (done) return;
        done = true;
        try { window.removeEventListener('message', onMsg); } catch (e) {}
        if (timer) clearTimeout(timer);
        if (d.port) PORT_OVERRIDE = d.port;
        resolve(extractToken(String(d.token || '')));
      }
      try { window.addEventListener('message', onMsg); } catch (e) {}
      try {
        var w = (window.parent && window.parent !== window) ? window.parent : window.top;
        if (w && w !== window) w.postMessage({ t: 'dsui:needEnv' }, '*');
      } catch (e) {}
      timer = setTimeout(function () {
        if (done) return;
        done = true;
        try { window.removeEventListener('message', onMsg); } catch (e) {}
        resolve('');
      }, 1200);
    });
  }

  function discoverToken(force) {
    if (TOKEN_CACHE && !force) return Promise.resolve(TOKEN_CACHE);
    if (Date.now() < TOKEN_COOL && !force) return Promise.resolve('');
    var lt = '';
    try {
      lt = localStorage.getItem(TOKEN_KEY) || localStorage.getItem('myhome_mcptoken') || '';
    } catch (e) {}
    if (lt && !force) { TOKEN_CACHE = lt; return Promise.resolve(lt); }

    var et = envToken();
    if (et) { TOKEN_CACHE = et; return Promise.resolve(et); }

    var url = gwOrigin() + '/';
    return nativeGet(url).then(function (tk) {
      if (tk) return tk;
      return fetch(url, { cache: 'no-store' })
        .then(function (r) { return r.text(); })
        .then(extractToken, function () { return ''; });
    }).then(function (tk) {
      if (tk) return tk;
      return askParentEnv();
    }).then(function (tk) {
      if (tk) {
        TOKEN_CACHE = tk;
        try { localStorage.setItem(TOKEN_KEY, tk); } catch (e) {}
        dismissTokenPrompt();
        return tk;
      }
      TOKEN_COOL = Date.now() + 5000;
      return '';
    });
  }

  function invalidateToken() {
    SESS.sid = null; SESS.token = null; SESS.pend = null;
    TOKEN_CACHE = null; TOKEN_COOL = 0;
    try { localStorage.removeItem(TOKEN_KEY); } catch (e) {}
  }

  function dismissTokenPrompt() {
    prompting = false;
    try {
      var box = document.querySelector('[data-dsui-token]');
      if (box && box.parentNode) box.parentNode.removeChild(box);
    } catch (e) {}
  }

  function fm() {
    try { if (window.fm && window.fm.vod) return window.fm; } catch (e) {}
    try {
      if (window.parent && window.parent !== window && window.parent.fm && window.parent.fm.vod) return window.parent.fm;
    } catch (e) {}
    try {
      if (window.top && window.top !== window && window.top.fm && window.top.fm.vod) return window.top.fm;
    } catch (e) {}
    return null;
  }

  function done(id, res) {
    if (id && typeof window.__onNativeSuccess === 'function') {
      try { window.__onNativeSuccess(id, res, false); } catch (e) {}
    }
  }
  function fail(id, err) {
    if (id && typeof window.__onNativeError === 'function') {
      try { window.__onNativeError(id, String((err && err.message) || err)); } catch (e) {}
    }
  }

  function asciiJson(o) {
    return JSON.stringify(o).replace(/[\u007f-\uffff]/g, function (c) {
      return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
    });
  }

  function httpPost(url, headers, body, timeoutMs) {
    var opt = { method: 'POST', headers: headers, body: asciiJson(body) };
    if (typeof AbortController === 'function') {
      var ac = new AbortController();
      opt.signal = ac.signal;
      var t = setTimeout(function () { try { ac.abort(); } catch (e) {} }, timeoutMs || 12000);
      return fetch(url, opt).then(function (r) { clearTimeout(t); return r; },
        function (e) { clearTimeout(t); throw e; });
    }
    return fetch(url, opt);
  }

  function parseSse(txt) {
    if (!txt) return null;
    var t = txt.trim();
    if (t.charAt(0) === '{') { try { return JSON.parse(t); } catch (e) {} }
    var data = [];
    t.split(/\r?\n/).forEach(function (ln) {
      if (ln.indexOf('data:') === 0) data.push(ln.slice(5).replace(/^\s/, ''));
    });
    var joined = data.join('\n').trim();
    if (!joined) return null;
    try { return JSON.parse(joined); } catch (e) { return null; }
  }

  function extractToolResult(msg) {
    var r = msg && msg.result;
    if (!r) return null;
    var txt = (r.content && r.content.length)
      ? r.content.map(function (c) { return (c && c.text) || ''; }).join('') : '';
    if (r.isError) throw new Error(txt || '工具执行失败');
    if (r.structuredContent) {
      var sc = r.structuredContent;
      if (typeof sc === 'string') {
        try { return JSON.parse(sc); } catch (e) { return sc; }
      }
      return sc;
    }
    if (txt) { try { return JSON.parse(txt); } catch (e) { return txt; } }
    return r;
  }

  function mcpHeaders(tk, sid) {
    var h = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
    if (tk) h['Authorization'] = 'Bearer ' + tk;
    if (sid) h['Mcp-Session-Id'] = sid;
    return h;
  }

  function mcpHandshake(tk) {
    return httpPost(mcpUrl(), mcpHeaders(tk), {
      jsonrpc: '2.0', id: 1, method: 'initialize',
      params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'dsui', version: '1.0' } }
    }).then(function (res) {
      if (res.status === 401 || res.status === 403) {
        var e = new Error('网关拒绝（HTTP ' + res.status + ' ' + diag() + '）'); e.auth = true; throw e;
      }
      if (!res.ok && res.status !== 202) throw new Error('initialize HTTP ' + res.status + ' ' + diag());
      var sid = res.headers.get('Mcp-Session-Id') || res.headers.get('mcp-session-id');
      return res.text().then(function () { return sid; });
    }).then(function (sid) {
      return httpPost(mcpUrl(), mcpHeaders(tk, sid), { jsonrpc: '2.0', method: 'notifications/initialized' })
        .then(function (r) { return r.text(); })
        .then(function () { return sid; });
    });
  }

  var SESS = { sid: null, token: null, pend: null };

  function diag() {
    return '@' + gwOrigin() + (SESS.token ? ' [token#' + SESS.token.slice(0, 8) + ']' : ' [no token]');
  }

  function resolveToken(tk) {
    if (typeof tk === 'string' && tk) return Promise.resolve(tk);
    if (SESS.token) return Promise.resolve(SESS.token);
    return discoverToken();
  }

  function mcpInit(tk) {
    return resolveToken(tk).then(function (t) {
      if (SESS.sid && SESS.token === t) return SESS.sid;
      if (SESS.pend && SESS.token === t) return SESS.pend;
      SESS.token = t; SESS.sid = null;
      SESS.pend = mcpHandshake(t).then(function (sid) {
        SESS.sid = sid; SESS.pend = null; return sid;
      }, function (e) { SESS.pend = null; throw e; });
      return SESS.pend;
    });
  }

  function mcpTool(tool, args, tk, _authRetried) {
    return resolveToken(tk).then(function (t) {
      return mcpInit(t).then(function (sid) {
        return httpPost(mcpUrl(), mcpHeaders(t, sid), {
          jsonrpc: '2.0', id: 2, method: 'tools/call',
          params: { name: tool, arguments: args || {} }
        }).then(function (res) {
          if (!res.ok) {
            var e = new Error('tools/call HTTP ' + res.status + ' ' + diag());
            if (res.status === 401 || res.status === 403) e.auth = true; else e.http = res.status;
            throw e;
          }
          return res.text();
        }).then(function (txt) {
          var msg = parseSse(txt);
          if (!msg) throw new Error('MCP 空响应');
          if (msg.error) throw new Error(msg.error.message || JSON.stringify(msg.error));
          return extractToolResult(msg);
        });
      });
    })['catch'](function (err) {
      if (err && err.auth) {
        if (_authRetried) { promptToken(); throw err; }
        var old = SESS.token || '';
        invalidateToken();
        return discoverToken(true).then(function (nt) {
          if (nt && nt !== old) return mcpTool(tool, args, tk, true);
          promptToken();
          throw err;
        }, function () { promptToken(); throw err; });
      }
      throw err;
    });
  }

  function mcpCall(tool, args, tk) {
    return mcpTool(tool, args, tk)['catch'](function (err) {
      if (err && err.http && SESS.sid) { SESS.sid = null; return mcpTool(tool, args, tk); }
      throw err;
    });
  }

  var prompting = false;

  function promptToken() {
    if (prompting) return;
    if (!document.body) return;
    prompting = true;
    try {
      var old = document.querySelector('[data-dsui-token]');
      if (old && old.parentNode) old.parentNode.removeChild(old);
      var box = document.createElement('div');
      box.setAttribute('data-dsui-token', '1');
      box.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483000;'
        + 'background:rgba(0,0,0,.66);display:flex;align-items:center;justify-content:center;padding:24px;'
        + 'font:14px/1.6 system-ui,"Microsoft YaHei",sans-serif';
      box.innerHTML = '<div style="width:min(580px,100%);background:#1b1b21;color:#eee;border:1px solid #33333d;'
        + 'border-radius:14px;padding:20px 22px;box-shadow:0 20px 60px rgba(0,0,0,.55)">'
        + '<div style="font-size:16px;font-weight:600;margin-bottom:6px">需要填写网关 Token</div>'
        + '<div style="color:#a6a6b0;font-size:13px;margin-bottom:12px">本机 DsPlayer 网关拒绝了请求。请在本机浏览器打开 '
        + '<b style="color:#8ab4ff;word-break:break-all">' + gwOrigin() + '/</b>，点「复制 Claude 配置 JSON」，'
        + '把其中 <b style="color:#8ab4ff">mcp_</b> 开头的一串粘贴到下面。</div>'
        + '<input data-tok spellcheck="false" placeholder="mcp_xxxxxxxxxxxxxxxx" style="width:100%;box-sizing:border-box;'
        + 'padding:10px 12px;border-radius:9px;border:1px solid #3a3a46;background:#111116;color:#eee;'
        + 'font:13px/1.4 ui-monospace,Consolas,monospace;outline:none">'
        + '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:14px">'
        + '<button data-cancel style="padding:8px 16px;border-radius:9px;border:1px solid #3a3a46;background:transparent;'
        + 'color:#c8c8d0;cursor:pointer">取消</button>'
        + '<button data-ok style="padding:8px 18px;border-radius:9px;border:0;background:#3b6ef5;color:#fff;'
        + 'cursor:pointer">保存并重试</button></div></div>';
      document.body.appendChild(box);

      var inp = box.querySelector('[data-tok]');
      function close() {
        prompting = false;
        try { box.parentNode.removeChild(box); } catch (e) {}
      }
      box.querySelector('[data-cancel]').onclick = close;
      box.querySelector('[data-ok]').onclick = function () {
        var m = /mcp_[A-Za-z0-9_\-]+/.exec(String(inp.value || '').trim());
        if (!m) { inp.style.borderColor = '#e0564f'; try { inp.focus(); } catch (e) {} return; }
        try { localStorage.setItem(TOKEN_KEY, m[0]); } catch (e) {}
        TOKEN_CACHE = m[0];
        try { location.reload(); } catch (e) { close(); }
      };
      setTimeout(function () { try { inp.focus(); } catch (e) {} }, 60);
    } catch (e) { prompting = false; }
  }

  function b64utf8(s) {
    try { return btoa(unescape(encodeURIComponent(s))); }
    catch (e) { try { return btoa(s); } catch (e2) { return ''; } }
  }

  function filtersFromMcp(m) {
    var out = {};
    try {
      var m0 = (m && m.siteKey && m.filters && typeof m.filters === 'object') ? m.filters : (m || {});
      for (var tid in m0) {
        var gs = m0[tid];
        if (!gs || !gs.length) continue;
        var arr = [];
        for (var i = 0; i < gs.length; i++) {
          var g = gs[i];
          if (!g || !g.key) continue;
          var vals = [];
          var ops = g.options || [];
          for (var j = 0; j < ops.length; j++) {
            var o = ops[j];
            if (!o) continue;
            vals.push({ n: String(o.label != null ? o.label : (o.value == null ? '' : o.value)),
                        v: String(o.value == null ? '' : o.value) });
          }
          arr.push({ key: String(g.key), name: String(g.name || g.key), value: vals });
        }
        if (arr.length) out[String(tid)] = arr;
      }
    } catch (e) {}
    return out;
  }

  function mcpCategory(siteKey, tid, pg, filtersJson) {
    var args = { siteKey: siteKey, tid: String(tid), pg: String(pg) };
    if (filtersJson) {
      try {
        var f = (typeof filtersJson === 'string') ? JSON.parse(filtersJson) : filtersJson;
        if (f && typeof f === 'object') args.ext = b64utf8(JSON.stringify(f));
      } catch (e) {}
    }
    return mcpCall('site_category', args)['catch'](function (e) {
      if (!('ext' in args)) throw e;
      delete args.ext;
      return mcpCall('site_category', args);
    });
  }

  var PIC_CACHE = {};

  function mcpPic(siteKey, vodId) {
    return mcpCall('site_detail', { siteKey: siteKey, vodId: String(vodId) })
      .then(function (d) { return (d && d.vod_pic) || ''; });
  }

  function enrichPics(siteKey, items) {
    if (!PIC_FILL || !items || !items.length) return Promise.resolve();
    var todo = [], i;
    for (i = 0; i < items.length && todo.length < PIC_CAP; i++) {
      var it = items[i];
      if (!it || it.vod_pic || !it.vod_id) continue;
      var ck = siteKey + '|' + it.vod_id;
      if (PIC_CACHE[ck]) { it.vod_pic = PIC_CACHE[ck]; continue; }
      todo.push({ it: it, ck: ck });
    }
    if (!todo.length) return Promise.resolve();

    return new Promise(function (resolve) {
      var idx = 0, active = 0, settled = false;
      var timer = setTimeout(function () { settled = true; resolve(); }, PIC_BUDGET);
      function next() {
        if (settled) return;
        if (idx >= todo.length && active === 0) { settled = true; clearTimeout(timer); resolve(); return; }
        while (active < PIC_CONC && idx < todo.length) {
          (function (job) {
            active++;
            Promise.resolve().then(function () { return mcpPic(siteKey, job.it.vod_id); })
              .then(function (p) {
                if (p) { job.it.vod_pic = p; PIC_CACHE[job.ck] = p; }
                active--; next();
              }, function () { active--; next(); });
          })(todo[idx++]);
        }
      }
      next();
    });
  }

  function listSites(id) {
    return mcpCall('list_sites', {}).then(function (ls) {
      var sites = (ls && ls.sites) || [];
      var res = { host: [], py: [], js: [], cj: [], xl: [], selfKey: 'local_web_ui' };
      var TYPE2TAB = {
        'drpys': 'host', 'drpys-local': 'host',
        'drpy3-local': 'cj', 'dr2-online': 'cj', 'qjs-online': 'cj',
        'py-local': 'py', 'py-online': 'py', 'php-local': 'xl', 'php-online': 'xl'
      };
      sites.forEach(function (s) {
        if (!s || !s.key) return;
        var t = String(s.sourceType || '');
        if (/^web/i.test(t)) return;
        var item = { key: s.key, name: s.name, sourceType: s.sourceType };
        var m = String(s.name || '').match(/\((ds|dr\d*|php|py|hipy|js)\)\s*$/i);
        var tab;
        if (m) {
          var suf = m[1].toLowerCase();
          tab = suf === 'ds' ? 'host'
              : (suf === 'php' ? 'xl' : ((suf === 'py' || suf === 'hipy') ? 'py' : 'cj'));
          if (suf === 'js') tab = /cat/i.test(String(s.name || '')) ? 'js' : '';
        } else {
          tab = TYPE2TAB[t] || '';
        }
        if (tab && res[tab]) res[tab].push(item);
      });
      return res;
    }).then(function (res) { done(id, res); }, function (e) { fail(id, e); });
  }

  function getHome(sourceType, siteKey, id) {
    return mcpCall('site_home', { siteKey: siteKey }).then(function (h) {
      var list = (h && h.list) || [];
      var f0 = filtersFromMcp(h && h.filters);
      var hasF = false, k;
      for (k in f0) { hasF = true; break; }
      var fp = hasF ? Promise.resolve(f0)
        : mcpCall('site_filters', { siteKey: siteKey })
            .then(function (f) { return filtersFromMcp(f); }, function () { return {}; });
      return Promise.all([enrichPics(siteKey, list), fp]).then(function (r) {
        done(id, { 'class': (h && h.classes) || [], filters: r[1] || {}, list: list });
      });
    })['catch'](function (e) { fail(id, e); });
  }

  function getCategory(sourceType, siteKey, tid, pg, filtersJson, id) {
    return mcpCategory(siteKey, tid, pg, filtersJson).then(function (c) {
      var list = (c && c.list) || [];
      var p = Number((c && c.page) || pg) || Number(pg) || 1;
      var hasNext = !!(c && c.hasNext);
      return enrichPics(siteKey, list).then(function () {
        done(id, { list: list, pagecount: hasNext ? p + 1 : p, hasNext: hasNext });
      });
    })['catch'](function (e) { fail(id, e); });
  }

  function search(sourceType, siteKey, kw, id) {
    return mcpCall('site_search', { siteKey: siteKey, wd: String(kw), pg: '1' }).then(function (s) {
      var list = (s && s.list) || [];
      return enrichPics(siteKey, list).then(function () {
        done(id, { list: list, pagecount: 1, hasNext: false });
      });
    })['catch'](function (e) { fail(id, e); });
  }

  function detailOf(sourceType, siteKey, vodId, id) {
    return mcpCall('site_detail', { siteKey: siteKey, vodId: String(vodId) }).then(function (d) {
      done(id, d || {});
    })['catch'](function (e) { fail(id, e); });
  }

  var NB = {
    getAllTabsSourcesAsync: function (id) { listSites(id); },
    getLastSelectedSiteAsync: function (id) {
      var o = {};
      try { o = JSON.parse(localStorage.getItem('dsui_last_site') || '{}') || {}; } catch (e) {}
      done(id, o);
    },
    saveLastSelectedSite: function (type, key, name, id) {
      try { localStorage.setItem('dsui_last_site', JSON.stringify({ type: type, key: key, name: name })); } catch (e) {}
      done(id, {});
    },
    setHostHomeSite: function (key, id) {
      try { localStorage.setItem('dsui_host_home', String(key || '')); } catch (e) {}
      done(id, {});
    },
    getHomeContentAsync: function (sourceType, siteKey, id) { getHome(sourceType, siteKey, id); },
    getCategoryContentAsync: function (sourceType, siteKey, tid, pg, filtersJson, id) {
      getCategory(sourceType, siteKey, tid, pg, filtersJson, id);
    },
    searchContentAsync: function (sourceType, siteKey, kw, id) { search(sourceType, siteKey, kw, id); },
    getDetailAsync: function (sourceType, siteKey, vodId, id) { detailOf(sourceType, siteKey, vodId, id); },
    openDetail: function (sourceType, siteKey, vodId, vodName, vodPic) {
      var msg = {
        t: 'dsui:openDetail', sourceType: sourceType, siteKey: siteKey,
        vodId: vodId, vodName: vodName, vodPic: vodPic
      };
      if (window.parent && window.parent !== window) {
        try { window.parent.postMessage(msg, '*'); return; } catch (e) {}
      }
      var b = fm();
      if (b && typeof b.vod === 'function') {
        try { b.vod(siteKey, vodId, vodName, vodPic); } catch (e) {}
      }
    },
    exitSourceUi: function () {
      if (window.parent && window.parent !== window) {
        try { window.parent.postMessage({ t: 'dsui:exit' }, '*'); } catch (e) {}
      } else {
        var b = fm();
        if (b && typeof b.back === 'function') { try { b.back(); } catch (e) {} }
      }
    },
    saveUserPreference: function (themeKey, layout, baseColor, spotsJson, running) {
      try {
        if (themeKey) localStorage.setItem('dsui_theme', String(themeKey));
        if (layout) localStorage.setItem('dsui_layout', String(layout));
      } catch (e) {}
    },
    setStatusBarTheme: function () {}
  };

  var MusicUI = (function () {
    var KW = /[音]|音乐|music|歌曲|歌手|电台|广播|有声|听书|评书|相声/i;
    var PAGE = '音乐播放器.html';

    function likely(siteKey) { return KW.test(String(siteKey || '')); }

    function uiPlayerOn() {
      try { return localStorage.getItem('dsui_uiplayer') !== '0'; } catch (e) { return true; }
    }

    function open(ctx) {
      if (!uiPlayerOn() || typeof window.__dsuiMpOpen !== 'function') {
        if (MusicUI._fallback) MusicUI._fallback(ctx.sourceType, ctx.siteKey, ctx.vodId, ctx.vodName, ctx.vodPic);
        return;
      }
      window.__dsuiMpOpen(PAGE +
        '?mode=full&site=' + encodeURIComponent(ctx.siteKey || '') +
        '&type=' + encodeURIComponent(ctx.sourceType || '') +
        '&id=' + encodeURIComponent(ctx.vodId || '') +
        '&name=' + encodeURIComponent(ctx.vodName || '') +
        '&pic=' + encodeURIComponent(ctx.vodPic || '') +
        '&back=' + encodeURIComponent(String(window.location.href || '')));
    }

    return { likely: likely, open: open, uiPlayerOn: uiPlayerOn };
  })();

  var __nativeOpenDetail = NB.openDetail;
  MusicUI._fallback = __nativeOpenDetail;
  NB.openDetail = function (sourceType, siteKey, vodId, vodName, vodPic) {
    if (MusicUI.likely(siteKey)) {
      MusicUI.open({ sourceType: sourceType, siteKey: siteKey, vodId: vodId, vodName: vodName, vodPic: vodPic });
      return;
    }
    __nativeOpenDetail(sourceType, siteKey, vodId, vodName, vodPic);
  };

  NB.exitSourceUI = NB.exitSourceUi;

  NB.mcpCallAsync = function (tool, args, id) {
    mcpCall(tool, args).then(function (r) { done(id, r); }, function (e) { fail(id, e); });
  };

  (function () {
    var PAGE = '音乐播放器.html';

    function isSelf() {
      var href = '';
      try { href = decodeURIComponent(String(window.location.href || '')); } catch (e) { href = String(window.location.href || ''); }
      return href.indexOf(PAGE) >= 0;
    }
    function frameEl() { return document.getElementById('dsui-mp-frame'); }
    function styleFrame(f, mode) {
      f.style.cssText = mode === 'full'
        ? 'position:fixed;inset:0;width:100%;height:100%;border:0;z-index:2147483000;background:transparent;'
        : 'position:fixed;z-index:2147482000;border:0;background:transparent;'
          + 'left:max(10px,env(safe-area-inset-left,0px));right:max(10px,env(safe-area-inset-right,0px));'
          + 'bottom:calc(10px + env(safe-area-inset-bottom,0px));height:64px;width:auto;';
    }
    function createFrame(mode, src) {
      var old = frameEl();
      if (old && old.parentNode) old.parentNode.removeChild(old);
      var f = document.createElement('iframe');
      f.id = 'dsui-mp-frame';
      f.setAttribute('allow', 'autoplay');
      f.src = src;
      styleFrame(f, mode);
      document.body.appendChild(f);
      return f;
    }
    function setMode(mode) {
      var f = frameEl();
      if (!f) return;
      styleFrame(f, mode);
      try { f.contentWindow.postMessage({ t: 'dsui-mp-mode', mode: mode }, '*'); } catch (e) {}
    }
    window.addEventListener('message', function (ev) {
      var d = ev && ev.data;
      if (!d || !d.t) return;
      if (d.t === 'dsui-mp-minimize') setMode('mini');
      else if (d.t === 'dsui-mp-expand') setMode('full');
      else if (d.t === 'dsui-mp-close') {
        var f = frameEl();
        if (f && f.parentNode) f.parentNode.removeChild(f);
        try { localStorage.removeItem('dsui_mp_state'); } catch (e) {}
      }
    });
    window.__dsuiMpOpen = function (src) {
      if (isSelf()) return;
      createFrame('full', src);
    };
    function inject() {
      if (isSelf() || frameEl()) return;
      var saved = null;
      try { saved = localStorage.getItem('dsui_mp_state'); } catch (e) {}
      if (!saved) return;
      createFrame('mini', PAGE + '?mode=mini&t=' + Date.now());
    }
    function boot() { setTimeout(inject, 400); }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
    window.addEventListener('pageshow', function (e) { if (e && e.persisted) inject(); });
  })();

  window.NativeBridge = NB;
})();
