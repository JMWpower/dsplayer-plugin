(function () {
  'use strict';

  // 壳子推送桥（移植自旧阅读页 lr-tvbox.js，适配本地书架数据源）。
  // 壳子向页面注入 window.fm / window.ds，推送走 vodInline / openVod（TVBox vod spec）。
  // 章节哨兵 lr://b/<key>/<index>，key = 'b' + shelfId.toString(36)，解析时无需查表。

  var PUSH_EVENT = 'lr-push-book';
  var SENTINEL_RE = /^lr:\/\/b\/([a-z0-9]+)\/(\d+)$/i;

  var isFrame = false;
  try { isFrame = !!(window.parent && window.parent !== window); } catch (e) { isFrame = true; }

  function nativeBridge() { return window.fm || window.ds || null; }

  function canPush() {
    var f = nativeBridge();
    return !!(f && (typeof f.vodInline === 'function' || typeof f.openVod === 'function' || typeof f.play === 'function'));
  }

  function queryShellFlag() {
    try {
      var v = new URLSearchParams(window.location.search || '').get('lr_shell');
      return v === '1' || v === 'on' || v === 'true';
    } catch (e) {
      return false;
    }
  }

  function baseUrl() {
    try {
      if (/^https?:/i.test(window.location.protocol)) return window.location.origin;
    } catch (e) { }
    return '';
  }

  function message(e) { return (e && e.message) ? e.message : String(e || '未知错误'); }

  function toast(text) {
    try {
      var el = document.getElementById('lr-shell-toast');
      if (!el) {
        el = document.createElement('div');
        el.id = 'lr-shell-toast';
        el.style.cssText = [
          'position:fixed', 'left:50%', 'bottom:calc(28px + env(safe-area-inset-bottom,0px))',
          'transform:translateX(-50%) translateY(12px)', 'background:rgba(20,26,22,.94)', 'color:#fff',
          'font:13.5px/1.55 -apple-system,"PingFang SC","Microsoft YaHei",system-ui,sans-serif',
          'padding:10px 18px', 'border-radius:12px', 'max-width:86vw', 'text-align:center',
          'z-index:2147483000', 'opacity:0', 'transition:opacity .18s ease,transform .18s ease',
          'pointer-events:none', 'box-shadow:0 12px 30px rgba(0,0,0,.28)'
        ].join(';') + ';';
        document.body.appendChild(el);
      }
      el.textContent = text;
      requestAnimationFrame(function () {
        el.style.opacity = '1';
        el.style.transform = 'translateX(-50%) translateY(0)';
      });
      clearTimeout(toast.timer);
      toast.timer = setTimeout(function () {
        el.style.opacity = '0';
        el.style.transform = 'translateX(-50%) translateY(12px)';
      }, 2600);
    } catch (e) { }
  }

  async function rawReq(url, opt) {
    opt = opt || {};
    var res = await fetch(url, {
      method: opt.method || 'GET',
      headers: opt.headers || {},
      body: opt.body != null ? JSON.stringify(opt.body) : undefined
    });
    var text = await res.text();
    var parsed = text;
    try { parsed = JSON.parse(text); } catch (e) { }
    return { ok: res.ok, status: res.status, body: parsed };
  }

  async function api(path, opt) {
    opt = opt || {};
    var r = await rawReq(baseUrl() + path, {
      method: opt.method || 'GET',
      headers: { 'Accept': 'application/json' },
      timeout: opt.timeout || 30
    });
    if (!r || !r.ok) {
      var text = (r && r.body && (r.body.message || r.body.msg)) || ('HTTP ' + ((r && r.status) || '?'));
      throw new Error(text);
    }
    return r.body;
  }

  function cleanName(name) { return String(name || '').replace(/[$#]/g, ' ').trim(); }

  function toText(text) {
    return String(text || '').split(/\r?\n+/)
      .map(function (line) { return line.trim(); })
      .filter(function (line) { return line !== ''; })
      .map(function (line) { return '\u3000\u3000' + line; })
      .join('\n');
  }

  function novelPayload(title, content) {
    return 'novel' + '://' + JSON.stringify({ title: title || '正文', content: content || '' });
  }

  function keyOf(id) { return 'b' + Number(id).toString(36); }
  function idOfKey(key) { return parseInt(String(key).slice(1), 36) || 0; }
  function sentinel(key, index) { return 'lr' + '://b/' + key + '/' + index; }

  function coverOf(book, base) {
    if (book.coverKey) return base + '/api/covers/' + encodeURIComponent(book.coverKey);
    var url = book.coverUrl || '';
    if (!url) return '';
    if (url.indexOf('data:') === 0) return url;
    if (!/^https?:\/\//i.test(url)) return base + (url.charAt(0) === '/' ? url : '/' + url);
    try {
      var f = nativeBridge();
      if (f && typeof f.res === 'function') return f.res(url);
    } catch (e) { }
    return url;
  }

  var state = { id: 0, chapters: [] };

  function buildSpec(book, chapters, startIndex) {
    var base = baseUrl();
    var key = keyOf(book.id);
    var eps = chapters.map(function (c, i) {
      return {
        name: cleanName(c && c.title) || ('第 ' + (i + 1) + ' 章'),
        url: sentinel(key, i),
        resolve: true,
        format: 'novel'
      };
    });
    var spec = {
      vod_id: 'lr_' + key,
      vod_name: book.name || '阅读',
      vod_pic: coverOf(book, base),
      vod_remarks: '共 ' + eps.length + ' 章',
      vod_type: '本地书',
      type_name: '本地书',
      vod_play_from: '阅读',
      mark: eps.length ? eps[startIndex].name : '',
      markIndex: startIndex,
      vod_play_index: startIndex,
      vod_content: (book.author ? '作者：' + book.author + '\n' : '') +
        '共 ' + eps.length + ' 章（目录已全部推送，点章按需加载正文）',
      episodes: eps,
      format: 'novel'
    };
    if (eps.length <= 500) {
      spec.vod_play_url = eps.map(function (e) { return e.name + '$' + e.url; }).join('#');
    }
    return spec;
  }

  async function deliver(spec, id, chapters, startIndex) {
    var f = nativeBridge();
    if (f && typeof f.vodInline === 'function') {
      await f.vodInline(spec);
      return 'native';
    }
    if (f && typeof f.openVod === 'function') {
      await f.openVod(spec);
      return 'native';
    }
    if (isFrame) {
      window.parent.postMessage({
        __lrTvboxPush: spec,
        book: { key: keyOf(id), id: id }
      }, '*');
      return 'parent';
    }
    if (f && typeof f.play === 'function') {
      var chapter = chapters[startIndex];
      if (!chapter) throw new Error('章节不存在');
      var data = await api('/api/shelf/' + id + '/read/' + startIndex, { timeout: 60 });
      await f.play(
        novelPayload(data.title || chapter.title, toText(data.text)),
        data.title || chapter.title,
        { pic: spec.vod_pic }
      );
      return 'chapter';
    }
    throw new Error('壳子不支持整本推送（缺 vodInline / openVod）');
  }

  async function pushBook(book, index) {
    if (!book || !book.id) throw new Error('缺少书籍信息');
    var toc = await api('/api/shelf/' + book.id + '/read', { timeout: 60 });
    var chapters = toc && Array.isArray(toc.chapters) ? toc.chapters : [];
    if (chapters.length === 0) throw new Error('目录还是空的，稍后再试');
    state = { id: book.id, chapters: chapters };
    var startIndex = Math.max(0, Math.min(index || 0, chapters.length - 1));
    var spec = buildSpec(book, chapters, startIndex);
    var way = await deliver(spec, book.id, chapters, startIndex);
    return { count: chapters.length, way: way, key: keyOf(book.id) };
  }

  async function resolveSentinel(url) {
    var m = SENTINEL_RE.exec(String(url || '').trim());
    if (!m) return '';
    var id = idOfKey(m[1]);
    var index = parseInt(m[2], 10) || 0;
    if (!id) return '';
    try {
      var data = await api('/api/shelf/' + id + '/read/' + index, { timeout: 60 });
      return novelPayload(data.title || ('第 ' + (index + 1) + ' 章'), toText(data.text));
    } catch (e) {
      try { console.warn('[lr-tvbox] 取章失败：' + message(e)); } catch (_) { }
      return '';
    }
  }

  function installResolver() {
    try {
      window.DL = window.DL || {};
      window.DL.resolveEpisode = resolveSentinel;
      window.__fmWebHomeInlineResolver = function (ep) {
        return resolveSentinel(typeof ep === 'string' ? ep : ((ep && ep.url) || ''));
      };
      var f = nativeBridge();
      if (f && typeof f.resolveEpisode !== 'function') {
        try { f.resolveEpisode = resolveSentinel; } catch (e) { }
      }
    } catch (e) { }
  }

  function onPushRequest(payload) {
    var book = (payload && payload.book) || null;
    if (!book || typeof book !== 'object') return;
    var index = parseInt(payload && payload.index, 10);
    if (!isFinite(index) || index < 0) index = 0;
    pushBook(book, index).then(function (built) {
      toast('已推送整本目录（' + built.count + ' 章）到阅读器');
    }).catch(function (e) {
      toast('推送失败：' + message(e));
    });
  }

  function hookPush() {
    try {
      window.addEventListener(PUSH_EVENT, function (ev) {
        onPushRequest(ev && ev.detail);
      });
    } catch (e) { }
  }

  window.__lrCanPush = canPush;

  hookPush();
  if (canPush() || isFrame || queryShellFlag()) installResolver();
})();
