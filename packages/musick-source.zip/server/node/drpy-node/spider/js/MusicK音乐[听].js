/*
@header({
  searchable: 1,
  filterable: 1,
  quickSearch: 0,
  title: 'MusicK音乐',
  author: 'JMWpower',
  '类型': '音乐',
  version: '1.1.1',
  lang: 'ds',
})
*/

var API_BASE = 'http://127.0.0.1:5566';

var SOURCES = [
    ['kw', '酷我'],
    ['kg', '酷狗'],
    ['tx', 'QQ音乐'],
    ['wy', '网易云'],
    ['mg', '咪咕'],
    ['qs', '汽水'],
];
var SOURCE_NAME = {
    kw: '酷我', kg: '酷狗', tx: 'QQ音乐', wy: '网易云', mg: '咪咕', qs: '汽水',
};
var SORT_MAP = {
    kw: [['hot', '最热'], ['new', '最新']],
    kg: [['5', '推荐'], ['6', '最热'], ['7', '最新']],
    tx: [['5', '最热'], ['2', '最新']],
    wy: [['hot', '最热']],
    mg: [['15127315', '推荐']],
    qs: [['recommend', '推荐'], ['mode', '模式']],
};
var SEARCH_PAGE_SIZE = 10;
var SEARCH_MAX = 60;

function srcName(id) {
    return SOURCE_NAME[id] || id;
}

function fmtSinger(singer) {
    if (!singer) return '';
    if (typeof singer === 'string') return singer;
    if (Array.isArray(singer)) return singer.map(function (s) { return (s && s.name) || s; }).join('、');
    return String(singer);
}

function fmtSong(song) {
    var img = song.img || song.pic || song.cover || song.picUrl || '';
    if (typeof img === 'object') img = img.url || img.small || img.medium || img.large || '';
    return {
        src: song.source || '',
        mid: String(song.songmid || song.song_id || song.musicId || song.id || song.mid || song.cid || ''),
        hash: song.hash || '',
        name: song.name || song.title || song.songname || '未知歌曲',
        singer: fmtSinger(song.singer),
        interval: song.interval || '',
        img: img,
    };
}

function songToken(s) {
    return 'S__' + encodeURIComponent(JSON.stringify([s.src, s.mid, s.hash, s.name, s.interval, s.img]));
}

function parseSongToken(input) {
    var raw = String(input || '');
    if (raw.indexOf('S__') !== 0) return null;
    try {
        var arr = JSON.parse(decodeURIComponent(raw.slice(3)));
        return { src: arr[0], mid: String(arr[1] || ''), hash: arr[2] || '', name: arr[3] || '', interval: arr[4] || '', img: arr[5] || '' };
    } catch (e) { return null; }
}

function cleanTitle(t) {
    return String(t || '').replace(/[$#]/g, ' ').trim() || '未知';
}

async function getJson(api) {
    var html = await request(api);
    var res = JSON.parse(html);
    if (res && res.code === 200 && res.data) return res.data;
    return null;
}

function songEntry(s) {
    var title = cleanTitle(s.name) + (s.singer ? ' - ' + cleanTitle(s.singer) : '');
    return title + '$' + songToken(s);
}

async function resolveMusicUrl(s) {
    if (!s.mid) return 'toast://缺少歌曲ID';
    var api = API_BASE + '/api/music/music-url?source=' + encodeURIComponent(s.src) +
        '&songmid=' + encodeURIComponent(s.mid) + '&resolve=true';
    if (s.hash) api += '&hash=' + encodeURIComponent(s.hash);
    if (s.name) api += '&name=' + encodeURIComponent(s.name);
    if (s.interval) api += '&interval=' + encodeURIComponent(s.interval);
    var res = JSON.parse(await request(api));
    var urls = [];
    if (res && res.code === 200 && res.data) urls = Array.isArray(res.data) ? res.data : [res.data];
    var picked = [];
    for (var i = 0; i < urls.length; i++) {
        var e = urls[i];
        if (!e) continue;
        var u = '';
        var label = '';
        if (typeof e === 'string') { u = e; }
        else if (typeof e === 'object') {
            u = e.url || e.musicUrl || e.src || '';
            var parts = [];
            if (e.type) parts.push(e.type);
            if (e.sourceName && e.sourceName !== '内置API') parts.push(e.sourceName);
            label = parts.join('·') || '';
        }
        if (typeof u === 'object') u = u.url || u.src || '';
        if (u && typeof u === 'string') {
            if (u.indexOf('/') === 0) u = API_BASE + u;
            if (u.indexOf('http') === 0) {
                if (!label) label = '线路' + (picked.length + 1);
                picked.push({ url: u, label: label });
            }
        }
    }
    if (!picked.length) return 'toast://' + ((res && res.error) || '获取播放链接失败，请检查音源脚本');
    var rank = function (u) {
        if (/\.mp3(\?|$)/i.test(u)) return 0;
        if (/\.(m4a|flac|wav|ogg|wma|aac)(\?|$)/i.test(u)) return 1;
        return 2;
    };
    picked.sort(function (a, b) { return rank(a.url) - rank(b.url); });
    var arr = [];
    for (var j = 0; j < picked.length; j++) {
        arr.push(picked[j].label, picked[j].url + '#isMusic=true#');
    }
    return arr;
}

async function fetchLyric(s) {
    if (!s.mid) return '';
    try {
        var api = API_BASE + '/api/music/lyric?source=' + encodeURIComponent(s.src) +
            '&songmid=' + encodeURIComponent(s.mid);
        if (s.hash) api += '&hash=' + encodeURIComponent(s.hash);
        if (s.name) api += '&name=' + encodeURIComponent(s.name);
        if (s.interval) api += '&interval=' + encodeURIComponent(s.interval);
        var res = JSON.parse(await request(api));
        var d = res && res.data;
        var lrc = '';
        if (typeof d === 'string') lrc = d;
        else if (d) lrc = d.lyric || d.lrc || d.lrcContent || '';
        if (typeof lrc !== 'string') lrc = '';
        return lrc.replace(/<br\s*\/?>/gi, '\n').trim();
    } catch (e) { return ''; }
}

var rule = {
    title: 'MusicK音乐',
    类型: '音乐',
    host: API_BASE,
    homeUrl: '',
    searchUrl: '',
    url: '',
    headers: { 'User-Agent': 'MOBILE_UA' },
    timeout: 15000,
    multi: 1,
    searchable: 1,
    filterable: 1,
    play_parse: true,

    class_parse: async function () {
        var classList = [];
        var filters = {};
        for (var i = 0; i < SOURCES.length; i++) {
            var id = SOURCES[i][0];
            classList.push({ type_id: id, type_name: SOURCES[i][1] });
            var sorts = (SORT_MAP[id] || []).map(function (s) { return { n: s[1], v: s[0] }; });
            var fl = [{ key: 'type', name: '内容', value: [{ n: '排行榜', v: 'bang' }, { n: '歌单', v: 'gedan' }] }];
            if (sorts.length) fl.push({ key: 'sort', name: '排序', value: sorts });
            filters[id] = fl;
        }
        return { class: classList, filters: filters };
    },

    一级: async function () {
        var cate = this.MY_CATE || 'wy';
        var page = parseInt(this.MY_PAGE) || 1;
        var ext = this.extend || arguments[3] || {};
        if (typeof ext === 'string') { try { ext = JSON.parse(ext); } catch (e) { ext = {}; } }
        ext = ext || {};
        var type = ext.type || 'bang';
        var d = [];
        try {
            if (type === 'gedan') {
                var sorts = SORT_MAP[cate] || [];
                var sort = ext.sort || (sorts.length ? sorts[0][0] : 'hot');
                var data = await getJson(API_BASE + '/api/music/songlist?source=' + encodeURIComponent(cate) +
                    '&sortId=' + encodeURIComponent(sort) + '&tagId=&page=' + page);
                var list = (data && data.list) || [];
                for (var i = 0; i < list.length; i++) {
                    var it = list[i] || {};
                    d.push({
                        title: cleanTitle(it.name || '歌单'),
                        img: it.img || '',
                        desc: [it.author || '', it.play_count ? it.play_count + '次播放' : '', it.total ? it.total + '首' : ''].filter(Boolean).join(' · '),
                        url: 'L__' + cate + '__' + String(it.id || ''),
                    });
                }
            } else {
                if (page > 1) return setResult([]);
                var data2 = await getJson(API_BASE + '/api/music/leaderboard?source=' + encodeURIComponent(cate));
                var list2 = (data2 && data2.list) || [];
                for (var j = 0; j < list2.length; j++) {
                    var b = list2[j] || {};
                    var raw = (b.bangid != null && b.bangid !== '') ? String(b.bangid)
                        : String(b.id || '').replace(/^[a-z]{2}__/, '');
                    if (!raw) continue;
                    d.push({
                        title: cleanTitle(b.name || '排行榜'),
                        img: b.img || b.pic || '',
                        desc: b.desc || '排行榜',
                        url: 'B__' + cate + '__' + raw,
                    });
                }
            }
        } catch (e) { }
        return setResult(d);
    },

    推荐: async function () {
        var d = [];
        var pool = SOURCES.slice();
        for (var i = pool.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var t = pool[i]; pool[i] = pool[j]; pool[j] = t;
        }
        var picks = pool.slice(0, 3);
        var results = await Promise.all(picks.map(function (p) {
            var cate = p[0];
            var sorts = SORT_MAP[cate] || [];
            var sort = sorts.length ? sorts[Math.floor(Math.random() * sorts.length)][0] : 'hot';
            var pg = 1 + Math.floor(Math.random() * 3);
            return getJson(API_BASE + '/api/music/songlist?source=' + encodeURIComponent(cate) +
                '&sortId=' + encodeURIComponent(sort) + '&tagId=&page=' + pg)
                .then(function (data) {
                    var list = (data && data.list) || [];
                    var out = [];
                    for (var i = 0; i < list.length; i++) {
                        var it = list[i] || {};
                        if (!it.id) continue;
                        out.push({
                            title: cleanTitle(it.name || '歌单'),
                            img: it.img || '',
                            desc: [it.author || '', it.total ? it.total + '首' : ''].filter(Boolean).join(' · '),
                            url: 'L__' + cate + '__' + String(it.id),
                        });
                    }
                    return out;
                })
                .catch(function () { return []; });
        }));
        var idx = 0;
        while (d.length < 24) {
            var added = false;
            for (var r = 0; r < results.length; r++) {
                var it2 = results[r][idx];
                if (it2) { added = true; d.push(it2); }
            }
            if (!added) break;
            idx++;
        }
        return setResult(d);
    },

    搜索: async function () {
        var KEY = this.KEY || '';
        var page = parseInt(this.MY_PAGE) || 1;
        var d = [];
        var kw = (KEY || '').trim();
        if (!kw || page > 3) return setResult(d);
        var tasks = SOURCES.map(function (p) {
            return getJson(API_BASE + '/api/music/search?source=' + encodeURIComponent(p[0]) +
                '&keyword=' + encodeURIComponent(kw) + '&page=' + page + '&limit=' + SEARCH_PAGE_SIZE)
                .then(function (data) {
                    var list = (data && data.list) || [];
                    var out = [];
                    for (var i = 0; i < list.length; i++) {
                        var s = fmtSong(list[i]);
                        if (!s.mid) continue;
                        if (!s.src) s.src = p[0];
                        out.push(s);
                    }
                    return out;
                })
                .catch(function () { return []; });
        });
        var results = await Promise.all(tasks);
        var idx = 0;
        while (d.length < SEARCH_MAX) {
            var added = false;
            for (var r = 0; r < results.length; r++) {
                var s2 = results[r][idx];
                if (s2) {
                    added = true;
                    d.push({
                        title: cleanTitle(s2.name),
                        img: s2.img,
                        desc: [s2.singer, s2.interval, srcName(s2.src)].filter(Boolean).join(' · '),
                        url: songToken(s2),
                    });
                }
            }
            if (!added) break;
            idx++;
        }
        return setResult(d);
    },

    二级: async function () {
        var id = String(this.orId || this.vid || this.input || '');
        var m = id.match(/^([BL])__([a-z]{2})__([\s\S]+)$/);
        var title = '未知', pic = '', from = 'MusicK', playUrl = '', remarks = '';
        if (m) {
            var kind = m[1], src = m[2], sub = m[3];
            var isBoard = kind === 'B';
            var api = isBoard
                ? API_BASE + '/api/music/leaderboard/detail?source=' + encodeURIComponent(src) + '&bangid=' + encodeURIComponent(sub) + '&page=1'
                : API_BASE + '/api/music/songlist/detail?source=' + encodeURIComponent(src) + '&id=' + encodeURIComponent(sub) + '&page=1';
            var list = [];
            try {
                var data = await getJson(api);
                list = (data && data.list) || [];
            } catch (e) { }
            var entries = [];
            for (var i = 0; i < list.length; i++) {
                var s = fmtSong(list[i]);
                if (!s.mid) continue;
                if (!pic) pic = s.img;
                if (!title) title = s.name;
                entries.push(songEntry(s));
            }
            from = srcName(src) + '·' + (isBoard ? '排行榜' : '歌单');
            title = from;
            remarks = entries.length ? '共' + entries.length + '首' : '暂无曲目';
            playUrl = entries.join('#');
        } else {
            var s2 = parseSongToken(id);
            if (s2 && s2.mid) {
                title = cleanTitle(s2.name);
                pic = s2.img;
                from = srcName(s2.src) || 'MusicK';
                remarks = s2.singer || '';
                playUrl = songEntry(s2);
            }
        }
        return {
            vod_name: title,
            vod_pic: pic,
            vod_remarks: remarks,
            vod_content: 'MusicK音乐 · 本地音乐服务(' + API_BASE.replace('http://', '') + ')',
            vod_play_from: from,
            vod_play_url: playUrl,
        };
    },

    lazy: async function () {
        var input = String(this.input || '');
        var s = parseSongToken(input);
        if (!s) return { parse: 0, url: input };
        try {
            var url = await resolveMusicUrl(s);
            if (typeof url === 'string' && url.indexOf('toast://') === 0) return { parse: 0, url: url };
            var lrc = await fetchLyric(s);
            var out = { parse: 0, url: url };
            if (lrc) { out.lrc = lrc; out.subtitle = lrc; }
            return out;
        } catch (e) {
            return { parse: 0, url: 'toast://播放获取失败: ' + (e && e.message ? e.message : '服务未响应') };
        }
    },
};
