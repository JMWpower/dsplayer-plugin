'use strict';
/*
 * HTML 规则书源（替代原来的 legado_t3.py）
 *
 * 这里同时干两件事：
 *   1. 生成能被「阅读 / Legado」用 CSS 规则解析的 HTML 页面（/hs/...）
 *      - /hs/browse    书库列表（探索）
 *      - /hs/search    搜索
 *      - /hs/book      书籍详情 + 目录
 *      - /hs/chapter   正文
 *      - /hs/manage    源管理列表
 *      - /hs/source    单个书源详情（章节 = 启用/停用/测试/查看/删除）
 *      - /hs/repos     源仓库列表
 *      - /hs/repo      某个仓库的书源列表（章节 = 导入）
 *      - /hs/import    导入动作（点开即导入，正文显示结果）
 *   2. 输出 bookSource JSON：/legado_html.json（ruleExplore/ruleSearch 等都是 HTML 规则）
 */

const { token, parseToken, cleanChapterName } = require('../core/engine');
const repos = require('./repos');

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function enc(s) { return encodeURIComponent(String(s == null ? '' : s)); }

const CSS = `
*{box-sizing:border-box}
body{margin:0;padding:0 0 40px;background:#f7f7f8;color:#1c1c1e;
  font:15px/1.7 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}
header{position:sticky;top:0;z-index:5;background:#fff;border-bottom:1px solid #e6e6ea;padding:10px 14px}
header a{color:#2b6cb0;text-decoration:none;font-size:13.5px}
header .nav a{margin-right:14px}
header h1{font-size:16px;margin:0 0 6px}
.wrap{padding:14px}
.list{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}
.book{background:#fff;border:1px solid #e9e9ee;border-radius:10px;padding:10px;overflow:hidden}
.book img.cover{width:100%;height:auto;max-height:200px;object-fit:cover;border-radius:6px;background:#eef0f4}
.book .title{display:block;margin-top:6px;color:#1c1c1e;font-weight:600;text-decoration:none;font-size:14px;
  overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.book .author,.book .kind,.book .last{display:block;color:#8a8a92;font-size:12px;margin-top:2px}
.book .intro{color:#6b6b73;font-size:12px;margin:6px 0 0;overflow:hidden;display:-webkit-box;
  -webkit-line-clamp:3;-webkit-box-orient:vertical}
.book-name{font-size:20px;margin:0 0 6px}
.book-author,.book-kind,.book-last,.book-words{display:inline-block;color:#8a8a92;font-size:12.5px;margin-right:10px}
#intro{color:#4a4a52;font-size:13.5px;background:#fff;border:1px solid #ececf1;border-radius:10px;padding:10px;margin:10px 0}
.cover.big{width:96px;height:auto;border-radius:8px;float:right;margin:0 0 8px 12px}
.chapters{background:#fff;border:1px solid #ececf1;border-radius:10px;padding:6px 12px}
.chapters a{display:block;color:#2b6cb0;text-decoration:none;font-size:13.5px;padding:6px 0;border-bottom:1px dashed #eee}
.chapters a:last-child{border-bottom:0}
.pager{display:flex;gap:8px;justify-content:center;margin:18px 0}
.pager a,.pager span{padding:6px 12px;border:1px solid #dcdce3;border-radius:8px;color:#2b6cb0;text-decoration:none;font-size:13px;background:#fff}
.pager span{color:#8a8a92}
#content p{margin:0 0 .95em;text-indent:2em;line-height:1.95;font-size:17px}
.chapter-title{font-size:18px;margin:0 0 14px}
.tag{display:inline-block;font-size:11px;color:#6b6b73;background:#eef0f4;border-radius:4px;padding:1px 6px;margin-right:4px}
.note{color:#8a8a92;font-size:12.5px}
.empty{color:#8a8a92;text-align:center;padding:30px 0}
.state{display:inline-block;font-size:11px;border-radius:4px;padding:0 6px;margin-left:6px}
.st-ok{background:#e7f6ec;color:#1a7f37}
.st-warn{background:#fff4e5;color:#a35a00}
.st-bad{background:#fdecec;color:#c0392b}
.notice{background:#fff8e6;border:1px solid #f2e2b8;color:#7a5b00;border-radius:10px;padding:10px 12px;
  margin:10px 0;font-size:13.5px;line-height:1.65}
.notice b{color:#8a5b00}
`;

function page(title, body, nav) {
  const head = nav || '';
  return '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
    + '<meta name="viewport" content="width=device-width,initial-scale=1">'
    + '<title>' + esc(title) + '</title><style>' + CSS + '</style></head><body>'
    + '<header><h1>' + esc(title) + '</h1>'
    + '<div class="nav"><a href="/hs/browse">书库</a><a href="/hs/manage">源管理</a>'
    + '<a href="/hs/repos">源仓库</a><a href="/">管理面板</a></div></header>'
    + '<div class="wrap">' + head + body + '</div></body></html>';
}

const STATE_LABEL = {
  ok: '可用', empty: '无内容', error: '抓取失败', timeout: '超时', unknown: '未检测', disabled: '已停用',
};

/** 书源状态小徽章：可用 / 无内容 / 抓取失败 …，悬停看原因 */
function stateTag(st) {
  const state = (st && st.state) || 'unknown';
  const label = STATE_LABEL[state] || '未检测';
  const cls = state === 'ok' ? 'st-ok' : (state === 'empty' || state === 'unknown' ? 'st-warn' : 'st-bad');
  const tip = st && st.msg ? ' title="' + esc(st.msg) + '"' : '';
  return '<span class="state ' + cls + '"' + tip + '>' + esc(label) + '</span>';
}

/** 空列表时告诉用户为什么空，别只甩一句「没有内容」 */
function notice(st, extra) {
  const msg = (st && st.msg) || '这个源没有返回任何条目';
  return '<div class="notice"><b>没有内容</b>：' + esc(msg)
    + (extra ? '<br>' + esc(extra) : '') + '</div>';
}

function pager(basePath, query, page, pagecount) {
  const q = new URLSearchParams(query);
  const make = (n) => {
    q.set('pg', String(n));
    return basePath + '?' + q.toString();
  };
  let html = '<div class="pager">';
  if (page > 1) html += '<a href="' + esc(make(page - 1)) + '">上一页</a>';
  html += '<span>第 ' + page + ' / ' + (pagecount || '?') + ' 页</span>';
  html += '<a href="' + esc(make(page + 1)) + '">下一页</a>';
  return html + '</div>';
}

function bookItem(b) {
  return '<div class="book">'
    + (b.cover ? '<img class="cover" src="' + esc(b.cover) + '" alt="" loading="lazy">' : '')
    + '<a class="title" href="' + esc(b.href) + '">' + esc(b.name) + '</a>'
    + (b.html || '')
    + (b.author ? '<span class="author">' + esc(b.author) + '</span>' : '')
    + (b.kind ? '<span class="kind">' + esc(b.kind) + '</span>' : '')
    + (b.last ? '<span class="last">' + esc(b.last) + '</span>' : '')
    + (b.intro ? '<p class="intro">' + esc(b.intro) + '</p>' : '')
    + '</div>';
}

function createRenderer(opts) {
  const getEngine = opts.getEngine;
  const store = opts.store;
  const reload = opts.reload || (() => {});
  const searchBudget = opts.searchBudget || 9000;

  function engine() { return getEngine(); }

  /* ── 书库 ── */
  async function browse(params) {
    const e = engine();
    const t = params.get('t') || '';
    const pg = Math.max(1, parseInt(params.get('pg') || '1', 10) || 1);
    const ch = params.get('ch') || '';
    if (!e || !e.sources.length) {
      return page('书库', '<div class="empty">还没有可用的书源，去 <a href="/hs/repos">源仓库</a> 导入几个吧</div>');
    }
    // 没指定书源时优先挑一个「上次抓过且有内容」的，别一上来就撞死源
    let idx;
    if (t === '') {
      idx = e.sources.findIndex((s, i) => e.statusOf(i).state === 'ok');
      if (idx < 0) idx = 0;
    } else {
      idx = Math.min(e.sources.length - 1, Math.max(0, parseInt(t, 10) || 0));
    }
    const src = e.sources[idx];
    const r = await e.category(String(idx), pg, ch).catch(() => ({ list: [], pagecount: 1 }));
    const items = (r.list || []).map((v) => ({
      name: v.vod_name,
      href: '/hs/book?id=' + enc(v.vod_id),
      author: v.vod_actor,
      kind: src.name + (v.vod_area ? ' · ' + v.vod_area : ''),
      last: v.vod_remarks,
      intro: v.vod_content,
      cover: v.vod_pic,
    }));
    const chips = (src.channels || []).slice(0, 12).map((c) => {
      const u = new URLSearchParams({ t: String(idx), pg: '1', ch: c.url });
      const on = c.url === ch ? ' style="color:#1c1c1e;font-weight:600"' : '';
      return '<a' + on + ' href="/hs/browse?' + u.toString() + '">' + esc(c.title) + '</a>';
    }).join(' ');
    const nav = '<div class="note" style="margin-bottom:10px">频道：' + (chips || '—')
      + (items.length ? '' : '') + '</div>';
    const list = items.length
      ? '<div class="list">' + items.map(bookItem).join('') + '</div>'
      : notice(e.statusOf(idx), '换一个书源试试，或者去「源管理」看看哪些源现在还能用。');
    const head = '<div class="note" style="margin-bottom:8px">当前书源：<b>' + esc(src.name) + '</b>'
      + stateTag(e.statusOf(idx)) + '</div>';
    return page('书库 · ' + src.name, head + nav + list + pager('/hs/browse', { t: String(idx), ch }, pg, r.pagecount), '');
  }

  /* ── 搜索 ── */
  async function search(params) {
    const e = engine();
    const key = params.get('key') || params.get('wd') || '';
    if (!key) {
      return page('搜索', '<div class="empty">在阅读里直接搜索书名即可</div>');
    }
    const r = await e.search(key, { timeout: searchBudget }).catch(() => ({ list: [] }));
    const items = (r.list || []).map((v) => ({
      name: v.vod_name,
      href: '/hs/book?id=' + enc(v.vod_id),
      author: v.vod_actor,
      kind: v.type_name || v.source,
      last: v.vod_remarks,
      intro: v.vod_content,
      cover: v.vod_pic,
    }));
    const bad = Object.values(e.statusMap()).filter((s) => s.state !== 'ok' && s.state !== 'unknown').length;
    const empty = items.length ? '' : notice(
      { msg: bad ? '关键词没有命中；' + bad + ' 个书源当前抓不到内容（可能已失效）' : '关键词没有命中任何书源' },
      '换一个关键词试试，或者先去「书库」挑一个能用的源。'
    );
    return page('搜索：' + key,
      (items.length ? '<div class="list">' + items.map(bookItem).join('') + '</div>' : empty)
      + pager('/hs/search', { key }, 1, 1));
  }

  /* ── 详情 + 目录 ── */
  async function book(params) {
    const e = engine();
    const id = params.get('id') || '';
    let d;
    try {
      d = await e.detail(id);
    } catch (err) {
      return page('书籍详情', '<div class="empty">打开失败：' + esc(err.message) + '</div>');
    }
    const cover = d.vod_pic ? '<img class="cover big" src="' + esc(d.vod_pic) + '" alt="">' : '';
    const chapters = (d.chapters || []).map((c, i) => {
      const nm = cleanChapterName(c.name, i);
      return '<a href="/hs/chapter?id=' + enc(token(parseToken(id).idx, c.url)) + '">' + esc(nm) + '</a>';
    }).join('');
    const body = cover
      + '<h2 class="book-name">' + esc(d.vod_name) + '</h2>'
      + (d.vod_actor ? '<span class="book-author">作者：' + esc(d.vod_actor) + '</span>' : '')
      + (d.vod_area ? '<span class="book-kind">' + esc(d.vod_area) + '</span>' : '')
      + '<span class="book-words">共 ' + (d.chapter_count || 0) + ' 章</span>'
      + '<p id="intro">' + esc(d.vod_content || '暂无简介') + '</p>'
      + '<div class="chapters">' + (chapters || '<div class="empty">无目录</div>') + '</div>';
    return page(d.vod_name || '书籍详情', body);
  }

  /* ── 正文 ── */
  async function chapter(params) {
    const e = engine();
    const id = params.get('id') || params.get('f') || '';
    let d;
    try {
      d = await e.chapterDetail(id);
    } catch (err) {
      return page('正文', '<div class="empty">正文获取失败：' + esc(err.message) + '</div>');
    }
    const ps = String(d.content || '').split(/\n+/).filter(Boolean)
      .map((x) => '<p>' + esc(x) + '</p>').join('');
    return page(d.title || '正文',
      '<h2 class="chapter-title">' + esc(d.title || '') + '</h2><div id="content">' + ps + '</div>');
  }

  /* ── 源管理 ── */
  function manage() {
    const e = engine();
    const rows = store.info().map((s) => {
      const st = e ? e.statusForUrl(s.host) : { state: 'unknown' };
      return bookItem({
        name: s.name,
        href: '/hs/source?i=' + s.index,
        author: s.host,
        html: stateTag(st),
        kind: (s.enabled ? '启用中' : '已停用') + (s.searchable ? ' · 可搜索' : '') + (s.channels.length ? ' · ' + s.channels.length + ' 频道' : ''),
        last: s.group,
        intro: '',
      });
    }).join('');
    return page('源管理 · 共 ' + store.size + ' 个书源',
      '<p class="note">点开任意书源，它的「章节」就是操作项：启用/停用、测试浏览、测试搜索、查看 JSON、删除。</p>'
      + (rows ? '<div class="list">' + rows + '</div>' : '<div class="empty">还没有书源</div>'));
  }

  function sourceDetail(params) {
    const idx = parseInt(params.get('i') || '0', 10);
    const info = store.info()[idx];
    if (!info) return page('书源详情', '<div class="empty">书源不存在</div>');
    const e = engine();
    const st = e ? e.statusForUrl(info.host) : { state: 'unknown' };
    const acts = [
      ['toggle', info.enabled ? '停用此书源' : '启用此书源'],
      ['browse', '测试浏览（抓一次分类页）'],
      ['test', '测试搜索（关键字：剑来）'],
      ['json', '查看书源 JSON'],
      ['delete', '删除此书源'],
    ].map(([k, label]) => '<a href="/hs/act?i=' + idx + '&do=' + k + '">' + esc(label) + '</a>').join('');
    const body = '<h2 class="book-name">' + esc(info.name) + '</h2>'
      + '<span class="book-author">' + esc(info.host) + '</span>'
      + '<span class="book-kind">' + (info.enabled ? '启用中' : '已停用') + '</span>'
      + '<span class="book-words">' + info.channels.length + ' 个频道</span>'
      + stateTag(st)
      + '<p id="intro">' + esc((st.msg || '上次抓取正常') + '\n分组：' + (info.group || '（没有分组）')) + '</p>'
      + '<div class="chapters">' + acts + '</div>';
    return page(info.name, body);
  }

  async function action(params) {
    const idx = parseInt(params.get('i') || '0', 10);
    const act = params.get('do') || '';
    const info = store.info()[idx];
    if (!info) return page('操作失败', '<div id="content">书源不存在</div>');
    if (act === 'toggle') {
      const r = store.setEnabled(idx, !info.enabled);
      reload();
      return page('已' + (r.enabled ? '启用' : '停用'),
        '<div id="content">书源「' + esc(r.name) + '」已' + (r.enabled ? '启用' : '停用') + '。</div>');
    }
    if (act === 'delete') {
      const r = store.remove(idx);
      reload();
      return page('已删除', '<div id="content">书源「' + esc(r.name) + '」已从本地移除。</div>');
    }
    if (act === 'json') {
      const raw = store.list()[idx];
      return page('书源 JSON',
        '<div id="content"><pre style="white-space:pre-wrap;word-break:break-all;font-size:12px">'
        + esc(JSON.stringify(raw, null, 2)) + '</pre></div>');
    }
    if (act === 'browse') {
      const e = engine();
      const at = e.sources.findIndex((s) => s.url === String(info.host || '').replace(/#.*$/, '').replace(/\/+$/, ''))
        || e.sources.findIndex((s) => s.name === info.name);
      if (at < 0) return page('测试结果', '<div id="content">这个书源当前没有加载（可能已停用）。</div>');
      const r = await e.probe(at, 1);
      const ok = r.count > 0;
      const msg = ok
        ? '能出内容：本次抓到 ' + r.count + ' 本，用时 ' + r.ms + 'ms。'
        : '没出内容：' + (r.msg || '未知原因') + '（用时 ' + r.ms + 'ms）';
      return page('测试结果 · ' + (ok ? '可用' : '无内容'),
        '<div id="content">' + esc(r.name + '\n' + msg) + '</div>'
        + '<div class="chapters"><a href="/hs/browse?t=' + at + '&pg=1">去书库看这个源</a>'
        + '<a href="/hs/source?i=' + idx + '">返回书源</a></div>');
    }
    if (act === 'test') {
      const e = engine();
      const at = e.sources.findIndex((s) => s.name === info.name);
      let msg;
      if (at < 0) msg = '该书源当前未启用或无法加载。';
      else {
        const r = await e.search('剑来', { only: at }).catch((err) => ({ list: [], err }));
        msg = r.list && r.list.length ? '搜索成功，返回 ' + r.list.length + ' 条。'
          : '搜索没有结果' + (r.err ? '（' + r.err.message + '）' : '') + '。';
      }
      return page('测试结果', '<div id="content">' + esc(msg) + '</div>');
    }
    return page('未知操作', '<div id="content">不认识的 do=' + esc(act) + '</div>');
  }

  /* ── 源仓库 ── */
  async function repoList() {
    const items = repos.REPOS.map((r) => bookItem({
      name: r.name,
      href: '/hs/repo?r=' + enc(r.id) + '&pg=1',
      author: r.home,
      kind: '点击查看书源',
      last: '',
      intro: r.note,
    })).join('');
    return page('源仓库 · ' + repos.REPOS.length + ' 个仓库', '<div class="list">' + items + '</div>');
  }

  async function repoDetail(params) {
    const rid = params.get('r') || 'yiove';
    const pg = Math.max(1, parseInt(params.get('pg') || '1', 10) || 1);
    const repo = repos.REPO_MAP[rid];
    if (!repo) return page('源仓库', '<div class="empty">未知仓库</div>');
    let r;
    try {
      r = await repos.list(rid, { page: pg, size: 20 });
    } catch (err) {
      return page(repo.name, '<div class="empty">仓库打开失败：' + esc(err.message) + '</div>');
    }
    const items = r.items.map((it) => bookItem({
      name: it.name,
      href: '/hs/import?r=' + enc(rid) + '&id=' + enc(it.id),
      author: it.author,
      kind: it.extra,
      last: it.views ? it.views + ' 次下载' : '',
      intro: it.desc || it.url,
    }));
    const body = '<p id="intro">' + esc(repo.name + '\n' + repo.home + '\n' + repo.note)
      + '\n共 ' + r.total + ' 个书源，点任意一本即导入本地。</p>'
      + (items.length ? '<div class="list">' + items.join('') + '</div>'
        : '<div class="empty">这一页没有数据</div>')
      + pager('/hs/repo', { r: rid }, pg, r.pages);
    return page(repo.name, body);
  }

  async function importOne(params) {
    const rid = params.get('r') || '';
    const id = params.get('id') || '';
    const repo = repos.REPO_MAP[rid];
    let res;
    try {
      const got = await repos.importOne(rid, id);
      res = store.addMany(got.sources, { repo: rid });
      reload();
    } catch (err) {
      return page('导入失败', '<div id="content">导入失败：' + esc(err.message) + '</div>'
        + '<div class="chapters"><a href="/hs/repos">返回源仓库</a></div>');
    }
    const name = res.added[0] || res.updated[0] || '书源';
    // 导入后立刻抓一次，别让用户点进书库才发现是空的
    const e = engine();
    const touched = [].concat(res.added || [], res.updated || []);
    const tests = [];
    for (const nm of touched.slice(0, 3)) {
      const at = e.sources.findIndex((s) => s.name === nm);
      if (at < 0) { tests.push({ name: nm, state: 'disabled', count: 0, msg: '没有加载（可能停用）' }); continue; }
      tests.push(await e.probe(at, 1));
    }
    const lines = tests.map((t) => (t.count > 0
      ? '✅ 「' + t.name + '」可用，抓到 ' + t.count + ' 本'
      : '⚠️ 「' + t.name + '」暂时没内容：' + (t.msg || '未知原因')));
    const msg = '已导入「' + name + '」：新增 ' + res.added.length + ' 个，更新 ' + res.updated.length + ' 个。'
      + (res.invalid ? ' 有 ' + res.invalid + ' 个不是有效的书源 JSON。' : '')
      + '\n当前共 ' + store.size + ' 个书源，启用 ' + store.enabledSize + ' 个。'
      + (lines.length ? '\n\n内容检测：\n' + lines.join('\n') : '')
      + '\n\n（书库 / 源管理里也能看到每个源的状态徽章）';
    const nav = [['/hs/repos', '返回源仓库'], ['/hs/browse', '去书库看看'], ['/hs/manage', '源管理']]
      .map(([href, label]) => '<a href="' + href + '">' + esc(label) + '</a>').join('');
    return page('导入完成 · ' + name,
      '<h2 class="book-name">已导入：' + esc(name) + '</h2>'
      + '<span class="book-author">来源：' + esc((repo && repo.name) || rid) + '</span>'
      + '<span class="book-words">共 ' + store.size + ' 个书源</span>'
      + '<p id="intro">' + esc(msg) + '</p>'
      + '<div id="content">' + esc(msg) + '</div>'
      + '<div class="chapters">' + nav + '</div>');
  }

  return { browse, search, book, chapter, manage, sourceDetail, action, repoList, repoDetail, importOne };
}

/* ───────────── 书源 JSON（HTML 规则） ───────────── */

const LIST_RULES = {
  bookList: '.book',
  name: '.title@text',
  author: '.author@text',
  kind: '.kind@text',
  lastChapter: '.last@text',
  intro: '.intro@text',
  coverUrl: '.cover@src',
  bookUrl: '.title@href',
  wordCount: '',
};

function bookSourceJson(base) {
  const host = String(base || 'http://127.0.0.1:13000').replace(/\/+$/, '');
  return {
    bookSourceComment: [
      '阅读源 · Node 聚合服务（HTML 规则版，替代 legado_t3.py）',
      '服务地址：' + host,
      '书库：/hs/browse   源管理：/hs/manage   源仓库：/hs/repos',
      '管理面板：' + host + '/',
    ].join('\n'),
    bookSourceGroup: '聚合',
    bookSourceName: '阅读源·Node',
    bookSourceType: 0,
    bookSourceUrl: host,
    customOrder: 999,
    enabled: true,
    enabledCookieJar: false,
    enabledExplore: true,
    enabledSearch: true,
    header: '',
    loginUrl: '',
    searchUrl: '/hs/search?key={{key}}&page={{page}},{"charset":"utf-8"}',
    exploreUrl: JSON.stringify([
      { title: '书库', url: '/hs/browse?pg={{page}}&t=0' },
      { title: '源管理', url: '/hs/manage' },
      { title: '源仓库', url: '/hs/repos' },
    ], null, 0),
    ruleExplore: Object.assign({}, LIST_RULES),
    ruleSearch: Object.assign({}, LIST_RULES),
    ruleBookInfo: {
      name: '.book-name@text',
      author: '.book-author@text',
      kind: '.book-kind@text',
      lastChapter: '.book-last@text',
      intro: '#intro@text',
      coverUrl: '.cover@src',
      wordCount: '.book-words@text',
      tocUrl: '',
      init: '',
    },
    ruleToc: {
      chapterList: '.chapters a',
      chapterName: 'text',
      chapterUrl: 'href',
      nextTocUrl: '',
    },
    ruleContent: {
      content: '#content@html',
      replaceRegex: '',
    },
  };
}

module.exports = { createRenderer, bookSourceJson, page, CSS };
