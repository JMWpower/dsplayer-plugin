# -*- coding: utf-8 -*-
"""
站点信息：
  名称: 阅读源（Legado 书源聚合服务 · DsPlayer 配套源）
  服务: 本机 / 局域网上的「阅读源 Node 服务」(index.js)，默认 http://127.0.0.1:13000
  内容类型: 小说 (novel://)
  配套关系: 与 DsPlayer 市场里的「阅读源·Node聚合」(server 包) 成对使用——
            Node 服务负责聚合书源并提供 /legado_html.json（乐读内核可直接导入的 HTML 规则源）；
            本文件是给 DsPlayer「阅读」/ hipy py 引擎用的代理源，数据同样来自那份服务。
  特殊说明: 本文件是「代理型」书源——分类 = 书源，书 = 条目，章节 = 剧集，正文 = novel:// 的 JSON 负载。
            写法与 肉书屋.py 模板保持一致：方法签名、filters、章节命名、novel:// 载荷、多地址兜底。
  最后验证时间: 2026-11-18（homeContent 24 分类 / categoryContent 36 本 / search 46 条 /
              detail 3000 章 / playerContent novel:// 正文 1359 字，全部对本机服务实测通过）

配置（在阅读器里给这个源填 ext，三种写法都行）：
  1) 只填地址：
        http://192.168.1.10:13000
  2) 填 JSON（推荐）：
        {"base":"http://192.168.1.10:13000","play_base":"http://192.168.1.10:13000","mode":"novel","timeout":25}
  3) 不填：依次用环境变量 LEGADO_NODE_BASE、DEFAULT_BASE、FALLBACK_BASES 探测

ext 可用的键：
  base        服务地址（必须能被阅读器所在设备访问到）
  play_base   写进播放地址的地址，默认等于 base
  mode        出正文的方式：novel（默认，novel:// 契约，与模板一致）
                           webview（返回 HTML 给内置浏览器，播放器不认 novel:// 时用）
                           direct（直接给纯文本地址）
  timeout     单次请求超时秒数，默认 25
  hide        要隐藏的分类（书源下标）列表，如 ["3","7"]
  max_ep      详情里最多返回多少章，0 = 全部（默认 0）
  search_only 只在这些书源里搜索，填下标列表，如 [0,2,5]；不填 = 全部
"""

import json
import os
import sys
import time
from urllib.parse import urlencode, quote

try:
    from base.spider import Spider as BaseSpider
except Exception:
    class BaseSpider(object):
        def fetch(self, *a, **k):
            return None

        def post(self, *a, **k):
            return None

try:
    import requests
except Exception:
    requests = None


def _abs_url(base, path):
    """拼地址：相对路径补域名，绝对路径原样返回"""
    path = str(path or '').strip()
    if not path:
        return base
    if path.lower().startswith(('http://', 'https://')):
        return path
    if not path.startswith('/'):
        path = '/' + path
    return base.rstrip('/') + path


class Spider(BaseSpider):

    DEFAULT_BASE = 'http://127.0.0.1:13000'
    # 探测不到时依次再试（容器里连宿主机 / 同机备用端口）
    FALLBACK_BASES = ('http://host.docker.internal:13000', 'http://127.0.0.1:13001')
    TIMEOUT = 25
    PING_TIMEOUT = 4
    PLAY_MODE = 'novel'
    LIST_TTL = 60        # 分类 / 首页 / 搜索缓存秒数
    DETAIL_TTL = 600     # 详情缓存秒数
    TXT_TTL = 1800       # 正文缓存秒数
    PAGE_SIZE = 20

    def __init__(self):
        self._base = ''
        self._play_base = ''
        self._mode = self.PLAY_MODE
        self._timeout = self.TIMEOUT
        self._ext_raw = ''
        self._hide = set()
        self._max_ep = 0
        self._search_only = []
        self._cache = {}
        self._base_checked_at = 0
        self._name = '阅读源'

    # ---------- 框架入口 ----------

    def getName(self):
        return self._name

    def getDependence(self):
        return []

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        return False

    def setExtendInfo(self, extend):
        self._apply_extend(extend)
        return None

    def init(self, extend=''):
        self._apply_extend(extend)
        return None

    def init_api(self, extend=''):
        return self.init(extend)

    def destroy(self):
        try:
            self._cache.clear()
            self._base_checked_at = 0
        except Exception:
            pass
        return None

    # ---------- 配置 ----------

    def _apply_extend(self, extend):
        if extend is None:
            return
        ext = str(extend).strip()
        if not ext:
            return
        if ext == self._ext_raw:
            return
        self._ext_raw = ext
        if ext.startswith('{'):
            try:
                cfg = json.loads(ext)
            except Exception:
                cfg = {}
            if not isinstance(cfg, dict):
                return
            base = str(cfg.get('base') or cfg.get('api') or cfg.get('host') or '').strip()
            if base:
                self._base = self._norm_base(base)
                if not self._play_base:
                    self._play_base = self._base
            pb = str(cfg.get('play_base') or cfg.get('playBase') or '').strip()
            if pb:
                self._play_base = self._norm_base(pb)
            mode = str(cfg.get('mode') or '').strip().lower()
            if mode in ('novel', 'webview', 'direct'):
                self._mode = mode
            try:
                if cfg.get('timeout'):
                    self._timeout = max(5, int(cfg.get('timeout')))
            except Exception:
                pass
            hide = cfg.get('hide')
            if isinstance(hide, (list, tuple)):
                self._hide = set(str(x) for x in hide)
            elif hide not in (None, ''):
                self._hide = set(x.strip() for x in str(hide).split(',') if x.strip())
            try:
                self._max_ep = max(0, int(cfg.get('max_ep') or cfg.get('maxEp') or 0))
            except Exception:
                pass
            only = cfg.get('search_only') or cfg.get('searchOnly')
            if isinstance(only, (list, tuple)):
                self._search_only = [str(x) for x in only]
            elif only not in (None, ''):
                self._search_only = [x.strip() for x in str(only).split(',') if x.strip()]
        elif ext.lower().startswith(('http://', 'https://')):
            self._base = self._norm_base(ext)
            if not self._play_base:
                self._play_base = self._base

    @staticmethod
    def _norm_base(url):
        url = str(url or '').strip().rstrip('/')
        if url and not url.lower().startswith(('http://', 'https://')):
            url = 'http://' + url
        return url

    def _candidates(self):
        out, seen = [], set()

        def add(u):
            u = self._norm_base(u)
            if u and u not in seen:
                seen.add(u)
                out.append(u)

        add(self._base)
        add(os.environ.get('LEGADO_NODE_BASE', ''))
        add(self.DEFAULT_BASE)
        for u in self.FALLBACK_BASES:
            add(u)
        return out

    def _pick_base(self):
        """确定可用服务地址：命中过就复用，探测失败也不会抛异常"""
        now = time.time()
        if self._base and self._alive(self._base):
            return self._base
        # 刚探测过就别每秒重探
        if self._base and now - self._base_checked_at < 30:
            return self._base
        self._base_checked_at = now
        for cand in self._candidates():
            if self._alive(cand):
                self._base = cand
                return cand
        if not self._base:
            self._base = self._candidates()[0]
        return self._base

    def _alive(self, base):
        try:
            txt = self._http(base + '/ping', timeout=self.PING_TIMEOUT)
            return bool(json.loads(txt).get('ok'))
        except Exception:
            return False

    def _playbase(self):
        if not self._play_base:
            self._play_base = self._pick_base()
        return self._play_base

    # ---------- 网络 ----------

    @staticmethod
    def _headers():
        return {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36',
            'Accept': 'application/json,text/plain,*/*',
        }

    @staticmethod
    def _resp_text(resp):
        if resp is None:
            return ''
        if isinstance(resp, bytes):
            return resp.decode('utf-8', 'replace')
        if isinstance(resp, str):
            return resp
        for attr in ('text', 'content', 'body'):
            val = getattr(resp, attr, None)
            if isinstance(val, bytes):
                return val.decode('utf-8', 'replace')
            if isinstance(val, str):
                return val
        try:
            return json.dumps(resp, ensure_ascii=False)
        except Exception:
            return ''

    def _http(self, url, timeout=None):
        """先走框架 fetch，再 requests，最后 urllib —— 三种环境都能跑"""
        timeout = timeout or self._timeout
        hdr = self._headers()

        fetcher = getattr(self, 'fetch', None)
        if callable(fetcher):
            for call in (
                lambda: fetcher(url, headers=hdr, timeout=timeout),
                lambda: fetcher(url, hdr),
                lambda: fetcher(url),
            ):
                try:
                    txt = self._resp_text(call())
                    if txt:
                        return txt
                except TypeError:
                    continue
                except Exception:
                    break

        if requests is not None:
            try:
                r = requests.get(url, headers=hdr, timeout=timeout)
                r.encoding = 'utf-8'
                if r.text:
                    return r.text
            except Exception:
                pass

        import urllib.request
        req = urllib.request.Request(url, headers=hdr)
        with urllib.request.urlopen(req, timeout=timeout) as f:
            return f.read().decode('utf-8', 'replace')

    def _url(self, path, params=None):
        url = _abs_url(self._pick_base(), path)
        if params:
            url += ('&' if '?' in url else '?') + urlencode(params)
        return url

    def _get_json(self, path, params=None, ttl=0):
        url = self._url(path, params)
        now = time.time()
        if ttl:
            hit = self._cache.get(url)
            if hit and now - hit[0] < hit[1]:
                return hit[2]
        txt = self._http(url)
        try:
            data = json.loads(txt)
        except Exception:
            raise RuntimeError('接口返回不是 JSON：' + txt[:120])
        if isinstance(data, dict) and data.get('code') and not data.get('list'):
            raise RuntimeError(str(data.get('msg') or data.get('code')))
        if ttl:
            self._cache[url] = (now, ttl, data)
            if len(self._cache) > 200:
                for k in list(self._cache)[:80]:
                    self._cache.pop(k, None)
        return data

    # ---------- 字段整理 ----------

    def _norm_class(self, classes):
        out = []
        for c in classes or []:
            if not isinstance(c, dict):
                continue
            tid = c.get('type_id', c.get('tid', ''))
            name = str(c.get('type_name') or c.get('name') or '').strip()
            if tid is None or tid == '':
                continue
            if self._hide and str(tid) in self._hide:
                continue
            out.append({'type_id': str(tid), 'type_name': name or ('分类' + str(tid))})
        return out

    @staticmethod
    def _norm_item(it, tid='', tname=''):
        if not isinstance(it, dict):
            it = {}
        return {
            'vod_id': str(it.get('vod_id') or ''),
            'vod_name': str(it.get('vod_name') or '').strip(),
            'vod_pic': str(it.get('vod_pic') or ''),
            'vod_remarks': str(it.get('vod_remarks') or ''),
            'vod_actor': str(it.get('vod_actor') or ''),
            'vod_director': '',
            'vod_area': str(it.get('vod_area') or ''),
            'vod_year': str(it.get('vod_year') or ''),
            'vod_lang': '',
            'type_id': str(it.get('type_id') or tid or ''),
            'type_name': str(it.get('type_name') or tname or ''),
            'vod_content': str(it.get('vod_content') or ''),
        }

    def _classes(self):
        try:
            d = self._get_json('/api.php/provide/vod/', {'ac': 'list'}, self.LIST_TTL)
            return self._norm_class(d.get('class'))
        except Exception:
            return []

    def _filters(self):
        try:
            d = self._get_json('/filters', None, self.LIST_TTL)
            f = d.get('filters') if isinstance(d, dict) else None
            return f if isinstance(f, dict) else {}
        except Exception:
            return {}

    @staticmethod
    def _clean_play_name(name):
        """章节名里不能出现 $ 和 #（它们是 T3 的分隔符）"""
        return str(name or '').replace('$', ' ').replace('#', ' ').strip()

    # ---------- 首页 ----------

    def homeContent(self, filter=False):
        classes, items, filters = [], [], {}
        try:
            d = self._get_json('/api.php/provide/vod/', {'ac': 'list', 'first': '0'}, self.LIST_TTL)
            classes = self._norm_class(d.get('class'))
            filters = d.get('filters') if isinstance(d.get('filters'), dict) else {}
            first = classes[0] if classes else {'type_id': '0', 'type_name': ''}
            for x in (d.get('list') or [])[:60]:
                items.append(self._norm_item(x, first['type_id'], first['type_name']))
        except Exception:
            # 接口挂了也要给出分类表，不然阅读器里这个源会直接"空"
            try:
                d = self._get_json('/sources', None, self.LIST_TTL)
                classes = self._norm_class([
                    {'type_id': s.get('type_id', s.get('index')), 'type_name': s.get('name')}
                    for s in (d.get('sources') or [])
                ])
            except Exception:
                classes = []
        if not filters:
            filters = self._filters()
        return {'class': classes, 'filters': filters, 'list': items}

    def getHomeContent(self, filter=False):
        return self.homeContent(filter)

    def homeVideoContent(self):
        try:
            d = self._get_json('/api.php/provide/vod/', {'ac': 'list'}, self.LIST_TTL)
            classes = self._norm_class(d.get('class'))
            first = classes[0] if classes else {'type_id': '0', 'type_name': ''}
            return {'list': [self._norm_item(x, first['type_id'], first['type_name'])
                             for x in (d.get('list') or [])[:60]]}
        except Exception:
            return {'list': []}

    # ---------- 分类 ----------

    def categoryContent(self, tid, pg=1, filter=False, extend='', *args, **kwargs):
        tid = str(tid if tid not in (None, '') else '0')
        try:
            pg = max(1, int(str(pg)))
        except Exception:
            pg = 1

        # 频道：extend 可能是 dict，也可能是 {"channel": "..."} 字符串
        channel = ''
        ext = extend
        if isinstance(ext, dict):
            channel = str(ext.get('channel') or ext.get('ch') or '').strip()
        elif ext:
            s = str(ext).strip()
            if s.startswith('{'):
                try:
                    obj = json.loads(s)
                    if isinstance(obj, dict):
                        channel = str(obj.get('channel') or obj.get('ch') or '').strip()
                except Exception:
                    channel = ''
            elif '=' not in s:
                channel = s

        name = ''
        for c in self._classes():
            if c['type_id'] == tid:
                name = c['type_name']
                break

        items, pagecount, total = [], 1, 0
        try:
            params = {'ac': 'list', 't': tid, 'pg': pg}
            if channel:
                params['channel'] = channel
            d = self._get_json('/api.php/provide/vod/', params, self.LIST_TTL)
            items = [self._norm_item(x, tid, name) for x in (d.get('list') or [])]
            try:
                pagecount = int(d.get('pagecount') or 999)
            except Exception:
                pagecount = 999
            try:
                total = int(d.get('total') or 9999)
            except Exception:
                total = 9999
            if not items and pg > 1:
                # 翻到空页就告诉阅读器到底了，别让它一直翻
                pagecount = pg
            if pagecount < pg:
                pagecount = pg
        except Exception:
            items, pagecount, total = [], 1, 0

        return {
            'list': items,
            'page': pg,
            'pagecount': pagecount,
            'limit': self.PAGE_SIZE,
            'total': total if total >= len(items) else len(items),
        }

    # ---------- 搜索 ----------

    def searchContent(self, key, quick=False, pg='1', *args, **kwargs):
        key = str(key or '').strip()
        if not key:
            return {'list': [], 'page': 1, 'pagecount': 1, 'total': 0}
        try:
            params = {'ac': 'detail', 'wd': key}
            d = self._get_json('/api.php/provide/vod/', params, self.LIST_TTL)
            seen, items = set(), []
            for x in (d.get('list') or []):
                it = self._norm_item(x)
                k = it['vod_id'] or it['vod_name']
                if not k or k in seen:
                    continue
                seen.add(k)
                items.append(it)
        except Exception:
            items = []
        return {'list': items, 'page': 1, 'pagecount': 1, 'total': len(items)}

    # ---------- 详情 + 章节 ----------

    def detailContent(self, ids):
        if isinstance(ids, (list, tuple, set)):
            id_list = [str(x) for x in ids if x]
        else:
            id_list = [x for x in str(ids or '').split(',') if x]
        if not id_list:
            return {'list': []}

        out = []
        for id in id_list:
            try:
                d = self._get_json('/api.php/provide/vod/',
                                   {'ac': 'detail', 'ids': id}, self.DETAIL_TTL)
                rows = d.get('list') or []
                if not rows:
                    continue
                x = rows[0]
                vod = self._norm_item(x)
                vod['vod_content'] = str(x.get('vod_content') or '')
                vod['vod_play_from'] = str(x.get('vod_play_from') or '阅读')

                plays = []
                for piece in str(x.get('vod_play_url') or '').split('#'):
                    piece = piece.strip()
                    if not piece:
                        continue
                    if '$' in piece:
                        cname, cid = piece.split('$', 1)
                    else:
                        cname, cid = '正文', piece
                    cname = self._clean_play_name(cname) or ('第%d章' % (len(plays) + 1))
                    if not cid:
                        continue
                    plays.append('%s$%s' % (cname, cid))

                if self._max_ep and len(plays) > self._max_ep:
                    plays = plays[:self._max_ep]

                remarks = vod.get('vod_remarks') or ''
                if plays:
                    tail = '共%d章' % len(plays)
                    remarks = (remarks + ' | ' if remarks and tail not in remarks else '') + tail
                vod['vod_remarks'] = remarks
                vod['vod_play_url'] = '#'.join(plays)
                out.append(vod)
            except Exception:
                continue
        return {'list': out}

    # ---------- 播放（正文）----------

    def playerContent(self, flag, id, vipFlags=None):
        raw = str(id or '').strip() or str(flag or '').strip()
        # 有些客户端把 "章节名$标记" 整段丢进来
        if '$' in raw and not raw.lower().startswith(('http://', 'https://')):
            raw = raw.split('$', 1)[1]
        if not raw:
            return {'parse': 0, 'url': '', 'header': self._headers()}

        base = self._playbase()

        if self._mode == 'novel':
            # 与 肉书屋.py 模板一致：正文以 novel:// + JSON 交出
            chapter = self._fetch_chapter(raw)
            payload = json.dumps(chapter, ensure_ascii=False)
            return {'parse': 0, 'url': 'novel://' + payload, 'header': self._headers()}

        if self._mode == 'direct':
            return {'parse': 0, 'url': base + '/txt?f=' + quote(raw, safe=''), 'header': self._headers()}

        # webview：交给内置浏览器排版显示
        return {
            'parse': 0,
            'url': base + '/txt?f=' + quote(raw, safe='') + '&fmt=html',
            'header': self._headers(),
        }

    def _fetch_chapter(self, token):
        """取正文，失败也返回结构完整的 dict，客户端不会因为空值崩掉"""
        cache_key = 'ch:' + token
        now = time.time()
        hit = self._cache.get(cache_key)
        if hit and now - hit[0] < hit[1]:
            return hit[2]

        title, content = '', ''
        try:
            d = self._get_json('/novel', {'f': token}, self.TXT_TTL)
            title = str(d.get('title') or '')
            content = str(d.get('content') or '')
        except Exception:
            # 退一步走纯文本接口
            try:
                content = self._http(self._url('/txt', {'f': token}))
            except Exception:
                content = ''

        if not content:
            content = '正文获取失败，请稍后重试（或检查阅读源服务是否在运行）'
        chapter = {'title': title, 'content': content}
        self._cache[cache_key] = (now, self.TXT_TTL, chapter)
        return chapter


# ─────────────── 单独跑一遍自检 ───────────────
# python3 legado_t3.py                 # 用默认地址
# python3 legado_t3.py http://IP:13000 # 指定服务地址
if __name__ == '__main__':
    ext = sys.argv[1] if len(sys.argv) > 1 else ''
    sp = Spider()
    sp.init(ext)
    print('名称     :', sp.getName())
    home = sp.homeContent(True)
    print('分类     :', len(home.get('class') or []), '个')
    for c in (home.get('class') or [])[:5]:
        print('           ', c['type_id'], c['type_name'])
    first = (home.get('class') or [{}])[0]
    if first.get('type_id') is not None:
        cat = sp.categoryContent(first['type_id'], 1, True, '')
        print('分类内容 :', len(cat.get('list') or []), '条')
        if cat.get('list'):
            print('           例:', cat['list'][0]['vod_name'])
            det = sp.detailContent([cat['list'][0]['vod_id']])
            if det.get('list'):
                v = det['list'][0]
                eps = [x for x in (v['vod_play_url'] or '').split('#') if x]
                print('详情     :', v['vod_name'], '/', len(eps), '章')
                if eps:
                    play = sp.playerContent(v['vod_play_from'], eps[0].split('$', 1)[1], None)
                    print('正文     :', play.get('url', '')[:40], '... 长度', len(play.get('url') or ''))
    sr = sp.searchContent('总裁', False, '1')
    print('搜索     :', len(sr.get('list') or []), '条')
