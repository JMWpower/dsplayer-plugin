// bundle 版入口：静态启动图在 dist/server.bundle.mjs（minify 单文件）。
// 与树版 index.js 同名同启动方式（node index.js），服务配置/环境变量不变。
import {start} from './dist/server.bundle.mjs';
start();
