'use strict';
/*
 * 契约自检：node test/contract.js [http://127.0.0.1:13000] [关键词]
 *
 * 按 肉书屋.py 模板所要求的 T3 契约，逐条验：
 *   分类表 / 筛选表 / 分类列表 / 搜索 / 详情（章节名+标记）/ 正文（标题+内容）
 * 任一条不过就打印 FAIL 并以非 0 退出，方便你在服务器上一把过。
 */

const BASE = (process.argv[2] || 'http://127.0.0.1:13000').replace(/\/+$/, '');
const KEY = process.argv[3] || '总裁';

let pass = 0;
let fail = 0;

function ok(name, extra) {
  pass++;
  console.log('  PASS  ' + name + (extra ? '  ' + extra : ''));
}

function bad(name, why) {
  fail++;
  console.log('  FAIL  ' + name + '  ' + why);
}

async function getJson(path) {
  const url = BASE + path;
  const res = await fetch(url, { headers: { 'User-Agent': 'contract-check' } });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch (e) { /* keep null */ }
  return { status: res.status, json, text, url };
}

(async () => {
  console.log('服务地址: ' + BASE + '\n');

  // 1. 健康检查
  let r = await getJson('/ping');
  if (r.status === 200 && r.json && r.json.ok) ok('健康检查 /ping', '书源 ' + r.json.sources + ' 个');
  else bad('健康检查 /ping', 'status=' + r.status + ' body=' + r.text.slice(0, 80));

  // 2. 分类表（模板要求：class 非空，含 type_id / type_name）
  r = await getJson('/api.php/provide/vod/?ac=list&first=0');
  const cls = (r.json && r.json.class) || [];
  if (cls.length && cls.every((c) => c && c.type_id !== undefined && c.type_name)) {
    ok('分类表', cls.length + ' 个，例：' + cls[0].type_name);
  } else {
    bad('分类表', 'class 为空或结构不对：' + r.text.slice(0, 120));
  }

  // 3. 筛选表
  const filters = (r.json && r.json.filters) || {};
  const fkeys = Object.keys(filters);
  if (fkeys.length) ok('筛选表 filters', fkeys.length + ' 个书源带频道');
  else console.log('  SKIP  筛选表 filters（这本书源集里没有频道配置）');

  if (!cls.length) return finish();

  const tid = cls[0].type_id;

  // 4. 分类列表
  r = await getJson('/api.php/provide/vod/?ac=list&t=' + encodeURIComponent(tid) + '&pg=1');
  const list = (r.json && r.json.list) || [];
  if (Array.isArray(list) && list.length) {
    const it = list[0];
    const okItem = it.vod_id && it.vod_name;
    okItem ? ok('分类列表', '第 1 个分类返回 ' + list.length + ' 条，例：' + it.vod_name)
      : bad('分类列表', '条目缺 vod_id/vod_name');
  } else {
    bad('分类列表', '空列表（书源可能被站点挡了，换个分类再试）');
  }

  // 5. 搜索
  r = await getJson('/api.php/provide/vod/?ac=detail&wd=' + encodeURIComponent(KEY));
  const sList = (r.json && r.json.list) || [];
  if (sList.length) ok('搜索', '关键词「' + KEY + '」命中 ' + sList.length + ' 条');
  else console.log('  SKIP  搜索（当前书源都搜不到这个词）');

  const target = (list[0] || sList[0]);
  if (!target) return finish();

  // 6. 详情：章节名 + 章节标记
  r = await getJson('/api.php/provide/vod/?ac=detail&ids=' + encodeURIComponent(target.vod_id));
  const d = (r.json && r.json.list && r.json.list[0]) || null;
  if (!d) {
    bad('详情', '没返回条目');
    return finish();
  }
  const eps = String(d.vod_play_url || '').split('#').filter(Boolean);
  const shapeOk = eps.length > 0 && eps.every((e) => e.indexOf('$') > 0);
  if (shapeOk) ok('详情 / 章节', d.vod_name + ' · ' + eps.length + ' 章 · ' + (d.vod_remarks || ''));
  else bad('详情 / 章节', 'vod_play_url 结构不对：' + String(d.vod_play_url || '').slice(0, 80));
  if (d.vod_play_from) ok('播放源 vod_play_from', d.vod_play_from);
  else bad('播放源 vod_play_from', '缺失');

  if (!eps.length) return finish();

  // 7. 正文：novel 契约（title + content）
  const cid = eps[0].split('$').slice(1).join('$');
  r = await getJson('/novel?f=' + encodeURIComponent(cid));
  const content = (r.json && r.json.content) || '';
  if (content && content.length > 50) {
    ok('正文 /novel', '标题「' + (r.json.title || '(无)') + '」· ' + content.length + ' 字');
  } else {
    bad('正文 /novel', '内容过短或为空：' + String(content).slice(0, 60));
  }

  // 8. 正文 HTML 兜底
  const res = await fetch(BASE + '/txt?f=' + encodeURIComponent(cid) + '&fmt=html');
  const html = await res.text();
  if (res.status === 200 && /<p>/.test(html)) ok('正文 HTML /txt?fmt=html', html.length + ' 字节');
  else bad('正文 HTML /txt?fmt=html', 'status=' + res.status);

  // 9. 订阅
  r = await getJson('/sub');
  const site = r.json && r.json.sites && r.json.sites[0];
  if (site && site.type === 3 && site.api) ok('订阅 /sub', site.api);
  else bad('订阅 /sub', '结构不对');

  finish();
})().catch((e) => {
  console.log('\n自检中断: ' + e.message);
  process.exit(2);
});

function finish() {
  console.log('\n结果: ' + pass + ' 项通过，' + fail + ' 项失败');
  process.exit(fail ? 1 : 0);
}
