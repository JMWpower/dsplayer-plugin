'use strict';
/* 三个仓库各挑一条导入，看服务端能不能拿到书源 JSON */
const BASE = process.env.BASE || 'http://127.0.0.1:13000';
(async () => {
  for (const rid of ['yiove', 'yuancang', 'yckceo']) {
    const list = await (await fetch(BASE + '/api/repo?r=' + rid + '&pg=1')).json();
    if (!list.ok) { console.log(rid, '列表失败', list.error); continue; }
    const it = list.data.items[0];
    const t0 = Date.now();
    const res = await (await fetch(BASE + '/api/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repo: rid, id: it.id }),
    })).json();
    console.log(rid, '|', it.name, '|', res.ok
      ? ('新增 ' + res.data.added.length + ' 更新 ' + res.data.updated.length + ' 共 ' + res.data.total)
      : ('失败 ' + res.error), '|', (Date.now() - t0) + 'ms');
  }
})();
