'use strict';
const fs = require('fs');
const path = require('path');
const { Engine } = require('../core/engine');
const data = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'sources.json'), 'utf8'));
const engine = new Engine(data);
const key = process.argv[2] || '斗罗';

async function one(s, i) {
  const r = { i, name: s.name, search: 0, detail: '', toc: 0, content: 0, ms: 0, err: '' };
  const t0 = Date.now();
  try {
    const list = await s.search(key, 1);
    r.search = list.length;
    if (!list.length) { r.ms = Date.now() - t0; return r; }
    const info = await s.bookInfo(list[0].bookUrl);
    r.detail = (info.name || '(空)') + ' / ' + (info.author || '-');
    const chapters = await s.toc(info.tocUrl || list[0].bookUrl);
    r.toc = chapters.length;
    if (chapters.length) {
      const text = await s.content(chapters[0].url);
      r.content = text.length;
    }
  } catch (e) {
    r.err = e.message.slice(0, 70);
  }
  r.ms = Date.now() - t0;
  return r;
}

(async () => {
  const jobs = engine.sources.map((s, i) => one(s, i));
  const res = await Promise.all(jobs);
  for (const r of res) {
    const ok = r.search && r.toc && r.content;
    console.log(`${ok ? '✅' : (r.search ? '⚠️' : '·')} ${r.i} ${r.name.padEnd(18)} 搜${r.search} 目录${r.toc} 正文${r.content}字 ${r.ms}ms ${r.err} ${r.detail}`);
  }
})();
