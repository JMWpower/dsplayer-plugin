'use strict';
/*
 * 前端「本地 JSON 导入」端到端测试（无头 Edge + CDP）
 *   1. 起一个 headless Edge，打开面板 #repos
 *   2. 在页面里造一个 File 对象，调用页面自己的 importLocalFile()
 *   3. 校验 toast 文案、书源计数真的变了
 *   4. 收尾：把测试源删掉，关掉浏览器
 *
 * 用法：node test/ui-import-check.js [http://127.0.0.1:13000]
 */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const BASE = process.argv[2] || process.env.BASE || 'http://127.0.0.1:13000';
const PORT = 9333;
const EDGE = ['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => fs.existsSync(p));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function ok(cond, label, extra) {
  console.log((cond ? '  ✔ ' : '  ✘ ') + label + (extra ? '  ' + extra : ''));
  if (!cond) process.exitCode = 1;
  return cond;
}

async function cdp(wsUrl) {
  const ws = new WebSocket(wsUrl);
  let id = 0;
  const waiting = new Map();
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id);
      waiting.delete(msg.id);
      if (msg.error) reject(new Error(msg.error.message));
      else resolve(msg.result);
    }
  });
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', () => reject(new Error('CDP 连接失败')), { once: true });
  });
  const send = (method, params) => new Promise((resolve, reject) => {
    const mid = ++id;
    waiting.set(mid, { resolve, reject });
    ws.send(JSON.stringify({ id: mid, method, params: params || {} }));
  });
  const evaluate = async (expression, awaitPromise) => {
    const r = await send('Runtime.evaluate', { expression, awaitPromise: !!awaitPromise, returnByValue: true });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text + ' ' + JSON.stringify(r.exceptionDetails.exception && r.exceptionDetails.exception.description));
    return r.result.value;
  };
  return { send, evaluate, close: () => ws.close() };
}

(async () => {
  if (!EDGE) { console.log('跳过：本机没有 Edge，无法跑前端用例'); return; }
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'edge-legado-'));
  const child = spawn(EDGE, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--remote-debugging-port=' + PORT, '--user-data-dir=' + profile,
    '--window-size=1440,1200', BASE + '/#repos',
  ], { stdio: 'ignore', detached: false });

  let page = null;
  for (let i = 0; i < 40 && !page; i++) {
    await sleep(500);
    try {
      const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json();
      page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl);
    } catch (e) { /* 还没起来 */ }
  }
  if (!page) { child.kill(); console.log('  ✘ 浏览器没起来'); process.exitCode = 1; return; }

  const client = await cdp(page.webSocketDebuggerUrl);
  const before = await (await fetch(BASE + '/api/state')).json();

  const src = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'sources.json'), 'utf8'))[0];
  const probe = Object.assign({}, src, {
    bookSourceName: '前端导入测试源',
    bookSourceUrl: 'https://sma.yueyouxs.com/ui-import-test',
  });
  const fileText = JSON.stringify([probe]);

  // 等页面脚本就绪
  for (let i = 0; i < 30; i++) {
    const ready = await client.evaluate('typeof window.importLocalFile === "function" && !!document.querySelector("#local-import")');
    if (ready) break;
    await sleep(400);
  }
  ok(await client.evaluate('!!document.querySelector("#local-import")'), '源仓库页有「本地 JSON 导入」卡片');
  ok(await client.evaluate('!!document.querySelector("#manage-import")'), '源管理工具栏有「导入本地 JSON」按钮');

  const toast = await client.evaluate(`(async () => {
    const file = new File([${JSON.stringify(fileText)}], 'ui-import-test.json', { type: 'application/json' });
    await window.importLocalFile(file);
    return document.querySelector('#toast').textContent;
  })()`, true);
  ok(/ui-import-test\.json/.test(toast), 'toast 里有文件名', toast.slice(0, 70));
  ok(/新增 1/.test(toast), 'toast 报告新增 1 个', toast.slice(0, 90));

  const after = await (await fetch(BASE + '/api/state')).json();
  ok(after.data.total === before.data.total + 1, '书源总数 +1', before.data.total + ' → ' + after.data.total);
  ok(after.data.sources.some((s) => s.name === '前端导入测试源'), '新书源已出现在列表里');

  // 拖拽遮罩存在（不真的拖文件，只校验元素在）
  ok(await client.evaluate('!!document.querySelector("#drop-mask")'), '拖拽遮罩元素存在');

  // 清理
  const st = await (await fetch(BASE + '/api/state')).json();
  const hit = st.data.sources.find((s) => s.name === '前端导入测试源');
  if (hit) {
    await fetch(BASE + '/api/source/remove', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ index: hit.index }),
    });
  }
  const end = await (await fetch(BASE + '/api/state')).json();
  ok(end.data.total === before.data.total, '测试源已清理', '回到 ' + end.data.total + ' 个');

  client.close();
  child.kill();
  await sleep(300);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  console.log(process.exitCode ? '\n有失败项' : '\n全部通过');
})();
