'use strict';
/* 面板用到的接口逐个打一遍（含写操作，结束时恢复原状） */
const BASE = process.env.BASE || 'http://127.0.0.1:13000';

async function get(path) {
  const r = await fetch(BASE + path);
  const j = await r.json();
  return j;
}
async function post(path, body) {
  const r = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return r.json();
}
function ok(cond, label, extra) {
  console.log((cond ? '  ✔ ' : '  ✘ ') + label + (extra ? '  ' + extra : ''));
  if (!cond) process.exitCode = 1;
}

(async () => {
  const st0 = await get('/api/state');
  const st = st0.data || st0;
  ok(st0.ok, 'GET /api/state', st.total + ' 个书源 / 启用 ' + st.enabled);
  ok(Array.isArray(st.repos) && st.repos.length === 3, 'GET /api/state 仓库', st.repos.map((r) => r.name).join('、'));
  ok(!!st.bookSourceUrl, '书源 JSON 地址', st.bookSourceUrl);

  const br = await get('/api/browse?t=0&pg=1');
  ok(br.ok && br.data.list.length > 0, 'GET /api/browse', br.data.list.length + ' 本，' + br.data.name);
  ok(Array.isArray(br.data.sources) && br.data.sources.length > 0, '浏览页书源下拉', br.data.sources.length + ' 项');

  const ch = br.data.channels && br.data.channels[0];
  if (ch) {
    const b2 = await get('/api/browse?t=0&pg=1&ch=' + encodeURIComponent(ch.url));
    ok(b2.ok && b2.data.list.length > 0, 'GET /api/browse 频道', ch.title + ' → ' + b2.data.list.length + ' 本');
  } else {
    console.log('  - 该书源没有频道，跳过频道测试');
  }

  const se = await get('/api/browse?key=' + encodeURIComponent('剑来'));
  ok(se.ok && se.data.list.length > 0, 'GET /api/browse 搜索', se.data.list.length + ' 条');

  const idx = st.sources.findIndex((s) => s.enabled && s.searchable);
  const t0 = Date.now();
  const test = await post('/api/source/test', { index: idx });
  ok(test.ok, 'POST /api/source/test', test.data ? (test.data.count + ' 条 / ' + test.data.ms + 'ms') : test.error);

  const toggled = await post('/api/source/toggle', { index: idx });
  ok(toggled.ok && !toggled.data.enabled, 'POST /api/source/toggle 关', toggled.data && toggled.data.name);
  const st2raw = await get('/api/state');
  const st2 = st2raw.data || st2raw;
  ok(st2.enabled === st.enabled - 1, '关掉后启用数 -1', st2.enabled);
  const back = await post('/api/source/toggle', { index: idx, enabled: true });
  ok(back.ok && back.data.enabled, 'POST /api/source/toggle 开');

  const mv = await post('/api/source/move', { index: 1, delta: -1 });
  ok(mv.ok, 'POST /api/source/move', '移到 ' + mv.data.index);
  await post('/api/source/move', { index: 0, delta: 1 });

  const raw = await get('/api/source?i=0');
  ok(raw.ok && raw.data.bookSourceName, 'GET /api/source', raw.data.bookSourceName);

  const rp = await get('/api/repo?r=yiove&pg=1');
  ok(rp.ok && rp.data.items.length > 0, 'GET /api/repo', rp.data.items.length + ' 条 / 共 ' + rp.data.total);

  const rp2 = await get('/api/repo?r=yuancang&pg=1&key=' + encodeURIComponent('小说'));
  ok(rp2.ok, 'GET /api/repo 搜索', rp2.ok ? rp2.data.items.length + ' 条' : rp2.error);

  // 不重复导入，改用一条已存在的源验证「更新」路径
  if (rp.ok) {
    const first = rp.data.items[0];
    const im = await post('/api/import', { repo: 'yiove', id: first.id });
    ok(im.ok, 'POST /api/import（已存在→更新）',
      im.ok ? ('新增 ' + im.data.added.length + ' / 更新 ' + im.data.updated.length) : im.error);
  }

  console.log('\n接口检查完成，耗时约 ' + Math.round((Date.now() - t0) / 1000) + 's');
})();
