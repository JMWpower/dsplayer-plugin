'use strict';
const fs = require('fs');
const path = require('path');
const { Engine } = require('../core/engine');

const key = process.argv[2] || '斗罗大陆';
const only = process.argv[3];
const data = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'sources.json'), 'utf8'));
const engine = new Engine(data);

(async () => {
  const info = engine.info();
  console.log('书源数:', info.length);
  const jobs = engine.sources.map((s, i) => {
    if (only != null && parseInt(only, 10) !== i) return Promise.resolve({ i, n: 0, sample: '', ms: 0, err: '' });
    const t0 = Date.now();
    return s.search(key, 1)
      .then((list) => ({ i, n: list.length, sample: list[0] ? list[0].name + ' | ' + list[0].bookUrl : '', ms: Date.now() - t0 }))
      .catch((e) => ({ i, n: 0, sample: '', ms: Date.now() - t0, err: e.message.slice(0, 60) }));
  });
  const res = await Promise.all(jobs);
  for (const r of res) {
    const name = engine.sources[r.i].name;
    if (r.err) console.log(`✗ ${r.i} ${name}  ${r.ms}ms  ${r.err}`);
    else console.log(`${r.n ? '✓' : '·'} ${r.i} ${name}  ${r.n}条 ${r.ms}ms  ${r.sample.slice(0, 90)}`);
  }
})();
