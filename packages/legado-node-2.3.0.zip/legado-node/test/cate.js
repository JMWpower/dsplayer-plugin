'use strict';
const fs = require('fs'); const path = require('path');
const { Engine } = require('../core/engine');
const data = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'sources.json'), 'utf8'));
const engine = new Engine(data);
(async () => {
  const jobs = engine.sources.map(async (s, i) => {
    if (!s.channels.length) return { i, n: 0, ch: 0, sample: '', ms: 0 };
    const t0 = Date.now();
    try {
      const r = await engine.category(String(i), 1, s.channels[0].url);
      return { i, n: r.list.length, ch: s.channels.length, sample: r.list[0] ? r.list[0].vod_name : '', ms: Date.now() - t0, chName: s.channels[0].title };
    } catch (e) {
      return { i, n: 0, ch: s.channels.length, sample: '', err: e.message.slice(0, 50), ms: Date.now() - t0 };
    }
  });
  const res = await Promise.all(jobs);
  for (const r of res) {
    console.log(`${r.n ? '✓' : '·'} ${r.i} ${engine.sources[r.i].name.padEnd(18)} 频道${r.ch || 0} 「${r.chName || '-'}」 ${r.n}条 ${r.ms}ms ${r.sample} ${r.err || ''}`);
  }
})();
