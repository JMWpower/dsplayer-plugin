'use strict';
const fs=require('fs'),path=require('path');
const {Engine}=require('../core/engine');
const rule=require('../core/rule');
const {parseHTML,selectAll}=require('../core/html');
const data=JSON.parse(fs.readFileSync(path.join(__dirname,'..','sources.json'),'utf8'));
const e=new Engine(data);
const idx=parseInt(process.argv[2]||'0',10), key=process.argv[3]||'斗罗';
(async()=>{
  const s=e.sources[idx];
  console.log('源:',s.name,s.url);
  console.log('searchUrl:',s.searchUrl);
  const {splitSearchUrl}=require('../core/source');
  console.log('split:',JSON.stringify(splitSearchUrl(s.searchUrl)));
  const u=s.resolveUrl(rule.applyTemplate(splitSearchUrl(s.searchUrl).url,{key:encodeURIComponent(key),page:1}));
  console.log('URL:',u);
  const res=await s.fetch(u);
  console.log('status',res.status,'len',res.text.length);
  console.log('head:',res.text.slice(0,300).replace(/\s+/g,' '));
  const ctx=rule.makeContext({html:res.text,baseUrl:res.url});
  const listRule=s.rules.search.bookList;
  console.log('bookList规则:',JSON.stringify(listRule));
  const items=rule.evalElements(listRule,ctx,ctx.root);
  console.log('bookList命中:',items.length);
  if(items.length){
    const el=items[0];
    for(const f of ['name','author','bookUrl','coverUrl','intro','kind']){
      console.log(' ',f,'=',JSON.stringify(rule.evalString(s.rules.search[f]||'',ctx,el)).slice(0,120));
    }
  }
})();
