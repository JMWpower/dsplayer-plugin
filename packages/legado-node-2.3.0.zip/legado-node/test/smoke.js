'use strict';
/* 冒烟测试：把所有新接口跑一遍，打印状态码/长度/关键片段 */
const BASE = process.env.BASE || 'http://127.0.0.1:13000';

async function hit(path, opts) {
  const t0 = Date.now();
  const res = await fetch(BASE + path, opts);
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch (e) { /* not json */ }
  return { path, status: res.status, ms: Date.now() - t0, len: text.length, text, json };
}

function show(r, note) {
  const head = (r.json ? JSON.stringify(r.json).slice(0, 160) : r.text.replace(/\s+/g, ' ').slice(0, 160));
  console.log(String(r.status).padEnd(4), String(r.ms + 'ms').padEnd(7), String(r.len).padEnd(8), r.path, note || '', '|', head);
}

(async () => {
  const tests = [
    ['/', '面板'],
    ['/assets/app.css', '样式'],
    ['/assets/app.js', '脚本'],
    ['/api/state', '状态'],
    ['/legado_html.json', '书源JSON'],
    ['/hs/browse?t=0&pg=1', '书库'],
    ['/hs/search?key=%E5%89%91%E6%9D%A5&page=1', '搜索'],
    ['/hs/manage', '源管理'],
    ['/hs/source?i=0', '源详情'],
    ['/hs/repos', '仓库列表'],
    ['/hs/repo?r=yiove&pg=1', '仓库内容'],
    ['/hs/repo?r=yuancang&pg=1', '仓库内容'],
    ['/hs/repo?r=yckceo&pg=1', '仓库内容'],
    ['/status', '旧状态页'],
  ];
  const results = [];
  for (const [p, note] of tests) {
    try {
      const r = await hit(p);
      results.push({ ...r, note });
      show(r, note);
    } catch (e) {
      console.log('ERR ', p, e.message);
    }
  }

  // 书源 JSON 规则自检
  const js = results.find((r) => r.path === '/legado_html.json');
  if (js && js.json) {
    console.log('\n[书源JSON] name=' + js.json.bookSourceName + ' url=' + js.json.bookSourceUrl);
    console.log('[书源JSON] searchUrl=' + js.json.searchUrl);
    console.log('[书源JSON] exploreUrl=' + js.json.exploreUrl);
    console.log('[书源JSON] ruleExplore=' + JSON.stringify(js.json.ruleExplore));
  }

  // 仓库列表解析数量
  for (const r of results.filter((x) => x.path.startsWith('/hs/repo'))) {
    const n = (r.text.match(/class="chapters"/g) || []).length;
    const links = (r.text.match(/\/hs\/import\?/g) || []).length;
    console.log('[仓库]', r.path, 'import 链接数=', links, 'chapters块=', n);
  }
})();
