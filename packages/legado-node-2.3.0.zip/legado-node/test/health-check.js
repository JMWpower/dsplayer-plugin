'use strict';
/*
 * 书源体检：确认「没内容」这件事有明确状态和原因，而不是一片空白。
 * 用法：node test/health-check.js [服务地址]
 */

const { sanitizeHeaders } = require('../core/http');

const BASE = (process.argv[2] || 'http://127.0.0.1:13000').replace(/\/$/, '');
let fail = 0;

function check(name, ok, extra) {
  console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : ''));
  if (!ok) fail++;
}

async function json(path, init) {
  const res = await fetch(BASE + path, init);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(path + ' HTTP ' + res.status + ' ' + JSON.stringify(body).slice(0, 120));
  return body.data !== undefined ? body.data : body;
}

(async () => {
  // 1. 头名清洗：书源里的全角/不换行连字符要能修好，否则 fetch 直接抛 ByteString
  const h1 = sanitizeHeaders({ 'User\u2011Agent': 'UA-1', 'Referer': 'https://a.com', '坏头 名': 'x' });
  check('header 名修好 U+2011', h1['User-Agent'] === 'UA-1', JSON.stringify(h1));
  check('非法头名被丢弃', !Object.keys(h1).some((k) => /坏头/.test(k)), JSON.stringify(h1));
  const h2 = sanitizeHeaders({ 'X-Test': '中文值' });
  check('头值全是非 Latin1 时整条丢弃', !('X-Test' in h2), JSON.stringify(h2));

  // 2. /api/state 每个源都带状态字段
  const st = await json('/api/state');
  check('state.sources 非空', Array.isArray(st.sources) && st.sources.length > 0, st.sources.length + ' 个源');
  const noState = (st.sources || []).filter((s) => !s.state);
  check('每个源都有 state', noState.length === 0, noState.map((s) => s.name).join(','));
  check('broken 是数字', typeof st.broken === 'number', String(st.broken));

  // 3. /api/health 全量体检
  const t0 = Date.now();
  const h = await json('/api/health', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
  const ms = Date.now() - t0;
  check('health.summary.total == 引擎源数', h.summary.total === (st.engine ? st.engine.count : h.summary.total),
    h.summary.total + ' vs ' + (st.engine && st.engine.count));
  check('health.list 长度一致', (h.list || []).length === h.summary.total, (h.list || []).length + ' 条');
  check('health.summary.ok+bad == total', h.summary.ok + h.summary.bad === h.summary.total,
    h.summary.ok + '+' + h.summary.bad);
  check('至少一个源有内容', h.summary.ok > 0, h.summary.ok + ' 个可用');
  const okRow = (h.list || []).find((x) => x.count > 0);
  check('可用源给出书名数', okRow && okRow.count > 0, okRow ? okRow.name + ' ' + okRow.count + ' 本' : '无');
  const badRow = (h.list || []).find((x) => !x.count);
  if (badRow) {
    check('不可用源给出原因', !!badRow.msg, badRow.name + '：' + badRow.msg);
  }
  console.log('health 用时 ' + ms + 'ms：' + h.summary.ok + '/' + h.summary.total + ' 个源有内容');

  // 4. 逛一个空源时页面要说清楚为什么空
  if (badRow) {
    const html = await (await fetch(BASE + '/hs/browse?t=' + badRow.index)).text();
    check('空源页面有 .notice 提示', /class="notice"/.test(html),
      (html.match(/class="notice"[\s\S]{0,120}/) || [''])[0].replace(/\s+/g, ' ').slice(0, 90));
  }

  // 5. 单个源体检
  if (okRow) {
    const one = await json('/api/health', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ index: okRow.index }),
    });
    check('单个源体检返回一条', (one.list || []).length === 1 && one.list[0].index === okRow.index);
  }

  console.log(fail ? '\n' + fail + ' 项失败' : '\n全部通过');
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('健康检查异常：' + e.message); process.exit(2); });
