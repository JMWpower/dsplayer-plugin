'use strict';
/*
 * 单个乐读书源（bookSource）实现
 * 对应 Legado 的 BookSource：search / explore / bookInfo / toc / content
 */

const { request, CookieJar } = require('./http');
const gbk = require('./gbk');
const rule = require('./rule');
const { parseHTML, selectAll, findByText, selectorFromLegado } = require('./html');

function toAbsolute(base, url) {
  if (!url) return '';
  const u = String(url).trim();
  if (!u) return '';
  if (/^https?:\/\//i.test(u)) return u;
  if (u.startsWith('//')) return 'https:' + u;
  try {
    return new URL(u, base).toString();
  } catch (e) {
    return u;
  }
}

function stripTags(html) {
  return String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h[1-6]|li|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#(\d+);/g, (m, d) => String.fromCharCode(parseInt(d, 10)))
    .replace(/[ \t\u00a0\u3000]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** 从书源注释里抽「备用源URL：xxx」，再加上 bookSourceUrl 里 # 后面写的备选 */
function parseAltHosts(raw, primary) {
  const out = [];
  const add = (u) => {
    let s = String(u || '').trim().replace(/[，,。;；]+$/, '').replace(/\/+$/, '');
    if (!s) return;
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    try { s = new URL(s).origin; } catch (e) { return; }
    if (!s || s === primary || out.indexOf(s) >= 0) return;
    out.push(s);
  };
  const comment = String(raw.bookSourceComment || '');
  const re = /备用(?:源)?(?:URL|域名|地址)\s*[:：]\s*(https?:\/\/[^\s，,；;]+)/gi;
  let m;
  while ((m = re.exec(comment)) !== null) add(m[1]);
  return out.slice(0, 4);
}

function splitSearchUrl(raw) {
  const str = String(raw || '').trim();
  if (!str) return { url: '', options: {} };
  const braceAt = str.indexOf(',{');
  if (braceAt < 0) return { url: str, options: {} };
  const url = str.slice(0, braceAt).trim();
  const jsonPart = str.slice(braceAt + 1).trim();
  try {
    return { url, options: JSON.parse(jsonPart) };
  } catch (e) {
    return { url, options: {} };
  }
}

function parseExplore(raw) {
  // 两种格式：GBK 风格 "标题::url\n标题::url"  /  JSON 数组 [{title,url}]
  const str = String(raw || '').trim();
  if (!str) return [];
  if (str.startsWith('[')) {
    try {
      const arr = JSON.parse(str);
      return arr
        .filter((x) => x && typeof x === 'object')
        .map((x) => ({ title: String(x.title || '').trim(), url: String(x.url || '').trim() }))
        .filter((x) => x.title && x.url);
    } catch (e) {
      return [];
    }
  }
  const out = [];
  for (const line of str.split(/\r?\n/)) {
    const t = line.trim();
    if (!t) continue;
    const idx = t.indexOf('::');
    if (idx < 0) continue;
    const title = t.slice(0, idx).trim();
    const url = t.slice(idx + 2).trim();
    if (title && url) out.push({ title, url });
  }
  return out;
}

function buildPageUrl(template, page) {
  // Legado 分页语法 <a,b>：第 1 页用 a，第 2 页起用 b（b 里可含 {{page}}）
  let t = String(template || '');
  t = t.replace(/<([^<>]*)>/g, (m, inner) => {
    const comma = inner.indexOf(',');
    if (comma < 0) {
      return /\{\{\s*page\s*\}\}/.test(inner) ? inner.replace(/\{\{\s*page\s*\}\}/g, '1') : String(page);
    }
    const a = inner.slice(0, comma);
    const b = inner.slice(comma + 1);
    if (page <= 1) return a;
    return /\{\{\s*page\s*\}\}/.test(b) ? b : String(page);
  });
  t = t.replace(/\{\{\s*page\s*\}\}/g, String(page));
  return t;
}


/** 兜底：全页找文字最多的块（排除 script/style/nav/header/footer） */
function pickLargestBlock(html) {
  const { parseHTML } = require('./html');
  const root = parseHTML(html);
  const skip = /^(script|style|nav|header|footer|aside|form|select|ol|ul)$/i;
  let best = null;
  let bestLen = 0;
  for (const el of root.descendants()) {
    if (skip.test(el.tag)) continue;
    const cls = (el.attrs.class || '') + ' ' + (el.attrs.id || '');
    if (/nav|menu|footer|header|breadcrumb|comment|ad-|advert/i.test(cls)) continue;
    const t = el.textContent.trim();
    if (t.length < bestLen) continue;
    // 只看包含较多换行的块，避免把整个 body 选进来
    const brCount = (el.innerHTML.match(/<br\s*\/?>/gi) || []).length;
    if (brCount < 5) continue;
    best = el;
    bestLen = t.length;
  }
  return best ? best.innerHTML : '';
}

/** 容错取值：忽略规则末尾的索引，选中文字最多的那个元素 */
function tolerantSelect(ruleStr, html, baseUrl) {
  if (!ruleStr) return '';
  let main = String(ruleStr).split('##')[0];
  main = main.split('@').filter((p) => p && !/^(text|html|all|textNodes|ownText)$/i.test(p.trim())).join('@');
  main = main.replace(/(?:\.-?\d+(?::\d+)?|\[[\d,\s-]+\])$/, '');
  const ctx = rule.makeContext({ html, baseUrl });
  let els = [];
  try { els = rule.evalElements(main, ctx, ctx.root); } catch (e) { els = []; }
  if (!els.length) return '';
  let best = null;
  let bestLen = 0;
  for (const el of els) {
    const t = el.textContent.trim();
    if (t.length > bestLen) { best = el; bestLen = t.length; }
  }
  return best && bestLen > 30 ? best.innerHTML : '';
}

class BookSource {
  constructor(raw, index) {
    this.raw = raw || {};
    this.index = index == null ? 0 : index;
    this.name = String(this.raw.bookSourceName || ('书源' + (this.index + 1)));
    this.url = String(this.raw.bookSourceUrl || '').split('#')[0].trim();
    this.enabled = this.raw.enabled !== false;
    this.jar = new CookieJar();
    this.header = {};
    this.searchUrl = this.raw.searchUrl || '';
    this.exploreUrl = this.raw.exploreUrl || '';
    // 备用域名：书源注释里常写 "备用源URL：https://xxx"，主域名挂了自动切
    this.altHosts = parseAltHosts(this.raw, this.url);
    this.activeHost = this.url;
    this.rules = {
      search: this.raw.ruleSearch || {},
      explore: this.raw.ruleExplore || {},
      bookInfo: this.raw.ruleBookInfo || {},
      toc: this.raw.ruleToc || {},
      content: this.raw.ruleContent || {},
    };
    if (this.raw.header) {
      try {
        const h = typeof this.raw.header === 'string' ? JSON.parse(this.raw.header) : this.raw.header;
        for (const k in h) this.header[k] = h[k];
      } catch (e) { /* ignore */ }
    }
    this.channels = parseExplore(this.exploreUrl);
  }

  resolveUrl(path) {
    return toAbsolute((this.activeHost || this.url) + '/', path);
  }

  ctx(html, extra) {
    return rule.makeContext(Object.assign({
      html,
      baseUrl: this.activeHost || this.url,
      host: this.activeHost || this.url,
      cookie: this.jar.header(),
      title: this.name,
    }, extra || {}));
  }

  /** 把 url 的域名换成指定 host */
  _swapHost(url, host) {
    try {
      const u = new URL(url);
      const h = new URL(host);
      return h.origin + u.pathname + u.search;
    } catch (e) {
      return url;
    }
  }

  async fetch(url, opts = {}) {
    const cfg = Object.assign({
      headers: this.header,
      jar: this.jar,
      timeout: 15000,
      retry: 1,
      referer: this.activeHost || this.url,
    }, opts);

    const hosts = [this.activeHost || this.url].concat(this.altHosts || []);
    let lastErr = null;
    let lastRes = null;
    for (let i = 0; i < hosts.length; i++) {
      const host = hosts[i];
      let target = url;
      if (i > 0) target = this._swapHost(url, host);
      try {
        const res = await request(target, cfg);
        if (res && res.ok) {
          if (host !== this.activeHost) {
            this.activeHost = host;
            this.url = host;
            if (typeof console !== 'undefined') {
              console.log('[书源] ' + this.name + ' 切换到备用域名 ' + host);
            }
          }
          return res;
        }
        lastRes = res;
      } catch (e) {
        lastErr = e;
      }
    }
    if (lastRes) return lastRes;
    throw lastErr || new Error('请求失败');
  }

  /** 搜索 */
  async search(key, page = 1) {
    if (!this.searchUrl) return [];
    const cleaned = String(this.searchUrl)
      .split(/\r?\n/)
      .filter((line) => !line.trim().startsWith('{{'))
      .join('\n')
      .trim();
    // 搜索地址是 JS 脚本（<js> / @js:）的源，HTML 规则引擎没法执行
    if (/^(<js>|@?js\s*:)/i.test(cleaned)) {
      throw new Error('这个源的搜索规则是 JS 脚本（' + cleaned.slice(0, 4) + '…），当前只支持 HTML 规则，搜不了');
    }
    const { url, options } = splitSearchUrl(cleaned);
    let target = url;
    let method = (options.method || 'GET').toUpperCase();
    let body;
    const cs = String(options.charset || '').toLowerCase();
    const gbkLike = /gbk|gb2312|gb18030/.test(cs);
    const keyEnc = gbkLike ? gbk.encodeURIComponentGbk(key) : encodeURIComponent(key);
    const vars = { key: keyEnc, page };

    if (method === 'POST' && options.body) {
      body = rule.applyTemplate(String(options.body), vars);
      target = this.resolveUrl(rule.applyTemplate(target, vars));
    } else {
      target = this.resolveUrl(rule.applyTemplate(target, vars));
    }

    const res = await this.fetch(target, {
      method,
      body,
      charset: options.charset,
      headers: Object.assign({}, this.header, options.headers || {}, method === 'POST'
        ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}),
    });
    if (!res.ok) return [];
    return this.parseList(res.text, res.url, this.rules.search, '*');
  }

  /** 分类/发现 */
  async explore(channelUrl, page = 1) {
    let tpl = channelUrl || (this.channels[0] && this.channels[0].url) || '';
    if (!tpl) return [];
    const target = this.resolveUrl(buildPageUrl(tpl, page));
    const res = await this.fetch(target);
    if (!res.ok) return [];
    let cfg = this.rules.explore;
    if (!cfg || !Object.keys(cfg).length || !cfg.bookList) {
      // 很多源没写 ruleExplore，直接借搜索规则解析分类页
      cfg = Object.assign({}, this.rules.search);
    }
    const out = this.parseList(res.text, res.url, cfg, '*', true);
    return out;
  }

  parseList(html, baseUrl, cfg, defaultNameRule, allowEmptyBookUrl) {
    const ctx = this.ctx(html, { baseUrl });
    let bookListRule = cfg && cfg.bookList;
    let items = [];
    if (bookListRule) {
      items = rule.evalElements(bookListRule, ctx, ctx.root);
    }
    if (!items.length) {
      items = selectAll(ctx.root, 'a[href]').filter((a) => {
        const t = a.textContent.trim();
        return t.length >= 2 && t.length <= 60 && /book|read|info|content|\/\d+/i.test(a.attr('href') || '');
      });
    }
    const out = [];
    for (const el of items.slice(0, 60)) {
      const book = this.extractBook(el, baseUrl, cfg || {}, ctx);
      if (book && book.name) out.push(book);
      else if (allowEmptyBookUrl && book && book.bookUrl) out.push(book);
    }
    // 去重
    const seen = new Set();
    return out.filter((b) => {
      const k = b.bookUrl;
      if (!k || seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  extractBook(el, baseUrl, cfg, ctxHtml) {
    const val = (field, dflt) => {
      const spec = cfg[field] === undefined ? dflt : cfg[field];
      if (!spec) return '';
      return rule.evalString(spec, ctxHtml, el);
    };
    const name = val('name', 'text') || el.textContent.trim().slice(0, 40);
    const bookUrl = toAbsolute(baseUrl, val('bookUrl', 'href'));
    const coverUrl = toAbsolute(baseUrl, val('coverUrl', ''));
    return {
      name: name.trim(),
      author: val('author', '').trim(),
      kind: val('kind', '').trim(),
      lastChapter: val('lastChapter', '').trim(),
      intro: val('intro', '').trim(),
      coverUrl,
      bookUrl,
      wordCount: val('wordCount', '').trim(),
    };
  }

  /** 书籍详情 */
  async bookInfo(bookUrl) {
    const res = await this.fetch(bookUrl);
    if (!res.ok) throw new Error('详情页打不开 ' + res.status);
    const cfg = this.rules.bookInfo;
    let html = res.text;
    let ctx = this.ctx(html, { baseUrl: res.url });

    if (cfg.init) {
      const initVal = rule.evalString(cfg.init, ctx, ctx.root);
      if (initVal && initVal.trim().startsWith('<')) {
        html = initVal;
        ctx = this.ctx(html, { baseUrl: res.url });
      }
    }
    const get = (field) => (cfg[field] ? rule.evalString(cfg[field], ctx, ctx.root) : '');
    let tocUrl = get('tocUrl');
    tocUrl = tocUrl ? toAbsolute(res.url, tocUrl.split('\n')[0]) : res.url;
    return {
      name: get('name') || '',
      author: get('author') || '',
      kind: get('kind') || '',
      lastChapter: get('lastChapter') || '',
      intro: get('intro') || '',
      coverUrl: toAbsolute(res.url, get('coverUrl') || ''),
      wordCount: get('wordCount') || '',
      tocUrl,
      bookUrl,
    };
  }

  /** 目录（含多页 nextTocUrl） */
  async toc(tocUrl) {
    const cfg = this.rules.toc;
    let url = tocUrl;
    const chapters = [];
    const seenChapter = new Map();
    const seenPage = new Set();
    let guard = 0;
    while (url && !seenPage.has(url) && guard < 30) {
      seenPage.add(url);
      guard++;
      const res = await this.fetch(url);
      if (!res.ok) break;
      const ctx = this.ctx(res.text, { baseUrl: res.url });
      let listRule = cfg.chapterList;
      let items = listRule ? rule.evalElements(listRule, ctx, ctx.root) : [];
      if (!items.length) items = selectAll(ctx.root, 'a[href]').filter((a) => /\d/.test(a.textContent) && a.textContent.trim().length < 60);

      for (const el of items) {
        const name = rule.evalString(cfg.chapterName || 'text', ctx, el).trim();
        let href = rule.evalString(cfg.chapterUrl || 'href', ctx, el).trim();
        href = toAbsolute(res.url, href.split('\n')[0]);
        if (!href) continue;
        // 同一章在页面里可能出现多次（"最新章节"块 + 完整目录），保留最后一次出现的位置
        if (seenChapter.has(href)) {
          const prev = seenChapter.get(href);
          const at = chapters.indexOf(prev);
          if (at >= 0) chapters.splice(at, 1);
        }
        const item = { name: name || ('第' + (chapters.length + 1) + '章'), url: href };
        chapters.push(item);
        seenChapter.set(href, item);
      }
      if (chapters.length >= 3000) break;

      // 下一页目录
      let nextUrl = '';
      if (cfg.nextTocUrl) {
        const v = rule.evalString(cfg.nextTocUrl, ctx, ctx.root);
        if (v) nextUrl = v.split('\n')[0].trim();
        if (nextUrl && !/^https?:/i.test(nextUrl)) nextUrl = toAbsolute(res.url, nextUrl);
      }
      url = nextUrl;
    }
    return chapters;
  }

  /** 正文 */
  async content(chapterUrl) {
    const cfg = this.rules.content;
    let html = '';
    let url = chapterUrl;
    const seen = new Set();
    let guard = 0;
    while (url && !seen.has(url) && guard < 8) {
      seen.add(url);
      guard++;
      const res = await this.fetch(url);
      if (!res.ok) break;
      const ctx = this.ctx(res.text, { baseUrl: res.url });
      let part = cfg.content ? rule.evalString(cfg.content, ctx, ctx.root) : '';
      if (!part) {
        const guess = selectAll(ctx.root, '#content, #chaptercontent, .content, .read-content, .showtxt, #nr1, .yd_text2');
        part = guess.length ? guess[0].innerHTML : '';
      }
      if (part) html += '<div>' + part + '</div>';
      let next = '';
      if (cfg.nextContentUrl) {
        next = rule.evalString(cfg.nextContentUrl, ctx, ctx.root).split('\n')[0].trim();
        if (next && !/^https?:/i.test(next)) next = toAbsolute(res.url, next);
      }
      url = next;
    }
    // 规则没抓到内容（索引写法与站点结构不完全对齐时常见）→ 忽略索引，取最大的一段
    if (stripTags(html).length < 80) {
      try {
        const res = await this.fetch(chapterUrl);
        if (res.ok) {
          const guess = tolerantSelect(cfg.content, res.text, res.url);
          if (guess) html = guess;
        }
      } catch (e) { /* ignore */ }
    }

    let text = stripTags(html);
    if (cfg.replaceRegex) {
      const parts = String(cfg.replaceRegex).split('##');
      const pattern = parts[1] !== undefined ? parts[1] : parts[0];
      const repl = parts[2] !== undefined ? parts[2] : '';
      try { text = text.replace(new RegExp(pattern, 'g'), repl); } catch (e) { /* ignore */ }
    }
    return text;
  }
}

module.exports = { BookSource, stripTags, toAbsolute, parseExplore, splitSearchUrl, buildPageUrl };
