'use strict';
/*
 * 请求层：cookie 自动管理 + 编码自动识别（gbk/gb2312/big5/utf-8）+ 重试 + 超时
 * 只用 Node 内置能力（fetch / TextDecoder），不需要任何第三方包。
 */

const DEFAULT_UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36';

class CookieJar {
  constructor() { this.map = new Map(); }

  setFromResponse(res, url) {
    let list = [];
    try {
      if (typeof res.headers.getSetCookie === 'function') list = res.headers.getSetCookie();
    } catch (e) { list = []; }
    if (!list || !list.length) {
      const raw = res.headers.get('set-cookie');
      if (raw) list = [raw];
    }
    for (const item of list) {
      const first = String(item).split(';')[0];
      const eq = first.indexOf('=');
      if (eq <= 0) continue;
      const name = first.slice(0, eq).trim();
      const value = first.slice(eq + 1).trim();
      if (/expires=Thu, 01 Jan 1970/i.test(item) || value === 'deleted') this.map.delete(name);
      else this.map.set(name, value);
    }
  }

  header() {
    if (!this.map.size) return '';
    return Array.from(this.map.entries()).map(([k, v]) => k + '=' + v).join('; ');
  }
}

function detectCharset(buf, contentType) {
  const head = Buffer.from(buf.slice(0, 4096)).toString('latin1');
  let m = /charset\s*=\s*["']?([\w-]+)/i.exec(contentType || '');
  if (m) return m[1].toLowerCase();
  m = /<meta[^>]+charset\s*=\s*["']?([\w-]+)/i.exec(head);
  if (m) return m[1].toLowerCase();
  m = /<meta[^>]+content\s*=\s*["'][^"']*charset\s*=\s*([\w-]+)/i.exec(head);
  if (m) return m[1].toLowerCase();
  return 'utf-8';
}

function decodeBody(buf, charset) {
  const cs = String(charset || 'utf-8').toLowerCase().replace(/^utf8$/, 'utf-8');
  const alias = { gb2312: 'gbk', gb18030: 'gbk', 'x-gbk': 'gbk', gbk: 'gbk', big5: 'big5', 'utf-8': 'utf-8', utf8: 'utf-8', 'iso-8859-1': 'utf-8' };
  const name = alias[cs] || cs;
  try {
    return new TextDecoder(name).decode(buf);
  } catch (e) {
    try { return new TextDecoder('utf-8').decode(buf); } catch (e2) { return Buffer.from(buf).toString('utf8'); }
  }
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

/**
 * 书源里的 header 经常有脏字符：全角连字符、不换行连字符（U+2011）、中文，
 * 直接丢给 fetch 会抛 “Cannot convert argument to a ByteString”。
 * 这里把名字修好（常见请求头统一大小写），值里的非法字符去掉，修不好的头直接丢掉。
 */
const HEADER_TOKEN = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
const CANON_HEADERS = {
  'user-agent': 'User-Agent', referer: 'Referer', referrer: 'Referer', cookie: 'Cookie',
  accept: 'Accept', 'accept-language': 'Accept-Language', 'accept-encoding': 'Accept-Encoding',
  'content-type': 'Content-Type', 'content-length': 'Content-Length', origin: 'Origin',
  authorization: 'Authorization', 'cache-control': 'Cache-Control', 'x-requested-with': 'X-Requested-With',
};

function fixHeaderName(name) {
  const s = String(name || '')
    .replace(/[\u2010-\u2015\u2212\u2043\uFE63\uFF0D]/g, '-') // 各种横线 → ASCII '-'
    .replace(/[^\x21-\x7e]/g, '')                             // 其余非 ASCII 去掉
    .trim();
  if (!s || !HEADER_TOKEN.test(s)) return '';
  return CANON_HEADERS[s.toLowerCase()] || s;
}

function fixHeaderValue(v) {
  return String(v == null ? '' : v).replace(/[\r\n]+/g, ' ').replace(/[^\x09\x20-\xff]/g, '');
}

function sanitizeHeaders(input) {
  const out = {};
  if (!input || typeof input !== 'object') return out;
  for (const k of Object.keys(input)) {
    const name = fixHeaderName(k);
    if (!name) continue;
    const value = fixHeaderValue(input[k]);
    if (!value) continue;
    if (out[name] === undefined) out[name] = value;
  }
  return out;
}

/**
 * @param {string} url
 * @param {object} opts {method, headers, body, charset, timeout, jar, retry, referer}
 * @returns {Promise<{ok:boolean, status:number, url:string, text:string, headers:Headers}>}
 */
async function request(url, opts = {}) {
  const timeout = opts.timeout || 15000;
  const retry = opts.retry === undefined ? 1 : opts.retry;
  const jar = opts.jar;
  let lastErr = null;

  for (let attempt = 0; attempt <= retry; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const headers = Object.assign({ 'User-Agent': DEFAULT_UA }, sanitizeHeaders(opts.headers));
      if (jar && jar.header() && !headers.Cookie) headers.Cookie = jar.header();
      if (opts.referer && !headers.Referer) headers.Referer = opts.referer;
      if (!headers['Accept-Language']) headers['Accept-Language'] = 'zh-CN,zh;q=0.9';
      if (!headers.Accept) headers.Accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';

      const res = await fetch(url, {
        method: opts.method || 'GET',
        headers,
        body: opts.body,
        redirect: 'follow',
        signal: controller.signal,
        // 部分站点对 HTTP/2 指纹敏感时，这里保持默认即可
      });
      clearTimeout(timer);
      if (jar) jar.setFromResponse(res, url);
      const buf = Buffer.from(await res.arrayBuffer());
      const contentType = res.headers.get('content-type') || '';
      const charset = opts.charset || detectCharset(buf, contentType);
      const text = opts.raw ? buf : decodeBody(buf, charset);
      return { ok: res.ok, status: res.status, url: res.url || url, text, headers: res.headers };
    } catch (e) {
      clearTimeout(timer);
      lastErr = e;
      if (attempt < retry) await sleep(400 + attempt * 600);
    }
  }
  const err = new Error('请求失败: ' + (lastErr && lastErr.message ? lastErr.message : '未知错误'));
  err.cause = lastErr;
  err.url = url;
  throw err;
}

module.exports = { request, CookieJar, decodeBody, detectCharset, DEFAULT_UA, sleep, sanitizeHeaders };
