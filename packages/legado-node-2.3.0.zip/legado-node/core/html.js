'use strict';
/*
 * 零依赖 HTML 解析 + CSS 选择器内核
 * 目标：跑得动 Legado（阅读）书源里出现的选择器写法，
 *       class.xxx / id.xxx / tag.xxx / text.xxx / 原生 CSS / 索引 [0] .0 .1:3
 */

const VOID_TAGS = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
  'link', 'meta', 'param', 'source', 'track', 'wbr']);

const RAW_TEXT_TAGS = new Set(['script', 'style', 'textarea', 'title']);

const ENTITIES = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: '\u00a0',
  copy: '\u00a9', reg: '\u00ae', trade: '\u2122', hellip: '\u2026',
  mdash: '\u2014', ndash: '\u2013', lsquo: '\u2018', rsquo: '\u2019',
  ldquo: '\u201c', rdquo: '\u201d', middot: '\u00b7', bull: '\u2022',
  times: '\u00d7', divide: '\u00f7', deg: '\u00b0', yen: '\u00a5',
  euro: '\u20ac', pound: '\u00a3', sect: '\u00a7', para: '\u00b6',
  laquo: '\u00ab', raquo: '\u00bb', ensp: '\u2002', emsp: '\u2003',
  thinsp: '\u2009', zwnj: '\u200c', zwj: '\u200d', shy: '\u00ad',
  dagger: '\u2020', Dagger: '\u2021', permil: '\u2030', prime: '\u2032',
  Prime: '\u2033', lsaquo: '\u2039', rsaquo: '\u203a', oline: '\u203e',
  frasl: '\u2044', minus: '\u2212', le: '\u2264', ge: '\u2265',
  ne: '\u2260', asymp: '\u2248', infin: '\u221e', sum: '\u2211',
  prod: '\u220f', radic: '\u221a', int: '\u222b', part: '\u2202',
  forall: '\u2200', exist: '\u2203', empty: '\u2205', isin: '\u2208',
  notin: '\u2209', cap: '\u2229', cup: '\u222a', sub: '\u2282',
  sup: '\u2283', nsub: '\u2284', and: '\u2227', or: '\u2228',
  not: '\u00ac', there4: '\u2234', sim: '\u223c', cong: '\u2245',
  alpha: '\u03b1', beta: '\u03b2', gamma: '\u03b3', delta: '\u03b4',
  epsilon: '\u03b5', zeta: '\u03b6', eta: '\u03b7', theta: '\u03b8',
  iota: '\u03b9', kappa: '\u03ba', lambda: '\u03bb', mu: '\u03bc',
  nu: '\u03bd', xi: '\u03be', omicron: '\u03bf', pi: '\u03c0',
  rho: '\u03c1', sigma: '\u03c3', tau: '\u03c4', upsilon: '\u03c5',
  phi: '\u03c6', chi: '\u03c7', psi: '\u03c8', omega: '\u03c9',
  Alpha: '\u0391', Beta: '\u0392', Gamma: '\u0393', Delta: '\u0394',
  Theta: '\u0398', Lambda: '\u039b', Pi: '\u03a0', Sigma: '\u03a3',
  Phi: '\u03a6', Psi: '\u03a8', Omega: '\u03a9', star: '\u2606',
  starf: '\u2605', check: '\u2713', cross: '\u2717', hearts: '\u2665',
};

function decodeEntities(str) {
  if (str.indexOf('&') < 0) return str;
  return str.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z][a-zA-Z0-9]*);/g, (m, body) => {
    if (body[0] === '#') {
      const code = body[1] === 'x' || body[1] === 'X'
        ? parseInt(body.slice(2), 16)
        : parseInt(body.slice(1), 10);
      if (!isFinite(code) || code <= 0) return m;
      try { return String.fromCodePoint(code); } catch (e) { return m; }
    }
    const hit = ENTITIES[body];
    return hit === undefined ? m : hit;
  });
}

class TextNode {
  constructor(text, parent) {
    this.type = 'text';
    this.text = text;
    this.parent = parent;
  }
  get textContent() { return this.text; }
  get children() { return EMPTY; }
  get attrMap() { return EMPTY_MAP; }
}

class Element {
  constructor(tag, attrs, parent) {
    this.type = 'tag';
    this.tag = tag;
    this.attrs = attrs;
    this.parent = parent;
    this.children = [];
    this._text = null;
  }

  get attrMap() { return this.attrs; }

  attr(name) {
    if (name == null) return undefined;
    const v = this.attrs[String(name).toLowerCase()];
    return v === undefined ? undefined : v;
  }

  hasAttr(name) {
    return Object.prototype.hasOwnProperty.call(this.attrs, String(name).toLowerCase());
  }

  get id() { return this.attrs.id; }

  get classList() {
    const c = this.attrs.class;
    return c ? c.split(/\s+/).filter(Boolean) : EMPTY;
  }

  get textContent() {
    if (this._text !== null) return this._text;
    if (RAW_TEXT_TAGS.has(this.tag)) {
      let s = '';
      for (const c of this.children) s += c.type === 'text' ? c.text : c.textContent;
      this._text = s;
      return s;
    }
    let out = '';
    const walk = (node) => {
      for (const c of node.children) {
        if (c.type === 'text') out += c.text;
        else {
          if (c.tag === 'br') { out += '\n'; continue; }
          if (c.tag === 'script' || c.tag === 'style') continue;
          walk(c);
        }
      }
    };
    walk(this);
    this._text = out;
    return out;
  }

  get innerHTML() {
    let out = '';
    for (const c of this.children) out += c.type === 'text' ? escapeText(c.text) : serializeNode(c);
    return out;
  }

  get outerHTML() { return serializeNode(this); }

  // 直接子元素
  get childElements() {
    return this.children.filter((c) => c.type === 'tag');
  }

  * descendants() {
    for (const c of this.children) {
      if (c.type !== 'tag') continue;
      yield c;
      yield* c.descendants();
    }
  }
}

const EMPTY = [];
const EMPTY_MAP = {};

function escapeText(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escapeAttr(s) {
  return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

function serializeNode(el) {
  if (el.type === 'text') return escapeText(el.text);
  let s = '<' + el.tag;
  for (const k in el.attrs) {
    const v = el.attrs[k];
    s += v === '' ? ' ' + k : ' ' + k + '="' + escapeAttr(v) + '"';
  }
  if (VOID_TAGS.has(el.tag)) return s + '/>';
  s += '>';
  if (el.tag === 'script' || el.tag === 'style') {
    for (const c of el.children) s += c.type === 'text' ? c.text : serializeNode(c);
  } else {
    for (const c of el.children) s += serializeNode(c);
  }
  return s + '</' + el.tag + '>';
}

/* ─────────────── 解析器 ─────────────── */

function parseHTML(html) {
  const root = new Element('#document', {}, null);
  const stack = [root];
  const src = String(html == null ? '' : html);
  const len = src.length;
  let i = 0;

  const top = () => stack[stack.length - 1];

  const pushText = (text) => {
    if (!text) return;
    const parent = top();
    const last = parent.children[parent.children.length - 1];
    if (last && last.type === 'text') last.text += text;
    else parent.children.push(new TextNode(text, parent));
  };

  while (i < len) {
    const lt = src.indexOf('<', i);
    if (lt < 0) {
      pushText(decodeEntities(src.slice(i)));
      break;
    }
    if (lt > i) pushText(decodeEntities(src.slice(i, lt)));
    i = lt;

    // 注释
    if (src.startsWith('<!--', i)) {
      const end = src.indexOf('-->', i + 4);
      i = end < 0 ? len : end + 3;
      continue;
    }
    // 声明 / doctype / CDATA
    if (src[i + 1] === '!' || src[i + 1] === '?') {
      if (src.startsWith('<![CDATA[', i)) {
        const end = src.indexOf(']]>', i + 9);
        pushText(end < 0 ? src.slice(i + 9) : src.slice(i + 9, end));
        i = end < 0 ? len : end + 3;
        continue;
      }
      const end = src.indexOf('>', i + 2);
      i = end < 0 ? len : end + 1;
      continue;
    }
    // 结束标签
    if (src[i + 1] === '/') {
      const end = src.indexOf('>', i + 2);
      const rawName = (end < 0 ? src.slice(i + 2) : src.slice(i + 2, end)).trim().toLowerCase();
      const name = rawName.split(/\s+/)[0];
      i = end < 0 ? len : end + 1;
      for (let k = stack.length - 1; k > 0; k--) {
        if (stack[k].tag === name) {
          stack.length = k;
          break;
        }
      }
      continue;
    }
    // 开始标签
    const nameMatch = /^<([a-zA-Z][^\s/>]*)/.exec(src.slice(i, i + 64));
    if (!nameMatch) {
      pushText('<');
      i += 1;
      continue;
    }
    const tag = nameMatch[1].toLowerCase();
    let j = i + nameMatch[0].length;
    const attrs = {};
    let selfClose = false;
    while (j < len) {
      while (j < len && /\s/.test(src[j])) j++;
      if (j >= len) break;
      if (src[j] === '>') { j++; break; }
      if (src[j] === '/' && src[j + 1] === '>') { selfClose = true; j += 2; break; }
      if (src[j] === '/') { j++; continue; }
      let k = j;
      while (k < len && !/[\s=/>]/.test(src[k])) k++;
      const attrName = src.slice(j, k).toLowerCase();
      j = k;
      while (j < len && /\s/.test(src[j])) j++;
      let value = '';
      if (src[j] === '=') {
        j++;
        while (j < len && /\s/.test(src[j])) j++;
        const q = src[j];
        if (q === '"' || q === "'") {
          const end = src.indexOf(q, j + 1);
          value = end < 0 ? src.slice(j + 1) : src.slice(j + 1, end);
          j = end < 0 ? len : end + 1;
        } else {
          let e = j;
          while (e < len && !/[\s>]/.test(src[e])) e++;
          value = src.slice(j, e);
          j = e;
        }
      }
      if (attrName) attrs[attrName] = decodeEntities(value);
    }
    i = j;

    const el = new Element(tag, attrs, top());
    top().children.push(el);

    if (VOID_TAGS.has(tag) || selfClose) continue;

    if (RAW_TEXT_TAGS.has(tag)) {
      const closeRe = new RegExp('</' + tag + '\\s*>', 'i');
      const rest = src.slice(i);
      const m = closeRe.exec(rest);
      const raw = m ? rest.slice(0, m.index) : rest;
      if (raw) el.children.push(new TextNode(tag === 'script' || tag === 'style' ? raw : decodeEntities(raw), el));
      i = m ? i + m.index + m[0].length : len;
      continue;
    }
    stack.push(el);
  }

  return root;
}

/* ─────────────── 选择器 ─────────────── */

let selectorCache = new Map();

function parseSelectorList(selector) {
  const key = selector;
  if (selectorCache.has(key)) return selectorCache.get(key);
  const groups = splitTop(selector, ',').map((s) => parseComplex(s.trim())).filter(Boolean);
  selectorCache.set(key, groups);
  return groups;
}

function splitTop(str, sep) {
  const out = [];
  let depth = 0;
  let quote = null;
  let buf = '';
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (quote) {
      buf += ch;
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; buf += ch; continue; }
    if (ch === '(' || ch === '[') depth++;
    if (ch === ')' || ch === ']') depth--;
    if (ch === sep && depth === 0) { out.push(buf); buf = ''; continue; }
    buf += ch;
  }
  if (buf.trim()) out.push(buf);
  return out;
}

function parseComplex(sel) {
  if (!sel) return null;
  // 拆组合子：空格 / > / + / ~
  const tokens = [];
  let buf = '';
  let depth = 0;
  let quote = null;
  let comb = ' ';
  for (let i = 0; i < sel.length; i++) {
    const ch = sel[i];
    if (quote) { buf += ch; if (ch === quote) quote = null; continue; }
    if (ch === '"' || ch === "'") { quote = ch; buf += ch; continue; }
    if (ch === '[' || ch === '(') depth++;
    if (ch === ']' || ch === ')') depth--;
    if (depth === 0 && (ch === '>' || ch === '+' || ch === '~')) {
      if (buf.trim()) tokens.push({ comb, part: buf.trim() });
      buf = '';
      comb = ch;
      continue;
    }
    if (depth === 0 && /\s/.test(ch)) {
      if (buf.trim()) { tokens.push({ comb, part: buf.trim() }); buf = ''; comb = ' '; }
      continue;
    }
    buf += ch;
  }
  if (buf.trim()) tokens.push({ comb, part: buf.trim() });
  if (!tokens.length) return null;
  return tokens.map((t) => ({ comb: t.comb, part: parseSimple(t.part) }));
}

function parseSimple(part) {
  const simple = { tag: null, id: null, classes: [], attrs: [], pseudos: [], textEq: null };
  let i = 0;
  if (part[0] === '*') { i = 1; }
  const m = /^[a-zA-Z][a-zA-Z0-9-]*/.exec(part);
  if (m) { simple.tag = m[0].toLowerCase(); i = m[0].length; }
  while (i < part.length) {
    const ch = part[i];
    if (ch === '.') {
      const mm = /^\.([^\s.#\[:()>+~]+)/.exec(part.slice(i));
      if (!mm) { i++; continue; }
      simple.classes.push(mm[1]);
      i += mm[0].length;
    } else if (ch === '#') {
      const mm = /^#([^\s.#\[:()>+~]+)/.exec(part.slice(i));
      if (!mm) { i++; continue; }
      simple.id = mm[1];
      i += mm[0].length;
    } else if (ch === '[') {
      const end = part.indexOf(']', i);
      if (end < 0) break;
      const body = part.slice(i + 1, end);
      const am = /^([^\s~^$*=|]+)\s*(?:([~^$*|]?=)\s*(.*))?$/.exec(body.trim());
      if (am) {
        let val = am[3];
        if (val != null) {
          val = val.trim();
          if ((val[0] === '"' && val.endsWith('"')) || (val[0] === "'" && val.endsWith("'"))) {
            val = val.slice(1, -1);
          }
        }
        simple.attrs.push({ name: am[1].toLowerCase(), op: am[2] || null, val });
      }
      i = end + 1;
    } else if (ch === ':') {
      const mm = /^:([a-zA-Z-]+)(?:\(([^)]*)\))?/.exec(part.slice(i));
      if (!mm) { i++; continue; }
      simple.pseudos.push({ name: mm[1].toLowerCase(), arg: mm[2] });
      i += mm[0].length;
    } else {
      i++;
    }
  }
  return simple;
}

function matchSimple(el, simple, scope) {
  if (el.type !== 'tag') return false;
  if (simple.tag && el.tag !== simple.tag) return false;
  if (simple.id && el.attrs.id !== simple.id) return false;
  if (simple.classes.length) {
    const cls = el.attrs.class;
    if (!cls) return false;
    const list = cls.split(/\s+/);
    for (const c of simple.classes) if (list.indexOf(c) < 0) return false;
  }
  for (const a of simple.attrs) {
    const v = el.attrs[a.name];
    if (v === undefined) return false;
    if (a.op === null) continue;
    const val = a.val === undefined ? '' : a.val;
    switch (a.op) {
      case '=': if (v !== val) return false; break;
      case '~=': if ((' ' + v + ' ').indexOf(' ' + val + ' ') < 0) return false; break;
      case '^=': if (!v.startsWith(val)) return false; break;
      case '$=': if (!v.endsWith(val)) return false; break;
      case '*=': if (v.indexOf(val) < 0) return false; break;
      case '|=': if (v !== val && !v.startsWith(val + '-')) return false; break;
      default: break;
    }
  }
  if (simple.pseudos.length) {
    const siblings = el.parent ? el.parent.children.filter((c) => c.type === 'tag') : [el];
    const idx = siblings.indexOf(el);
    for (const p of simple.pseudos) {
      switch (p.name) {
        case 'first':
        case 'first-child':
          if (idx !== 0) return false;
          break;
        case 'last':
        case 'last-child':
          if (idx !== siblings.length - 1) return false;
          break;
        case 'eq':
        case 'nth-child': {
          const n = parseInt(p.arg, 10);
          if (p.name === 'nth-child' ? idx !== n - 1 : idx !== (n < 0 ? siblings.length + n : n)) return false;
          break;
        }
        case 'lt': {
          const n = parseInt(p.arg, 10);
          if (!(idx < n)) return false;
          break;
        }
        case 'gt': {
          const n = parseInt(p.arg, 10);
          if (!(idx > n)) return false;
          break;
        }
        case 'contains':
          if (el.textContent.indexOf(String(p.arg).replace(/^['"]|['"]$/g, '')) < 0) return false;
          break;
        case 'empty':
          if (el.childElements.length) return false;
          break;
        case 'not': {
          const inner = parseSimple(String(p.arg || '').trim());
          if (matchSimple(el, inner, scope)) return false;
          break;
        }
        default:
          break;
      }
    }
  }
  return true;
}

function elementChildren(node) {
  return node.children.filter((c) => c.type === 'tag');
}

function selectAll(scopeEl, selector) {
  const groups = parseSelectorList(selector);
  const out = [];
  const seen = new Set();
  for (const tokens of groups) {
    let current = [scopeEl];
    for (let t = 0; t < tokens.length; t++) {
      const { comb, part } = tokens[t];
      const next = [];
      const pool = [];
      if (comb === '>') {
        for (const el of current) pool.push(...elementChildren(el));
      } else if (comb === ' ') {
        for (const el of current) pool.push(...el.descendants());
      } else if (comb === '+') {
        for (const el of current) {
          if (!el.parent) continue;
          const sibs = elementChildren(el.parent);
          const i = sibs.indexOf(el);
          if (i >= 0 && sibs[i + 1]) pool.push(sibs[i + 1]);
        }
      } else if (comb === '~') {
        for (const el of current) {
          if (!el.parent) continue;
          const sibs = elementChildren(el.parent);
          const i = sibs.indexOf(el);
          for (let k = i + 1; k < sibs.length; k++) pool.push(sibs[k]);
        }
      }
      const seenLocal = new Set();
      for (const el of pool) {
        if (seenLocal.has(el)) continue;
        seenLocal.add(el);
        if (matchSimple(el, part, scopeEl)) next.push(el);
      }
      current = next;
      if (!current.length) break;
    }
    for (const el of current) {
      if (!seen.has(el)) { seen.add(el); out.push(el); }
    }
  }
  return out;
}

function selectOne(scopeEl, selector) {
  const all = selectAll(scopeEl, selector);
  return all.length ? all[0] : null;
}

/**
 * Legado 的元素过滤前缀：class.xxx / id.xxx / tag.xxx / text.xxx
 * 转成标准 CSS；text.xxx 需要按文本内容匹配，返回特殊标记
 */
function selectorFromLegado(filter) {
  if (!filter) return null;
  const s = filter.trim();
  if (s.startsWith('class.')) return '.' + cssEscapeIdent(s.slice(6));
  if (s.startsWith('id.')) return '#' + cssEscapeIdent(s.slice(3));
  if (s.startsWith('tag.')) {
    const rest = s.slice(4).trim();
    return rest || '*';
  }
  if (s.startsWith('text.')) {
    return { text: s.slice(5) };
  }
  return s;
}

function cssEscapeIdent(s) {
  return String(s).replace(/([^a-zA-Z0-9_\u00a0-\uffff-])/g, '\\$1');
}

function findByText(scopeEl, text) {
  const want = String(text).trim();
  const out = [];
  for (const el of scopeEl.descendants()) {
    const t = el.textContent.trim();
    if (t === want) out.push(el);
  }
  if (!out.length) {
    for (const el of scopeEl.descendants()) {
      if (el.textContent.indexOf(want) >= 0) out.push(el);
    }
  }
  return out;
}

module.exports = {
  parseHTML,
  Element,
  TextNode,
  selectAll,
  selectOne,
  selectorFromLegado,
  findByText,
  decodeEntities,
  escapeText,
};
