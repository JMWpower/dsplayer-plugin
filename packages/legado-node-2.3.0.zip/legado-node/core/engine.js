'use strict';
/*
 * 聚合引擎：把 sources.json 里的多个乐读书源当成一个「影视源」暴露出去
 *   - 分类 = 书源（每个书源下再用 channel 选频道）
 *   - 搜索 = 全部书源并发搜，结果合并
 *   - 详情 = 书籍信息 + 目录（章节即剧集）
 *   - 播放 = 章节正文（同时给出 JSON，供 novel:// 契约使用）
 *
 * 契约与 肉书屋.py 模板保持一致：
 *   分类带 filters、详情 vod_play_url = "章节名$章节标记"、正文出 {title, content}
 */

const { BookSource, stripTags } = require('./source');

/* ────────── 章节标记（token）──────────
 * 形如 "3~aHR0cHM6Ly8..."（书源下标 + base64url 的原始地址）
 * base64url 里不含 $ # & 空格，可以直接塞进 vod_play_url，不需要二次转义。
 * 同时兼容老格式 "3::http://..."（旧订阅里已经存下来的链接不会失效）。
 */
function b64url(buf) {
  return Buffer.from(buf, 'utf8').toString('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function unb64url(str) {
  const s = String(str || '').replace(/-/g, '+').replace(/_/g, '/');
  const pad = s.length % 4 ? '='.repeat(4 - (s.length % 4)) : '';
  return Buffer.from(s + pad, 'base64').toString('utf8');
}

function token(idx, url) {
  return idx + '~' + b64url(String(url || ''));
}

function parseToken(t) {
  const s = String(t == null ? '' : t).trim();
  if (!s) return { idx: -1, url: '' };
  const legacy = s.indexOf('::');
  if (legacy > 0) {
    return { idx: parseInt(s.slice(0, legacy), 10), url: s.slice(legacy + 2) };
  }
  const tilde = s.indexOf('~');
  if (tilde > 0) {
    const idx = parseInt(s.slice(0, tilde), 10);
    const body = s.slice(tilde + 1);
    if (/^\d+$/.test(String(idx))) {
      try { return { idx, url: unb64url(body) }; } catch (e) { /* 落到下面 */ }
    }
  }
  if (/^https?:\/\//i.test(s)) return { idx: -1, url: s };
  return { idx: -1, url: s };
}

/* ────────── 小工具 ────────── */

function withTimeout(promise, ms, fallback) {
  let timer;
  const timeout = new Promise((resolve) => {
    timer = setTimeout(() => resolve(fallback), ms);
  });
  return Promise.race([Promise.resolve(promise).catch(() => fallback), timeout])
    .finally(() => clearTimeout(timer));
}

/**
 * 和 withTimeout 一样会超时/吞异常，但把「为什么没内容」留下来：
 * { status: 'ok' | 'error' | 'timeout', value, error, ms }
 */
function raceTimeout(promise, ms) {
  const started = Date.now();
  let timer;
  const timeout = new Promise((resolve) => {
    timer = setTimeout(() => resolve({ status: 'timeout', error: new Error('请求超时（' + ms + 'ms）'), ms: Date.now() - started }), ms);
  });
  const settled = Promise.resolve(promise).then(
    (value) => ({ status: 'ok', value, ms: Date.now() - started }),
    (error) => ({ status: 'error', error, ms: Date.now() - started })
  );
  return Promise.race([settled, timeout]).finally(() => clearTimeout(timer));
}

/** 并发闸门：n 个一组跑，避免一次把十几个站全捅一遍被一起限流 */
async function mapLimit(items, limit, worker) {
  const out = new Array(items.length);
  let cursor = 0;
  const runners = new Array(Math.max(1, Math.min(limit, items.length))).fill(0).map(async () => {
    while (cursor < items.length) {
      const i = cursor++;
      out[i] = await worker(items[i], i);
    }
  });
  await Promise.all(runners);
  return out;
}

function cleanLine(s) {
  return String(s == null ? '' : s).split(/[\r\n]+/)[0].replace(/\s+/g, ' ').trim();
}

function cleanName(s) {
  let v = cleanLine(s);
  v = v.replace(/\s*(作者|著)[:：].*$/, '').trim();
  v = v.replace(/^[《【](.+)[》】]$/, '$1').trim();
  return v.slice(0, 60);
}

function cleanKind(s) {
  return String(s == null ? '' : s)
    .split(/[\r\n]+/)
    .map((x) => x.replace(/^[^：:]{1,6}[:：]/, '').trim())
    .filter(Boolean)
    .filter((x, i, arr) => arr.indexOf(x) === i)
    .join(' · ')
    .slice(0, 40);
}

function cleanIntro(s) {
  if (!s) return '';
  return stripTags(String(s).replace(/<br\s*\/?>/gi, '\n')).replace(/\n{3,}/g, '\n\n').trim().slice(0, 600);
}

/** 章节名清洗：去掉模板站常见的后缀，保留可读标题 */
function cleanChapterName(raw, i) {
  let v = cleanLine(raw)
    .replace(/\s*[（(]?\s*(?:免费|最新|手机阅读|无弹窗|全文阅读|请记住本站)[^)）]*[)）]?\s*$/g, '')
    .replace(/[$#]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!v) v = '第' + (i + 1) + '章';
  return v.slice(0, 80);
}

class Engine {
  constructor(sourcesJson, opts = {}) {
    this.sources = [];
    const list = Array.isArray(sourcesJson) ? sourcesJson
      : (sourcesJson && Array.isArray(sourcesJson.sources) ? sourcesJson.sources : []);
    list.forEach((raw) => {
      if (!raw || raw.enabled === false) return;
      const s = new BookSource(raw, this.sources.length);
      if (!s.url) return;
      this.sources.push(s);
    });
    this.opts = Object.assign({
      searchTimeout: 20000,   // 单源搜索上限
      sourceTimeout: 15000,   // 单源分类页上限
      detailTimeout: 25000,   // 单源详情+目录上限
      chapterTimeout: 20000,  // 单源正文上限
      searchConcurrency: 6,   // 全源搜索并发
      channelConcurrency: 3,  // 合并频道并发
      maxChapters: 3000,      // 单本最多返回多少章（防超长目录拖死）
      listLimit: 60,          // 单个列表最多多少条
    }, opts);
    this._cache = new Map();
    this._cacheMax = 800;
    // 章节名索引：详情里算过一次，正文接口就能带出标题（key = "下标|地址"）
    this._titles = new Map();
    // 每个书源最近一次抓取的结果：ok / empty / error / timeout / js / unknown
    // 面板和 /hs 页面靠它告诉用户「为什么这个源没内容」，而不是空白一片
    this._status = new Map();
  }

  /* ────────── 书源状态 ────────── */

  _markOk(idx) {
    const prev = this._status.get(idx);
    this._status.set(idx, { state: 'ok', msg: '', bad: 0, at: Date.now(), ms: prev ? prev.ms : 0 });
  }

  _markEmpty(idx, msg, ms) {
    this._status.set(idx, { state: 'empty', msg: msg || '', bad: 1, at: Date.now(), ms: ms || 0 });
  }

  _markError(idx, msg, ms) {
    this._status.set(idx, { state: /超时|timeout|aborted/i.test(String(msg)) ? 'timeout' : 'error', msg: String(msg || '').slice(0, 180), bad: 1, at: Date.now(), ms: ms || 0 });
  }

  /** 最近一次抓取状态；从没抓过就是 unknown */
  statusOf(idx) {
    const s = this._status.get(idx);
    if (s) return s;
    return { state: 'unknown', msg: '', at: 0, ms: 0 };
  }

  /**
   * 按书源地址拿状态（store 的下标和 engine 的下标不一定一致）
   * 书源地址可能带 #注释、末尾斜杠、大小写差异，这里统一比较
   */
  statusForUrl(url) {
    const norm = (u) => String(u || '').split('#')[0].trim().replace(/\/+$/, '').toLowerCase();
    const want = norm(url);
    const at = this.sources.findIndex((s) => norm(s.url) === want);
    return at < 0 ? { state: 'disabled', msg: '已停用', at: 0, ms: 0 } : this.statusOf(at);
  }

  /**
   * 这个源是不是「JS 源」：带 jsLib，或者规则/发现页里写着 @js: / js:
   * 这种源用 HTML 规则引擎抓不出东西，得单独说明，不然用户只看到空白
   */
  _jsSource(s) {
    const raw = s.raw || {};
    if (raw.jsLib && String(raw.jsLib).trim()) return true;
    const fields = ['exploreUrl', 'ruleExplore', 'ruleSearch', 'ruleBookInfo', 'ruleToc', 'ruleContent'];
    for (const f of fields) {
      const v = raw[f];
      if (v == null) continue;
      const text = typeof v === 'string' ? v : JSON.stringify(v);
      if (/(^|@)js\s*:/.test(text)) return true;
    }
    return false;
  }

  /** 没内容时的解释文案 */
  _emptyReason(idx, extra) {
    const s = this.sources[idx];
    if (!s) return '书源不存在';
    if (!s.channels.length) {
      if (this._jsSource(s)) return '这个源用 JS 脚本（jsLib/@js）生成发现页，当前只支持 HTML 规则，抓不到内容';
      return '这个源没有配置发现/分类页（exploreUrl），只能搜索，不能浏览';
    }
    if (this._jsSource(s)) return '这个源的规则是 JS 脚本（@js），当前只支持 HTML 规则，可能抓不到内容';
    return extra || '页面能打开，但按规则没解析到书（站点可能改版或需要 JS）';
  }

  /** 按书源地址汇总状态，给面板「源管理」列表用 */
  statusMap() {
    const out = {};
    this.sources.forEach((s, i) => { out[s.url] = this.statusOf(i); });
    return out;
  }

  /** 健康检查：真的抓一次分类页，回报「有没有内容 / 为什么没有」 */
  async probe(idx, page = 1) {
    const s = this.sources[idx];
    if (!s) return { index: idx, name: '', state: 'missing', msg: '书源不存在', count: 0, ms: 0 };
    const started = Date.now();
    let count = 0;
    try {
      const r = await this.category(String(idx), page, '');
      count = (r.list || []).length;
    } catch (e) {
      this._markError(idx, e.message, Date.now() - started);
    }
    const st = this.statusOf(idx);
    return { index: idx, name: s.name, state: count ? 'ok' : st.state, msg: st.msg, count, ms: Date.now() - started };
  }

  _putTitle(idx, url, name) {
    if (!url || !name) return;
    this._titles.set(idx + '|' + url, name);
    if (this._titles.size > 20000) {
      const drop = this._titles.size - 16000;
      let n = 0;
      for (const k of this._titles.keys()) {
        this._titles.delete(k);
        if (++n >= drop) break;
      }
    }
  }

  get size() { return this.sources.length; }

  _remember(key, value, ttlMs) {
    this._cache.set(key, { at: Date.now(), ttl: ttlMs, value });
    if (this._cache.size > this._cacheMax) {
      // 顺手清过期，再不行就丢最老的
      const now = Date.now();
      for (const [k, v] of this._cache) {
        if (now - v.at > v.ttl) this._cache.delete(k);
      }
      while (this._cache.size > this._cacheMax) {
        this._cache.delete(this._cache.keys().next().value);
      }
    }
    return value;
  }

  _recall(key) {
    const hit = this._cache.get(key);
    if (!hit) return null;
    if (Date.now() - hit.at > hit.ttl) {
      this._cache.delete(key);
      return null;
    }
    return hit.value;
  }

  info() {
    return this.sources.map((s, i) => ({
      index: i,
      type_id: String(i),
      name: s.name,
      host: s.url,
      altHosts: s.altHosts || [],
      channels: s.channels,
      searchable: !!s.searchUrl,
      group: s.raw.bookSourceGroup || '',
    }));
  }

  /** 分类列表：每个书源一个分类 */
  categories() {
    return this.sources.map((s, i) => ({ type_id: String(i), type_name: s.name }));
  }

  /** 筛选：每个书源的频道（就是它自己的分类页） */
  filters() {
    const out = {};
    this.sources.forEach((s, i) => {
      if (!s.channels.length) return;
      out[String(i)] = [{
        key: 'channel',
        name: '频道',
        value: [{ n: '全部频道', v: '' }].concat(s.channels.map((c) => ({ n: c.title, v: c.url }))),
      }];
    });
    return out;
  }

  /**
   * 分类内容
   * @param {string} typeId 书源下标
   * @param {number} page 页码
   * @param {string} channel 频道 url（空 = 合并前几个频道）
   */
  async category(typeId, page = 1, channel = '') {
    const idx = parseInt(typeId, 10);
    const s = this.sources[idx];
    if (!s) return { list: [], page, pagecount: 1, total: 0 };
    const pg = Math.max(1, parseInt(page, 10) || 1);

    if (channel) {
      const key = 'c:' + idx + ':' + channel + ':' + pg;
      const hit = this._recall(key);
      if (hit) return hit;
      const r = await raceTimeout(Promise.resolve().then(() => s.explore(channel, pg)), this.opts.sourceTimeout);
      if (r.status !== 'ok') {
        this._markError(idx, (r.error && r.error.message) || '请求失败', r.ms);
        return { list: [], page: pg, pagecount: 1, total: 0 };
      }
      const list = (r.value || []).map((b) => this.toVod(idx, b));
      if (!list.length) {
        this._markEmpty(idx, this._emptyReason(idx), r.ms);
        return { list: [], page: pg, pagecount: 1, total: 0 };
      }
      this._markOk(idx);
      return this._remember(key, {
        list: list.slice(0, this.opts.listLimit),
        page: pg, pagecount: 999, total: 9999,
      }, 60 * 1000);
    }

    if (!s.channels.length) {
      this._markEmpty(idx, this._emptyReason(idx));
      return { list: [], page: pg, pagecount: 1, total: 0 };
    }

    // 没指定频道：合并前 3 个「真分类页」（跳过首页那种空 url）——再多就太慢
    const real = s.channels.filter((c) => c.url && c.url !== '/' && c.url !== '');
    const use = (real.length ? real : s.channels).slice(0, 3);
    const key = 'c:' + idx + ':all:' + pg;
    const hit = this._recall(key);
    if (hit) return hit;

    const results = await mapLimit(use, this.opts.channelConcurrency, (c) =>
      raceTimeout(Promise.resolve().then(() => s.explore(c.url, pg)), this.opts.sourceTimeout)
    );
    const merged = [];
    const seen = new Set();
    let firstErr = null;
    let slowest = 0;
    for (const r of results) {
      if (!r) continue;
      if (r.ms > slowest) slowest = r.ms;
      if (r.status !== 'ok') {
        if (!firstErr) firstErr = (r.error && r.error.message) || '请求失败';
        continue;
      }
      for (const b of r.value || []) {
        if (!b || !b.bookUrl || seen.has(b.bookUrl)) continue;
        seen.add(b.bookUrl);
        merged.push(this.toVod(idx, b));
      }
    }
    // 一个频道有内容就算这个源能用；全都空/报错才判空
    if (!merged.length) {
      if (firstErr) this._markError(idx, firstErr, slowest);
      else this._markEmpty(idx, this._emptyReason(idx), slowest);
      return { list: [], page: pg, pagecount: 1, total: 0 };
    }
    this._markOk(idx);
    return this._remember(key, {
      list: merged.slice(0, this.opts.listLimit),
      page: pg, pagecount: 999, total: 9999,
    }, 60 * 1000);
  }

  /** 全源搜索（opts.timeout 可给单次搜索一个更紧的预算，比如给 HTML 页面用） */
  async search(key, opts = {}) {
    const only = opts.only;
    const limit = opts.limit || this.opts.listLimit;
    const budget = opts.timeout || this.opts.searchTimeout;
    const jobs = this.sources.map((s, i) => {
      if (!s.searchUrl) return null;
      if (only != null && only !== '' && parseInt(only, 10) !== i) return null;
      return i;
    }).filter((x) => x !== null);

    const results = await mapLimit(jobs, this.opts.searchConcurrency, async (i) => {
      const s = this.sources[i];
      const r = await raceTimeout(Promise.resolve().then(() => s.search(key, 1)), budget);
      if (r.status !== 'ok') {
        this._markError(i, (r.error && r.error.message) || '请求失败', r.ms);
        return [];
      }
      const list = (r.value || []).map((b) => this.toVod(i, b));
      if (!list.length) this._markEmpty(i, this._jsSource(s) ? '搜索规则是 JS 脚本（@js），当前不支持' : '搜不到结果（站点可能失效或规则过期）', r.ms);
      else this._markOk(i);
      return list;
    });

    const out = [];
    const seen = new Set();
    for (const arr of results) {
      for (const v of arr || []) {
        if (!v || !v.vod_id) continue;
        const k = v.vod_name + '|' + (v.vod_actor || '');
        if (seen.has(k)) continue;
        seen.add(k);
        out.push(v);
      }
    }
    return {
      list: out.slice(0, limit * 2),
      page: 1, pagecount: 1, limit: out.length, total: out.length,
    };
  }

  toVod(idx, b) {
    return {
      vod_id: token(idx, b.bookUrl),
      vod_name: cleanName(b.name),
      vod_pic: b.coverUrl || '',
      vod_remarks: cleanLine(b.lastChapter || b.wordCount || '').slice(0, 40),
      vod_content: cleanIntro(b.intro),
      vod_actor: cleanLine(b.author).replace(/^作者[:：]/, ''),
      vod_area: cleanKind(b.kind),
      vod_year: '',
      vod_lang: '',
      vod_director: '',
      vod_play_from: '阅读',
      source: this.sources[idx] ? this.sources[idx].name : '',
    };
  }

  /** 详情：书信息 + 章节目录 */
  async detail(id) {
    const { idx, url } = parseToken(id);
    const s = this.sources[idx];
    if (!s || !url) throw new Error('书源无效或链接缺失');

    const key = 'd:' + id;
    const hit = this._recall(key);
    if (hit) return hit;

    const build = async () => {
      const info = await s.bookInfo(url);
      const chapters = await s.toc(info.tocUrl || url);
      const max = this.opts.maxChapters;
      const list = chapters.slice(0, max);
      const playUrl = list
        .map((c, i) => {
          const nm = cleanChapterName(c.name, i);
          this._putTitle(idx, c.url, nm);
          return nm + '$' + token(idx, c.url);
        })
        .join('#');
      return {
        vod_id: id,
        vod_name: cleanName(info.name) || '未知书名',
        vod_pic: info.coverUrl || '',
        vod_content: cleanIntro(info.intro),
        vod_actor: cleanLine(info.author).replace(/^作者[:：]/, ''),
        vod_area: cleanKind(info.kind),
        vod_remarks: (cleanLine(info.lastChapter) || info.wordCount || '').slice(0, 60),
        vod_year: info.wordCount || '',
        vod_play_from: '阅读',
        vod_play_url: playUrl,
        chapter_count: list.length,
        chapters: list,
      };
    };

    const r = await raceTimeout(build(), this.opts.detailTimeout);
    if (r.status !== 'ok' || !r.value) {
      const msg = r.status === 'ok' ? '详情页没解析出内容' : ((r.error && r.error.message) || '详情获取失败');
      this._markError(idx, msg, r.ms);
      throw new Error(msg);
    }
    this._markOk(idx);
    return this._remember(key, r.value, 10 * 60 * 1000);
  }

  async chapters(id) {
    const d = await this.detail(id);
    return d.chapters || [];
  }

  /** 章节正文（纯文本） */
  async chapter(flag) {
    const { title, content } = await this.chapterDetail(flag);
    return content;
  }

  /** 章节正文（标题 + 正文，给 novel:// 用） */
  async chapterDetail(flag) {
    const { idx, url } = parseToken(flag);
    const s = this.sources[idx];
    if (!s || !url) throw new Error('章节标记无效');

    const key = 'ch:' + flag;
    const hit = this._recall(key);
    if (hit) return hit;

    const r = await raceTimeout(Promise.resolve().then(() => s.content(url)), this.opts.chapterTimeout);
    const text = (r.status === 'ok' && r.value) || '';
    if (!text) {
      const msg = r.status === 'ok' ? '正文页没解析出内容（可能要 JS 渲染）' : ((r.error && r.error.message) || '正文获取失败');
      this._markError(idx, msg, r.ms);
      throw new Error(msg);
    }
    this._markOk(idx);
    const title = this._titles.get(idx + '|' + url) || '';
    const value = { title, content: text, chars: text.length };
    return this._remember(key, value, 30 * 60 * 1000);
  }
}

module.exports = { Engine, token, parseToken, cleanChapterName, cleanName, mapLimit, withTimeout };
