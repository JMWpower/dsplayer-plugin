'use strict';
/*
 * Legado（阅读）书源规则引擎 —— 纯 JS 复刻
 *
 * 支持写法（覆盖 cc.json 里 22 个书源实际用到的全部语法）：
 *   .cls / #id / tag / [attr=val] / 原生 CSS
 *   class.xxx / id.xxx / tag.xxx / text.xxx / children
 *   索引 .0  [-1]  [0,2]  1:3
 *   @ 链式：@text @html @textNodes @ownText @href @src @任意属性
 *   ##正则##替换（支持 $1，单段表示删除）
 *   && 多规则合并、|| 兜底、- 前缀倒序
 *   js: / @js: （沙箱里带 result / src / baseUrl / key / page / java）
 *   {{key}} {{page}} {{baseUrl}} 模板
 *   $.json.path 取 JSON
 */

const { parseHTML, selectAll, findByText, selectorFromLegado } = require('./html');

const OUTPUT_TOKENS = new Set(['text', 'textNodes', 'ownText', 'html', 'all']);

function collapse(s) {
  return String(s == null ? '' : s).replace(/[\s\u00a0\u3000]+/g, ' ').trim();
}

/* ───────────── 模板变量 ───────────── */

function applyTemplate(str, vars) {
  if (typeof str !== 'string' || str.indexOf('{{') < 0) return str;
  return str.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (m, expr) => {
    const key = expr.trim();
    if (vars && Object.prototype.hasOwnProperty.call(vars, key)) {
      const v = vars[key];
      return v == null ? '' : String(v);
    }
    // {{cookie.removeCookie(source.getKey())}} 这类模板函数：统一当空处理
    if (expr.indexOf('(') >= 0) return '';
    return '';
  });
}

/* ───────────── 规则切分 ───────────── */

function splitReplace(rule) {
  const idx = rule.indexOf('##');
  if (idx < 0) return { main: rule, replaces: [] };
  const parts = rule.split('##');
  const main = parts.shift();
  const replaces = [];
  for (let i = 0; i < parts.length; i += 2) {
    const pattern = parts[i];
    const replacement = i + 1 < parts.length ? parts[i + 1] : '';
    if (pattern === '') continue;
    replaces.push([pattern, replacement]);
  }
  return { main, replaces };
}

function applyReplaces(str, replaces) {
  if (!replaces.length || str == null || str === '') return str;
  let out = String(str);
  for (const [pattern, replacement] of replaces) {
    try {
      out = out.replace(new RegExp(pattern, 'g'), replacement);
    } catch (e) {
      try {
        out = out.split(pattern).join(replacement);
      } catch (e2) { /* ignore */ }
    }
  }
  return out;
}

/* ───────────── 索引解析 ───────────── */

function extractIndex(token) {
  // [0] / [-1] / [0,2] / .0 / .1:3
  let m = /\[([\d\s,:-]+)\]$/.exec(token);
  let rest = token;
  let spec = null;
  if (m) {
    spec = m[1];
    rest = token.slice(0, m.index);
  } else {
    m = /\.(-?\d+(?::\d+)?(?:,-?\d+)*)$/.exec(token);
    if (m) {
      spec = m[1];
      rest = token.slice(0, m.index);
    }
  }
  if (spec === null) return { rest, index: null };
  let index;
  if (spec.indexOf(':') >= 0) {
    const [a, b] = spec.split(':');
    const from = parseInt(a, 10);
    const to = parseInt(b, 10);
    if (isFinite(from) && isFinite(to)) index = { from, to };
    else if (isFinite(from)) index = { from };
  } else if (spec.indexOf(',') >= 0) {
    index = { list: spec.split(',').map((x) => parseInt(x, 10)).filter((x) => isFinite(x)) };
  } else {
    const n = parseInt(spec, 10);
    if (isFinite(n)) index = { at: n };
  }
  return { rest, index };
}

function applyIndex(list, index) {
  if (!index || !list.length) return list;
  if (index.list) return index.list.map((i) => list[i < 0 ? list.length + i : i]).filter(Boolean);
  if (index.at !== undefined) {
    const i = index.at < 0 ? list.length + index.at : index.at;
    return list[i] ? [list[i]] : [];
  }
  const from = index.from >= 0 ? index.from : Math.max(0, list.length + index.from);
  if (index.to === undefined) return list.slice(from);
  const to = index.to >= 0 ? index.to : list.length + index.to;
  return list.slice(from, to + 1);
}

/* ───────────── JS 沙箱 ───────────── */

function makeJavaShim(ctx) {
  const shim = {
    getString: (rule, el) => (el ? evalString(rule, ctx, el) : evalString(rule, ctx, ctx.root)),
    getStringList: (rule, el) => evalElements(rule, ctx, el || ctx.root).map((e) => e.textContent.trim()),
    ajax: (urlOrObj) => ctx.ajax ? ctx.ajax(urlOrObj) : '',
    base64Encode: (s) => Buffer.from(String(s), 'utf8').toString('base64'),
    base64Decode: (s) => Buffer.from(String(s), 'base64').toString('utf8'),
    md5Encode: (s) => require('crypto').createHash('md5').update(String(s), 'utf8').digest('hex'),
    md5Encode16: (s) => require('crypto').createHash('md5').update(String(s), 'utf8').digest('hex').slice(8, 24),
    timeFormat: () => String(Date.now()),
    log: () => {}, toast: () => {},
    put: (k, v) => { if (ctx.vars) ctx.vars[k] = v; },
    get: (k) => (ctx.vars ? ctx.vars[k] : ''),
    randomUUID: () => require('crypto').randomUUID(),
    encodeURI: (s) => encodeURIComponent(String(s)),
  };
  return shim;
}

function runJs(code, ctx, result) {
  const params = ['result', 'src', 'baseUrl', 'key', 'page', 'cookie', 'java', 'book', 'title', 'base', 'host'];
  const values = [
    result,
    ctx.src != null ? ctx.src : '',
    ctx.baseUrl || '',
    ctx.key || '',
    ctx.page || 1,
    ctx.cookie || '',
    makeJavaShim(ctx),
    ctx.book || {},
    ctx.title || '',
    ctx.baseUrl || '',
    ctx.host || '',
  ];
  try {
    // eslint-disable-next-line no-new-func
    const fn = new Function(...params, 'var __src = arguments[arguments.length - 1]; return eval(__src);');
    let out = fn(...values, code);
    if (out === undefined || out === null) return '';
    if (Array.isArray(out)) return out.map((x) => (x == null ? '' : String(x))).join('\n');
    if (typeof out === 'object') {
      try { return JSON.stringify(out); } catch (e) { return ''; }
    }
    return String(out);
  } catch (e) {
    return '';
  }
}

/* ───────────── 元素选择 ───────────── */

function selectPart(elements, part, ctx) {
  const { rest, index } = extractIndex(part);
  let token = rest.trim();
  if (!token) return applyIndex(elements, index);

  let picked = [];

  if (token === 'children' || token.startsWith('children.')) {
    const sub = token === 'children' ? '' : token.slice(9);
    for (const el of elements) {
      let kids = el.children.filter((c) => c.type === 'tag');
      if (sub) {
        const s = selectorFromLegado(sub);
        kids = typeof s === 'string' ? selectAll(el, s).filter((k) => k.parent === el) : findByText(el, s.text).filter((k) => k.parent === el);
      }
      picked.push(...kids);
    }
    return applyIndex(picked, index);
  }

  const mapped = selectorFromLegado(token);
  if (mapped && typeof mapped === 'object' && mapped.text != null) {
    for (const el of elements) picked.push(...findByText(el, mapped.text));
    return applyIndex(picked, index);
  }

  const selector = typeof mapped === 'string' ? mapped : token;
  for (const el of elements) picked.push(...selectAll(el, selector));
  return applyIndex(picked, index);
}

function elementsTo(accessor, elements, ctx) {
  const out = [];
  for (const el of elements) {
    switch (accessor) {
      case 'text':
        out.push(collapse(el.textContent));
        break;
      case 'ownText': {
        let s = '';
        for (const c of el.children) if (c.type === 'text') s += c.text;
        out.push(collapse(s));
        break;
      }
      case 'textNodes': {
        const arr = [];
        const walk = (n) => {
          for (const c of n.children) {
            if (c.type === 'text') { const t = collapse(c.text); if (t) arr.push(t); }
            else walk(c);
          }
        };
        walk(el);
        out.push(arr.join('\n'));
        break;
      }
      case 'html':
      case 'all':
        out.push(el.innerHTML);
        break;
      case 'content':
        out.push(el.textContent);
        break;
      default:
        out.push('');
    }
  }
  return out.filter((s) => s !== '');
}

function getAttr(elements, name) {
  const out = [];
  for (const el of elements) {
    let v = el.attr(name);
    if (v === undefined && el.tag === 'a' && name === 'content') v = el.attr('href');
    if (v !== undefined && v !== '') out.push(v);
  }
  return out;
}

/* ───────────── 主求值 ───────────── */

/**
 * 求值结果为字符串（多个结果用 \n 连接）
 */
function evalString(rule, ctx, scopeEl) {
  if (rule == null) return '';
  let str = String(rule).trim();
  if (!str) return '';

  // && 合并 / || 兜底（js: 里可能有 &&，遇到 js: 就不拆）
  if (str.indexOf('js:') < 0) {
    if (str.indexOf('||') >= 0) {
      const alts = str.split('||');
      for (const alt of alts) {
        const v = evalString(alt, ctx, scopeEl);
        if (v) return v;
      }
      return '';
    }
    if (str.indexOf('&&') >= 0) {
      const segs = str.split('&&').map((s) => s.trim()).filter(Boolean);
      const vals = segs.map((s) => evalString(s, ctx, scopeEl)).filter((v) => v !== '');
      return vals.join('\n');
    }
  }

  const { main, replaces } = splitReplace(str);
  const parts = splitChain(main);
  let current = typeof scopeEl === 'string' ? [scopeEl] : [scopeEl || ctx.root];
  let isString = false;
  let stringVal = '';

  for (let i = 0; i < parts.length; i++) {
    let part = parts[i].trim();
    if (!part) continue;

    if (part.startsWith('js:') || part.startsWith('@js:')) {
      const code = part.replace(/^@?js:/, '');
      const input = isString ? stringVal : current.map((e) => (e && e.textContent ? collapse(e.textContent) : ''));
      const value = runJs(code, ctx, isString ? input : (input.length === 1 ? input[0] : input));
      if (i === parts.length - 1) {
        isString = true;
        stringVal = value;
      } else {
        // 结果继续参与挑选时，若为元素 id 无法还原 → 中断
        isString = true;
        stringVal = value;
      }
      continue;
    }

    if (isString) {
      // 字符串之后继续的话，Legado 视为对字符串做处理，这里只做简单取值
      continue;
    }

    if (OUTPUT_TOKENS.has(part)) {
      const vals = elementsTo(part, current, ctx);
      isString = true;
      stringVal = vals.join('\n');
      continue;
    }

    // 属性取值（href/src/onclick 等）
    if (/^[a-zA-Z_:][-a-zA-Z0-9_:.]*$/.test(part) && !/^[a-z]+\.[^\s]/.test(part)) {
      const attrVals = getAttr(current, part.toLowerCase());
      if (attrVals.length) {
        isString = true;
        stringVal = attrVals.join('\n');
        continue;
      }
    }

    const next = selectPart(current, part, ctx);
    if (next.length) {
      current = next;
    } else {
      // 选不到就保持空
      current = [];
    }
  }

  let out;
  if (isString) out = stringVal;
  else out = current.map((e) => collapse(e.textContent)).filter((s) => s !== '').join('\n');

  return applyReplaces(out, replaces);
}

/**
 * 求值结果为元素数组（用于 bookList / chapterList）
 */
function evalElements(rule, ctx, scopeEl) {
  if (rule == null) return [];
  let str = String(rule).trim();
  if (!str) return [];
  if (str.indexOf('js:') >= 0) return [];
  const { main } = splitReplace(str);
  let reverse = false;
  if (main.startsWith('-')) { reverse = true; str = main.slice(1); }
  const segs = str.split('&&').map((s) => s.trim()).filter(Boolean);
  let list = [];
  for (const seg of segs) {
    const inner = seg.startsWith('-') ? seg.slice(1) : seg;
    let current = [typeof scopeEl === 'string' ? ctx.root : (scopeEl || ctx.root)];
    const parts = splitChain(inner);
    let broke = false;
    for (const part of parts) {
      const p = part.trim();
      if (!p) continue;
      if (OUTPUT_TOKENS.has(p) || p.startsWith('js:')) { broke = true; break; }
      current = selectPart(current, p, ctx);
      if (!current.length) { broke = true; break; }
    }
    if (!broke) list = list.concat(current);
  }
  if (reverse) list.reverse();
  return list;
}

function splitChain(rule) {
  // 按 @ 切分，但 js: 段里的 @ 不切（例如 js 代码中的邮箱/装饰器极少见）
  const parts = [];
  let buf = '';
  let inJs = false;
  for (let i = 0; i < rule.length; i++) {
    const ch = rule[i];
    if (!inJs && ch === '@') {
      parts.push(buf);
      buf = '';
      continue;
    }
    buf += ch;
    if (buf.trimEnd().endsWith('js:')) inJs = true;
  }
  parts.push(buf);
  return parts;
}

/* ───────────── 便捷封装 ───────────── */

function makeContext(opts) {
  const html = opts.html || '';
  let root = opts.root;
  if (!root) {
    root = typeof html === 'string' ? parseHTML(html) : html;
  }
  return {
    root,
    src: typeof html === 'string' ? html : '',
    baseUrl: opts.baseUrl || '',
    host: opts.host || '',
    key: opts.key || '',
    page: opts.page || 1,
    cookie: opts.cookie || '',
    vars: opts.vars || {},
    ajax: opts.ajax,
    title: opts.title || '',
    book: opts.book || {},
  };
}

module.exports = {
  applyTemplate,
  collapse,
  splitReplace,
  applyReplaces,
  evalString,
  evalElements,
  makeContext,
  runJs,
};
