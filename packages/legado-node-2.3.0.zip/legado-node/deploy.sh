#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# 阅读源 Node 服务 · 一键部署脚本
#
#   bash deploy.sh install      安装为系统服务（开机自启，需 root/sudo）
#   bash deploy.sh start        启动服务
#   bash deploy.sh stop         停止服务
#   bash deploy.sh restart      重启服务
#   bash deploy.sh status       看状态
#   bash deploy.sh logs         看日志（Ctrl+C 退出）
#   bash deploy.sh run          前台直接跑（不装服务，调试用）
#   bash deploy.sh check        跑一遍接口契约自检
#   bash deploy.sh uninstall    卸载服务
#
# 端口用环境变量改： PORT=13001 bash deploy.sh install
# ─────────────────────────────────────────────────────────────
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVICE_NAME="legado-node"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
PORT="${PORT:-13000}"
NODE_BIN="$(command -v node || true)"

log() { printf '\033[36m[部署]\033[0m %s\n' "$*"; }
err() { printf '\033[31m[错误]\033[0m %s\n' "$*" >&2; }

need_node() {
  if [ -z "$NODE_BIN" ]; then
    err "没找到 node，请先装 Node.js 18+（Debian/Ubuntu: apt install -y nodejs）"
    exit 1
  fi
  local major
  major="$("$NODE_BIN" -p 'process.versions.node.split(".")[0]')"
  if [ "$major" -lt 18 ]; then
    err "Node 版本太低（当前 $("$NODE_BIN" -v)），需要 18 以上"
    exit 1
  fi
  log "Node $("$NODE_BIN" -v) · 端口 $PORT · 目录 $DIR"
}

check_port() {
  if command -v ss >/dev/null 2>&1 && ss -ltn "( sport = :$PORT )" 2>/dev/null | grep -q LISTEN; then
    err "端口 $PORT 已被占用，换个端口： PORT=13001 bash deploy.sh install"
    exit 1
  fi
}

do_install() {
  need_node
  if [ ! -f "$DIR/index.js" ]; then err "当前目录没有 index.js，请在项目根目录运行"; exit 1; fi

  if [ "$(id -u)" -ne 0 ]; then
    err "安装为系统服务需要 root：sudo bash deploy.sh install"
    exit 1
  fi

  check_port

  log "写服务文件 $SERVICE_FILE"
  cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Legado Node Source Service (阅读源)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$DIR
ExecStart=$NODE_BIN $DIR/index.js --port $PORT
Restart=always
RestartSec=3
Environment=NODE_ENV=production
Environment=TZ=Asia/Shanghai
LimitNOFILE=65535
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable "$SERVICE_NAME" >/dev/null 2>&1 || true
  systemctl restart "$SERVICE_NAME"
  sleep 1.5
  do_status
  echo
  log "订阅地址： http://<本机IP>:$PORT/sub"
  log "状态页：   http://<本机IP>:$PORT/"
}

do_status() {
  if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    log "服务运行中（$SERVICE_NAME）"
  else
    err "服务未运行"
  fi
  if command -v curl >/dev/null 2>&1; then
    local body
    body="$(curl -s --max-time 5 "http://127.0.0.1:$PORT/ping" || true)"
    if [ -n "$body" ]; then log "健康检查： $body"; else err "健康检查无响应"; fi
  fi
}

do_run() {
  need_node
  log "前台启动，按 Ctrl+C 停止"
  exec "$NODE_BIN" "$DIR/index.js" --port "$PORT"
}

do_check() {
  need_node
  "$NODE_BIN" "$DIR/test/contract.js" "http://127.0.0.1:$PORT" "${KEY:-总裁}"
}

case "${1:-install}" in
  install)   do_install ;;
  start)     systemctl start "$SERVICE_NAME" && do_status ;;
  stop)      systemctl stop "$SERVICE_NAME" && log "已停止" ;;
  restart)   systemctl restart "$SERVICE_NAME" && sleep 1 && do_status ;;
  status)    do_status ;;
  logs)      journalctl -u "$SERVICE_NAME" -f -n 80 ;;
  run)       do_run ;;
  check)     do_check ;;
  uninstall)
    systemctl stop "$SERVICE_NAME" 2>/dev/null || true
    systemctl disable "$SERVICE_NAME" 2>/dev/null || true
    rm -f "$SERVICE_FILE"
    systemctl daemon-reload
    log "已卸载服务（程序文件没动）"
    ;;
  *)
    echo "用法: bash deploy.sh [install|start|stop|restart|status|logs|run|check|uninstall]"
    exit 1
    ;;
esac
