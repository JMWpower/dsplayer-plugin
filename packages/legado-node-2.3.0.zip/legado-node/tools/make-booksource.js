'use strict';
/*
 * 生成可离线导入的 HTML 规则书源 JSON 文件。
 *
 *   node tools/make-booksource.js [base] [输出路径]
 *
 * base 默认 http://127.0.0.1:13000 —— 书源里的所有规则都指向这个地址，
 * 换机器/换端口时重新生成或直接改文件里的 bookSourceUrl。
 * 服务运行时也可以直接导入 http://<host>:<port>/legado_html.json（自动带正确 base）。
 */
const fs = require('fs');
const path = require('path');
const { bookSourceJson } = require('../server/legado');

const base = (process.argv[2] || 'http://127.0.0.1:13000').replace(/\/+$/, '');
const out = process.argv[3] || path.join(__dirname, '..', 'legado_html.json');

const source = bookSourceJson(base);
fs.writeFileSync(out, JSON.stringify([source], null, 2) + '\n', 'utf8');
console.log('已写入 ' + out);
console.log('  ' + source.bookSourceName + '  ' + source.bookSourceUrl);
console.log('  分组: ' + source.bookSourceGroup + ' / 探索: ' + JSON.parse(source.exploreUrl).map((e) => e.title).join('、'));
