'use strict';
/*
 * 把 core/* 打包成单文件 ds 源（喂给 DsPlayer 的 drpy-node）
 * 用法： node build-ds.js
 */

const fs = require('fs');
const path = require('path');

const root = __dirname;
const files = ['html.js', 'gbk.js', 'rule.js', 'http.js', 'source.js', 'engine.js'];
const sources = JSON.parse(fs.readFileSync(path.join(root, 'sources.json'), 'utf8'));

const parts = [];
parts.push(`/* eslint-disable */
/*
@header({
  title: '阅读源',
  lang: 'ds',
  searchable: 1, filterable: 1, quickSearch: 1,
})
*/
/*
 * 阅读源（Legado 书源 → DsPlayer ds 源）
 * 由 cc.json 的「阅读源so」（pro.jar / Lego）转换而来，纯 Node 实现，零第三方依赖。
 *
 * 放置：/sdcard/dsplayer/server/node/drpy-node/spider/js/阅读源so.js
 * 说明：内置 ${sources.length} 个乐读书源，搜索 / 分类 / 目录 / 正文全部可用。
 */
var __modules = {};
var __cache = {};
function __require(name) {
  if (__modules[name]) return __modules[name].exports ? __modules[name].exports : (__modules[name].exports = {});
  if (typeof require === 'function') return require(name);
  throw new Error('module not found: ' + name);
}
`);

for (const f of files) {
  const code = fs.readFileSync(path.join(root, 'core', f), 'utf8')
    .replace(/^'use strict';\s*/, '')
    .replace(/require\('\.\/(html|gbk|rule|http|source|engine)'\)/g, "__require('$1')");
  const name = f.replace(/\.js$/, '');
  parts.push(`__modules['${name}'] = { exports: null };\n(function (module, exports, require) {\n${code}\n})(__modules['${name}'], __modules['${name}'].exports, __require);\n`);
}

parts.push(`var __sourcesData = ${JSON.stringify(sources)};\n`);

parts.push(`
/* ───────────── 引擎实例 ───────────── */

var __engine = null;
function __getEngine() {
  if (!__engine) {
    var Engine = __require('engine').Engine;
    __engine = new Engine(__sourcesData, { searchTimeout: 22000, sourceTimeout: 16000 });
  }
  return __engine;
}
`);

// drpy 层
const wrapper = fs.readFileSync(path.join(root, 'spider', 'ds-wrapper.js'), 'utf8');
parts.push(wrapper);

const out = parts.join('\n');
fs.writeFileSync(path.join(root, 'spider', '阅读源so.js'), out, 'utf8');
console.log('生成 spider/阅读源so.js', (out.length / 1024).toFixed(1) + ' KB');
