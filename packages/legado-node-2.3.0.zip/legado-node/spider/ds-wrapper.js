/* ───────────── drpy-node（DsPlayer ds 源）接口层 ───────────── */

var _eng = __getEngine();
var _info = _eng.info();

function _splitFilter(extend) {
  // drpy 的 extend 可能是对象，也可能是 "channel=xxx&x=y" 字符串
  if (!extend) return {};
  if (typeof extend === 'object') return extend;
  var out = {};
  String(extend).split('&').forEach(function (kv) {
    var i = kv.indexOf('=');
    if (i < 0) return;
    try {
      out[kv.slice(0, i)] = decodeURIComponent(kv.slice(i + 1));
    } catch (e) {
      out[kv.slice(0, i)] = kv.slice(i + 1);
    }
  });
  return out;
}

var rule = {
  title: '阅读源',
  host: '',
  homeUrl: '',
  url: '',
  searchUrl: '',
  searchable: 2,
  quickSearch: 1,
  filterable: 1,
  headers: { 'User-Agent': 'MOBILE_UA' },
  timeout: 15000,
  play_parse: false,
  lazy: '',
  limit: 6,
  double: false,
  class_name: _info.map(function (x) { return x.name; }).join('&'),
  class_url: _info.map(function (x, i) { return String(i); }).join('&'),
  推荐: '',
  一级: '',
  二级: '*',
  搜索: '',
  filter: (function () {
    var f = {};
    _info.forEach(function (s, i) {
      if (!s.channels || !s.channels.length) return;
      f[String(i)] = [{
        key: 'channel',
        name: '频道',
        value: [{ n: '全部频道', v: '' }].concat(s.channels.map(function (c) { return { n: c.title, v: c.url }; })),
      }];
    });
    return f;
  })(),
};

/** 首页：只出分类，不出推荐（推荐需要全站抓一遍，太慢） */
async function home() {
  return {
    class: _eng.categories().map(function (c) { return { type_id: c.type_id, type_name: c.type_name }; }),
    filters: _eng.filters(),
    list: [],
  };
}

async function homeVod() {
  try {
    var r = await _eng.category('0', 1, '');
    return { list: r.list };
  } catch (e) {
    return { list: [] };
  }
}

/** 分类 */
async function category(tid, pg, filter, extend) {
  var ex = _splitFilter(extend);
  var channel = ex.channel || ex.ch || '';
  var page = parseInt(pg, 10) || 1;
  var r = await _eng.category(String(tid), page, channel);
  return {
    page: page,
    pagecount: r.pagecount || 999,
    limit: 20,
    total: r.total || 9999,
    list: r.list,
  };
}

/** 详情：书籍信息 + 目录（章节当剧集）；章节标记直接用引擎给的那份 */
async function detail(id) {
  var d = await _eng.detail(id);
  return {
    list: [{
      vod_id: d.vod_id,
      vod_name: d.vod_name,
      vod_pic: d.vod_pic || '',
      vod_content: d.vod_content || '',
      vod_actor: d.vod_actor || '',
      vod_area: d.vod_area || '',
      vod_remarks: d.vod_remarks || ('共' + (d.chapter_count || 0) + '章'),
      vod_play_from: '阅读',
      vod_play_url: d.vod_play_url,
    }],
  };
}

/** 搜索 */
async function search(wd, quick, pg) {
  var r = await _eng.search(wd);
  return { list: r.list, page: 1, pagecount: 1, limit: r.list.length, total: r.list.length };
}

/** 播放：交给代理出正文 */
async function play(flag, id, flags) {
  var token = String(flag || id || '');
  if (!token) return { parse: 0, url: '' };
  var url = '';
  try {
    if (typeof getProxyUrl === 'function') {
      url = getProxyUrl({ do: 'content', f: token });
    }
  } catch (e) { url = ''; }
  if (!url) {
    // 没有代理能力时退化成 data URL（短章节也能显示）
    try {
      var text = await _eng.chapter(token);
      url = 'data:text/plain;charset=utf-8;base64,' + Buffer.from(text, 'utf8').toString('base64');
    } catch (e2) {
      url = '';
    }
  }
  return { parse: 0, url: url, header: {} };
}

/** 代理：返回章节正文 */
async function proxy(params) {
  var p = params || {};
  if (typeof p === 'string') {
    try { p = JSON.parse(p); } catch (e) { p = { f: p }; }
  }
  var token = p.f || p.flag || p.url || '';
  if (!token) return { content: '', headers: { 'Content-Type': 'text/plain; charset=utf-8' } };
  var text = '';
  try {
    text = await _eng.chapter(token);
  } catch (e) {
    text = '正文获取失败：' + e.message;
  }
  return {
    content: text,
    headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'max-age=600' },
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { rule: rule, home: home, homeVod: homeVod, category: category, detail: detail, search: search, play: play, proxy: proxy };
}
