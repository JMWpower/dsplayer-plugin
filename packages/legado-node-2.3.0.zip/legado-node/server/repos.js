'use strict';
/*
 * 源仓库适配器：三个内置仓库
 *   yiove    → https://shuyuan.yiove.com/book-sources?page=1&page_size=20
 *   yuancang → https://yuancang.cc/platform/1?cat=书源
 *   yckceo   → https://www.yckceo.com/yuedu/shuyuan/index.html
 *
 * 三者都是 SPA/服务端渲染，这里直接对接它们的后端接口：
 *   yiove    GET /shuyuan/book-sources?page&page_size      + /shuyuan/search?search_key
 *   yuancang GET /api/v1/sources?platform_id=1&category_id=1&page&page_size&q
 *   yckceo   GET /yuedu/shuyuan/index.html?page&keys       （HTML，自己解析）
 * 导入（拿书源 JSON）：
 *   yiove    GET /import/book-source/{id}
 *   yuancang GET /api/v1/sources/{id}/content → data.content(JSON 字符串)
 *   yckceo   GET /yuedu/shuyuan/json/id/{id}.json
 */

const { parseHTML, selectAll } = require('../core/html');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

const REPOS = [
  {
    id: 'yiove',
    name: 'Yiove 书源仓库',
    home: 'https://shuyuan.yiove.com/book-sources?page=1&page_size=20',
    note: '书源列表最全，带有效率标记',
  },
  {
    id: 'yuancang',
    name: '源仓 yuancang.cc',
    home: 'https://yuancang.cc/platform/1?cat=%E4%B9%A6%E6%BA%90',
    note: '按板块分类，支持版本记录',
  },
  {
    id: 'yckceo',
    name: '源仓库 yckceo.com',
    home: 'https://www.yckceo.com/yuedu/shuyuan/index.html',
    note: '老牌书源站，带下载量与发布者',
  },
];

const REPO_MAP = REPOS.reduce((m, r) => { m[r.id] = r; return m; }, {});

/* ───────────── HTTP ───────────── */

async function getText(url, opts = {}) {
  const timeout = opts.timeout || 15000;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      redirect: 'follow',
      headers: Object.assign({
        'User-Agent': UA,
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.6',
        Accept: 'text/html,application/json,application/xhtml+xml,*/*;q=0.8',
      }, opts.headers || {}),
    });
    const body = await res.text();
    if (!res.ok) {
      const err = new Error('HTTP ' + res.status + ' ' + url);
      err.status = res.status;
      err.body = body.slice(0, 200);
      throw err;
    }
    return { text: body, status: res.status, url: res.url || url };
  } finally {
    clearTimeout(timer);
  }
}

async function getJson(url, opts = {}) {
  const { text } = await getText(url, opts);
  try {
    return JSON.parse(text);
  } catch (e) {
    throw new Error('接口返回不是 JSON：' + text.slice(0, 120));
  }
}

async function retry(fn, times = 2) {
  let last;
  for (let i = 0; i <= times; i++) {
    try { return await fn(); } catch (e) { last = e; }
  }
  throw last;
}

/* ───────────── 缓存 ───────────── */

const cache = new Map();
const CACHE_TTL = 120 * 1000;

function cached(key, ms, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ms) return Promise.resolve(hit.value);
  return fn().then((value) => {
    cache.set(key, { at: Date.now(), value });
    if (cache.size > 300) cache.delete(cache.keys().next().value);
    return value;
  });
}

/* ───────────── 工具 ───────────── */

function clampInt(v, dflt, min, max) {
  const n = parseInt(v, 10);
  if (!isFinite(n)) return dflt;
  return Math.max(min, Math.min(max, n));
}

function splitNameUrl(text) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  const m = /^(.*?)\s+(https?:\/\/\S+)$/.exec(s);
  if (m) return { name: m[1].trim(), url: m[2].trim() };
  return { name: s, url: '' };
}

function ts(v) {
  if (!v) return 0;
  if (typeof v === 'number') return v > 1e12 ? Math.round(v) : Math.round(v * (v > 1e9 ? 1000 : 1));
  const t = Date.parse(v);
  return isFinite(t) ? t : 0;
}

/* ───────────── yiove ───────────── */

const YIOVE = 'https://shuyuan-api.yiove.com';
const YIOVE_HEADERS = { Origin: 'https://shuyuan.yiove.com', Referer: 'https://shuyuan.yiove.com/' };

async function yioveList({ page, size, keyword }) {
  const q = String(keyword || '').trim();
  const url = q
    ? YIOVE + '/shuyuan/search?search_key=' + encodeURIComponent(q)
      + '&search_type=book-sources&page=' + page + '&page_size=' + size
    : YIOVE + '/shuyuan/book-sources?page=' + page + '&page_size=' + size;
  const json = await retry(() => getJson(url, { headers: YIOVE_HEADERS }));
  const items = (json.items || []).map((x) => ({
    id: x.id,
    name: String(x.name || '').trim(),
    url: String(x.url || '').trim(),
    desc: String(x.description || '').trim(),
    author: '',
    extra: x.is_valid === false ? '可能失效' : '',
    views: x.view_total || 0,
    time: ts(x.create_time),
    tags: [],
  }));
  const total = json.total || items.length;
  return { items, total, pages: Math.max(1, json.pages || Math.ceil(total / size)) };
}

async function yioveImport(id) {
  const json = await retry(() => getJson(YIOVE + '/import/book-source/' + encodeURIComponent(id), { headers: YIOVE_HEADERS }));
  const list = Array.isArray(json) ? json : [json];
  return { name: String((list[0] && list[0].bookSourceName) || ''), sources: list };
}

/* ───────────── yuancang ───────────── */

const YC = 'https://yuancang.cc';
const YC_HEADERS = { Origin: YC, Referer: YC + '/platform/1', Accept: 'application/json, text/plain, */*' };

async function yuancangList({ page, size, keyword }) {
  const q = String(keyword || '').trim();
  let url = YC + '/api/v1/sources?platform_id=1&category_id=1&page=' + page + '&page_size=' + size;
  if (q) url += '&q=' + encodeURIComponent(q);
  const json = await retry(() => getJson(url, { headers: YC_HEADERS }));
  const data = json.data || {};
  const items = (data.items || []).map((x) => ({
    id: x.id,
    name: String(x.name || '').trim(),
    url: '',
    desc: String(x.description || '').trim(),
    author: String(x.username || ''),
    extra: String(x.category_name || x.type || ''),
    views: x.download_count || 0,
    time: ts(x.updated_at || x.created_at),
    tags: Array.isArray(x.tag_list) ? x.tag_list.slice(0, 3) : [],
    version: String(x.version || ''),
  }));
  const total = data.total || items.length;
  return { items, total, pages: Math.max(1, Math.ceil(total / size)) };
}

/** 从任意文本里抠出书源 JSON（有的仓库把 JSON 塞在字符串里、带转义或 base64） */
function parseSourcesText(text) {
  const s = String(text || '').trim();
  if (!s) return [];
  const tryParse = (t) => {
    try { return JSON.parse(t); } catch (e) { return undefined; }
  };
  let v = tryParse(s);
  if (typeof v === 'string') v = tryParse(v); // 双重编码
  if (v === undefined) {
    const at = s.search(/[[{]/);
    if (at > 0) v = tryParse(s.slice(at));
  }
  if (v === undefined && /^[A-Za-z0-9+/=\s]+$/.test(s) && s.length > 40) {
    try {
      const dec = Buffer.from(s.replace(/\s+/g, ''), 'base64').toString('utf8');
      v = tryParse(dec);
    } catch (e) { /* ignore */ }
  }
  if (v === undefined || v === null) return [];
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object') {
    if (Array.isArray(v.sources)) return v.sources;
    if (v.bookSourceUrl || v.bookSourceName) return [v];
    if (v.data) return parseSourcesText(typeof v.data === 'string' ? v.data : JSON.stringify(v.data));
  }
  return [];
}

async function yuancangImport(id) {
  const json = await retry(() => getJson(YC + '/api/v1/sources/' + encodeURIComponent(id) + '/content', { headers: YC_HEADERS }));
  const data = (json && json.data) || {};
  const sources = parseSourcesText(data.content);
  if (!sources.length) {
    throw new Error('该书源内容为加密/异常格式，无法直接导入（可在源仓网页端手动导入）');
  }
  return { name: String(data.name || (sources[0] && sources[0].bookSourceName) || ''), sources };
}

/* ───────────── yckceo ───────────── */

const YCK = 'https://www.yckceo.com';
const YCK_HEADERS = { Referer: YCK + '/yuedu/shuyuan/index.html' };

function yckceoParse(html) {
  const root = parseHTML(String(html || ''));
  const items = [];
  for (const el of selectAll(root, '.ylist')) {
    const a = selectAll(el, 'h2 a')[0];
    if (!a) continue;
    const href = a.attr('href') || '';
    const idm = /\/id\/(\d+)\.html/.exec(href);
    if (!idm) continue;
    const { name, url } = splitNameUrl(a.textContent);
    const timeText = (selectAll(el, 'p.m-right')[0] || { textContent: '' }).textContent.trim();
    const badges = selectAll(el, 'span')
      .map((s) => s.textContent.replace(/\s+/g, ' ').trim())
      .filter(Boolean);
    const user = (badges.find((b) => b.indexOf('用户') === 0) || '').replace(/^用户[:：]\s*/, '');
    const views = parseInt(((badges.find((b) => b.indexOf('下载') === 0) || '').replace(/[^\d]/g, '') || '0'), 10) || 0;
    items.push({
      id: idm[1],
      name: name,
      url: url,
      desc: '',
      author: user,
      extra: badges.filter((b) => !/^用户|^下载/.test(b)).join(' · '),
      views,
      timeText,
      time: 0,
      tags: [],
    });
  }
  const totalM = /共有\s*([\d,]+)\s*条数据/.exec(String(html || ''));
  const total = totalM ? parseInt(totalM[1].replace(/,/g, ''), 10) : items.length;
  return { items, total };
}

async function yckceoList({ page, size, keyword }) {
  const q = String(keyword || '').trim();
  let url = YCK + '/yuedu/shuyuan/index.html?page=' + page;
  if (q) url += '&keys=' + encodeURIComponent(q);
  const { text } = await retry(() => getText(url, { headers: YCK_HEADERS }));
  const { items, total } = yckceoParse(text);
  // 该站固定每页 100 条，和请求里的 size 无关
  return { items, total, pages: Math.max(1, Math.ceil(total / 100)) };
}

async function yckceoImport(id) {
  const { text } = await retry(() => getText(YCK + '/yuedu/shuyuan/json/id/' + encodeURIComponent(id) + '.json', { headers: YCK_HEADERS }));
  const sources = parseSourcesText(text);
  if (!sources.length) throw new Error('书源 JSON 解析失败');
  return { name: String((sources[0] && sources[0].bookSourceName) || ''), sources };
}

/* ───────────── 对外接口 ───────────── */

async function list(repoId, opts = {}) {
  const repo = REPO_MAP[repoId];
  if (!repo) throw new Error('未知仓库: ' + repoId);
  const page = clampInt(opts.page, 1, 1, 10000);
  const size = clampInt(opts.size, 20, 5, 100);
  const keyword = String(opts.keyword || '').trim();
  const key = repoId + '|' + page + '|' + size + '|' + keyword;
  const data = await cached(key, CACHE_TTL, () => {
    if (repoId === 'yiove') return yioveList({ page, size, keyword });
    if (repoId === 'yuancang') return yuancangList({ page, size, keyword });
    return yckceoList({ page, size, keyword });
  });
  return Object.assign({ repo: repoId, page, size, keyword }, data);
}

async function importOne(repoId, id) {
  if (!REPO_MAP[repoId]) throw new Error('未知仓库: ' + repoId);
  if (!id) throw new Error('缺少书源 id');
  if (repoId === 'yiove') return Object.assign({ repo: repoId }, await yioveImport(id));
  if (repoId === 'yuancang') return Object.assign({ repo: repoId }, await yuancangImport(id));
  return Object.assign({ repo: repoId }, await yckceoImport(id));
}

module.exports = { REPOS, REPO_MAP, list, importOne, parseSourcesText, getText, getJson };
