'use strict';
/*
 * 书源仓库（本地 sources.json 的读写层）
 *   - 保存完整的书源数组（含 enabled:false 的，Engine 只吃启用的）
 *   - 导入去重按 bookSourceUrl（去掉 # 后面的备选域、末尾斜杠、大小写）
 *   - 写盘用 tmp + rename，避免写一半把配置写坏
 */

const fs = require('fs');
const path = require('path');
const { parseExplore } = require('../core/source');

function keyOf(s) {
  const u = String((s && s.bookSourceUrl) || '').split('#')[0].trim().replace(/\/+$/, '').toLowerCase();
  if (u) return u;
  return 'name:' + String((s && s.bookSourceName) || '').trim().toLowerCase();
}

function normalize(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const s = Object.assign({}, raw);
  s.bookSourceName = String(s.bookSourceName || s.name || '').trim();
  s.bookSourceUrl = String(s.bookSourceUrl || s.url || '').split('#')[0].trim();
  if (!s.bookSourceUrl || !/^https?:\/\//i.test(s.bookSourceUrl)) return null;
  if (!s.bookSourceName) {
    try { s.bookSourceName = new URL(s.bookSourceUrl).host; } catch (e) { s.bookSourceName = s.bookSourceUrl; }
  }
  if (s.enabled === undefined) s.enabled = true;
  return s;
}

class SourceStore {
  constructor(file) {
    this.file = file;
    this.raw = [];
    this.error = '';
    this.mtime = 0;
  }

  load() {
    try {
      const text = fs.readFileSync(this.file, 'utf8');
      const json = JSON.parse(text);
      const list = Array.isArray(json) ? json : (json && Array.isArray(json.sources) ? json.sources : []);
      this.raw = list.filter((x) => x && typeof x === 'object');
      this.error = '';
      this.mtime = Date.now();
    } catch (e) {
      this.raw = this.raw || [];
      this.error = '读取书源文件失败：' + e.message;
      throw e;
    }
    return this.raw;
  }

  save() {
    const dir = path.dirname(this.file);
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { /* ignore */ }
    const tmp = this.file + '.tmp-' + process.pid;
    fs.writeFileSync(tmp, JSON.stringify(this.raw, null, 2), 'utf8');
    fs.renameSync(tmp, this.file);
    this.mtime = Date.now();
  }

  get size() { return this.raw.length; }
  get enabledSize() { return this.raw.filter((s) => s.enabled !== false).length; }

  list() { return this.raw.slice(); }

  info() {
    return this.raw.map((s, i) => {
      let channels = [];
      try { channels = parseExplore(s.exploreUrl); } catch (e) { channels = []; }
      return {
        index: i,
        name: String(s.bookSourceName || ('书源' + (i + 1))),
        host: String(s.bookSourceUrl || ''),
        group: String(s.bookSourceGroup || ''),
        enabled: s.enabled !== false,
        searchable: !!s.searchUrl,
        channels: channels.map((c) => c.title),
        type: s.bookSourceType || 0,
      };
    });
  }

  find(key) {
    const k = typeof key === 'number' ? key : null;
    if (k != null) return k >= 0 && k < this.raw.length ? k : -1;
    const want = String(key || '');
    for (let i = 0; i < this.raw.length; i++) {
      if (String(this.raw[i].bookSourceUrl || '') === want) return i;
    }
    return -1;
  }

  /** 合并导入：同 URL 覆盖规则，新 URL 追加 */
  addMany(list, opts = {}) {
    const incoming = (Array.isArray(list) ? list : [list]).map(normalize).filter(Boolean);
    const added = [];
    const updated = [];
    const invalid = (Array.isArray(list) ? list : [list]).length - incoming.length;
    const touched = [];
    for (const src of incoming) {
      const k = keyOf(src);
      let at = -1;
      for (let i = 0; i < this.raw.length; i++) {
        if (keyOf(this.raw[i]) === k) { at = i; break; }
      }
      if (at >= 0) {
        const old = this.raw[at];
        this.raw[at] = Object.assign({}, src, {
          // 用户自己关掉的源，导入时保留关闭状态；其余以新导入为准
          enabled: old.enabled === false ? false : true,
        });
        if (added.indexOf(this.raw[at].bookSourceName) < 0) updated.push(this.raw[at].bookSourceName);
      } else {
        const built = Object.assign({}, src, { enabled: true });
        this.raw.push(built);
        added.push(built.bookSourceName);
        at = this.raw.length - 1;
      }
      touched.push({ index: at, name: this.raw[at].bookSourceName });
    }
    if (incoming.length) this.save();
    return {
      added, updated, invalid,
      imported: incoming.length,
      touched,
      repo: opts.repo || '',
    };
  }

  setEnabled(index, enabled) {
    const at = this.find(index);
    if (at < 0) throw new Error('书源不存在: ' + index);
    this.raw[at].enabled = !!enabled;
    this.save();
    return { index: at, name: this.raw[at].bookSourceName, enabled: this.raw[at].enabled };
  }

  remove(index) {
    const at = this.find(index);
    if (at < 0) throw new Error('书源不存在: ' + index);
    const [gone] = this.raw.splice(at, 1);
    this.save();
    return { index: at, name: gone.bookSourceName };
  }

  move(index, delta) {
    const at = this.find(index);
    const to = at + delta;
    if (at < 0 || to < 0 || to >= this.raw.length) throw new Error('位置无效');
    const [item] = this.raw.splice(at, 1);
    this.raw.splice(to, 0, item);
    this.save();
    return { index: to, name: item.bookSourceName };
  }

  setAll(enabled) {
    for (const s of this.raw) s.enabled = !!enabled;
    this.save();
    return { total: this.raw.length, enabled: !!enabled };
  }
}

module.exports = { SourceStore, keyOf, normalize };
