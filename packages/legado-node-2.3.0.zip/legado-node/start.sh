#!/usr/bin/env bash
# 前台启动： bash start.sh [端口]
set -e
cd "$(dirname "$0")"
PORT="${1:-13000}"
if ! command -v node >/dev/null 2>&1; then
  echo "没找到 node，请先装 Node.js 18+"
  exit 1
fi
echo "启动阅读源服务，端口 $PORT ..."
exec node index.js --port "$PORT"
