/*
@header({
  searchable: 2,
  filterable: 1,
  quickSearch: 1,
  title: '蓝莓短剧',
  '类型': '短剧',
  lang: 'ds'
})
*/

// ===========================================================================
//  蓝莓短剧 CatVod 数据源 —— 占位实现（壳）
// ---------------------------------------------------------------------------
//  后端二进制已经就绪，监听 127.0.0.1:8997，并提供以下接口（网页端 / API）：
//    GET /web/api/platforms                平台清单（section.Key / section.Name）
//    GET /web/api/list?plat=&cat=&page=    分类列表（返回 webCard 数组）
//    GET /web/api/search?plat=&wd=&page=   搜索
//    GET /web/api/series?plat=&id=         详情（含 episodes 列表）
//    GET /web/api/playone?plat=&id=&ep=    单集直链（返回 {src, type}）
//    GET /media?u=<b64>                     媒体代理（playone 的 src 即指向它）
//
//  下面 一级 / 二级 / lazy 只是骨架，需要按 CatVod 规则把上面的接口映射成
//  vod_id / vod_name / vod_pic / vod_remarks / vod_content / vod_play_url 等。
//  参考实现：juku-lite-1/ds/短剧库.js（它调的是 /api/home 等 CatVod 风格接口，
//  蓝莓没有那套，需改接上面列出的 /web/api/*）。
// ===========================================================================

var rule = {
    title: '蓝莓短剧',
    host: 'http://127.0.0.1:8997',
    homeUrl: 'http://127.0.0.1:8997/web/api/list?plat=hongguo&page=1',
    searchUrl: 'http://127.0.0.1:8997/web/api/search?wd=**&plat=hongguo&page=fypage',
    url: 'http://127.0.0.1:8997/web/api/list?plat=fyclass&page=fypage',
    // TODO: 从 GET /web/api/platforms 取 section.Name 用 & 拼成 class_name，
    //       取 section.Key 用 & 拼成 class_url（顺序需一一对应）。
    class_name: '红果',
    class_url: 'hongguo',
    filterable: 1,
    headers: {
        'User-Agent': 'MOBILE_UA'
    },
    timeout: 15000,
    multi: 1,
    searchable: 2,
    play_parse: true,

    // 一级（分类 / 搜索列表）：调 /web/api/list 或 /web/api/search，
    // 把每条 webCard {id,plat,plat_name,name,cover,remarks,desc}
    // 映射为 vod_id / vod_name / vod_pic / vod_remarks / vod_content。
    一级: async function () {
        // TODO: 实现
        return '';
    },

    // 二级（详情 + 选集）：调 /web/api/series 拿 episodes，
    // 再按需 /web/api/episode 或 /web/api/playone，
    // 组装 vod_play_from / vod_play_url（格式：集名$播放地址#集名$播放地址）。
    二级: async function () {
        // TODO: 实现
        return { vod_play_from: '蓝莓', vod_play_url: '' };
    },

    // lazy（解析直链）：调 /web/api/playone?plat=&id=&ep=，
    // 返回 { parse: 0, url: data.src }（src 形如 /media?u=<b64>）。
    lazy: async function () {
        // TODO: 实现
        return { parse: 0, url: '' };
    }
};
