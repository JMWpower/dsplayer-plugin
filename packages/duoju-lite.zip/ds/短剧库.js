/*
@header({
  searchable: 2,
  filterable: 1,
  quickSearch: 1,
  title: '短剧库',
  '类型': '短剧',
  lang: 'ds'
})
*/

// 主分类 = 平台（红果/黄豆/黄果），子分类 = 各平台自己的分类（filter 按主分类 id 分组）
var filter_def = 'H4sIAAAAAAAC/60aWVMTzfa/8CwlSUgCPl0ffbhV98mXW1/dGkhMBmGCSUbAr6yCL6zKkggiSARZZJFFENRAiPyZ6ZnJv7hnMr2cHoZAJFVoVfc50332rfN3SzKlJRJ6quXRf/9ueR4fannU0q1kWx60aEpfHBZkctw6KcP6pdKrx2tYGmybw2Urd2i+OzS3iw4QttKK9rw1mcq2vH7g4ljFNePigkzteHDScaWXI5mX+9cxulN9ajdHefzkOoaiXr+GweH41lha6VM8l1B47XAPQu0KCldUBvzr9V8PWgbiakJXtAblQ8Z2q7lddmJvLz0sGYdzGzvJ+v67OjxFT+pRtcSgQw0jnMxt2ZtjFJrQXyUBmODQ6sSMtbDG+HY0nUnGEZwc/SQXh/xsJasioDny1po8ocBeVdEcmde4yCQVLQmrZjICKjSPF7gKtRdCwebisdDOoKr16EL3C0Vy9JmCskBjjUnB//C4vcH409RBcSa5vLCHx8jKKqm8o/AX8HniVTIucL5MkPMyhyYluW/NGOUJCnumw7WCKKN0SFYq5sY2Bb+iLtZ3u+hdI1FSzxs2ONcbsRd0pWJAMRJWHTmak0vWl1VOr6I5diKk/GXVPvlKoQ4EKMRAMl1GwCH1ruqxfyyRvSt+q64OIs3uXdk/33gMGPgZ0pGCLv+xcxUKHVI1LF97OQ8GzFSvxx0DRsLfNxc/kKMx+J/5DhAWQ0q0ZkeF8h1LddVfU1CXosb0+wSEF3BWl34nEVZzFVL6h8JieiaJpDt7bJQ37d1hMzfGtapoMUUdUsB/sLHVEdTNPnKL9iAF2JsjTHsA6UZB2c5Pk6NPFOgYfhcymfrWdrNyAFWVdFTPLusaQPXDV7L3kX/paFe7TfW3G6ZfhD0/Ax1x6da044kBxuW2lR+XI0GvrvWqOMh7FZ3QfdRsHm4bvz/D/+bUPMUb0MEkBgD5Tk5X/fTOXPpifl4nK4c87oFiQTpwTGpIuACEj8RQo6kMog8pXjBOIWjiXHWHAGZcfiSFJaM0b1zsUyygfwhrx1xagyRDvlSkSCenmjpxsLp0SsamJDpByImEm1VrnL9Q+5SGq6XZXXsmTw9s8yekNeDxeVC2OcpMLBCMhvyTPkCC/tEiHA14bNooL4OB8A87Iv65LhwVNBrn6+anAgN0IuKPC5Dl+Bchf5MPY+KuWxfQ0OExXwoJYeJ3Coi4znbxRXHfKC0yQDiCqolp82CdjOXEPZ3+Ea+9rc3j2pyAkH+2j3aGxRenZavMdBTtiArKPuXs47f8izb/kiza0Y40cGoO75iT+er7K0415nVq3h4tOVGtxIQbDUT8I1p7R1u9Sqe9TSjFvqqQ7bI1sm8XDoTRRwNh/0olgkyjundgLXzn0heKtEem0VHBdk9oZwJuFwKu7i+ZU2+N0ltyciKYFyojuyfGed5cmgX/FvCwf4KLBqPoxjF8o+DbXLmyeRSJBoLYCIxzVrqFQoIr8n4cEhe/I4TME1R6bJXnAEMQF0BhCwV4gKAvt35DTLO/fapuLAm4kLA9cUa+TTOtdQoiycgvkj8gVzmyecw/xBoYLZhnLMOGg8JMIF9WP+xKqTuCFCSl7RByKCllh5GAofsiIxNkJledYFGiA0lTyjahiH/JEwhGOv2Teghp8ngOegRrak8ICoWvlQ1RqoTbhWGYBxtksUjGt8CKmRwjktOREuM3EhC3Ved/krmCuArRMfbDmmWeHezwrzeQY0pVVFBYhfnPgbXIbkACNfOr1kGBRw5kLCM/wMxFQIvShBSDXhWyU4PtwuSJKCYUVSoj6pSc9dtNqUK5VoPW6abcFt7aGeZlSVyDHnBQ1f3F5aRz3GZUCiKPDgBFPd6SxlPM8CLmWRMa+9uldgMNDZfxrvOyykdxGkqUonbAmI0Sk3BM0V6Ceu5Q5vsklpjiVMtOQav4J0fRivFq0PnX1IkAFISC23QcM+tXwdUIGVL7mjuWqDNBqDMB8B2d3HUmM7dV3ZzlLvYMw+o1inWdr45x1nMsMjtO5r5zPmqfuUMx3SW6QVHjUOhGMD8xS0UhWIG9PuxXxrl+45c23X5JSsW0dP8DI5WagYC/CYY8XQyL6p62hAV1T7vB0hal8rk+0Gh/YU0XjcpnM3dqFXkGQuKAFF04lSJ+ADGycka2PoIXkIpIrYLCYqk6Mu/WC9bHUSdKc+MNhDxpnlTmAZlB2/H4Ff7cStP+9Y0heEtMueGJUHFoqg5/94nS2GLAS+guXeDMxmF04esGdOHrWXQhupDvQuR04TtkoAtfm6cLTgtUM9zu6MLXlemCfze+Ylww46ALUdL8NMqLzpCdUytt8WypN1xlVHydBMeBiH8QCNfLjwF/8bf7SzcYqjdJ4YaWcYuZZhgaZOLqRkHKAtKWXKZLapO25JZaysDSllyeSV2+tCWLVJKdtCXOm7ErB/yk2oKfMVkxF1n+owsOW0ODHLpgiWPgXr5MF8KSfoFU2UXuQlaCJP47ea1UCdEFP/PNCbli7SRd+JovXfgmdbrwLSTowrf3pos7eTsutumCPi44Ru4MURt+7xMvcFLZe7hgLpwLWF8qgYodM1+0zjYENBNX0t1JAV74aX+YE+BnystUWs2iCf/RtFWeRwiqBlWIh5Vgg7xUtxer6z9YGQ1VNHoGlCzXeQmUJ5CPn0hPiYDQJz+xbBfJzHv0UAn1RgaT2/hLq1ufShPEdLw71Qf1cAwNwobtq4JRegNlCStW4wPxTLZ5rAF8ZgMaBQF3GJKm6o+fuNaAjpCswe/FOPMQPxm7bHoxfPitFMmbFS9efyob17Kq0uuReLBZPZ59tWqVD/1S2r+fPqyunRrneQEM4HBoTU1cKwphzzz6cS13ubqEskzoUu+PKdl4Bonpnb0+LbOP3g8p26neWKOeUR41V4tkdo1MrrB3H6WrtQ0bwWTeKQKxLTkogWsokjU5KMGb7MQBhjDtPQ1Hp+KwENa/wPJZOxj/g182YE9jI5aecOA+AdPRD9av2zyItqJGMQWHAx75Jx7xrRuc2cHhW2Ji52gBYdANUdR6bmF31Djudtq7xoUnHeo8zHR7fpCA9e5JFdhe5NDjjofk2dDNgc0T1yRn7kqnBjJiauHYmqo0ISLjGOZeKOk3m4yD/6ZRO+gMsqV4Chc/krb5cZUTe2dcEpyDK22L8mTX6bVKJXNyDuPi7XrvmIArbcvPHNKQvYaLt3nTUys1jasj0BrClbblelV6K6nRi7elmKbcx5mvp5F7mKsnXfoZrGSXTTHbBz7hzoW1iqD33GGh6w/MWgopreGewW4VZebDTXtnVMLRUuk+pfd/mWQqnfWEHZm3mN6bZWg0nnYG7kOd94ctt2nimhoQhuNFvE3IJNV+VfPkWQrrV1TpwdqjQUfizk+IHglV1njtiwXb2jsa5NZzNnzSGkQPmBdl+2TcNd7HTxBOxINiXH4mX98hBHGGWRqzLr6R4wJ0RggBzXQePzVKh9DVkcMP5Pw9pgQ9u1SMix174qv5dgYfggS4YUOXtLUjHo8cBFHsdAauAaN4VErmNu3jnPl+GR+P+vzlir08S/b3yPY5pjDo/Y3F+YlxuY0x0NtjuWAuLpN8zpov4lvQ62MNRlZ+i4a3P5XJZjzOKlmS+M2faw0pLd6sKpSMzdhnjN1n6bgIDE+f/OehtfMNDqTQl2o/m26k9B69aXXwXecWzZ5H3HWuUhvwSK+c0lajcxWfEZS0Jc9LpKmXtCW/AUi/oJC2HJW9/j+QubVWmysAAA==';;;;;

var rule = {
    title: '短剧库',
    host: 'http://127.0.0.1:8998',
    homeUrl: 'http://127.0.0.1:8998/api/home?plat=hongguo&page=1',
    searchUrl: 'http://127.0.0.1:8998/api/search?wd=**&plat=fyclass&page=fypage',
    url: 'http://127.0.0.1:8998/api/category?plat=fyclass&page=fypage',
    filter_url: 'cat={{fl.cat}}',
    class_name: '红果&围观&河马&山海&好看&百度&星芽&七猫&大芒&西饭&星星&薏米&悟圣&七星&酷我&牛牛&喜福&爽爽&五五&搜剧AI',
    class_url: 'hongguo&weiguan&hema&shanhai&haokan&baidu&xingya&qimao&damang&xifan&xingxing&yimi&wusheng&qixing&kuwo&niuniu&xifu&shuang&wuwu&souju',
    filter: filter_def,
    filterable: 1,
    headers: {
        'User-Agent': 'MOBILE_UA'
    },
    timeout: 15000,
    multi: 1,
    searchable: 2,
    play_parse: true,
    推荐: 'json:data.list;vod_name;vod_pic;vod_remarks;vod_id;vod_content',
    一级: 'json:data.list;vod_name;vod_pic;vod_remarks;vod_id;vod_content',
    搜索: 'json:data.list;vod_name;vod_pic;vod_remarks;vod_id;vod_content',
    二级: async function () {
        let id = String(this.vid || this.orId || '').trim();
        if (!id) {
            id = String(this.input || '').split('?')[0].split('/').pop();
        }
        let platKey = '';
        let platName = '短剧库';
        // 平台名表：顺序与 class_name / class_url 一致，跟 Go 侧 platformOrder 同步
        const PLAT_NAMES = {
            hongguo: '红果', weiguan: '围观', hema: '河马', shanhai: '山海',
            haokan: '好看', baidu: '百度', xingya: '星芽', qimao: '七猫',
            damang: '大芒', xifan: '西饭', xingxing: '星星', yimi: '薏米',
            wusheng: '悟圣', qixing: '七星', kuwo: '酷我', niuniu: '牛牛', xifu: '喜福', shuang: '爽爽',
            wuwu: '五五', huangdou: '黄豆', huangdou2: '黄豆2', huangguo: '黄果',
            huangguo2: '黄果2', huangguoold: '黄果旧版', huangju: '黄剧',
            yeguo: '野果', dj51: '51短剧', chengguo: '橙果', xiangjiao: '香蕉',
            huanggua: '黄瓜', kuangbiao: '狂飙', dj91: '91短剧', md2048: '2048短剧',
            duanjuone: '短剧one', souju: '搜剧AI'
        };
        let colonIdx = id.indexOf(':');
        if (colonIdx > 0) {
            platKey = id.substring(0, colonIdx);
            if (PLAT_NAMES[platKey]) platName = PLAT_NAMES[platKey];
        }
        let api = 'http://127.0.0.1:8998/api/detail?id=' + encodeURIComponent(id);
        let html = JSON.parse(await request(api));
        let d = html.data || {};
        let base_vod = {
            vod_id: id,
            vod_name: d.vod_name || '',
            type_name: d.vod_class || '',
            vod_pic: d.vod_pic || '',
            vod_content: d.vod_content || ''
        };
        let playUrls = [];
        for (let ep of (d.episodes || [])) {
            playUrls.push((ep.name || ('第' + ep.no + '集')) + '$' + ep.url);
        }
        base_vod.vod_play_from = platName;
        base_vod.vod_play_url = playUrls.join('#');
        return base_vod;
    },
    lazy: async function () {
        let {input} = this;
        let playPage = String(input || '').trim();
        if (!playPage) {
            return {parse: 0, url: ''};
        }
        let api = 'http://127.0.0.1:8998/api/play?url=' + encodeURIComponent(playPage);
        let res = JSON.parse(await request(api));
        if (res && res.code === 200 && res.data && res.data.url) {
            return {parse: 0, url: res.data.url};
        }
        return {parse: 0, url: playPage};
    }
};