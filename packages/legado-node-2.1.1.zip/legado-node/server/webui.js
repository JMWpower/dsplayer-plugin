'use strict';
/*
 * 管理面板的 JSON 接口（前端在 web/ 下，纯静态，无构建步骤）
 *
 *   GET  /api/state                     服务状态 + 书源列表 + 引擎信息
 *   GET  /api/browse?t=&pg=&ch=&key=     浏览/搜索
 *   GET  /api/source?i=                 单个书源原始 JSON
 *   POST /api/source/toggle             {index, enabled?}
 *   POST /api/source/remove             {index}
 *   POST /api/source/move               {index, delta}
 *   POST /api/source/all                {enabled}
 *   POST /api/source/test               {index, key?}
 *   GET  /api/repos                     三个仓库
 *   GET  /api/repo?r=&pg=&key=          仓库书源列表
 *   POST /api/import                    {repo, id}   导入并顺便测一次内容
 *   POST /api/health                    {index?}    全量/单个书源体检
 *   GET  /legado_html.json              HTML 规则书源 JSON
 */

const repos = require('./repos');
const { bookSourceJson } = require('./legado');
const { mapLimit } = require('../core/engine');

function readBody(req) {
  return new Promise((resolve, reject) => {
    if (req.method === 'GET' || req.method === 'HEAD') return resolve({});
    let buf = '';
    req.on('data', (c) => {
      buf += c;
      if (buf.length > 2 * 1024 * 1024) { reject(new Error('请求体过大')); req.destroy(); }
    });
    req.on('end', () => {
      if (!buf) return resolve({});
      try { resolve(JSON.parse(buf)); } catch (e) { resolve({}); }
    });
    req.on('error', reject);
  });
}

function createApi(deps) {
  const getEngine = deps.getEngine;
  const store = deps.store;
  const reload = deps.reload || (() => {});
  const searchBudget = deps.searchBudget || 9000;

  function engineOrThrow() {
    const e = getEngine();
    if (!e || !e.sources.length) throw new Error('没有可用的书源，请先到「源仓库」导入');
    return e;
  }

  async function browse(q) {
    const e = engineOrThrow();
    const key = (q.get('key') || '').trim();
    const pg = Math.max(1, parseInt(q.get('pg') || '1', 10) || 1);
    const t = q.get('t');
    const sources = e.sources.map((s, i) => ({ index: i, name: s.name, channels: (s.channels || []).map((c) => c.title) }));
    if (key) {
      const r = await e.search(key, { timeout: searchBudget });
      return {
        mode: 'search', key, sources, page: 1, pagecount: 1,
        list: (r.list || []).map(item),
      };
    }
    // 没指定书源时优先挑一个「上次抓过且有内容」的
    let idx;
    if (t == null || t === '') {
      idx = e.sources.findIndex((s, i) => e.statusOf(i).state === 'ok');
      if (idx < 0) idx = 0;
    } else {
      idx = Math.min(e.sources.length - 1, Math.max(0, parseInt(t, 10) || 0));
    }
    const src = e.sources[idx];
    const ch = q.get('ch') || '';
    const r = await e.category(String(idx), pg, ch).catch(() => ({ list: [], pagecount: 1 }));
    const st = e.statusOf(idx);
    return {
      mode: 'browse', index: idx, name: src.name, page: pg,
      pagecount: r.pagecount || 1,
      channels: (src.channels || []).map((c) => ({ title: c.title, url: c.url })),
      channel: ch, sources,
      state: st.state, msg: st.msg,
      list: (r.list || []).map(item),
    };
  }

  function item(v) {
    return {
      id: v.vod_id,
      name: v.vod_name,
      author: v.vod_actor || '',
      kind: v.type_name || v.vod_area || '',
      last: v.vod_remarks || '',
      intro: v.vod_content || '',
      cover: v.vod_pic || '',
      link: '/hs/book?id=' + encodeURIComponent(v.vod_id || ''),
    };
  }

  /** 返回 true 表示这个请求已经被处理 */
  async function handle(req, res, url, rawJson, base) {
    // 本文件里统一写 sendJson(res, status, obj)，这里适配外部 sendJson(res, obj, status)
    const sendJson = (r, status, obj) => rawJson(r, obj, status);
    const p = url.pathname;
    const q = url.searchParams;
    let body = null;
    const need = async () => (body = body || await readBody(req));

    if (p === '/api/state') {
      const e = getEngine();
      const sources = store.info().map((s) => {
        const st = e ? e.statusForUrl(s.host) : null;
        return Object.assign({}, s, {
          state: st ? st.state : 'unknown',
          msg: st ? st.msg : '',
          checkedAt: st ? st.at : 0,
        });
      });
      const broken = sources.filter((s) => s.enabled && (s.state === 'empty' || s.state === 'error' || s.state === 'timeout')).length;
      sendJson(res, 200, {
        ok: true,
        data: {
          name: '阅读源 · Node',
          base,
          sources,
          total: store.size,
          enabled: store.enabledSize,
          broken,
          engine: {
            count: e ? e.sources.length : 0,
            error: deps.getEngineError ? deps.getEngineError() : '',
          },
          repos: repos.REPOS,
          bookSourceUrl: base + '/legado_html.json',
        },
      });
      return true;
    }

    if (p === '/api/browse') {
      sendJson(res, 200, { ok: true, data: await browse(q) });
      return true;
    }

    if (p === '/api/source') {
      const i = parseInt(q.get('i') || '-1', 10);
      const raw = store.list()[i];
      if (!raw) { sendJson(res, 404, { ok: false, error: '书源不存在' }); return true; }
      sendJson(res, 200, { ok: true, data: raw });
      return true;
    }

    if (p.indexOf('/api/source/') === 0) {
      const act = p.slice('/api/source/'.length);
      await need();
      const index = parseInt(body.index, 10);
      try {
        if (act === 'toggle') {
          const info = store.info()[index];
          if (!info) throw new Error('书源不存在');
          const r = store.setEnabled(index, body.enabled == null ? !info.enabled : !!body.enabled);
          reload();
          sendJson(res, 200, { ok: true, data: r });
          return true;
        }
        if (act === 'remove') {
          const r = store.remove(index);
          reload();
          sendJson(res, 200, { ok: true, data: r });
          return true;
        }
        if (act === 'move') {
          const r = store.move(index, parseInt(body.delta, 10) || 0);
          reload();
          sendJson(res, 200, { ok: true, data: r });
          return true;
        }
        if (act === 'all') {
          const r = store.setAll(!!body.enabled);
          reload();
          sendJson(res, 200, { ok: true, data: r });
          return true;
        }
        if (act === 'test') {
          const e = engineOrThrow();
          const info = store.info()[index];
          if (!info) throw new Error('书源不存在');
          const at = e.sources.findIndex((s) => s.name === info.name);
          if (at < 0) throw new Error('该书源已停用');
          const key = String(body.key || '剑来').trim() || '剑来';
          const started = Date.now();
          const r = await e.search(key, { only: at });
          sendJson(res, 200, {
            ok: true,
            data: {
              key, ms: Date.now() - started,
              count: (r.list || []).length,
              sample: (r.list || []).slice(0, 5).map((v) => v.vod_name),
            },
          });
          return true;
        }
        sendJson(res, 404, { ok: false, error: '未知操作 ' + act });
      } catch (err) {
        sendJson(res, 400, { ok: false, error: err.message });
      }
      return true;
    }

    if (p === '/api/repos') {
      sendJson(res, 200, { ok: true, data: repos.REPOS });
      return true;
    }

    if (p === '/api/repo') {
      const rid = q.get('r') || 'yiove';
      try {
        const data = await repos.list(rid, {
          page: q.get('pg') || 1,
          size: q.get('size') || 20,
          keyword: q.get('key') || '',
        });
        sendJson(res, 200, { ok: true, data });
      } catch (err) {
        sendJson(res, 502, { ok: false, error: err.message });
      }
      return true;
    }

    if (p === '/api/import') {
      await need();
      try {
        const got = await repos.importOne(String(body.repo || ''), String(body.id || ''));
        const r = store.addMany(got.sources, { repo: got.repo });
        reload();
        // 导入后马上抓一次：告诉用户「这个源到底有没有内容」，别等点进书库才发现空白
        const e = getEngine();
        const touched = [].concat(r.added || [], r.updated || []);
        const tests = [];
        for (const nm of touched.slice(0, 3)) {
          const at = e ? e.sources.findIndex((s) => s.name === nm) : -1;
          if (at < 0) { tests.push({ name: nm, state: 'disabled', count: 0, msg: '没有加载（可能已停用）' }); continue; }
          const t = await e.probe(at, 1);
          tests.push({ name: nm, state: t.count ? 'ok' : t.state, count: t.count, msg: t.msg, ms: t.ms });
        }
        sendJson(res, 200, {
          ok: true,
          data: {
            name: got.name || (got.sources[0] && got.sources[0].bookSourceName) || '',
            added: r.added, updated: r.updated, invalid: r.invalid,
            total: store.size, enabled: store.enabledSize,
            tests,
          },
        });
      } catch (err) {
        sendJson(res, 502, { ok: false, error: err.message });
      }
      return true;
    }

    // 全量体检：逐个书源抓一次分类页，返回谁有内容、谁失效了
    if (p === '/api/health') {
      await need();
      const e = engineOrThrow();
      const only = body && body.index != null ? [parseInt(body.index, 10)] : null;
      const list = only ? only.filter((i) => i >= 0 && i < e.sources.length)
        : e.sources.map((s, i) => i);
      const started = Date.now();
      const out = await mapLimit(list, 4, (i) => e.probe(i, 1));
      const summary = { total: out.length, ok: out.filter((x) => x.count > 0).length, ms: Date.now() - started };
      summary.bad = summary.total - summary.ok;
      sendJson(res, 200, { ok: true, data: { summary, list: out } });
      return true;
    }

    return false;
  }

  return { handle, browse, bookSourceJson };
}

module.exports = { createApi, readBody };
