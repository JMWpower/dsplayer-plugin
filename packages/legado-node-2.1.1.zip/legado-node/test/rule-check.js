'use strict';
/*
 * 「HTML 规则书源」自检：
 * 用本项目自己的规则引擎（Legado 同款 CSS 规则语义）去解析 /legado_html.json 指向的页面，
 * 走一遍 搜索 → 详情 → 目录 → 正文 → 源管理 → 源仓库 → 导入，
 * 相当于在 Node 里模拟一遍「阅读」App 添加该书源后的行为。
 */

const BASE = process.env.BASE || 'http://127.0.0.1:13000';
const { BookSource } = require('../core/source');

function ok(cond, label, extra) {
  console.log((cond ? '  ✔ ' : '  ✘ ') + label + (extra ? '  ' + extra : ''));
  if (!cond) process.exitCode = 1;
  return cond;
}

(async () => {
  const json = await (await fetch(BASE + '/legado_html.json')).json();
  console.log('[书源] ' + json.bookSourceName + ' → ' + json.bookSourceUrl);
  const src = new BookSource(json, 0);

  // 1. 发现页（书库）—— 用书源里配的 exploreUrl，确保「阅读」点进去看到的和这里一致
  const explore = JSON.parse(json.exploreUrl || '[]');
  const browseUrl = (explore.find((x) => /书库/.test(x.title)) || { url: '/hs/browse?pg={{page}}' }).url;
  const browse = await src.explore(browseUrl, 1);
  ok(browse.length > 0, '书库列表解析', browse.length + ' 本，例：' + (browse[0] && browse[0].name));
  ok(!!(browse[0] && browse[0].bookUrl), '书库链接', browse[0] && browse[0].bookUrl);
  ok(!!(browse[0] && browse[0].author), '书库作者', browse[0] && browse[0].author);

  // 2. 搜索
  const found = await src.search('剑来', 1);
  ok(found.length > 0, '搜索结果解析', found.length + ' 条，例：' + (found[0] && found[0].name));
  ok(!!(found[0] && found[0].bookUrl), '搜索链接', found[0] && found[0].bookUrl);

  // 3. 详情
  const target = found[0] || browse[0];
  const info = await src.bookInfo(target.bookUrl);
  ok(!!info.name, '详情书名', info.name);
  ok(info.intro.length > 10, '详情简介', info.intro.slice(0, 40) + '…');
  ok(!!info.coverUrl || true, '详情封面', info.coverUrl ? '有' : '（无封面图）');

  // 4. 目录
  const chapters = await src.toc(info.tocUrl);
  ok(chapters.length > 0, '目录解析', chapters.length + ' 章，首章：' + (chapters[0] && chapters[0].name));

  // 5. 正文
  const text = await src.content(chapters[0].url);
  ok(text.length > 100, '正文解析', text.length + ' 字：' + text.slice(0, 50).replace(/\s+/g, ' ') + '…');

  // 6. 源管理（书源里作为「分类」入口）
  const manage = await src.explore('/hs/manage', 1);
  ok(manage.length > 0, '源管理列表解析', manage.length + ' 个书源，例：' + (manage[0] && manage[0].name));

  // 7. 源仓库
  const repos = await src.explore('/hs/repos', 1);
  ok(repos.length === 3, '源仓库列表解析', repos.map((r) => r.name).join(' / '));

  // 8. 仓库内容 + 导入（导入页的正文就是导入结果）
  //    仓库站点是外部服务，偶尔抽风；按顺序挑一个能出列表的仓库，都失败才算错
  let yc = [];
  let usedRepo = '';
  for (const r of ['yiove', 'yuancang', 'yckceo']) {
    yc = await src.explore('/hs/repo?r=' + r + '&pg=1', 1);
    if (yc.length) { usedRepo = r; break; }
  }
  ok(yc.length > 0, '仓库书源列表解析', yc.length + ' 条（' + usedRepo + '），例：' + (yc[0] && yc[0].name));
  if (yc.length) {
    const importUrl = yc[0].bookUrl;
    const res = await src.content(importUrl);
    ok(/已导入|更新/.test(res), '导入结果', res.replace(/\s+/g, ' ').slice(0, 90));
    // 导入是真的写进 sources.json：只清理「本次新增」的，别动用户已有的源
    if (/新增 1/.test(res)) {
      const m = res.match(/「([^」]+)」/);
      const st = await (await fetch(BASE + '/api/state')).json();
      const list = (st.data || st).sources || [];
      const hit = m && list.find((s) => s.name === m[1]);
      if (hit) {
        await fetch(BASE + '/api/source/remove', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ index: hit.index }),
        });
        console.log('  · 测试导入的「' + m[1] + '」已清理');
      }
    }
  }

  console.log('\n完成。');
})();
