'use strict';
/*
 * 请求层：cookie 自动管理 + 编码自动识别（gbk/gb2312/big5/utf-8）+ 重试 + 超时
 * 只用 Node 内置能力（fetch / TextDecoder），不需要任何第三方包。
 */

const DEFAULT_UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36';

class CookieJar {
  constructor() { this.map = new Map(); }

  setFromResponse(res, url) {
    let list = [];
    try {
      if (typeof res.headers.getSetCookie === 'function') list = res.headers.getSetCookie();
    } catch (e) { list = []; }
    if (!list || !list.length) {
      const raw = res.headers.get('set-cookie');
      if (raw) list = [raw];
    }
    for (const item of list) {
      const first = String(item).split(';')[0];
      const eq = first.indexOf('=');
      if (eq <= 0) continue;
      const name = first.slice(0, eq).trim();
      const value = first.slice(eq + 1).trim();
      if (/expires=Thu, 01 Jan 1970/i.test(item) || value === 'deleted') this.map.delete(name);
      else this.map.set(name, value);
    }
  }

  header() {
    if (!this.map.size) return '';
    return Array.from(this.map.entries()).map(([k, v]) => k + '=' + v).join('; ');
  }
}

function detectCharset(buf, contentType) {
  const head = Buffer.from(buf.slice(0, 4096)).toString('latin1');
  let m = /charset\s*=\s*["']?([\w-]+)/i.exec(contentType || '');
  if (m) return m[1].toLowerCase();
  m = /<meta[^>]+charset\s*=\s*["']?([\w-]+)/i.exec(head);
  if (m) return m[1].toLowerCase();
  m = /<meta[^>]+content\s*=\s*["'][^"']*charset\s*=\s*([\w-]+)/i.exec(head);
  if (m) return m[1].toLowerCase();
  return 'utf-8';
}

function decodeBody(buf, charset) {
  const cs = String(charset || 'utf-8').toLowerCase().replace(/^utf8$/, 'utf-8');
  const alias = { gb2312: 'gbk', gb18030: 'gbk', 'x-gbk': 'gbk', gbk: 'gbk', big5: 'big5', 'utf-8': 'utf-8', utf8: 'utf-8', 'iso-8859-1': 'utf-8' };
  const name = alias[cs] || cs;
  try {
    return new TextDecoder(name).decode(buf);
  } catch (e) {
    try { return new TextDecoder('utf-8').decode(buf); } catch (e2) { return Buffer.from(buf).toString('utf8'); }
  }
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

/**
 * @param {string} url
 * @param {object} opts {method, headers, body, charset, timeout, jar, retry, referer}
 * @returns {Promise<{ok:boolean, status:number, url:string, text:string, headers:Headers}>}
 */
async function request(url, opts = {}) {
  const timeout = opts.timeout || 15000;
  const retry = opts.retry === undefined ? 1 : opts.retry;
  const jar = opts.jar;
  let lastErr = null;

  for (let attempt = 0; attempt <= retry; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const headers = Object.assign({ 'User-Agent': DEFAULT_UA }, opts.headers || {});
      if (jar && jar.header() && !headers.Cookie) headers.Cookie = jar.header();
      if (opts.referer && !headers.Referer) headers.Referer = opts.referer;
      if (!headers['Accept-Language']) headers['Accept-Language'] = 'zh-CN,zh;q=0.9';
      if (!headers.Accept) headers.Accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';

      const res = await fetch(url, {
        method: opts.method || 'GET',
        headers,
        body: opts.body,
        redirect: 'follow',
        signal: controller.signal,
        // 部分站点对 HTTP/2 指纹敏感时，这里保持默认即可
      });
      clearTimeout(timer);
      if (jar) jar.setFromResponse(res, url);
      const buf = Buffer.from(await res.arrayBuffer());
      const contentType = res.headers.get('content-type') || '';
      const charset = opts.charset || detectCharset(buf, contentType);
      const text = opts.raw ? buf : decodeBody(buf, charset);
      return { ok: res.ok, status: res.status, url: res.url || url, text, headers: res.headers };
    } catch (e) {
      clearTimeout(timer);
      lastErr = e;
      if (attempt < retry) await sleep(400 + attempt * 600);
    }
  }
  const err = new Error('请求失败: ' + (lastErr && lastErr.message ? lastErr.message : '未知错误'));
  err.cause = lastErr;
  err.url = url;
  throw err;
}

module.exports = { request, CookieJar, decodeBody, detectCharset, DEFAULT_UA, sleep };
