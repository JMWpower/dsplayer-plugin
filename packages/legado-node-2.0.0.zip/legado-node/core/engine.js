'use strict';
/*
 * 聚合引擎：把 sources.json 里的多个乐读书源当成一个「影视源」暴露出去
 *   - 分类 = 书源（每个书源下再用 channel 选频道）
 *   - 搜索 = 全部书源并发搜，结果合并
 *   - 详情 = 书籍信息 + 目录（章节即剧集）
 *   - 播放 = 章节正文（同时给出 JSON，供 novel:// 契约使用）
 *
 * 契约与 肉书屋.py 模板保持一致：
 *   分类带 filters、详情 vod_play_url = "章节名$章节标记"、正文出 {title, content}
 */

const { BookSource, stripTags } = require('./source');

/* ────────── 章节标记（token）──────────
 * 形如 "3~aHR0cHM6Ly8..."（书源下标 + base64url 的原始地址）
 * base64url 里不含 $ # & 空格，可以直接塞进 vod_play_url，不需要二次转义。
 * 同时兼容老格式 "3::http://..."（旧订阅里已经存下来的链接不会失效）。
 */
function b64url(buf) {
  return Buffer.from(buf, 'utf8').toString('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function unb64url(str) {
  const s = String(str || '').replace(/-/g, '+').replace(/_/g, '/');
  const pad = s.length % 4 ? '='.repeat(4 - (s.length % 4)) : '';
  return Buffer.from(s + pad, 'base64').toString('utf8');
}

function token(idx, url) {
  return idx + '~' + b64url(String(url || ''));
}

function parseToken(t) {
  const s = String(t == null ? '' : t).trim();
  if (!s) return { idx: -1, url: '' };
  const legacy = s.indexOf('::');
  if (legacy > 0) {
    return { idx: parseInt(s.slice(0, legacy), 10), url: s.slice(legacy + 2) };
  }
  const tilde = s.indexOf('~');
  if (tilde > 0) {
    const idx = parseInt(s.slice(0, tilde), 10);
    const body = s.slice(tilde + 1);
    if (/^\d+$/.test(String(idx))) {
      try { return { idx, url: unb64url(body) }; } catch (e) { /* 落到下面 */ }
    }
  }
  if (/^https?:\/\//i.test(s)) return { idx: -1, url: s };
  return { idx: -1, url: s };
}

/* ────────── 小工具 ────────── */

function withTimeout(promise, ms, fallback) {
  let timer;
  const timeout = new Promise((resolve) => {
    timer = setTimeout(() => resolve(fallback), ms);
  });
  return Promise.race([Promise.resolve(promise).catch(() => fallback), timeout])
    .finally(() => clearTimeout(timer));
}

/** 并发闸门：n 个一组跑，避免一次把十几个站全捅一遍被一起限流 */
async function mapLimit(items, limit, worker) {
  const out = new Array(items.length);
  let cursor = 0;
  const runners = new Array(Math.max(1, Math.min(limit, items.length))).fill(0).map(async () => {
    while (cursor < items.length) {
      const i = cursor++;
      out[i] = await worker(items[i], i);
    }
  });
  await Promise.all(runners);
  return out;
}

function cleanLine(s) {
  return String(s == null ? '' : s).split(/[\r\n]+/)[0].replace(/\s+/g, ' ').trim();
}

function cleanName(s) {
  let v = cleanLine(s);
  v = v.replace(/\s*(作者|著)[:：].*$/, '').trim();
  v = v.replace(/^[《【](.+)[》】]$/, '$1').trim();
  return v.slice(0, 60);
}

function cleanKind(s) {
  return String(s == null ? '' : s)
    .split(/[\r\n]+/)
    .map((x) => x.replace(/^[^：:]{1,6}[:：]/, '').trim())
    .filter(Boolean)
    .filter((x, i, arr) => arr.indexOf(x) === i)
    .join(' · ')
    .slice(0, 40);
}

function cleanIntro(s) {
  if (!s) return '';
  return stripTags(String(s).replace(/<br\s*\/?>/gi, '\n')).replace(/\n{3,}/g, '\n\n').trim().slice(0, 600);
}

/** 章节名清洗：去掉模板站常见的后缀，保留可读标题 */
function cleanChapterName(raw, i) {
  let v = cleanLine(raw)
    .replace(/\s*[（(]?\s*(?:免费|最新|手机阅读|无弹窗|全文阅读|请记住本站)[^)）]*[)）]?\s*$/g, '')
    .replace(/[$#]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!v) v = '第' + (i + 1) + '章';
  return v.slice(0, 80);
}

class Engine {
  constructor(sourcesJson, opts = {}) {
    this.sources = [];
    const list = Array.isArray(sourcesJson) ? sourcesJson
      : (sourcesJson && Array.isArray(sourcesJson.sources) ? sourcesJson.sources : []);
    list.forEach((raw) => {
      if (!raw || raw.enabled === false) return;
      const s = new BookSource(raw, this.sources.length);
      if (!s.url) return;
      this.sources.push(s);
    });
    this.opts = Object.assign({
      searchTimeout: 20000,   // 单源搜索上限
      sourceTimeout: 15000,   // 单源分类页上限
      detailTimeout: 25000,   // 单源详情+目录上限
      chapterTimeout: 20000,  // 单源正文上限
      searchConcurrency: 6,   // 全源搜索并发
      channelConcurrency: 3,  // 合并频道并发
      maxChapters: 3000,      // 单本最多返回多少章（防超长目录拖死）
      listLimit: 60,          // 单个列表最多多少条
    }, opts);
    this._cache = new Map();
    this._cacheMax = 800;
    // 章节名索引：详情里算过一次，正文接口就能带出标题（key = "下标|地址"）
    this._titles = new Map();
  }

  _putTitle(idx, url, name) {
    if (!url || !name) return;
    this._titles.set(idx + '|' + url, name);
    if (this._titles.size > 20000) {
      const drop = this._titles.size - 16000;
      let n = 0;
      for (const k of this._titles.keys()) {
        this._titles.delete(k);
        if (++n >= drop) break;
      }
    }
  }

  get size() { return this.sources.length; }

  _remember(key, value, ttlMs) {
    this._cache.set(key, { at: Date.now(), ttl: ttlMs, value });
    if (this._cache.size > this._cacheMax) {
      // 顺手清过期，再不行就丢最老的
      const now = Date.now();
      for (const [k, v] of this._cache) {
        if (now - v.at > v.ttl) this._cache.delete(k);
      }
      while (this._cache.size > this._cacheMax) {
        this._cache.delete(this._cache.keys().next().value);
      }
    }
    return value;
  }

  _recall(key) {
    const hit = this._cache.get(key);
    if (!hit) return null;
    if (Date.now() - hit.at > hit.ttl) {
      this._cache.delete(key);
      return null;
    }
    return hit.value;
  }

  info() {
    return this.sources.map((s, i) => ({
      index: i,
      type_id: String(i),
      name: s.name,
      host: s.url,
      altHosts: s.altHosts || [],
      channels: s.channels,
      searchable: !!s.searchUrl,
      group: s.raw.bookSourceGroup || '',
    }));
  }

  /** 分类列表：每个书源一个分类 */
  categories() {
    return this.sources.map((s, i) => ({ type_id: String(i), type_name: s.name }));
  }

  /** 筛选：每个书源的频道（就是它自己的分类页） */
  filters() {
    const out = {};
    this.sources.forEach((s, i) => {
      if (!s.channels.length) return;
      out[String(i)] = [{
        key: 'channel',
        name: '频道',
        value: [{ n: '全部频道', v: '' }].concat(s.channels.map((c) => ({ n: c.title, v: c.url }))),
      }];
    });
    return out;
  }

  /**
   * 分类内容
   * @param {string} typeId 书源下标
   * @param {number} page 页码
   * @param {string} channel 频道 url（空 = 合并前几个频道）
   */
  async category(typeId, page = 1, channel = '') {
    const idx = parseInt(typeId, 10);
    const s = this.sources[idx];
    if (!s) return { list: [], page, pagecount: 1, total: 0 };
    const pg = Math.max(1, parseInt(page, 10) || 1);

    if (channel) {
      const key = 'c:' + idx + ':' + channel + ':' + pg;
      const hit = this._recall(key);
      if (hit) return hit;
      const list = await withTimeout(
        s.explore(channel, pg).then((arr) => arr.map((b) => this.toVod(idx, b))),
        this.opts.sourceTimeout, []
      );
      return this._remember(key, {
        list: list.slice(0, this.opts.listLimit),
        page: pg, pagecount: 999, total: 9999,
      }, 60 * 1000);
    }

    if (!s.channels.length) return { list: [], page: pg, pagecount: 1, total: 0 };

    // 没指定频道：合并前 3 个「真分类页」（跳过首页那种空 url）——再多就太慢
    const real = s.channels.filter((c) => c.url && c.url !== '/' && c.url !== '');
    const use = (real.length ? real : s.channels).slice(0, 3);
    const key = 'c:' + idx + ':all:' + pg;
    const hit = this._recall(key);
    if (hit) return hit;

    const results = await mapLimit(use, this.opts.channelConcurrency, (c) =>
      withTimeout(s.explore(c.url, pg), this.opts.sourceTimeout, [])
    );
    const merged = [];
    const seen = new Set();
    for (const arr of results) {
      for (const b of arr || []) {
        if (!b || !b.bookUrl || seen.has(b.bookUrl)) continue;
        seen.add(b.bookUrl);
        merged.push(this.toVod(idx, b));
      }
    }
    return this._remember(key, {
      list: merged.slice(0, this.opts.listLimit),
      page: pg, pagecount: 999, total: 9999,
    }, 60 * 1000);
  }

  /** 全源搜索（opts.timeout 可给单次搜索一个更紧的预算，比如给 HTML 页面用） */
  async search(key, opts = {}) {
    const only = opts.only;
    const limit = opts.limit || this.opts.listLimit;
    const budget = opts.timeout || this.opts.searchTimeout;
    const jobs = this.sources.map((s, i) => {
      if (!s.searchUrl) return null;
      if (only != null && only !== '' && parseInt(only, 10) !== i) return null;
      return i;
    }).filter((x) => x !== null);

    const results = await mapLimit(jobs, this.opts.searchConcurrency, (i) =>
      withTimeout(
        this.sources[i].search(key, 1).then((list) => list.map((b) => this.toVod(i, b))),
        budget, []
      )
    );

    const out = [];
    const seen = new Set();
    for (const arr of results) {
      for (const v of arr || []) {
        if (!v || !v.vod_id) continue;
        const k = v.vod_name + '|' + (v.vod_actor || '');
        if (seen.has(k)) continue;
        seen.add(k);
        out.push(v);
      }
    }
    return {
      list: out.slice(0, limit * 2),
      page: 1, pagecount: 1, limit: out.length, total: out.length,
    };
  }

  toVod(idx, b) {
    return {
      vod_id: token(idx, b.bookUrl),
      vod_name: cleanName(b.name),
      vod_pic: b.coverUrl || '',
      vod_remarks: cleanLine(b.lastChapter || b.wordCount || '').slice(0, 40),
      vod_content: cleanIntro(b.intro),
      vod_actor: cleanLine(b.author).replace(/^作者[:：]/, ''),
      vod_area: cleanKind(b.kind),
      vod_year: '',
      vod_lang: '',
      vod_director: '',
      vod_play_from: '阅读',
      source: this.sources[idx] ? this.sources[idx].name : '',
    };
  }

  /** 详情：书信息 + 章节目录 */
  async detail(id) {
    const { idx, url } = parseToken(id);
    const s = this.sources[idx];
    if (!s || !url) throw new Error('书源无效或链接缺失');

    const key = 'd:' + id;
    const hit = this._recall(key);
    if (hit) return hit;

    const build = async () => {
      const info = await s.bookInfo(url);
      const chapters = await s.toc(info.tocUrl || url);
      const max = this.opts.maxChapters;
      const list = chapters.slice(0, max);
      const playUrl = list
        .map((c, i) => {
          const nm = cleanChapterName(c.name, i);
          this._putTitle(idx, c.url, nm);
          return nm + '$' + token(idx, c.url);
        })
        .join('#');
      return {
        vod_id: id,
        vod_name: cleanName(info.name) || '未知书名',
        vod_pic: info.coverUrl || '',
        vod_content: cleanIntro(info.intro),
        vod_actor: cleanLine(info.author).replace(/^作者[:：]/, ''),
        vod_area: cleanKind(info.kind),
        vod_remarks: (cleanLine(info.lastChapter) || info.wordCount || '').slice(0, 60),
        vod_year: info.wordCount || '',
        vod_play_from: '阅读',
        vod_play_url: playUrl,
        chapter_count: list.length,
        chapters: list,
      };
    };

    const value = await withTimeout(build(), this.opts.detailTimeout, null);
    if (!value) throw new Error('详情获取超时');
    return this._remember(key, value, 10 * 60 * 1000);
  }

  async chapters(id) {
    const d = await this.detail(id);
    return d.chapters || [];
  }

  /** 章节正文（纯文本） */
  async chapter(flag) {
    const { title, content } = await this.chapterDetail(flag);
    return content;
  }

  /** 章节正文（标题 + 正文，给 novel:// 用） */
  async chapterDetail(flag) {
    const { idx, url } = parseToken(flag);
    const s = this.sources[idx];
    if (!s || !url) throw new Error('章节标记无效');

    const key = 'ch:' + flag;
    const hit = this._recall(key);
    if (hit) return hit;

    const text = await withTimeout(s.content(url), this.opts.chapterTimeout, '');
    if (!text) throw new Error('正文获取失败');
    const title = this._titles.get(idx + '|' + url) || '';
    const value = { title, content: text, chars: text.length };
    return this._remember(key, value, 30 * 60 * 1000);
  }
}

module.exports = { Engine, token, parseToken, cleanChapterName, cleanName, mapLimit, withTimeout };
