'use strict';
/* 管理面板前端：纯原生 JS，无构建步骤 */

const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.prototype.slice.call((root || document).querySelectorAll(sel));

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));

const state = {
  tab: 'browse',
  base: '',
  sources: [],
  repos: [],
  browse: { t: '0', pg: 1, ch: '', key: '' },
  repo: { id: 'yiove', pg: 1, key: '' },
};

/* ── 网络 ── */
async function api(path, body) {
  const opts = body === undefined ? {} : {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
  const res = await fetch(path, opts);
  let json;
  try { json = await res.json(); } catch (e) { throw new Error('服务返回异常 (HTTP ' + res.status + ')'); }
  if (!json.ok) throw new Error(json.error || ('请求失败 (HTTP ' + res.status + ')'));
  return json.data;
}

let toastTimer = 0;
function toast(msg, kind) {
  const el = $('#toast');
  el.textContent = msg;
  el.className = 'toast show' + (kind ? ' ' + kind : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = 'toast'; }, 3200);
}

function busy(el, on) {
  if (!el) return;
  el.classList.toggle('loading', !!on);
  el.disabled = !!on;
}

/* ── 状态 ── */
async function refreshState() {
  const data = await api('/api/state');
  state.base = data.base || '';
  state.sources = data.sources || [];
  state.repos = data.repos || [];
  $('#brand-sub').textContent = data.engine && data.engine.error
    ? '书源加载失败：' + data.engine.error
    : 'HTML 规则书源 · ' + data.total + ' 个书源 / 启用 ' + data.enabled;
  $('#stats').innerHTML =
    '<span class="stat"><b>' + data.total + '</b> 书源</span>'
    + '<span class="stat"><b>' + data.enabled + '</b> 启用</span>'
    + '<span class="stat">引擎 <b>' + (data.engine ? data.engine.count : 0) + '</b></span>';
  $('#manage-json').href = '/legado_html.json';
  if (state.repos.length) renderRepoCards();
  return data;
}

/* ── 浏览 ── */
function renderBrowseControls(data) {
  const sel = $('#browse-source');
  const list = data.sources || [];
  sel.innerHTML = list.map((s) =>
    '<option value="' + s.index + '"' + (String(s.index) === String(state.browse.t) ? ' selected' : '') + '>'
    + esc(s.name) + '</option>').join('') || '<option>（无书源）</option>';
  const chSel = $('#browse-channel');
  const chs = data.channels || [];
  chSel.innerHTML = '<option value="">全部</option>' + chs.map((c) =>
    '<option value="' + esc(c.url) + '"' + (c.url === state.browse.ch ? ' selected' : '') + '>'
    + esc(c.title) + '</option>').join('');
  $('#browse-channel-wrap').hidden = !chs.length;
}

function coverHtml(src, name) {
  if (!src) return '<div class="cover placeholder">' + esc((name || '?').slice(0, 1)) + '</div>';
  return '<img class="cover" src="' + esc(src) + '" alt="" loading="lazy" referrerpolicy="no-referrer"'
    + ' onerror="this.className=\'cover placeholder\';this.removeAttribute(\'src\')">';
}

function cardHtml(b) {
  return '<a class="card" href="' + esc(b.link) + '" target="_blank" rel="noopener">'
    + coverHtml(b.cover, b.name)
    + '<div class="card-body">'
    + '<div class="card-name">' + esc(b.name) + '</div>'
    + (b.author ? '<div class="card-meta">' + esc(b.author) + '</div>' : '')
    + (b.kind ? '<div class="card-meta">' + esc(b.kind) + '</div>' : '')
    + (b.last ? '<div class="card-last">' + esc(b.last) + '</div>' : '')
    + (b.intro ? '<div class="card-intro">' + esc(b.intro) + '</div>' : '')
    + '</div></a>';
}

function renderPager(el, page, pagecount, go) {
  el.innerHTML = '';
  if (!pagecount || pagecount <= 1) return;
  const mk = (label, to, disabled) => {
    const b = document.createElement('button');
    b.className = 'btn sm';
    b.textContent = label;
    b.disabled = !!disabled;
    b.onclick = () => go(to);
    return b;
  };
  el.appendChild(mk('上一页', page - 1, page <= 1));
  const info = document.createElement('span');
  info.className = 'page-info';
  info.textContent = page + ' / ' + pagecount;
  el.appendChild(info);
  el.appendChild(mk('下一页', page + 1, page >= pagecount));
}

async function loadBrowse() {
  const listEl = $('#browse-list');
  listEl.innerHTML = '<div class="empty">加载中…</div>';
  const q = new URLSearchParams({ t: state.browse.t, pg: String(state.browse.pg) });
  if (state.browse.ch) q.set('ch', state.browse.ch);
  if (state.browse.key) q.set('key', state.browse.key);
  try {
    const data = await api('/api/browse?' + q.toString());
    renderBrowseControls(data);
    state.browse.pg = data.page || state.browse.pg;
    const items = data.list || [];
    $('#browse-hint').textContent = data.mode === 'search'
      ? '搜索「' + data.key + '」：' + items.length + ' 条结果'
      : '书源「' + (data.name || '') + '」第 ' + (data.page || 1) + ' 页';
    listEl.innerHTML = items.length ? items.map(cardHtml).join('')
      : '<div class="empty">' + (data.mode === 'search' ? '没有搜到结果' : '这个频道没有内容') + '</div>';
    renderPager($('#browse-pager'), data.page || 1, data.pagecount || 1, (p) => {
      state.browse.pg = p;
      loadBrowse();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  } catch (err) {
    listEl.innerHTML = '<div class="empty">' + esc(err.message) + '</div>';
    $('#browse-hint').textContent = '';
    $('#browse-pager').innerHTML = '';
  }
}

/* ── 源管理 ── */
function badge(text, kind) {
  return '<span class="badge ' + (kind || '') + '">' + esc(text) + '</span>';
}

function renderManage(data) {
  const list = data.sources || [];
  $('#manage-hint').textContent = list.length
    ? '共 ' + data.total + ' 个书源，其中 ' + data.enabled + ' 个启用。点书源名可以看它的 HTML 页面。'
    : '还没有任何书源，去「源仓库」导入几个吧。';
  const rows = list.map((s) => {
    const badges = [
      s.enabled ? badge('启用', 'on') : badge('停用', 'off'),
      s.searchable ? badge('可搜索') : '',
      s.channels.length ? badge(s.channels.length + ' 频道') : '',
      s.group ? badge(s.group) : '',
    ].join('');
    return '<div class="row' + (s.enabled ? '' : ' dim') + '">'
      + '<div class="row-main">'
      + '<a class="row-name" href="/hs/source?i=' + s.index + '" target="_blank" rel="noopener">' + esc(s.name) + '</a>'
      + '<div class="row-meta">' + esc(s.host) + '</div>'
      + '</div>'
      + '<div class="row-badges">' + badges + '</div>'
      + '<div class="row-acts">'
      + '<button class="btn sm" data-act="toggle" data-i="' + s.index + '" data-on="' + (s.enabled ? '1' : '0') + '">'
      + (s.enabled ? '停用' : '启用') + '</button>'
      + '<button class="btn sm" data-act="test" data-i="' + s.index + '">测试</button>'
      + '<button class="btn sm" data-act="json" data-i="' + s.index + '">JSON</button>'
      + '<button class="btn sm" data-act="up" data-i="' + s.index + '">↑</button>'
      + '<button class="btn sm" data-act="down" data-i="' + s.index + '">↓</button>'
      + '<button class="btn sm danger" data-act="remove" data-i="' + s.index + '">删除</button>'
      + '</div></div>';
  }).join('');
  $('#manage-list').innerHTML = rows || '<div class="empty">暂无书源</div>';
}

async function loadManage() {
  const data = await refreshState();
  renderManage(data);
}

async function sourceAction(act, index, extra) {
  if (act === 'json') {
    const raw = await api('/api/source?i=' + index);
    showJson(raw);
    return;
  }
  if (act === 'test') {
    toast('正在测试搜索…');
    const r = await api('/api/source/test', { index });
    toast('「' + r.key + '」' + r.count + ' 条，耗时 ' + r.ms + 'ms'
      + (r.sample && r.sample.length ? '：' + r.sample.join('、') : ''), r.count ? 'ok' : 'warn');
    return;
  }
  if (act === 'remove') {
    if (!confirm('确定删除这个书源？')) return;
    await api('/api/source/remove', { index });
    toast('已删除', 'ok');
  } else if (act === 'toggle') {
    const on = extra === '1';
    await api('/api/source/toggle', { index, enabled: !on });
    toast(on ? '已停用' : '已启用', 'ok');
  } else if (act === 'up' || act === 'down') {
    await api('/api/source/move', { index, delta: act === 'up' ? -1 : 1 });
  }
  await loadManage();
}

/* ── JSON 弹层 ── */
function showJson(raw) {
  const mask = document.createElement('div');
  mask.className = 'mask';
  mask.innerHTML = '<div class="dialog"><div class="dialog-head"><b>' + esc(raw.bookSourceName || '书源 JSON')
    + '</b><button class="btn sm" data-close="1">关闭</button></div>'
    + '<pre>' + esc(JSON.stringify(raw, null, 2)) + '</pre></div>';
  mask.addEventListener('click', (e) => {
    if (e.target === mask || e.target.dataset.close) mask.remove();
  });
  document.body.appendChild(mask);
}

/* ── 源仓库 ── */
function renderRepoCards() {
  $('#repo-cards').innerHTML = state.repos.map((r) =>
    '<button class="repo-card' + (r.id === state.repo.id ? ' active' : '') + '" data-repo="' + esc(r.id) + '">'
    + '<div class="repo-name">' + esc(r.name) + '</div>'
    + '<div class="repo-home">' + esc(r.home) + '</div>'
    + '<div class="repo-note">' + esc(r.note) + '</div>'
    + '</button>').join('');
  $('#repo-toolbar').hidden = false;
}

async function loadRepo() {
  renderRepoCards();
  const cur = state.repos.find((r) => r.id === state.repo.id);
  $('#repo-title').textContent = cur ? cur.name : '';
  const listEl = $('#repo-list');
  listEl.innerHTML = '<div class="empty">加载中…</div>';
  const q = new URLSearchParams({ r: state.repo.id, pg: String(state.repo.pg) });
  if (state.repo.key) q.set('key', state.repo.key);
  try {
    const data = await api('/api/repo?' + q.toString());
    const items = data.items || [];
    listEl.innerHTML = items.length ? items.map((it) => {
      const meta = [
        it.author ? '作者 ' + it.author : '',
        it.views ? it.views + ' 次下载' : '',
        it.extra || '',
        it.time ? new Date(it.time).toLocaleDateString('zh-CN') : '',
      ].filter(Boolean).map(esc).join(' · ');
      return '<div class="row">'
        + '<div class="row-main"><div class="row-name">' + esc(it.name) + '</div>'
        + (it.url ? '<div class="row-meta">' + esc(it.url) + '</div>' : '')
        + (it.desc ? '<div class="row-desc">' + esc(it.desc) + '</div>' : '')
        + (meta ? '<div class="row-meta">' + meta + '</div>' : '')
        + '</div>'
        + '<div class="row-acts"><button class="btn sm primary" data-import="' + esc(it.id) + '">导入</button></div>'
        + '</div>';
    }).join('') : '<div class="empty">这个仓库没有数据</div>';
    $('#repo-pager').innerHTML = '';
    renderPager($('#repo-pager'), data.page || 1, data.pages || 1, (p) => {
      state.repo.pg = p;
      loadRepo();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  } catch (err) {
    listEl.innerHTML = '<div class="empty">' + esc(err.message) + '</div>';
    $('#repo-pager').innerHTML = '';
  }
}

async function importSource(id, btn) {
  busy(btn, true);
  btn.textContent = '导入中';
  try {
    const r = await api('/api/import', { repo: state.repo.id, id });
    const parts = [];
    if (r.added.length) parts.push('新增 ' + r.added.length);
    if (r.updated.length) parts.push('更新 ' + r.updated.length);
    if (r.invalid) parts.push(r.invalid + ' 个无效');
    toast('已导入「' + (r.name || id) + '」（' + (parts.join('，') || '无变化') + '），现有 ' + r.total + ' 个书源', 'ok');
    btn.textContent = '已导入';
    await refreshState();
    if (state.tab === 'manage') await loadManage();
  } catch (err) {
    toast('导入失败：' + err.message, 'err');
    btn.textContent = '导入';
  } finally {
    busy(btn, false);
  }
}

/* ── 事件 ── */
const TABS = ['browse', 'manage', 'repos'];

function switchTab(name, silent) {
  if (!TABS.includes(name)) name = 'browse';
  state.tab = name;
  $$('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  $$('.panel').forEach((p) => p.classList.toggle('active', p.id === 'panel-' + name));
  if (!silent && location.hash !== '#' + name) location.hash = name;
  if (name === 'manage') loadManage().catch((e) => toast(e.message, 'err'));
  if (name === 'repos') {
    renderRepoCards();
    loadRepo().catch((e) => toast(e.message, 'err'));
  }
  if (name === 'browse' && !$('#browse-list').children.length) loadBrowse();
}

$('#tabs').addEventListener('click', (e) => {
  const t = e.target.closest('.tab');
  if (t) switchTab(t.dataset.tab);
});

window.addEventListener('hashchange', () => {
  const name = location.hash.replace(/^#/, '');
  if (name && name !== state.tab) switchTab(name, true);
});

$('#browse-source').addEventListener('change', (e) => {
  state.browse.t = e.target.value;
  state.browse.pg = 1;
  state.browse.ch = '';
  loadBrowse();
});

$('#browse-channel').addEventListener('change', (e) => {
  state.browse.ch = e.target.value;
  state.browse.pg = 1;
  loadBrowse();
});

$('#browse-go').addEventListener('click', () => {
  state.browse.key = $('#browse-key').value.trim();
  state.browse.pg = 1;
  loadBrowse();
});

$('#browse-key').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('#browse-go').click();
});

$('#browse-reset').addEventListener('click', () => {
  $('#browse-key').value = '';
  state.browse.key = '';
  state.browse.pg = 1;
  state.browse.ch = '';
  loadBrowse();
});

$('#manage-list').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-act]');
  if (!b) return;
  sourceAction(b.dataset.act, parseInt(b.dataset.i, 10), b.dataset.on).catch((err) => toast(err.message, 'err'));
});

$('#manage-refresh').addEventListener('click', () => loadManage().catch((e) => toast(e.message, 'err')));

$('#manage-enable-all').addEventListener('click', async () => {
  await api('/api/source/all', { enabled: true });
  toast('已全部启用', 'ok');
  await loadManage();
});

$('#manage-disable-all').addEventListener('click', async () => {
  await api('/api/source/all', { enabled: false });
  toast('已全部停用', 'ok');
  await loadManage();
});

$('#manage-copy').addEventListener('click', async () => {
  const url = state.base + '/legado_html.json';
  try {
    await navigator.clipboard.writeText(url);
    toast('已复制：' + url, 'ok');
  } catch (e) {
    toast(url, 'warn');
  }
});

$('#repo-cards').addEventListener('click', (e) => {
  const c = e.target.closest('[data-repo]');
  if (!c) return;
  state.repo.id = c.dataset.repo;
  state.repo.pg = 1;
  state.repo.key = '';
  $('#repo-key').value = '';
  loadRepo();
});

$('#repo-go').addEventListener('click', () => {
  state.repo.key = $('#repo-key').value.trim();
  state.repo.pg = 1;
  loadRepo();
});

$('#repo-key').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('#repo-go').click();
});

$('#repo-list').addEventListener('click', (e) => {
  const b = e.target.closest('[data-import]');
  if (b) importSource(b.dataset.import, b);
});

/* ── 启动 ── */
(async function boot() {
  const want = location.hash.replace(/^#/, '');
  if (TABS.includes(want)) switchTab(want, true);
  try {
    await refreshState();
    if (!state.sources.length) switchTab('repos', true);
    else if (TABS.includes(want) && want !== 'browse') switchTab(want, true);
    else loadBrowse();
  } catch (err) {
    toast('连接服务失败：' + err.message, 'err');
  }
}());
