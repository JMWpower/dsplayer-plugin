import { BrowserClient } from '../src/core/client.js';

const c = new BrowserClient();
const targets = [
  'https://huangguo.video/updates?page=1',
  'https://duanju.one/dramas',
];
for (const t of targets) {
  try {
    const r = await c.do('GET', t, {}, {});
    const body = await r.buffer();
    console.log(t, '->', r.status, 'len', body.length);
  } catch (e) {
    console.log(t, 'ERR', e.message);
  }
}
