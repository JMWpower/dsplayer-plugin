

import fs from 'node:fs';

const BASE = 'http://127.0.0.1:5689';
const VIP_RE = /vip|试看|试听|preview|付费|收费|开通|会员|login|登录|版权|下架|违规|购买|授权|禁止/i;
const STEP_TIMEOUT = 90000;

async function jget(url, timeout = STEP_TIMEOUT) {
  const r = await fetch(url, { signal: AbortSignal.timeout(timeout) });
  const text = await r.text();
  try { return JSON.parse(text); } catch { return { code: r.status, msg: text.slice(0, 120), _raw: true }; }
}

function classifyMedia(buf, contentType) {
  if (!buf || buf.length === 0) return { ok: false, why: 'empty-body' };
  const ct = String(contentType || '').toLowerCase();
  const head = buf.subarray(0, 16);
  if (head.subarray(0, 7).toString('latin1') === '#EXTM3U') return { ok: true, kind: 'm3u8' };
  if (head.subarray(4, 8).toString('latin1') === 'ftyp') return { ok: true, kind: 'mp4' };
  if (head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3) return { ok: true, kind: 'webm' };
  if (head.subarray(0, 3).toString('latin1') === 'ID3' || (head[0] === 0xff && (head[1] & 0xe0) === 0xe0)) return { ok: true, kind: 'mp3' };
  if ((head[0] === 0xff && (head[1] & 0xf6) === 0xf0) || head.subarray(0, 4).toString('latin1') === 'OggS') return { ok: true, kind: 'audio' };
  if (head[0] === 0xff && head[1] === 0xd8) return { ok: true, kind: 'jpeg' };
  if (head.subarray(0, 8).toString('latin1') === '\x89PNG\r\n\x1a\n') return { ok: true, kind: 'png' };
  if (head.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return { ok: true, kind: 'webp' };
  if (head.subarray(0, 3).toString('latin1') === 'GIF') return { ok: true, kind: 'gif' };
  if (ct.includes('mpegurl')) return { ok: false, why: 'm3u8-declared-but-invalid' };
  if (ct.includes('video/') || ct.includes('audio/')) return { ok: true, kind: 'stream-' + ct.split('/')[1].split(';')[0] };
  const text = buf.subarray(0, 600).toString('utf8');
  if (/<html|<!doctype|\{"code"/i.test(text)) return { ok: false, why: 'not-media: ' + text.slice(0, 120).replace(/\s+/g, ' ') };
  return { ok: false, why: 'unknown-magic: ' + head.toString('hex').slice(0, 32) };
}

async function fetchMedia(proxyURL) {
  const r = await fetch(proxyURL, {
    headers: { Range: 'bytes=0-131071' },
    signal: AbortSignal.timeout(STEP_TIMEOUT),
  });
  const buf = Buffer.from(await r.arrayBuffer());
  return { status: r.status, contentType: r.headers.get('content-type') || '', buf };
}

function findProxyURL(obj) {
  
  if (obj && typeof obj === 'object') {
    if (typeof obj.url === 'string' && obj.url.includes('/m/')) return obj.url;
    if (typeof obj.src === 'string' && obj.src.startsWith('http://127.0.0.1')) return obj.src;
    for (const v of Object.values(obj)) {
      const hit = findProxyURL(v);
      if (hit) return hit;
    }
  } else if (typeof obj === 'string' && obj.startsWith('http://127.0.0.1')) {
    return obj;
  }
  return '';
}

function pickArray(v) {
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object') {
    for (const k of ['list', 'episodes', 'vod_play_url', 'chapters', 'items', 'data']) {
      if (Array.isArray(v[k])) return v[k];
    }
  }
  return [];
}

async function testDuanju(plat) {
  const out = { plat, module: 'duanju' };
  const home = await jget(`${BASE}/api/duanju/api/home?plat=${plat}`);
  const cards = pickArray(home.data);
  if (home.code !== 200 || cards.length === 0) {
    return { ...out, verdict: 'FAIL', step: 'home', msg: String(home.msg || 'empty').slice(0, 120) };
  }
  const card = cards[0];
  const det = await jget(`${BASE}/api/duanju/api/detail?plat=${plat}&id=${encodeURIComponent(card.vod_id)}`);
  const eps = pickArray(det.data);
  if (det.code !== 200 || eps.length === 0) {
    return { ...out, verdict: 'FAIL', step: 'detail', msg: String(det.msg || 'no-episodes').slice(0, 120) };
  }
  const ep = eps[0];
  const epURL = ep.url || ep.play_url || '';
  const play = await jget(`${BASE}/api/duanju/api/play?plat=${plat}&id=${encodeURIComponent(card.vod_id)}&url=${encodeURIComponent(epURL)}`);
  if (play.code !== 200) {
    const msg = String(play.msg || '');
    return { ...out, verdict: VIP_RE.test(msg) ? 'VIP' : 'FAIL', step: 'play', msg: msg.slice(0, 140), ep: ep.name };
  }
  const proxyURL = findProxyURL(play.data);
  if (!proxyURL) {
    return { ...out, verdict: 'FAIL', step: 'play', msg: 'no-playable-url', ep: ep.name };
  }
  try {
    const m = await fetchMedia(proxyURL);
    const c = classifyMedia(m.buf, m.contentType);
    if (c.ok) return { ...out, verdict: 'OK', kind: c.kind, bytes: m.buf.length, ep: ep.name };
    const bodyText = m.buf.toString('utf8').slice(0, 300);
    return { ...out, verdict: VIP_RE.test(bodyText) || VIP_RE.test(JSON.stringify(play.data)) ? 'VIP' : 'FAIL', step: 'media', msg: c.why + ' | ' + bodyText.slice(0, 100).replace(/\s+/g, ' '), ep: ep.name };
  } catch (e) {
    return { ...out, verdict: 'FAIL', step: 'media', msg: (e.message || '').slice(0, 120), ep: ep.name };
  }
}

async function testManhua(plat) {
  const out = { plat, module: 'manhua' };
  const home = await jget(`${BASE}/api/manhua/api/home?plat=${plat}`);
  const cards = pickArray(home.data);
  if (home.code !== 200 || cards.length === 0) {
    return { ...out, verdict: 'FAIL', step: 'home', msg: String(home.msg || 'empty').slice(0, 120) };
  }
  const card = cards[0];
  const det = await jget(`${BASE}/api/manhua/api/detail?plat=${plat}&id=${encodeURIComponent(card.vod_id)}`);
  const chs = pickArray(det.data);
  if (det.code !== 200 || chs.length === 0) {
    return { ...out, verdict: 'FAIL', step: 'detail', msg: String(det.msg || 'no-chapters').slice(0, 120) };
  }
  const ch = chs[0];
  const chURL = ch.url || '';
  const play = await jget(`${BASE}/api/manhua/api/play?plat=${plat}&id=${encodeURIComponent(card.vod_id)}&url=${encodeURIComponent(chURL)}`);
  if (play.code !== 200) {
    const msg = String(play.msg || '');
    return { ...out, verdict: VIP_RE.test(msg) ? 'VIP' : 'FAIL', step: 'play', msg: msg.slice(0, 140), ch: ch.name };
  }
  const pics = (play.data && play.data.pics) || [];
  if (pics.length === 0) {
    const j = JSON.stringify(play.data || {});
    return { ...out, verdict: VIP_RE.test(j) ? 'VIP' : 'FAIL', step: 'pics', msg: 'no-pics', ch: ch.name };
  }
  try {
    const m = await fetchMedia(pics[0]);
    const c = classifyMedia(m.buf, m.contentType);
    if (c.ok) return { ...out, verdict: 'OK', kind: c.kind, bytes: m.buf.length, pics: pics.length, ch: ch.name };
    return { ...out, verdict: 'FAIL', step: 'img', msg: c.why, ch: ch.name };
  } catch (e) {
    return { ...out, verdict: 'FAIL', step: 'img', msg: (e.message || '').slice(0, 120), ch: ch.name };
  }
}

async function testTing(plat) {
  const out = { plat, module: 'ting' };
  const home = await jget(`${BASE}/api/ting/api/home?plat=${plat}`);
  const cards = pickArray(home.data);
  if (home.code !== 200 || cards.length === 0) {
    
    const s = await jget(`${BASE}/api/ting/api/search?plat=${plat}&wd=%E5%87%A1%E4%BA%BA`);
    const sCards = pickArray(s.data);
    if (s.code !== 200 || sCards.length === 0) {
      return { ...out, verdict: 'FAIL', step: 'home', msg: String(s.msg || home.msg || 'empty').slice(0, 120) };
    }
    cards.push(...sCards);
  }
  const card = cards[0];
  const det = await jget(`${BASE}/api/ting/api/detail?plat=${plat}&id=${encodeURIComponent(card.vod_id)}`);
  const eps = pickArray(det.data);
  if (det.code !== 200 || eps.length === 0) {
    return { ...out, verdict: 'FAIL', step: 'detail', msg: String(det.msg || 'no-episodes').slice(0, 120) };
  }
  const ep = eps[0];
  const epURL = ep.url || '';
  const play = await jget(`${BASE}/api/ting/api/play?plat=${plat}&id=${encodeURIComponent(card.vod_id)}&url=${encodeURIComponent(epURL)}`);
  if (play.code !== 200) {
    const msg = String(play.msg || '');
    return { ...out, verdict: VIP_RE.test(msg) ? 'VIP' : 'FAIL', step: 'play', msg: msg.slice(0, 140), ep: ep.name };
  }
  const proxyURL = findProxyURL(play.data);
  if (!proxyURL) {
    return { ...out, verdict: 'FAIL', step: 'play', msg: 'no-playable-url', ep: ep.name };
  }
  try {
    const m = await fetchMedia(proxyURL);
    const c = classifyMedia(m.buf, m.contentType);
    if (c.ok) return { ...out, verdict: 'OK', kind: c.kind, bytes: m.buf.length, ep: ep.name };
    const bodyText = m.buf.toString('utf8').slice(0, 300);
    return { ...out, verdict: VIP_RE.test(bodyText) ? 'VIP' : 'FAIL', step: 'media', msg: c.why + ' | ' + bodyText.slice(0, 100).replace(/\s+/g, ' '), ep: ep.name };
  } catch (e) {
    return { ...out, verdict: 'FAIL', step: 'media', msg: (e.message || '').slice(0, 120), ep: ep.name };
  }
}

async function mapLimit(items, limit, fn) {
  const results = [];
  let next = 0;
  const workers = Array.from({ length: limit }, async () => {
    while (next < items.length) {
      const i = next++;
      try {
        results[i] = await fn(items[i]);
      } catch (e) {
        results[i] = { plat: items[i], module: fn.name, verdict: 'FAIL', step: 'crash', msg: (e.message || '').slice(0, 120) };
      }
      process.stdout.write(`[${results.filter(Boolean).length}/${items.length}] ${results[i].plat} => ${results[i].verdict} ${results[i].msg || results[i].kind || ''}\n`);
    }
  });
  await Promise.all(workers);
  return results;
}

const [,, which] = process.argv;
const t0 = Date.now();
let results = [];
if (!which || which === 'duanju') {
  const plats = (await (await fetch(`${BASE}/api/duanju/api/platform`)).json()).data.platforms.map((p) => p.key);
  console.log(`== duanju: ${plats.length} 平台 ==`);
  results.push(...await mapLimit(plats, 4, testDuanju));
}
if (!which || which === 'manhua') {
  const plats = (await (await fetch(`${BASE}/api/manhua/api/platform`)).json()).data.platforms.map((p) => p.key);
  console.log(`== manhua: ${plats.length} 平台 ==`);
  results.push(...await mapLimit(plats, 4, testManhua));
}
if (!which || which === 'ting') {
  const plats = (await (await fetch(`${BASE}/api/ting/api/platform`)).json()).data.platforms.map((p) => p.key);
  console.log(`== ting: ${plats.length} 平台 ==`);
  results.push(...await mapLimit(plats, 3, testTing));
}
fs.writeFileSync(new URL('./deep-result.json', import.meta.url), JSON.stringify(results, null, 1));
const summary = {};
for (const r of results) summary[r.verdict] = (summary[r.verdict] || 0) + 1;
console.log('summary:', JSON.stringify(summary), `${Math.round((Date.now() - t0) / 1000)}s`);
