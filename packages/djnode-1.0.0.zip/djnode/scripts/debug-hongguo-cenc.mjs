
import { BrowserClient } from '../src/core/client.js';
import { MediaProxy } from '../src/core/media.js';

const UA = 'com.phoenix.read/71332 (Linux; U; Android 16; zh_CN; 25053RTCK; Build/BP2A.250605.031.A3; Cronet/TTNetVersion:04657795 2026-01-23 QuicVersion:c67e9834 2025-09-08)';

async function main() {
  
  const h = await (await fetch('http://127.0.0.1:5690/api/duanju/api/home?plat=hongguo&page=1')).json();
  const card = h.data.list[0];
  const d = await (await fetch('http://127.0.0.1:5690/api/duanju/api/detail?plat=hongguo&id=' + encodeURIComponent(card.vod_id))).json();
  const ep = d.data.episodes[0];
  console.log('ep url:', String(ep.url).slice(0, 100));
  const p = await (await fetch('http://127.0.0.1:5690/api/duanju/api/play?url=' + encodeURIComponent(ep.url) + '&plat=hongguo')).json();
  const src = p.data.src;
  const keyHex = new URL(p.data.url, 'http://x').searchParams.get('key') || '';
  console.log('src:', src.slice(0, 90));
  console.log('key:', keyHex);

  
  const client = new BrowserClient();
  const headers = { 'User-Agent': UA, Range: 'bytes=0-1048575' };
  const resp = await client.doCustom('GET', src, null, headers);
  console.log('doCustom status:', resp.status, 'ct:', resp.headers['content-type'], 'cr:', resp.headers['content-range']);
  const chunks = [];
  for await (const c of resp.stream) chunks.push(c);
  const probe = Buffer.concat(chunks);
  console.log('probe bytes:', probe.length, 'head:', probe.subarray(0, 32).toString('latin1'));
  console.log('bytes 24..64 hex:', probe.subarray(24, 64).toString('hex'), 'latin1:', probe.subarray(24, 64).toString('latin1'));
  
  const { default: fp } = await import('node:fs');
  
  let off = 0;
  while (off + 8 <= probe.length) {
    const size = probe.readUInt32BE(off);
    const typ = probe.toString('latin1', off + 4, off + 8);
    console.log('box at', off, typ, size);
    if (size < 8) { console.log('  bad size, stop'); break; }
    if (typ === 'moov') { console.log('  MOOV FOUND'); break; }
    off += size;
  }
  resp.stream.destroy?.();

  
  const media = new MediaProxy(client, { dataDir: undefined });
  try {
    const idx = await media.buildCENCIndex(src, '', Buffer.from(keyHex, 'hex'));
    console.log('CENC index OK, regions:', idx.regions.length, 'duration:', idx.duration, 'total:', idx.total);
  } catch (e) {
    console.log('CENC index FAIL:', e.message);
  }
  process.exit(0);
}
main().catch((e) => { console.error('DBG ERROR', e); process.exit(1); });
