
const BASE = process.env.BASE || 'http://127.0.0.1:5689';
const P = '/api/duanju/api';

let pass = 0, fail = 0;
function ok(name, cond, extra = '') {
  if (cond) { pass++; console.log(`  PASS ${name}${extra ? ' — ' + extra : ''}`); }
  else { fail++; console.log(`  FAIL ${name}${extra ? ' — ' + extra : ''}`); }
}

async function getJSON(url) {
  const r = await fetch(url);
  let body = null;
  try { body = await r.json(); } catch {}
  return { status: r.status, body };
}

console.log('== 1. 平台列表 ==');
let firstPlat = 'hongguo';
{
  const { status, body } = await getJSON(`${BASE}${P}/platform`);
  const list = body?.data?.list || body?.data?.platforms || [];
  const names = list.map((p) => p.name).slice(0, 8);
  ok('GET /platform 200', status === 200, `status=${status}`);
  ok('平台数量>=1', list.length >= 1, `count=${list.length} (完整版应≥36,其余provider转换中)`); console.log(`  INFO 已注册平台: ${names.join('/')}`);
  if (list.length) firstPlat = list[0].key || 'hongguo';
}

console.log('== 2. 首页/分类 ==');
let card = null;
{
  const { status, body } = await getJSON(`${BASE}${P}/home?plat=${firstPlat}`);
  const list = body?.data?.list || [];
  card = list.find((c) => c.vod_id && !String(c.vod_id).startsWith('teen')) || null;
  ok('GET /home 200', status === 200, `status=${status}`);
  ok('首页卡片>0', list.length > 0, `count=${list.length}`);
  if (card) ok('首页卡片字段', !!(card.vod_name && (card.vod_pic || card.vod_remarks)), `${card.vod_name} id=${card.vod_id}`);
}

console.log('== 3. 搜索 ==');
let scard = null;
{
  const { status, body } = await getJSON(`${BASE}${P}/search?wd=${encodeURIComponent('重生')}`);
  const list = body?.data?.list || [];
  scard = list.find((c) => c.vod_id && !String(c.vod_id).startsWith('teen')) || null;
  ok('GET /search 200', status === 200, `status=${status}`);
  ok('搜索结果>0', list.length > 0, `count=${list.length}`);
  if (scard) ok('搜索卡片字段', !!scard.vod_name, `${scard.vod_name} id=${scard.vod_id}`);
}

console.log('== 4. 详情 ==');
let detail = null;
const target = scard || card;
if (target) {
  const { status, body } = await getJSON(`${BASE}${P}/detail?id=${encodeURIComponent(target.vod_id)}`);
  detail = body?.data || null;
  ok('GET /detail 200', status === 200, `status=${status}`);
  const eps = detail?.episodes || [];
  ok('剧集>0', eps.length > 0, `count=${eps.length} name=${detail?.vod_name || ''}`);
  if (eps.length) ok('剧集含 url', !!eps[0].url, `ep1=${eps[0].name || eps[0].no}`);
} else {
  fail++; console.log('  FAIL 无可用卡片,跳过详情/播放');
}

console.log('== 5. 播放解析 ==');
let play = null;
if (detail?.episodes?.length) {
  const ep = detail.episodes[Math.min(1, detail.episodes.length - 1)];
  const url = `${BASE}${P}/play?url=${encodeURIComponent(ep.url)}`;
  const { status, body } = await getJSON(url);
  play = body?.data || null;
  ok('GET /play 200', status === 200, `status=${status}`);
  ok('返回 src', !!(play?.src), String(play?.src || '').slice(0, 80));
  ok('返回代理 url', !!(play?.url), String(play?.url || '').slice(0, 90));
}

console.log('== 6. 媒体代理与 CENC 解密 ==');
if (play?.url) {
  const proxy = play.url.startsWith('http') ? play.url : BASE + play.url;
  const r = await fetch(proxy);
  const text = await r.text();
  const isM3U8 = text.includes('#EXTM3U');
  ok('代理拉取成功', r.status === 200 || r.status === 206, `status=${r.status} type=${r.headers.get('content-type') || ''}`);
  if (isM3U8) {
    ok('CENC 播放列表', text.includes('BYTERANGE') || text.includes('#EXTINF'), `lines=${text.split('\n').length}`);
    
    const lines = text.split('\n').map((l) => l.trim());
    let segURL = null, range = null;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].startsWith('#EXT-X-BYTERANGE:')) {
        range = lines[i].split(':')[1];
        for (let j = i + 1; j < lines.length; j++) {
          if (lines[j] && !lines[j].startsWith('#')) { segURL = lines[j]; break; }
        }
        break;
      }
    }
    if (!segURL) {
      for (const l of lines) {
        if (l && !l.startsWith('#') && (l.includes('.ts') || l.includes('.mp4') || l.includes('/'))) { segURL = l; break; }
      }
    }
    if (segURL) {
      const segAbs = segURL.startsWith('http') ? segURL : new URL(segURL, proxy).href;
      const headers = {};
      if (range) headers.Range = `bytes=${range.startsWith('@') ? range.slice(1) : range}`;
      const sr = await fetch(segAbs, { headers });
      const buf = Buffer.from(await sr.arrayBuffer());
      const box = buf.subarray(4, 8).toString('ascii');
      const brand = buf.subarray(8, 12).toString('ascii');
      ok('分片解密为 MP4', sr.status === 206 || sr.status === 200, `status=${sr.status} bytes=${buf.length} box=${box}`);
      ok('ftyp 品牌', box === 'ftyp' && ['isom', 'iso2', 'mp42', 'avc1', 'dash'].includes(brand), `brand=${brand}`);
    } else {
      fail++; console.log('  FAIL 播放列表中未找到分片');
    }
  } else {
    ok('直接媒体流', r.status === 200 || r.status === 206, `bytes=${text.length}`);
  }
} else {
  fail++; console.log('  FAIL 无播放地址可测');
}

console.log('== 7. Web 静态资源 ==');
{
  const shell = await fetch(`${BASE}/`);
  ok('shell 200', shell.status === 200, `status=${shell.status}`);
  const web = await fetch(`${BASE}/api/duanju/web/`);
  ok('duanju web 200', web.status === 200, `status=${web.status}`);
  const bridge = await fetch(`${BASE}/__jdd/bridge.js`);
  ok('bridge.js 200', bridge.status === 200, `status=${bridge.status}`);
}

console.log(`\n结果: ${pass} 通过, ${fail} 失败`);
process.exit(fail > 0 ? 1 : 0);
