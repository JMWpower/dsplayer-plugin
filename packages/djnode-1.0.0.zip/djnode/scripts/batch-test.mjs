

import http from 'node:http';
import fs from 'node:fs';
import { URL } from 'node:url';

const baseURL = process.argv[2] || 'http://127.0.0.1:5690';
const outPath = new URL('../batch-test-result.json', import.meta.url).pathname.replace(/^\//, '');

function httpGet(urlStr, timeout = 15000, extraHeaders = {}) {
  return new Promise((resolve) => {
    let url;
    try { url = new URL(urlStr); } catch { return resolve({ ok: false, error: '无效URL' }); }
    const req = http.request({
      hostname: url.hostname, port: url.port || 80, path: url.pathname + url.search,
      method: 'GET', timeout, headers: { 'User-Agent': 'Mozilla/5.0', ...extraHeaders },
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const body = Buffer.concat(chunks).toString('utf8');
        let json = null;
        try { json = JSON.parse(body); } catch {}
        resolve({ ok: true, status: res.statusCode, body, json, headers: res.headers });
      });
    });
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: '超时' }); });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.end();
  });
}

async function testEndpoint(url, timeout = 50000) {
  const start = Date.now();
  const r = await httpGet(url, timeout);
  const elapsed = Date.now() - start;
  if (!r.ok) return { ok: false, error: r.error, elapsed, raw: r };
  if (r.status >= 500) {
    const msg = r.json?.msg || r.body?.slice(0, 300) || `HTTP ${r.status}`;
    return { ok: false, error: `HTTP ${r.status}: ${msg}`, elapsed, raw: r };
  }
  if (r.json) {
    if (r.json.code === 200) return { ok: true, data: r.json.data, elapsed, raw: r };
    return { ok: false, error: r.json.msg || `code=${r.json.code}`, elapsed, raw: r };
  }
  return { ok: false, error: `非JSON响应 status=${r.status}`, elapsed, raw: r };
}


async function testMediaAccess(targetUrl, timeout = 40000) {
  
  let fullUrl = targetUrl;
  if (targetUrl && targetUrl.startsWith('/')) {
    try {
      fullUrl = new URL(targetUrl, baseURL).toString();
    } catch {
      
    }
  }
  
  const r = await httpGet(fullUrl, timeout, { Range: 'bytes=0-1023' });
  if (!r.ok) return { ok: false, error: r.error, vipBlocked: false };
  const ct = r.headers?.['content-type'] || '';
  const status = r.status;
  const isText = ct.includes('text/html') || ct.includes('text/plain');
  const bodyPreview = typeof r.body === 'string' ? r.body.slice(0, 500) : '';
  const vipIndicators = /vip|会员|付费|充值|subscribe|paywall|解锁|开通|仅限会员/.test(bodyPreview);
  const actualContentOk = !isText || !vipIndicators;

  
  const directMedia = /(audio|video)\//.test(ct)
    || ct.includes('mpegurl')
    || ct.includes('mp4')
    || ct.includes('webm')
    || bodyPreview.includes('#EXTM3U');
  if ((status === 200 || status === 206) && directMedia) {
    return { ok: true, status, ct, vipBlocked: false };
  }
  if (status === 200 && isText && vipIndicators) {
    return { ok: false, status, ct, vipBlocked: true, preview: bodyPreview.slice(0, 200) };
  }
  if (status === 403 || status === 451) {
    return { ok: false, status, ct, vipBlocked: vipIndicators };
  }
  return { ok: status === 200 || status === 206, status, ct, vipBlocked: vipIndicators };
}


async function testDuanju() {
  console.log('\n========== 短剧模块 ==========');
  const r = await testEndpoint(`${baseURL}/api/duanju/api/platform`);
  if (!r.ok) return { module: 'duanju', error: r.error, providers: [] };
  const platforms = r.data.platforms;
  const results = [];

  for (const p of platforms) {
    const key = p.key;
    
    const line = await testEndpoint(`${baseURL}/api/duanju/api/home?plat=${encodeURIComponent(key)}&page=1`);
    const lineOK = line.ok && (line.data?.list?.length > 0);
    console.log(`\n${p.name}(${key}) home: ${lineOK ? `✓ ${line.data.list.length}条 (${line.elapsed}ms)` : `✗ ${line.ok ? '空列表' : line.error}`}`);

    let firstId = null, firstPlayURL = null;
    if (lineOK) {
      const first = line.data.list[0];
      firstId = first.vod_id || first.id;
      if (firstId) {
        const detail = await testEndpoint(`${baseURL}/api/duanju/api/detail?id=${encodeURIComponent(String(firstId))}&plat=${encodeURIComponent(key)}`, 45000);
        if (detail.ok) {
          
          const episodes = detail.data.episodes || detail.data.playlist || [];
          if (Array.isArray(episodes)) {
            const ep0 = episodes[0];
            if (ep0?.url) firstPlayURL = ep0.url;
          }
          if (!firstPlayURL && detail.data.vod_url) firstPlayURL = detail.data.vod_url;
        }
      }
    }

    let playOk = false, mediaOk = false, vipBlocked = false, playErr = null;
    if (firstPlayURL) {
      const play = await testEndpoint(`${baseURL}/api/duanju/api/play?url=${encodeURIComponent(firstPlayURL)}&plat=${encodeURIComponent(key)}`);
      playOk = play.ok;
      playErr = play.ok ? null : play.error;
      if (playOk && play.data?.url) {
        const media = await testMediaAccess(play.data.url);
        mediaOk = media.ok;
        vipBlocked = media.vipBlocked;
        console.log(`  play: ✓  media: ${mediaOk ? `✓ (${media.status}, ${media.ct?.slice(0, 30)})` : `✗ ${media.vipBlocked ? 'VIP限制' : media.error}`}`);
      } else {
        console.log(`  play: ${playOk ? '✓ (无代理URL)' : `✗ ${play.error}`}`);
      }
    } else if (lineOK) {
      console.log(`  detail/play: ✗ (无播放URL)`);
    }

    const finalOk = lineOK && playOk && mediaOk && !vipBlocked;
    results.push({
      key, name: p.name, finalOk,
      listOk: lineOK, detailOk: !!firstPlayURL, playOk, mediaOk, vipBlocked,
      error: !finalOk ? (lineOK ? null : line.error) : null,
    });
  }
  return { module: 'duanju', providers: results };
}


async function testManhua() {
  console.log('\n========== 漫画模块 ==========');
  const r = await testEndpoint(`${baseURL}/api/manhua/api/platform`);
  if (!r.ok) return { module: 'manhua', error: r.error, providers: [] };
  const platforms = r.data.platforms;
  const results = [];

  for (const p of platforms) {
    const key = p.key;
    const line = await testEndpoint(`${baseURL}/api/manhua/api/home?plat=${encodeURIComponent(key)}&cat=&page=1`);
    const lineOK = line.ok && (line.data?.list?.length > 0);
    console.log(`\n${p.name}(${key}) home: ${lineOK ? `✓ ${line.data.list.length}条 (${line.elapsed}ms)` : `✗ ${line.ok ? '空列表' : line.error}`}`);

    let detailOk = false, imgOk = false, vipBlocked = false;
    if (lineOK) {
      const first = line.data.list[0];
      const firstId = first.vod_id || first.id;
      if (firstId) {
        const detail = await testEndpoint(`${baseURL}/api/manhua/api/detail?id=${encodeURIComponent(String(firstId))}&plat=${encodeURIComponent(key)}`, 45000);
        detailOk = detail.ok;
        if (detailOk && detail.data?.chapters?.length > 0) {
          const ch0 = detail.data.chapters[0];
          const chUrl = ch0.url;
          if (chUrl) {
            const play = await testEndpoint(`${baseURL}/api/manhua/api/play?url=${encodeURIComponent(chUrl)}&plat=${encodeURIComponent(key)}`);
            if (play.ok) {
              
              const imgs = play.data?.pics || play.data?.images || play.data?.urls || play.data?.list || [];
              if (imgs.length > 0) {
                const firstImg = imgs[0];
                const imgUrl = typeof firstImg === 'string' ? firstImg : (firstImg?.url || firstImg?.src);
                if (imgUrl) {
                  const m = await testMediaAccess(imgUrl);
                  imgOk = m.ok;
                  vipBlocked = m.vipBlocked;
                  console.log(`  detail: ✓  chapters: ✓  play: ✓  img: ${imgOk ? `✓ (${m.status}, ${m.ct?.slice(0, 30)})` : `✗ VIP=${m.vipBlocked}`}`);
                }
              }
            } else {
              console.log(`  detail: ✓  chapters: ✓  play: ✗ ${play.error}`);
            }
          }
        } else if (detailOk) {
          console.log(`  detail: ✓  chapters: ✗ 无章节数据`);
        } else {
          console.log(`  detail: ✗ ${detail.error}`);
        }
      }
    }

    const finalOk = lineOK && detailOk && imgOk && !vipBlocked;
    results.push({
      key, name: p.name, finalOk,
      listOk: lineOK, detailOk, imgOk, vipBlocked,
      error: !finalOk ? (lineOK ? (detailOk ? (imgOk ? 'VIP/无图' : '图片失败') : '详情失败') : line.error) : null,
    });
  }
  return { module: 'manhua', providers: results };
}


async function testTing() {
  console.log('\n========== 听书模块 ==========');
  const r = await testEndpoint(`${baseURL}/api/ting/api/platform`);
  if (!r.ok) return { module: 'ting', error: r.error, providers: [] };
  const seen = new Set();
  const platforms = r.data.platforms.filter(p => {
    if (seen.has(p.key)) return false;
    seen.add(p.key); return true;
  });
  const results = [];

  for (const p of platforms) {
    const key = p.key;
    const line = await testEndpoint(`${baseURL}/api/ting/api/home?plat=${encodeURIComponent(key)}&cat=&page=1`);
    const lineOK = line.ok && (line.data?.list?.length > 0);
    console.log(`\n${p.name}(${key}) home: ${lineOK ? `✓ ${line.data.list.length}条 (${line.elapsed}ms)` : `✗ ${line.ok ? '空列表' : line.error}`}`);

    let detailOk = false, playOk = false, audioOk = false, vipBlocked = false;
    if (lineOK) {
      const first = line.data.list[0];
      const firstId = first.vod_id || first.id;
      if (firstId) {
        const detail = await testEndpoint(`${baseURL}/api/ting/api/detail?id=${encodeURIComponent(String(firstId))}&plat=${encodeURIComponent(key)}`, 45000);
        detailOk = detail.ok;
        if (detailOk && detail.data?.chapters?.length > 0) {
          const ch0 = detail.data.chapters[0];
          const chUrl = ch0.url;
          if (chUrl) {
            const play = await testEndpoint(`${baseURL}/api/ting/api/play?url=${encodeURIComponent(String(chUrl))}&plat=${encodeURIComponent(key)}`);
            playOk = play.ok;
            if (playOk && play.data?.url) {
              const m = await testMediaAccess(play.data.url);
              audioOk = m.ok;
              vipBlocked = m.vipBlocked;
              console.log(`  detail: ✓  play: ✓  audio: ${audioOk ? `✓ (${m.status}, ${m.ct?.slice(0, 30)})` : `✗ VIP=${m.vipBlocked}`}`);
            } else {
              console.log(`  detail: ✓  play: ${playOk ? '✓ (无代理URL)' : `✗ ${play.error}`}`);
            }
          }
        } else if (detailOk) {
          console.log(`  detail: ✓  chapters: ✗`);
        } else {
          console.log(`  detail: ✗ ${detail.error}`);
        }
      }
    }

    const finalOk = lineOK && detailOk && playOk && audioOk && !vipBlocked;
    results.push({
      key, name: p.name, finalOk,
      listOk: lineOK, detailOk, playOk, audioOk, vipBlocked,
      error: !finalOk ? (lineOK ? (detailOk ? (playOk ? '音频失败' : '播放失败') : '详情失败') : line.error) : null,
    });
  }
  return { module: 'ting', providers: results };
}


console.log(`开始批量测试 目标: ${baseURL}`);
const all = [];
all.push(await testDuanju());
all.push(await testManhua());
all.push(await testTing());


const summary = {};
for (const mod of all) {
  if (mod.error) { summary[mod.module] = { error: mod.error, total: 0, ok: 0, fail: 0, vip: 0 }; continue; }
  const total = mod.providers.length;
  let ok = 0, fail = 0, vip = 0;
  for (const p of mod.providers) {
    if (p.finalOk) ok++; else fail++;
    if (p.vipBlocked) vip++;
  }
  summary[mod.module] = { total, ok, fail, vip };
}

const fullResult = { timestamp: new Date().toISOString(), baseURL, summary, modules: all };
fs.writeFileSync(outPath, JSON.stringify(fullResult, null, 2), 'utf8');

console.log(`\n\n==================== 测试汇总 ====================`);
for (const [mod, s] of Object.entries(summary)) {
  if (s.error) console.log(`  ${mod}: ERROR - ${s.error}`);
  else console.log(`  ${mod}: ${s.ok}/${s.total} 通过, ${s.fail} 失败${s.vip ? `, ${s.vip} VIP限制` : ''}`);
}
console.log(`\n详细结果已写入: ${outPath}`);

console.log(`\n==================== 失败 Provider ====================`);
for (const mod of all) {
  if (mod.error) continue;
  console.log(`\n[${mod.module}]`);
  for (const p of mod.providers) {
    if (!p.finalOk) {
      const reasons = [];
      if (!p.listOk) reasons.push('列表失败');
      else if (!p.detailOk) reasons.push('详情失败');
      else if (!p.playOk) reasons.push('播放失败');
      else if (!p.mediaOk && mod.module === 'duanju') reasons.push('媒体失败');
      else if (!p.imgOk && mod.module === 'manhua') reasons.push('图片失败');
      else if (!p.audioOk && mod.module === 'ting') reasons.push('音频失败');
      if (p.vipBlocked) reasons.push('VIP限制');
      console.log(`  ❌ ${p.name} (${p.key}): ${reasons.join(', ') || p.error || '未知'}`);
    }
  }
}
