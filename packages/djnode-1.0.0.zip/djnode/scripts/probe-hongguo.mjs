
import { createHash } from 'node:crypto';
import { BrowserClient } from '../src/core/client.js';

const client = new BrowserClient();
const vid = process.argv[2] || '7694655210777480217';

const mod = await import('../src/duanju/providers/hongguo_device.js');
const consts = await import('../src/duanju/consts.js');

console.log('== 1. 设备注册 ==');
let identity = null;
try {
  identity = await mod.hongguoPlaybackIdentity(client);
  console.log('注册成功 deviceID=', identity.deviceID, 'installID=', identity.installID);
} catch (e) {
  console.log('注册失败:', e.message);
}

console.log('== 2. multi_video_model 原始响应 ==');
const { hongguoAppBaseURL } = consts;
const now = Date.now();
const params = {
  ac: 'wifi', channel: 'update_64', aid: '8662', app_name: 'novelread',
  version_code: '71332', version_name: '7.1.3.32', device_platform: 'android',
  os: 'android', ssmix: 'a', device_type: '25053RT47C', device_brand: 'Redmi',
  language: 'zh', os_api: '36', os_version: '16', manifest_version_code: '71332',
  resolution: '1280*2772', dpi: '520', update_version_code: '71332',
  host_abi: 'arm64-v8a', dragon_device_type: 'phone', pv_player: '71332',
  compliance_status: '0', need_personal_recommend: '1', player_so_load: '1',
  is_android_pad_screen: '0',
  device_id: identity ? identity.deviceID : '7123456789012345678',
  iid: identity ? identity.installID : '7123456789012345679',
  _rticket: String(now),
};
const qs = Object.keys(params).sort().map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`).join('&');
const payload = JSON.stringify({
  biz_param: {
    detail_page_version: 0, device_level: 3, disable_digg_stat: false,
    need_all_video_definition: true, need_mp4_align: false,
    use_os_player: false, use_server_dns: false, video_platform: 1024,
  },
  mixed_video_id_map: { '1004': [vid] },
});
const target = `${hongguoAppBaseURL}/novel/player/multi_video_model/v1/?${qs}`;
const headers = {
  'User-Agent': 'com.phoenix.read/71532 (Linux; U; Android 9; SM-N9860 Build/PPR1.180610.011;)',
  Accept: 'application/json; charset=utf-8,application/x-protobuf',
  'Content-Type': 'application/json; charset=UTF-8',
};
for (let i = 0; i < 2; i++) {
  try {
    const resp = await client.doCustom('POST', target, Buffer.from(payload, 'utf8'), headers);
    const content = await resp.buffer();
    console.log(`attempt ${i + 1}: status=${resp.status} bytes=${content.length}`);
    console.log('head:', JSON.stringify(content.toString('utf8').slice(0, 400)));
  } catch (e) {
    console.log(`attempt ${i + 1} error:`, e.message);
  }
  if (i === 0) await new Promise((r) => setTimeout(r, 800));
}
