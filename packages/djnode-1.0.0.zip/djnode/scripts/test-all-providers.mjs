


const BASE = (process.env.BASE || 'http://127.0.0.1:5690').replace(/\/$/, '');
const OUT = process.env.OUT || new URL('./full-test-result.json', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1');
const ONLY = process.env.ONLY || '';
const CONC = parseInt(process.env.CONC || '5', 10);
const TMO = parseInt(process.env.TMO || '45000', 10);
const onlySet = new Set(
  ONLY ? ONLY.split(',').map((s) => s.trim()).filter(Boolean).map((s) => (s.includes(':') ? s : '')) : []
);

const VIP_HINTS = /vip|会员|付费|收费|充值|解锁|积分|开通|购买|locked|lock|paid|premium|试看|试听|登录|登陆|授权|coin|price/i;
const TEEN_HINT = /teen/;

function isVipishText(s) {
  return typeof s === 'string' && VIP_HINTS.test(s) && !/https?:/.test(s);
}


function scanVip(obj, depth = 0, out = [], path = '') {
  if (depth > 6 || obj == null || out.length > 8) return out;
  if (Array.isArray(obj)) {
    for (const item of obj.slice(0, 5)) scanVip(item, depth + 1, out, path + '[]');
    return out;
  }
  if (typeof obj === 'object') {
    for (const [k, v] of Object.entries(obj)) {
      if (isVipishText(k) && v !== '' && v !== false && v !== 0) out.push(`${path}.${k}=${JSON.stringify(v).slice(0, 60)}`);
      else if (isVipishText(k)) out.push(`${path}.${k}(键名含VIP词)`);
      scanVip(v, depth + 1, out, path + '.' + k);
      if (out.length > 8) return out;
    }
  } else if (typeof obj === 'string' && obj.length < 60 && isVipishText(obj)) {
    out.push(`${path}="${obj}"`);
  }
  return out;
}

async function getJSON(url, timeoutMs = 45000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { signal: ctl.signal, headers: { Accept: 'application/json,*/*' } });
    const text = await r.text();
    let body = null;
    try { body = JSON.parse(text); } catch {}
    return { status: r.status, body, text: text.slice(0, 400) };
  } finally { clearTimeout(t); }
}

async function fetchBytes(url, headers = {}, timeoutMs = 30000, maxBytes = 262144) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { signal: ctl.signal, headers });
    const buf = Buffer.from(await r.arrayBuffer());
    return { status: r.status, type: r.headers.get('content-type') || '', buf: buf.subarray(0, maxBytes), total: buf.length };
  } finally { clearTimeout(t); }
}

const abs = (u) => (u && /^https?:\/\//.test(u) ? u : u ? BASE + (u.startsWith('/') ? u : '/' + u) : u);

function looksLikeMedia(buf, type) {
  if (!buf || buf.length < 256) return false;
  if (/^image\//.test(type) || /^audio\//.test(type) || /^video\//.test(type)) return true;
  if (type.includes('octet-stream') || type.includes('mpegurl')) return true;
  const b = buf;
  const isHTML = b.subarray(0, 200).toString('utf8').toLowerCase().includes('<!doctype') || b.subarray(0, 100).toString('utf8').toLowerCase().includes('<html');
  if (isHTML) return false;
  if (b[0] === 0xff && b[1] === 0xd8) return true; 
  if (b[0] === 0x89 && b[1] === 0x50) return true; 
  if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return true; 
  if (b[0] === 0x52 && b[1] === 0x49 && b.subarray(8, 12).toString() === 'WEBP') return true;
  if (b.subarray(4, 8).toString() === 'ftyp') return true; 
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return true; 
  if (b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) return true; 
  if (b[0] === 0xff && (b[1] & 0xe0) === 0xe0) return true; 
  if (b[0] === 0x47) return true; 
  if (b.subarray(0, 3).toString() === 'OggS') return true;
  if (b.subarray(0, 4).toString() === 'RIFF') return true;
  if (b.subarray(0, 7).toString() === '#EXTM3U') return true;
  
  const printable = b.subarray(0, 512).filter((c) => c >= 0x20 && c < 0x7f).length;
  return printable / Math.min(512, b.length) < 0.85;
}


async function verifyDuanjuPlay(plat, epUrl) {
  const out = {};
  const p = await getJSON(`${BASE}/api/duanju/api/play?url=${encodeURIComponent(epUrl)}&plat=${plat}`, TMO+30000);
  out.code = p.body?.code ?? p.status;
  out.errMsg = p.body?.msg || (p.body?.code && p.body.code !== 200 ? JSON.stringify(p.body).slice(0, 200) : '');
  const data = p.body?.data || {};
  if (TEEN_HINT.test(JSON.stringify(data)) && data.teen) { out.vipNote = 'teen-placeholder'; return out; }
  out.src = String(data.src || '');
  const proxy = abs(data.url);
  if (!proxy) return out;
  const m = await fetchBytes(proxy, {}, TMO+60000);
  out.mediaStatus = m.status;
  out.mediaType = m.type;
  out.mediaBytes = m.total;
  const text = m.buf.toString('utf8', 0, Math.min(m.buf.length, 65536));
  if (text.startsWith('#EXTM3U')) {
    out.mediaKind = 'm3u8';
    const lines = text.split('\n').map((l) => l.trim());
    out.segments = lines.filter((l) => l && !l.startsWith('#')).length;
    
    let seg = null, range = null;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].startsWith('#EXT-X-BYTERANGE:')) {
        range = lines[i].split(':')[1];
        for (let j2 = i + 1; j2 < lines.length; j2++) if (lines[j2] && !lines[j2].startsWith('#')) { seg = lines[j2]; break; }
        break;
      }
    }
    if (!seg) seg = lines.find((l) => l && !l.startsWith('#'));
    if (seg) {
      const segURL = abs(/^https?:/.test(seg) ? seg : new URL(seg, proxy).href);
      const h = {};
      if (range) h.Range = `bytes=${range.startsWith('@') ? range.split('@')[1] : range.split('@')[0]}-`;
      const s = await fetchBytes(segURL, h, 30000, 131072);
      out.segStatus = s.status;
      out.segBytes = s.buf.length;
      out.segMedia = looksLikeMedia(s.buf, s.type);
    }
  } else {
    out.mediaKind = 'binary';
    out.mediaOk = looksLikeMedia(m.buf, m.type);
  }
  return out;
}

async function verifyManhuaPlay(plat, chapUrl) {
  const out = {};
  const p = await getJSON(`${BASE}/api/manhua/api/play?plat=${plat}&url=${encodeURIComponent(chapUrl)}&cid=1`, TMO+30000);
  out.code = p.body?.code ?? p.status;
  out.errMsg = p.body?.msg || '';
  const data = p.body?.data || {};
  const pics = data.pics || [];
  out.picCount = pics.length;
  if (!pics.length) return out;
  const imgURL = abs(pics[0]);
  const img = await fetchBytes(imgURL, {}, 30000, 65536);
  out.imgStatus = img.status;
  out.imgType = img.type;
  out.imgBytes = img.total;
  out.imgOk = img.total > 1024 && looksLikeMedia(img.buf, img.type);
  return out;
}

async function verifyTingPlay(plat, epUrl) {
  const out = {};
  const p = await getJSON(`${BASE}/api/ting/api/play?plat=${plat}&url=${encodeURIComponent(epUrl)}`, TMO+30000);
  out.code = p.body?.code ?? p.status;
  out.errMsg = p.body?.msg || '';
  const data = p.body?.data || {};
  if (data.teen) { out.vipNote = 'teen-placeholder'; return out; }
  const proxy = abs(data.url || data.local);
  out.src = String(data.src || '').slice(0, 120);
  if (!proxy) return out;
  const a = await fetchBytes(proxy, { Range: 'bytes=0-131071' }, 30000, 131072);
  out.audioStatus = a.status;
  out.audioType = a.type;
  out.audioBytes = a.total;
  out.audioOk = looksLikeMedia(a.buf, a.type);
  return out;
}


async function testProvider(module, key, name) {
  const r = { module, plat: key, name, ts: new Date().toISOString() };
  const P = `/api/${module}/api`;
  try {
    
    const homeURL = `${BASE}${P}/home?plat=${key}&page=1`;
    const h = await getJSON(homeURL, TMO+45000);
    r.home = { status: h.status, code: h.body?.code, count: (h.body?.data?.list || []).length, msg: h.body?.msg || '' };
    const list = (h.body?.data?.list || []).filter((c) => !TEEN_HINT.test(JSON.stringify(c.teen || '')));
    const card = list.find((c) => c.vod_id || c.id) || null;
    if (!card) { r.verdict = 'fail'; r.failStage = 'home'; return r; }
    const id = card.vod_id || card.id;
    
    const dURL = `${BASE}${P}/detail?plat=${key}&id=${encodeURIComponent(id)}`;
    const d = await getJSON(dURL, TMO+45000);
    const dd = d.body?.data || {};
    const eps = dd.episodes || dd.chapters || dd.playlist || [];
    r.detail = {
      status: d.status, code: d.body?.code, name: dd.vod_name || card.vod_name || card.name || '',
      epCount: eps.length, msg: d.body?.msg || '',
    };
    r.vipFlags = scanVip(d.body?.data || {});
    if (!eps.length) { r.verdict = 'fail'; r.failStage = 'detail-empty'; return r; }
    
    const pick = [eps[0]];
    if (eps.length > 3) pick.push(eps[eps.length - 1]);
    r.plays = [];
    for (const ep of pick) {
      const epUrl = ep.url || ep.href || ep.id;
      if (!epUrl) { r.plays.push({ error: 'episode 无 url' }); continue; }
      let v;
      if (module === 'duanju') v = await verifyDuanjuPlay(key, String(epUrl));
      else if (module === 'manhua') v = await verifyManhuaPlay(key, String(epUrl));
      else v = await verifyTingPlay(key, String(epUrl));
      v.epName = String(ep.name || ep.title || '').slice(0, 30);
      r.plays.push(v);
    }
    
    const first = r.plays[0] || {};
    const mediaOk = (first.mediaKind === 'm3u8') ? (first.segMedia === true)
      : first.imgOk !== undefined ? first.imgOk === true
      : first.audioOk === true || first.mediaOk === true;
    const vipErr = (first.errMsg && VIP_HINTS.test(first.errMsg)) || (first.vipNote === 'teen-placeholder');
    const vipFlags = r.vipFlags.length > 0;
    if (mediaOk) r.verdict = vipErr || (vipFlags && first.errMsg) ? 'ok-vip-flag' : 'ok';
    else if (vipErr) r.verdict = 'vip-blocked';
    else r.verdict = 'fail';
    r.failStage = r.verdict === 'fail' ? 'play' : undefined;
  } catch (e) {
    r.verdict = 'fail';
    r.error = String(e && e.message || e).slice(0, 200);
  }
  return r;
}


const MODULES = [
  { key: 'duanju', name: '短剧' },
  { key: 'manhua', name: '漫画' },
  { key: 'ting', name: '听书' },
];

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  async function worker() {
    while (i < items.length) {
      const idx = i++;
      out[idx] = await fn(items[idx], idx);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return out;
}

const results = [];
for (const mod of MODULES) {
  const { status, body } = await getJSON(`${BASE}/api/${mod.key}/api/platform`);
  const plats = (body?.data?.platforms || body?.data || []);
  const targets = plats
    .map((p) => ({ key: p.key, name: p.name }))
    .filter((p) => !ONLY || onlySet.has(`${mod.key}:${p.key}`));
  console.log(`\n===== ${mod.name} (${targets.length} 个平台) =====`);
  const rs = await mapLimit(targets, CONC, async (p) => {
    const t0 = Date.now();
    const r = await testProvider(mod.key, p.key, p.name);
    r.ms = Date.now() - t0;
    console.log(`[${r.verdict?.toUpperCase().padEnd(12)}] ${mod.key}/${p.key} — ${r.ms}ms ${r.error || r.failStage || ''}`);
    return r;
  });
  results.push(...rs);
}

const fs = await import('node:fs');
fs.writeFileSync(OUT, JSON.stringify(results, null, 2), 'utf8');
const by = (v) => results.filter((r) => r.verdict === v).length;
console.log('\n===== 汇总 =====');
console.log(`ok: ${by('ok')}, ok-vip-flag: ${by('ok-vip-flag')}, vip-blocked: ${by('vip-blocked')}, fail: ${by('fail')}, total: ${results.length}`);
console.log('结果已写入', OUT);
