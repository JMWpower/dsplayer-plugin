import { ModuleClient, SessionClient } from 'tlsclientwrapper';

const mc = new ModuleClient();
const opts = {
  clientIdentifier: 'chrome_136',
  timeout: 20000,
  withRandomTLSExtensionOrder: true,
  proxyUrl: 'http://127.0.0.1:7890',
};
const s = new SessionClient(mc, opts);
const r = await s.request({
  url: 'https://huangguo.video/updates?page=1',
  method: 'GET',
  headers: { 'user-agent': 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36', accept: '*/*' },
});
console.log('tls+proxy status:', r.status, 'bodyLen:', (r.body || '').length, 'head:', (r.body || '').slice(0, 100).replace(/\n/g, ' '));
try { await s.destroySession(); } catch {}
