


import { Sign, BranchOf, __test } from '../src/duanju/providers/sign6.js';

const T = __test;
let passed = 0;
let failed = 0;

function check(name, cond, detail) {
  if (cond) {
    passed++;
  } else {
    failed++;
    console.error(`FAIL ${name}${detail ? `: ${detail}` : ''}`);
  }
}

const hex = (b) => Buffer.from(b).toString('hex');
const b64dec = (s) => Buffer.from(s, 'base64');


const testURL = 'https://api5-normal-sinfonlineb.fqnovel.com/novel/player/multi_video_model/v1/?device_id=3470001122334455&version_name=7.1.3.32&ts=1761123456&_rticket=1761123456789';
const testBody = Buffer.from('{"vid":"7693917197759958040","client":"Android"}');
const testKhronos = 1761123456;


{
  const cases = [
    ['abc', '66c7f0f462eeedd9d1f2d46bdc10e4e24167c4875cf2f7a2297da02b8f4ba8e0'],
    ['', '1ab21d8355cfa17f8e61194831e81a8f22bec8c728fefb747ed035eb5082aa2b'],
    ['abcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcd',
      'debe9ff92275b8a138604889c18e5a4d6fdb70e5387e5765293dcba39c0c5732'],
  ];
  for (const [input, want] of cases) {
    const got = hex(T.sm3(Buffer.from(input, 'utf8')));
    check(`SM3(${JSON.stringify(input.slice(0, 8))}...)`, got === want, `got ${got}, want ${want}`);
  }
}


{
  const out = Sign(testURL, testBody, testKhronos);
  const wantKeys = ['x-gorgon', 'x-khronos', 'x-ladon', 'x-argus', 'x-helios', 'x-medusa'];
  check('Sign 返回 6 个头', Object.keys(out).length === 6, JSON.stringify(Object.keys(out)));
  for (const k of wantKeys) {
    check(`存在 ${k}`, out[k] !== undefined && out[k] !== '', `缺少或为空`);
  }
  check('x-khronos', out['x-khronos'] === String(testKhronos), out['x-khronos']);
  
  const ladon = b64dec(out['x-ladon']);
  check('x-ladon = be32(khronos)', ladon.length === 4 && hex(ladon) === hex(T.be32(testKhronos)), hex(ladon));
  const argus = b64dec(out['x-argus']);
  check('x-argus = le32(khronos)', argus.length === 4 && hex(argus) === hex(T.le32(testKhronos)), hex(argus));
  
  const gorgon = out['x-gorgon'];
  check('x-gorgon 前缀 8404', gorgon.length >= 4 && gorgon.slice(0, 4) === '8404', gorgon);
  check('x-gorgon 合法十六进制', /^[0-9a-f]+$/.test(gorgon), gorgon);
  
  for (const k of ['x-helios', 'x-medusa']) {
    const b = b64dec(out[k]);
    check(`${k} 可 base64 解码且非空`, b.length > 0);
  }
}


{
  const first = BranchOf(testURL, testBody, testKhronos);
  check('BranchOf 在 0..2', first >= 0 && first <= 2, String(first));
  let stable = true;
  for (let i = 0; i < 20; i++) {
    if (BranchOf(testURL, testBody, testKhronos) !== first) stable = false;
  }
  check('BranchOf 稳定', stable);
  const seen = new Set();
  let inRange = true;
  for (let ts = 1761123400; ts < 1761123460; ts++) {
    const b = BranchOf(testURL + '&ts=' + ts, testBody, ts);
    if (b < 0 || b > 2) inRange = false;
    seen.add(b);
  }
  check('BranchOf(ts 扫描) 都在 0..2', inRange);
  console.info(`  branch 覆盖: ${[...seen].sort().join(',')} (${seen.size} 种)`);
}


{
  const bodyMd5 = T.md5Of(testBody);
  const counts = { 0: 0, 1: 0, 2: 0 };
  let lensOK = true;
  for (let ts = 1761123400; ts < 1761123600; ts++) {
    const u = testURL + '&ts=' + ts;
    const b = BranchOf(u, testBody, ts);
    counts[b]++;
    const qs = T.sm3(Buffer.from(T.queryOf(u)));
    const got = T.hashF13(qs, bodyMd5, T.le32(ts >>> 0), ts);
    const wantLen = b === 1 ? 36 : 20;
    if (got.length !== wantLen) {
      lensOK = false;
      console.error(`  ts=${ts} branch=${b} 长度=${got.length}, want ${wantLen}`);
    }
  }
  check('hashF13 三分支长度正确 (200 个时间点)', lensOK);
  console.info(`  200 个时间点的分支分布: 0=${counts[0]} 1=${counts[1]} 2=${counts[2]}`);
  for (const k of [0, 1, 2]) check(`分支 ${k} 被覆盖`, counts[k] > 0, `count=${counts[k]}`);
  
  for (const ts of [1761123400, 1761123405, 1761123406]) {
    const out = Sign(testURL + '&ts=' + ts, testBody, ts);
    check(`Sign(ts=${ts}) 返回 6 个头`, Object.keys(out).length === 6);
  }
}


{
  for (let i = 0; i < 8; i++) {
    const out = Sign(testURL, testBody, testKhronos);
    if (Object.keys(out).length !== 6) {
      check('重复调用返回 6 个头', false, `第 ${i} 次返回 ${Object.keys(out).length} 个`);
    }
  }
  check('重复调用返回 6 个头', true);
  const cases = [
    ['https://api5-normal-sinfonlineb.fqnovel.com/novel/player/multi_video_model/v1/', null],
    ['https://api5-normal-sinfonlineb.fqnovel.com/x?', Buffer.alloc(0)],
    ['https://api5-normal-sinfonlineb.fqnovel.com/x?device_id=&version_name=', testBody],
  ];
  for (const [url, body] of cases) {
    const out = Sign(url, body, testKhronos);
    for (const k of ['x-gorgon', 'x-khronos', 'x-ladon', 'x-argus', 'x-helios', 'x-medusa']) {
      check(`边界 url 的 ${k} 非空`, out[k] !== undefined && out[k] !== '', url.slice(-30));
    }
    const b = BranchOf(url, body, testKhronos);
    check('边界 url 的 BranchOf 在 0..2', b >= 0 && b <= 2, String(b));
  }
}


{
  const query = 'device_id=3470001122334455&version_name=7.1.3.32&ts=1761123456&_rticket=1761123456789';
  const bodyMd5 = T.md5Of(testBody);
  const qs = T.sm3(Buffer.from(query));
  T.setProcessState('PROC_NONCE_0123456789abcdefg', 1761123456789);

  const golden = [
    ['sm3(query)', hex(T.sm3(Buffer.from(query))), '41ae3287049bd322ebcd8e6b36b99faca9935edd91055720220419655a6ec315'],
    ['getIv 链', String(T.getIv(T.getIv(T.getIv(0x20230928, qs), bodyMd5), T.le32(testKhronos)) >>> 0), '2863269314'],
    ['sumMd5(bodyMd5)', String(T.sumMd5(bodyMd5) >>> 0), '857334015'],
    ['hashF13 b0 (ts=1761123406)', hex(T.hashF13(T.sm3(Buffer.from(T.queryOf(testURL + '&ts=1761123406'))), bodyMd5, T.le32(1761123406), 1761123406)), '1590e43de1b0824dab31fc43fa24c27966ccfda3'],
    ['hashF13 b1 (ts=1761123400)', hex(T.hashF13(T.sm3(Buffer.from(T.queryOf(testURL + '&ts=1761123400'))), bodyMd5, T.le32(1761123400), 1761123400)), '119f94fd8c0050c4edf64cc6b96d5f742fea1ab2baa0e21ed7efe5d8c9df46fd9fc5f307'],
    ['hashF13 b2 (ts=1761123405)', hex(T.hashF13(T.sm3(Buffer.from(T.queryOf(testURL + '&ts=1761123405'))), bodyMd5, T.le32(1761123405), 1761123405)), 'e2217b2c6a8b86eed8be2dba7a853555b5e97622'],
    ['xGorgon(r=0x1234)', T.xGorgon(query, testBody, testKhronos, 0x1234), '840434124001ab9a83ddc1d3a41d1364e71df6105af6cc82f92f'],
    ['xGorgon 空 body', T.xGorgon('device_id=3470001122334455', Buffer.alloc(0), testKhronos, 0x1234), '840434124001a1123656d9fe6cc91364e71df6105af6cc82f97f'],
    ['helios(r=123456789)', T.heliosWith(testKhronos, 123456789), 'Fc1bB+JsCNo7JPbUkcgIOVdDvvcAH4hPd4nuYLmWEwUQiS1Z'],
    ['keyHash(r=123456789)', hex(T.keyHash(Buffer.from('8ebdfa3806ecc5cee79423e6029ed82540bc2218bb7eaef71cb691f7aa8aa2f5', 'hex'), 123456789)[0]), 'db94d40671c12092915349ad95e0a3ea830fe7ed9477d021a39a3c0d3c965923'],
    ['keyHash seed(r=123456789)', hex(T.keyHash(Buffer.from('8ebdfa3806ecc5cee79423e6029ed82540bc2218bb7eaef71cb691f7aa8aa2f5', 'hex'), 123456789)[1]), 'a127fdff'],
    ['aesBlock(k=1761123456)', hex(T.aesBlock(T.newAesV3(Buffer.from('f1593376766ea98d34f31b057a9d5be4', 'hex'), 1761123456), Buffer.from([3, 20, 37, 54, 71, 88, 105, 122, 139, 156, 173, 190, 207, 224, 241, 2]))), '49a1fa89ff6538e71c4c326e647ce115'],
  ];
  for (const [name, got, want] of golden) {
    check(`golden: ${name}`, got === want, `got ${got}, want ${want}`);
  }
  T.setProcessState(Math.random().toString(36).slice(2), Date.now());
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
