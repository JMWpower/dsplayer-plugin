'use strict';
/*
 * 请求层（v3）
 *   - 域名级 Cookie 罐（对应 Legado 的 CookieStore，支持 cookie.getKey(url,key)）
 *   - 编码自动识别：gbk/gb2312/gb18030/big5/utf-8，可用 charset 强制指定
 *   - 重试 / 超时 / 重定向 / POST 表单与 JSON / 自定义请求头
 *   - 只用 Node 内置能力，不依赖第三方包
 */

const DEFAULT_UA = 'Mozilla/5.0 (Linux; Android 12; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

/* ─────────────── Cookie ─────────────── */

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase(); } catch (e) { return ''; }
}

function pathOf(url) {
  try { return new URL(url).pathname || '/'; } catch (e) { return '/'; }
}

function domainMatch(host, domain) {
  if (!domain) return true;
  const d = String(domain).replace(/^\./, '').toLowerCase();
  return host === d || host.endsWith('.' + d);
}

class CookieJar {
  constructor() {
    // key = domain + '|' + path + '|' + name
    this.map = new Map();
  }

  _put(name, value, domain, path, expires) {
    if (!name) return;
    const key = domain + '|' + path + '|' + name;
    if (value === undefined || value === null || value === '' || value === 'deleted') {
      // 过期删除：同域名同名一起删
      for (const k of Array.from(this.map.keys())) {
        const [d, , n] = k.split('|');
        if (n === name && domainMatch(d, domain)) this.map.delete(k);
      }
      return;
    }
    this.map.set(key, { name, value, domain, path, expires: expires || 0 });
  }

  /** 从响应里吸收 Set-Cookie */
  setFromResponse(res, url) {
    const host = hostOf(url);
    let list = [];
    try {
      if (res.headers && typeof res.headers.getSetCookie === 'function') list = res.headers.getSetCookie();
      if ((!list || !list.length) && res.headers && res.headers.get) {
        const raw = res.headers.get('set-cookie');
        if (raw) list = splitSetCookie(raw);
      }
    } catch (e) { list = []; }
    if (!list || !list.length) return;
    for (const item of list) {
      const segs = String(item).split(';');
      const first = segs.shift() || '';
      const eq = first.indexOf('=');
      if (eq <= 0) continue;
      const name = first.slice(0, eq).trim();
      const value = first.slice(eq + 1).trim();
      let domain = host;
      let path = '/';
      let expires = 0;
      for (const s of segs) {
        const t = s.trim();
        const i = t.indexOf('=');
        const k = (i < 0 ? t : t.slice(0, i)).trim().toLowerCase();
        const v = i < 0 ? '' : t.slice(i + 1).trim();
        if (k === 'domain') domain = v.replace(/^\./, '').toLowerCase() || host;
        else if (k === 'path') path = v || '/';
        else if (k === 'max-age') {
          const n = parseInt(v, 10);
          if (isFinite(n)) expires = n <= 0 ? -1 : Date.now() + n * 1000;
        } else if (k === 'expires') {
          const t2 = Date.parse(v);
          if (isFinite(t2)) expires = t2;
        }
      }
      if (expires && expires < Date.now()) {
        this._put(name, '', domain, path, 0);
        continue;
      }
      this._put(name, value, domain, path, expires);
    }
  }

  /** 手工塞入 cookie 串（对应 java.setCookie / cookie.setCookie） */
  setFromString(url, cookieStr) {
    const host = hostOf(url) || String(url || '').replace(/^\./, '');
    const path = '/';
    for (const piece of String(cookieStr || '').split(';')) {
      const t = piece.trim();
      if (!t) continue;
      const eq = t.indexOf('=');
      if (eq <= 0) continue;
      this._put(t.slice(0, eq).trim(), t.slice(eq + 1).trim(), host, path, 0);
    }
  }

  /** 某域名下的 cookie 串（对应 cookie.getCookie(url)） */
  header(url) {
    const host = hostOf(url) || String(url || '');
    const path = pathOf(url);
    if (!host) {
      // 没有主机信息时退回全量
      if (!this.map.size) return '';
      return Array.from(this.map.values()).map((c) => c.name + '=' + c.value).join('; ');
    }
    const picked = [];
    for (const c of this.map.values()) {
      if (!domainMatch(host, c.domain)) continue;
      if (c.path && c.path !== '/' && !path.startsWith(c.path)) continue;
      if (c.expires && c.expires < Date.now()) continue;
      picked.push(c);
    }
    // 同名的后来者覆盖
    const byName = new Map();
    for (const c of picked) byName.set(c.name, c.value);
    return Array.from(byName.entries()).map(([k, v]) => k + '=' + v).join('; ');
  }

  /** 取单条（对应 cookie.getKey(url, key)） */
  get(url, key) {
    const host = hostOf(url) || String(url || '');
    if (!key) return '';
    const suffix = '|' + key;
    let val = '';
    for (const [k, c] of this.map) {
      if (k.endsWith(suffix) && domainMatch(host, c.domain)) val = c.value;
    }
    return val || '';
  }

  /** 删除（对应 cookie.removeCookie(url)） */
  remove(url) {
    const host = hostOf(url) || String(url || '');
    for (const k of Array.from(this.map.keys())) {
      const [d] = k.split('|');
      if (domainMatch(host, d) || domainMatch(d, host)) this.map.delete(k);
    }
  }

  all() {
    return Array.from(this.map.values());
  }

  dump() {
    return Array.from(this.map.values()).map((c) => ({
      name: c.name, value: c.value, domain: c.domain, path: c.path, expires: c.expires,
    }));
  }

  load(list) {
    if (!Array.isArray(list)) return;
    for (const c of list) {
      if (!c || !c.name) continue;
      if (c.expires && c.expires < Date.now()) continue;
      this.map.set(String(c.domain) + '|' + String(c.path || '/') + '|' + c.name,
        { name: c.name, value: c.value, domain: c.domain, path: c.path || '/', expires: c.expires || 0 });
    }
  }
}

/** set-cookie 一条里可能塞了多条（用逗号分隔但日期里也有逗号） */
function splitSetCookie(raw) {
  const out = [];
  let buf = '';
  const parts = String(raw).split(',');
  for (const p of parts) {
    if (/^\s*[A-Za-z0-9_\-]+=/.test(p) && buf && !/expires=/i.test(buf.split(';').slice(1).join(';'))) {
      buf += ',' + p;
      continue;
    }
    if (/^\s*[A-Za-z0-9_\-]+=/.test(p)) {
      if (buf) out.push(buf);
      buf = p;
    } else {
      buf += ',' + p;
    }
  }
  if (buf) out.push(buf);
  return out.length ? out : [String(raw)];
}

/* ─────────────── 编码 ─────────────── */

function detectCharset(buf, contentType) {
  const head = Buffer.from(buf.slice(0, 4096)).toString('latin1');
  let m = /charset\s*=\s*["']?([\w-]+)/i.exec(contentType || '');
  if (m) return m[1].toLowerCase();
  m = /<meta[^>]+charset\s*=\s*["']?([\w-]+)/i.exec(head);
  if (m) return m[1].toLowerCase();
  m = /<meta[^>]+content\s*=\s*["'][^"']*charset\s*=\s*([\w-]+)/i.exec(head);
  if (m) return m[1].toLowerCase();
  if (/^\s*\{|^\s*\[/.test(head)) return 'utf-8';
  return 'utf-8';
}

/** 声明 gbk 实际发 UTF-8 的站不少，字节能无损解成 UTF-8 且含中文就用 UTF-8 */
function looksUtf8(buf) {
  try {
    const t = Buffer.from(buf).toString('utf8');
    if (t.includes('\uFFFD')) return '';
    const cn = (t.match(/[\u4e00-\u9fa5]/g) || []).length;
    return cn > 0 ? t : '';
  } catch (e) { return ''; }
}

function decodeBody(buf, charset) {
  const cs = String(charset || 'utf-8').toLowerCase().replace(/^utf8$/, 'utf-8');
  const alias = {
    gb2312: 'gbk', gb18030: 'gbk', 'x-gbk': 'gbk', gbk: 'gbk',
    big5: 'big5', 'big5-hkscs': 'big5', 'utf-8': 'utf-8', utf8: 'utf-8',
    'iso-8859-1': 'utf-8', 'windows-1252': 'utf-8',
  };
  const name = alias[cs] || cs;
  if (name === 'gbk') {
    const utf8 = looksUtf8(buf);
    if (utf8) return utf8;
  }
  try {
    return new TextDecoder(name).decode(buf);
  } catch (e) {
    try { return new TextDecoder('utf-8').decode(buf); } catch (e2) { return Buffer.from(buf).toString('utf8'); }
  }
}

/* ─────────────── 请求 ─────────────── */

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

/** fetch 的请求头必须是 ByteString：含中文的头直接丢掉，避免整个请求炸掉 */
function sanitizeHeaders(headers) {
  const out = {};
  for (const k of Object.keys(headers || {})) {
    const v = headers[k];
    if (v === undefined || v === null) continue;
    const sv = String(v);
    if (/[^\x00-\xff]/.test(sv)) continue;
    if (/[^\x00-\xff]/.test(k)) continue;
    out[k] = sv;
  }
  return out;
}

const BLOCK_HINT = /(cf-browser-verification|Just a moment|cf_chl_opt|Access denied|403 Forbidden|请完成验证|人机验证|滑动验证|安全验证|访问过于频繁|请求过于频繁)/i;

/**
 * @param {string} url
 * @param {object} opts {method, headers, body, charset, timeout, jar, retry, referer, raw, noCookie, decode}
 */
async function request(url, opts = {}) {
  const timeout = opts.timeout || 15000;
  const retry = opts.retry === undefined ? 1 : opts.retry;
  const jar = opts.jar;
  let lastErr = null;
  let lastRes = null;

  for (let attempt = 0; attempt <= retry; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const headers = sanitizeHeaders(Object.assign({ 'User-Agent': DEFAULT_UA }, opts.headers || {}));
      // 头名大小写归并，避免出现两个 User-Agent
      const lower = {};
      for (const k of Object.keys(headers)) {
        if (k.toLowerCase() === 'user-agent') { headers[k] = headers[k]; }
        lower[k.toLowerCase()] = k;
      }
      if (jar && !opts.noCookie && !Object.prototype.hasOwnProperty.call(lower, 'cookie')) {
        const ck = jar.header(url);
        if (ck) headers.Cookie = ck;
      } else if (opts.cookie && !lower.cookie) {
        headers.Cookie = opts.cookie;
      }
      if (opts.referer && !lower.referer) headers.Referer = opts.referer;
      if (!lower['accept-language']) headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8';
      if (!lower.accept) headers.Accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8';
      if (!lower['accept-encoding']) headers['Accept-Encoding'] = 'gzip, deflate';
      if (!lower.connection) headers.Connection = 'keep-alive';

      const res = await fetch(url, {
        method: opts.method || 'GET',
        headers: sanitizeHeaders(headers),
        body: opts.body,
        redirect: 'follow',
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (jar) jar.setFromResponse(res, res.url || url);

      const buf = Buffer.from(await res.arrayBuffer());
      const contentType = res.headers.get('content-type') || '';
      const charset = opts.charset || detectCharset(buf, contentType);
      const text = opts.raw ? buf : decodeBody(buf, charset);
      const out = {
        ok: res.ok, status: res.status, url: res.url || url,
        text, buffer: buf, charset, headers: res.headers, contentType,
      };
      if (res.status === 403 || res.status === 503 || BLOCK_HINT.test(String(text).slice(0, 4000))) {
        out.blocked = true;
      }
      lastRes = out;
      // 5xx / 403 重试一次（有些站第一次给挑战页，第二次就放行）
      if ((res.status >= 500 || res.status === 403 || res.status === 429) && attempt < retry) {
        await sleep(500 + attempt * 800);
        continue;
      }
      return out;
    } catch (e) {
      clearTimeout(timer);
      lastErr = e;
      if (attempt < retry) await sleep(400 + attempt * 700);
    }
  }
  if (lastRes) return lastRes;
  const err = new Error('请求失败: ' + (lastErr && lastErr.message ? lastErr.message : '未知错误'));
  err.cause = lastErr;
  err.url = url;
  throw err;
}

/** 表单编码（可指定 gbk） */
function formEncode(obj, charset) {
  const gbk = /gbk|gb2312|gb18030/i.test(String(charset || ''));
  const gbkMod = require('./gbk');
  const parts = [];
  for (const k in obj) {
    if (obj[k] === undefined || obj[k] === null) continue;
    const val = String(obj[k]);
    parts.push(gbk ? gbkMod.encodeURIComponentGbk(k) + '=' + gbkMod.encodeURIComponentGbk(val)
      : encodeURIComponent(k) + '=' + encodeURIComponent(val));
  }
  return parts.join('&');
}

module.exports = { request, CookieJar, decodeBody, detectCharset, DEFAULT_UA, sleep, formEncode, hostOf, splitSetCookie };
