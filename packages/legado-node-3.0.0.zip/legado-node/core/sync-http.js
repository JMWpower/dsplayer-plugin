'use strict';
/*
 * 同步 HTTP 子进程入口
 * Legado 的 JS 是同步执行的（java.ajax 直接返回字符串），
 * Node 主线程没法直接同步发请求，所以把请求丢给子进程跑，主线程等结果。
 * 输入（stdin JSON）：{url, method, headers, body, timeout, charset, cookie}
 * 输出（stdout JSON）：{ok, status, url, text, charset, setCookie:[...], error}
 */

const { request, CookieJar } = require('./http');

function readStdin() {
  return new Promise((resolve) => {
    const chunks = [];
    process.stdin.on('data', (c) => chunks.push(c));
    process.stdin.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    process.stdin.on('error', () => resolve(''));
  });
}

(async () => {
  let out = { ok: false, status: 0, url: '', text: '', charset: 'utf-8', setCookie: [], error: '' };
  try {
    const raw = await readStdin();
    const opts = JSON.parse(raw || '{}');
    const jar = new CookieJar();
    if (opts.cookie) jar.setFromString(opts.url, opts.cookie);
    const res = await request(opts.url, {
      method: opts.method || 'GET',
      headers: opts.headers || {},
      body: opts.body,
      timeout: opts.timeout || 15000,
      charset: opts.charset,
      jar,
      retry: opts.retry === undefined ? 1 : opts.retry,
      referer: opts.referer,
    });
    out = {
      ok: res.ok,
      status: res.status,
      url: res.url,
      text: res.text,
      charset: res.charset,
      setCookie: jar.dump().map((c) => c.name + '=' + c.value + '; domain=' + c.domain + '; path=' + (c.path || '/')),
      error: '',
    };
  } catch (e) {
    out.error = (e && e.message) || '请求失败';
  }
  process.stdout.write(JSON.stringify(out));
})();
