'use strict';
/*
 * DOM 兼容层
 * 把自研 Element 补成接近 Legado（Jsoup）的 API，
 * 书源 JS 里常见的 x.text() / x.attr('href') / x.select('a') / x.html() 才能直接跑。
 */

const H = require('./html');

const { Element } = H;

if (!Element.prototype.text) {
  Element.prototype.text = function text() {
    return this.textContent.replace(/[ \t\u00a0\u3000]+/g, ' ').trim();
  };

  Element.prototype.ownText = function ownText() {
    let s = '';
    for (const c of this.children) if (c.type === 'text') s += c.text;
    return s.replace(/[ \t\u00a0\u3000]+/g, ' ').trim();
  };

  Element.prototype.html = function html() {
    return this.innerHTML;
  };

  Element.prototype.outerHtml = function outerHtml() {
    return this.outerHTML;
  };

  Element.prototype.select = function select(sel) {
    const arr = H.selectAll(this, String(sel));
    return makeElements(arr);
  };

  Element.prototype.selectFirst = function selectFirst(sel) {
    const arr = H.selectAll(this, String(sel));
    return arr.length ? arr[0] : null;
  };

  Element.prototype.parentNode = function parentNode() {
    return this.parent;
  };

  Element.prototype.parents = function parents() {
    const out = [];
    let p = this.parent;
    while (p && p.tag !== '#document') { out.push(p); p = p.parent; }
    return makeElements(out);
  };

  Element.prototype.childrenList = function childrenList() {
    return makeElements(this.children.filter((c) => c.type === 'tag'));
  };

  Element.prototype.siblings = function siblings() {
    if (!this.parent) return makeElements([]);
    return makeElements(this.parent.children.filter((c) => c.type === 'tag' && c !== this));
  };

  Element.prototype.nextSibling = function nextSibling() {
    if (!this.parent) return null;
    const arr = this.parent.children.filter((c) => c.type === 'tag');
    const i = arr.indexOf(this);
    return i >= 0 && arr[i + 1] ? arr[i + 1] : null;
  };

  Element.prototype.hasClass = function hasClass(name) {
    return this.classList.indexOf(String(name)) >= 0;
  };

  /* Jsoup 的 attributes()：返回属性对象数组，按序号取，toString() 是 key="value"。
   * 很多源用 org.jsoup.Jsoup.parse(html).selectFirst(x).attributes() 去取 data-* 里的 JSON，
   * 缺这个方法目录就直接解析成空。 */
  Element.prototype.attributes = function attributes() {
    const attrs = this.attrs || {};
    const out = Object.keys(attrs).map((k) => {
      const v = attrs[k];
      return {
        key: k,
        value: v,
        getKey: () => k,
        getValue: () => v,
        toString: () => k + '="' + v + '"',
      };
    });
    return out;
  };

  Element.prototype.attrList = Element.prototype.attributes;

  Element.prototype.getElementsByTag = function getElementsByTag(tag) {
    return makeElements(H.selectAll(this, String(tag)));
  };

  Element.prototype.toString = function toString() {
    return this.outerHTML;
  };
}

/** 把元素数组包装成 Jsoup 的 Elements 风格（同时保留数组语义） */
const WRAP_MARK = '__zakaWrapped';

function makeElements(arr) {
  const list = Array.isArray(arr) ? arr : [];
  // 同一个数组被包装两次会抛 "Cannot redefine property: text"。
  // java.getElements(r) 内部会再包一层，很多源的 JS 规则就是这么静默失败的，
  // 所以这里必须做成幂等。
  if (list[WRAP_MARK]) return list;

  const def = (name, val) => {
    try {
      Object.defineProperty(list, name, {
        value: val,
        enumerable: false,
        configurable: true,
        writable: true,
      });
    } catch (e) { /* 定义不了就跳过，别把整条规则拖挂 */ }
  };

  def(WRAP_MARK, true);
  def('text', function text() {
    return list.map((e) => e.textContent.trim()).join(' ').replace(/\s+/g, ' ').trim();
  });
  def('html', function html() { return list.map((e) => e.innerHTML).join('\n'); });
  def('attr', function attr(name) {
    for (const e of list) { const v = e.attr(name); if (v !== undefined) return v; }
    return '';
  });
  def('select', function select(sel) {
    const out = [];
    for (const e of list) out.push(...H.selectAll(e, String(sel)));
    return makeElements(out);
  });
  def('first', function first() { return list.length ? list[0] : null; });
  def('last', function last() { return list.length ? list[list.length - 1] : null; });
  def('size', function size() { return list.length; });
  def('get', function get(i) { return list[i < 0 ? list.length + i : i] || null; });
  def('toArray', function toArray() { return Array.prototype.slice.call(list); });
  def('eachAttr', function eachAttr(name) { return list.map((e) => e.attr(name) || ''); });
  def('eachText', function eachText() { return list.map((e) => e.textContent.trim()); });
  return list;
}

function parse(html) {
  return H.parseHTML(html);
}

module.exports = Object.assign({}, H, { parse, makeElements });
