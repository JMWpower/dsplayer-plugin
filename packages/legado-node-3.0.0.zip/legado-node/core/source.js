'use strict';
/*
 * 单个乐读书源（bookSource）实现（v3）
 *   search / explore / bookInfo / toc / content 五步，
 *   规则全部交给 rule.js，JS 交给 jsrt.js，这里只负责流程、请求、容错。
 */

const { request, CookieJar } = require('./http');
const gbk = require('./gbk');
const rule = require('./rule');
const { parseHTML, selectAll, makeElements } = require('./dom');
const { RuntimeState, resolveUrl } = require('./jsrt');
const { store } = require('./store');

/* ───────── 工具 ───────── */

function toAbsolute(base, url) {
  if (!url) return '';
  const u = String(url).trim();
  if (!u) return '';
  if (/^https?:\/\//i.test(u)) return u;
  if (u.startsWith('//')) return 'https:' + u;
  try { return new URL(u, base).toString(); } catch (e) { return u; }
}

function stripTags(html) {
  return String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h[1-6]|li|tr|section)>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#(\d+);/g, (m, d) => String.fromCharCode(parseInt(d, 10)))
    .replace(/&#x([0-9a-f]+);/gi, (m, d) => String.fromCharCode(parseInt(d, 16)))
    .replace(/[ \t\u00a0\u3000]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function parseAltHosts(raw, primary) {
  const out = [];
  const add = (u) => {
    let s = String(u || '').trim().replace(/[，,。;；]+$/, '').replace(/\/+$/, '');
    if (!s) return;
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    try { s = new URL(s).origin; } catch (e) { return; }
    if (!s || s === primary || out.indexOf(s) >= 0) return;
    out.push(s);
  };
  const comment = String(raw.bookSourceComment || '');
  const re = /备用(?:源)?(?:URL|域名|地址)\s*[:：]\s*(https?:\/\/[^\s，,；;]+)/gi;
  let m;
  while ((m = re.exec(comment)) !== null) add(m[1]);
  return out.slice(0, 4);
}

/** searchUrl 里可能带 ,{"method":"POST",...} */
function splitOptions(str) {
  const s = String(str || '').trim();
  const at = s.search(/,\s*\{/);
  if (at < 0) return { url: s, options: {} };
  const url = s.slice(0, at).trim();
  const rest = s.slice(at + 1).trim();
  try {
    return { url, options: JSON.parse(rest) };
  } catch (e) {
    // 常见写法里带换行/尾逗号，尽力修一下
    try {
      return { url, options: JSON.parse(rest.replace(/,\s*}/g, '}')) };
    } catch (e2) {
      return { url, options: {} };
    }
  }
}

function parseExplore(raw) {
  const str = String(raw || '').trim();
  if (!str) return [];
  if (str.startsWith('[')) {
    try {
      const arr = JSON.parse(str);
      return arr.filter((x) => x && typeof x === 'object')
        .map((x) => ({ title: String(x.title || '').trim(), url: String(x.url || '').trim(), style: x.style }))
        .filter((x) => x.title);
    } catch (e) {
      try {
        const fixed = str.replace(/,\s*]/g, ']').replace(/,\s*}/g, '}');
        const arr = JSON.parse(fixed);
        return arr.filter((x) => x && typeof x === 'object')
          .map((x) => ({ title: String(x.title || '').trim(), url: String(x.url || '').trim() }))
          .filter((x) => x.title);
      } catch (e2) { return []; }
    }
  }
  const out = [];
  for (const line of str.split(/\r?\n/)) {
    const t = line.trim();
    if (!t) continue;
    const i = t.indexOf('::');
    if (i < 0) continue;
    const title = t.slice(0, i).trim();
    const url = t.slice(i + 2).trim();
    if (title) out.push({ title, url });
  }
  return out;
}

/** Legado 分页语法 <a,b> + {{page}} */
function buildPageUrl(template, page) {
  let t = String(template || '');
  t = t.replace(/<([^<>]*)>/g, (m, inner) => {
    const comma = inner.indexOf(',');
    if (comma < 0) {
      return /\{\{\s*page\s*\}\}/.test(inner) ? inner.replace(/\{\{\s*page\s*\}\}/g, String(page)) : String(page);
    }
    const a = inner.slice(0, comma);
    const b = inner.slice(comma + 1);
    if (page <= 1) return a;
    return /\{\{\s*page\s*\}\}/.test(b) ? b.replace(/\{\{\s*page\s*\}\}/g, String(page)) : String(page);
  });
  return t.replace(/\{\{\s*page\s*\}\}/g, String(page));
}

/* ───────── 主体 ───────── */

class BookSource {
  constructor(raw, index, opts = {}) {
    this.raw = raw || {};
    this.index = index == null ? 0 : index;
    this.opts = opts;
    this.name = String(this.raw.bookSourceName || ('书源' + (this.index + 1)));
    this.url = String(this.raw.bookSourceUrl || '').split('#')[0].trim().replace(/\/+$/, '');
    this.key = String(this.raw.bookSourceUrl || '').trim();
    this.enabled = this.raw.enabled !== false;
    this.type = this.raw.bookSourceType || 0;
    this.group = this.raw.bookSourceGroup || '';
    this.searchUrl = String(this.raw.searchUrl || '');
    this.exploreUrl = String(this.raw.exploreUrl || '');
    this.altHosts = parseAltHosts(this.raw, this.url);
    this.activeHost = this.url;
    this.rules = {
      search: normalizeRuleSet(this.raw.ruleSearch),
      explore: normalizeRuleSet(this.raw.ruleExplore),
      bookInfo: normalizeRuleSet(this.raw.ruleBookInfo),
      toc: normalizeRuleSet(this.raw.ruleToc),
      content: normalizeRuleSet(this.raw.ruleContent),
    };
    this.channels = parseExplore(this.exploreUrl);
    // 规则里带 java.ajax 的源会阻塞主线程（同步请求），搜索时排到后面
    this.usesJsNet = /java\.(ajax|post|connect|ajaxAll)/.test(
      JSON.stringify(this.rules) + this.searchUrl + this.exploreUrl
    );
    this.jar = new CookieJar();
    this.header = {};
    this.timeout = opts.requestTimeout || 15000;

    const st = store(opts.storeFile);
    this.jar.load(st.cookiesOf(this.key));
    const varsObj = st.varsOf(this.key);
    this.vars = new Map(Object.entries(varsObj));
    this._varsDirty = false;

    if (this.raw.header) {
      try {
        const h = typeof this.raw.header === 'string' ? JSON.parse(this.raw.header) : this.raw.header;
        for (const k in h) this.header[k] = String(h[k]);
      } catch (e) { /* header 不是 JSON 就忽略 */ }
    }
  }

  get searchable() { return !!this.searchUrl; }
  get hasExplore() { return this.channels.length > 0; }

  /* ── 运行状态 ── */

  makeState(extra = {}) {
    const state = new RuntimeState({
      src: extra.html || '',
      root: extra.root || null,
      baseUrl: extra.baseUrl || this.activeHost || this.url,
      host: this.activeHost || this.url,
      key: extra.key || '',
      page: extra.page || 1,
      title: extra.title || '',
      jar: this.jar,
      vars: this.vars,
      bookVars: new Map(),
      book: extra.book || null,
      chapter: extra.chapter || null,
      source: this.raw,
      cache: this.cacheStore(),
      headers: this.header,
      timeout: this.timeout,
      code: this.key,
    });
    return state;
  }

  cacheStore() {
    if (!this._cache) this._cache = new Map();
    return this._cache;
  }

  /** 把状态里的变量写回磁盘（延迟批量） */
  persist() {
    if (!this.vars) return;
    const st = store(this.opts.storeFile);
    const obj = {};
    for (const [k, v] of this.vars) obj[k] = v;
    st.setVars(this.key, obj);
    st.setCookies(this.key, this.jar.dump());
  }

  ctxFrom(state, html, baseUrl) {
    return rule.makeContext({
      html: html == null ? state.current() : html,
      root: state.root || undefined,
      baseUrl: baseUrl || state.baseUrl,
      host: state.host,
      key: state.key,
      page: state.page,
      cookie: this.jar.header(baseUrl || state.baseUrl),
      state,
      title: state.title,
    });
  }

  /** 模板渲染：{{key}} 默认按 URL 编码（与 Legado 一致） */
  render(str, state) {
    if (str == null) return '';
    let s = String(str);
    if (s.indexOf('{{') < 0) return s;
    s = s.replace(/\{\{\s*key\s*\}\}/g, encodeURIComponent(String(state.key || '')));
    const ctx = rule.makeContext({
      html: state.current(), baseUrl: state.baseUrl, host: state.host,
      key: state.key, page: state.page, state, root: state.root || undefined,
    });
    return rule.evalTemplate(s, ctx);
  }

  resolve(path) {
    return toAbsolute((this.activeHost || this.url) + '/', path);
  }

  _swapHost(url, host) {
    try {
      const u = new URL(url);
      const h = new URL(host);
      return h.origin + u.pathname + u.search;
    } catch (e) { return url; }
  }

  /* ── 请求 ── */

  async fetch(url, opts = {}) {
    if (!url || !/^https?:\/\//i.test(String(url))) {
      return { ok: false, status: 0, url: String(url || ''), text: '', blocked: false, headers: {} };
    }
    const cfg = Object.assign({
      headers: this.header,
      jar: this.jar,
      timeout: this.timeout,
      retry: 1,
      referer: this.activeHost || this.url,
    }, opts);

    const hosts = [this.activeHost || this.url].concat(this.altHosts || []);
    let lastErr = null;
    let lastRes = null;
    for (let i = 0; i < hosts.length; i++) {
      const host = hosts[i];
      const target = i > 0 ? this._swapHost(url, host) : url;
      try {
        const res = await request(target, cfg);
        if (res && res.ok) {
          if (host !== this.activeHost) {
            this.activeHost = host;
            this.url = host;
          }
          return res;
        }
        lastRes = res;
        if (res && res.blocked) break;
      } catch (e) {
        lastErr = e;
      }
    }
    if (lastRes) return lastRes;
    throw lastErr || new Error('请求失败');
  }

  /* ── 搜索 ── */

  async search(keyword, page = 1) {
    if (!this.searchUrl) return [];
    const cleaned = String(this.searchUrl).trim();
    const state = this.makeState({ key: keyword, page });
    // Legado 允许 searchUrl 先跑模板（例如 {{cookie.removeCookie(...)}}），再拼地址；
    // 也允许整条是 JS（@js:...），或地址后面再挂一段 @js:
    const jsrt = require('./jsrt');
    let rendered = '';
    const jsAt = findTopLevelJs(cleaned);
    if (jsAt >= 0) {
      const prefix = cleaned.slice(0, jsAt).trim();
      const code = cleaned.slice(jsAt + 4);
      const seed = prefix ? this.render(prefix, state) : '';
      const out = jsrt.runScript(code, state, seed);
      rendered = Array.isArray(out) ? out.join('') : String(out == null ? '' : out);
      if (!rendered.trim() && seed) rendered = seed;
      rendered = rendered.trim();
    } else {
      rendered = this.render(cleaned, state);
    }
    rendered = rendered
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean)
      .join('\n')
      .trim();
    const { url, options } = splitOptions(rendered);
    const method = String(options.method || 'GET').toUpperCase();
    const charset = options.charset || '';
    const target = this.resolve(url);
    const body = options.body ? String(options.body) : undefined;

    const headers = Object.assign({}, this.header, options.headers || {});
    if (method === 'POST' && !headers['Content-Type'] && !headers['content-type']) {
      headers['Content-Type'] = /json/i.test(String(options.bodyType || '')) ? 'application/json'
        : 'application/x-www-form-urlencoded';
    }

    const res = await this.fetch(target, { method, body, charset, headers });
    if (!res.ok) return [];
    const ctx = this.ctxFrom(state, res.text, res.url);
    return this.parseBookList(ctx, this.rules.search);
  }

  /* ── 分类 / 发现 ── */

  async explore(channelUrl, page = 1) {
    let tpl = channelUrl || (this.channels[0] && this.channels[0].url) || '';
    if (!tpl) return [];
    const state = this.makeState({ page });

    // 频道地址本身可能是 JS（exploreUrl 里写 @js:buildRequest(...) 的源不少）
    let url = '';
    if (/^@?js:|^<js>/i.test(String(tpl).trim())) {
      const jsrt = require('./jsrt');
      const code = String(tpl).trim().replace(/^<js>/i, '').replace(/<\/js>$/i, '').replace(/^@?js:/, '');
      const out = jsrt.runScript(code, state, '');
      url = Array.isArray(out) ? out.join('') : String(out == null ? '' : out);
    } else {
      url = this.render(buildPageUrl(tpl, page), state);
    }
    url = String(url || '').trim();
    if (!url) return [];
    const target = this.resolve(url);
    const res = await this.fetch(target);
    if (!res.ok) return [];
    let cfg = this.rules.explore;
    if (!cfg.bookList) cfg = Object.assign({}, this.rules.search);
    const ctx = this.ctxFrom(state, res.text, res.url);
    return this.parseBookList(ctx, cfg, true);
  }

  /* ── 书列表解析 ── */

  parseBookList(ctx, cfg, allowEmptyBookUrl) {
    cfg = cfg || {};
    let items = [];
    if (cfg.bookList) {
      items = rule.evalElements(String(cfg.bookList), ctx, ctx.root);
    }
    if (!items.length) {
      // 规则没命中时兜底：按链接结构猜
      items = selectAll(ctx.root, 'a[href]').filter((a) => {
        const t = a.textContent.trim();
        return t.length >= 2 && t.length <= 60 && /book|read|info|content|\/\d+/i.test(a.attr('href') || '');
      });
    }

    const out = [];
    for (const el of items.slice(0, 120)) {
      const book = this.extractBook(el, ctx, cfg);
      if (book && (book.name || (allowEmptyBookUrl && book.bookUrl))) out.push(book);
    }
    const seen = new Set();
    return out.filter((b) => {
      const k = b.bookUrl || (b.name + '|' + b.author);
      if (!k || seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  extractBook(el, ctx, cfg) {
    const val = (field, dflt) => {
      const spec = cfg[field] === undefined ? dflt : cfg[field];
      if (!spec) return '';
      return rule.evalString(String(spec), ctx, el);
    };
    const book = {
      name: '',
      author: cleanLine(val('author', '')),
      kind: cleanLine(val('kind', '')),
      lastChapter: cleanLine(val('lastChapter', '')),
      intro: cleanLine(val('intro', '')),
      coverUrl: toAbsolute(ctx.baseUrl, (val('coverUrl', '') || '').split('\n')[0].trim()),
      bookUrl: '',
      wordCount: cleanLine(val('wordCount', '')),
      origin: this.name,
      type: this.type,
    };
    book.name = (cleanLine(val('name', '')) || el.textContent.trim().slice(0, 40) || '').trim();

    // bookUrl 里常用 {{book.kind}} / {{book.name}}：先把已知字段挂到 book 上再算
    const st = ctx.state;
    const prev = st ? st.book : null;
    if (st) st.book = Object.assign({}, prev || {}, book);
    try {
      book.bookUrl = toAbsolute(ctx.baseUrl, (val('bookUrl', 'href') || '').split('\n')[0].trim());
    } finally {
      if (st) st.book = prev;
    }
    return book;
  }

  /* ── 详情 ── */

  async bookInfo(bookUrl, book) {
    const res = await this.fetch(bookUrl);
    if (!res.ok) throw new Error('详情页打不开 ' + res.status);
    const state = this.makeState({ html: res.text, baseUrl: res.url, book: book || null });
    state.root = parseHTML(res.text);

    const cfg = this.rules.bookInfo;
    if (cfg.init) {
      runInitRule(cfg.init, state);
    }
    const ctx = this.ctxFrom(state);
    const bookObj = Object.assign({}, state.book || {}, { bookUrl });
    const withBook = (fn) => {
      const prev = state.book;
      state.book = bookObj;
      try { return fn(); } finally { state.book = prev; }
    };
    const get = (field) => (cfg[field] ? rule.evalString(String(cfg[field]), ctx, ctx.root) : '');

    // 名字/作者/分类先算出来，后面的规则（尤其 tocUrl）常引用 {{book.kind}}
    bookObj.name = cleanLine(withBook(() => get('name'))) || bookObj.name || '';
    bookObj.author = cleanLine(withBook(() => get('author'))) || bookObj.author || '';
    bookObj.kind = cleanLine(withBook(() => get('kind'))) || bookObj.kind || '';

    const tocRaw = withBook(() => get('tocUrl'));
    const tocUrls = String(tocRaw || '').split('\n').map((x) => x.trim()).filter(Boolean)
      .map((x) => toAbsolute(res.url, x));
    return {
      name: cleanLine(withBook(() => get('name'))) || (book && book.name) || '',
      kind: cleanLine(get('kind')) || '',
      lastChapter: cleanLine(get('lastChapter')) || '',
      intro: cleanLine(get('intro')) || '',
      coverUrl: toAbsolute(res.url, (get('coverUrl') || '').split('\n')[0].trim()),
      wordCount: cleanLine(get('wordCount')) || '',
      tocUrl: tocUrls[0] || res.url,
      tocUrls: tocUrls.length ? tocUrls : [res.url],
      bookUrl,
      origin: this.name,
      type: this.type,
      state,
    };
  }

  /* ── 目录 ── */

  async toc(tocUrl, book) {
    const cfg = this.rules.toc;
    const chapters = [];
    const seenChapter = new Map();
    const seenPage = new Set();
    const queue = Array.isArray(tocUrl) ? tocUrl.slice() : [tocUrl];
    let guard = 0;

    while (queue.length && guard < 40) {
      const url = queue.shift();
      if (!url || seenPage.has(url)) continue;
      seenPage.add(url);
      guard++;

      let res;
      try { res = await this.fetch(url); } catch (e) { break; }
      if (!res.ok) break;

      const state = this.makeState({ html: res.text, baseUrl: res.url, book });
      state.root = parseHTML(res.text);
      if (cfg.preUpdateJs) runInitRule(cfg.preUpdateJs, state);
      const ctx = this.ctxFrom(state);

      let items = [];
      if (cfg.chapterList) items = evalChapterList(String(cfg.chapterList), ctx, state);

      if (!items.length) {
        items = selectAll(ctx.root, 'a[href]').filter((a) => {
          const t = a.textContent.trim();
          return t.length > 0 && t.length < 80 && /第|章|节|回/.test(t);
        });
      }

      for (const el of items) {
        let name = '';
        let href = '';
        if (el && el.__chapter) {
          name = el.__chapter.text || '';
          href = el.__chapter.href || '';
        } else if (typeof el === 'string') {
          name = el;
        } else {
          name = cfg.chapterName ? rule.evalString(String(cfg.chapterName), ctx, el) : el.textContent.trim();
          href = cfg.chapterUrl ? rule.evalString(String(cfg.chapterUrl), ctx, el) : (el.attr('href') || '');
        }
        href = toAbsolute(res.url, String(href || '').split('\n')[0].trim());
        if (!href) continue;
        name = cleanLine(name) || ('第' + (chapters.length + 1) + '章');
        if (seenChapter.has(href)) {
          const prev = seenChapter.get(href);
          const at = chapters.indexOf(prev);
          if (at >= 0) chapters.splice(at, 1);
        }
        const item = { name, url: href, index: chapters.length };
        chapters.push(item);
        seenChapter.set(href, item);
      }
      if (chapters.length >= 4000) break;

      if (cfg.nextTocUrl) {
        const nextVal = rule.evalString(String(cfg.nextTocUrl), ctx, ctx.root);
        for (const raw of String(nextVal || '').split('\n')) {
          const t = raw.trim();
          if (!t) continue;
          const abs = /^https?:/i.test(t) ? t : toAbsolute(res.url, t);
          if (!seenPage.has(abs)) queue.push(abs);
        }
      }
    }
    return chapters;
  }

  /* ── 正文 ── */

  async content(chapterUrl, book, chapter) {
    const cfg = this.rules.content;
    const parts = [];
    const seen = new Set();
    let url = chapterUrl;
    let firstHtml = '';
    let firstUrl = chapterUrl;
    let guard = 0;
    let title = '';

    while (url && !seen.has(url) && guard < 6) {
      seen.add(url);
      guard++;
      let res;
      try { res = await this.fetch(url); } catch (e) { break; }
      if (!res.ok) break;
      if (!firstHtml) { firstHtml = res.text; firstUrl = res.url; }

      const state = this.makeState({ html: res.text, baseUrl: res.url, book, chapter });
      state.root = parseHTML(res.text);
      const ctx = this.ctxFrom(state);

      if (!title && cfg.title) title = cleanLine(rule.evalString(String(cfg.title), ctx, ctx.root));

      let part = cfg.content ? rule.evalString(String(cfg.content), ctx, ctx.root) : '';
      if (!part) part = guessContent(ctx);
      if (part) parts.push(part);

      let next = '';
      if (cfg.nextContentUrl) {
        next = String(rule.evalString(String(cfg.nextContentUrl), ctx, ctx.root) || '').split('\n')[0].trim();
        if (next && !/^https?:/i.test(next)) next = toAbsolute(res.url, next);
      }
      url = next;
    }

    let html = parts.join('<div></div>');
    if (stripTags(html).length < 80 && firstHtml) {
      // 规则没抓到：去掉索引再来一次，再不行取正文里最大的一块
      const state = this.makeState({ html: firstHtml, baseUrl: firstUrl, book, chapter });
      state.root = parseHTML(firstHtml);
      const ctx = this.ctxFrom(state);
      html = tolerantContent(cfg.content, ctx) || guessContent(ctx) || html;
    }

    let text = html.indexOf('<') >= 0 ? stripTags(html) : cleanText(String(html || ''));
    if (cfg.replaceRegex) {
      const segs = String(cfg.replaceRegex).split('##');
      const pattern = segs[1] !== undefined ? segs[1] : segs[0];
      const repl = segs[2] !== undefined ? segs[2] : '';
      try { text = text.replace(new RegExp(pattern, 'g'), repl); } catch (e) { /* ignore */ }
    }
    return { title, content: text, url: firstUrl };
  }
}

/* ───────── 辅助 ───────── */

/** 找 {{}} 之外的 '@js:' 位置 */
function findTopLevelJs(str) {
  const s = String(str || '');
  let depth = 0;
  for (let i = 0; i < s.length; i++) {
    if (s.startsWith('{{', i)) { depth++; i++; continue; }
    if (s.startsWith('}}', i) && depth > 0) { depth--; i++; continue; }
    if (depth === 0 && s.startsWith('@js:', i)) return i;
  }
  return -1;
}

function normalizeRuleSet(r) {
  if (!r) return {};
  if (typeof r === 'string') {
    try { return JSON.parse(r); } catch (e) { return {}; }
  }
  return r;
}

function cleanLine(s) {
  return String(s == null ? '' : s).split(/[\r\n]+/)[0].replace(/\s+/g, ' ').trim();
}

function cleanText(s) {
  return String(s || '')
    .replace(/\r/g, '')
    .replace(/[ \t\u00a0\u3000]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** init / preUpdateJs 可能是 @js:、<js>、也可能是裸 JS */
function runInitRule(code, state) {
  const raw = String(code || '').trim();
  if (!raw) return;
  const isJs = /^@?js:/.test(raw) || /^<js>/i.test(raw)
    || /java\.|source\.|book\.|cookie\.|cache\.|result\b|;|\$\{/.test(raw);
  if (!isJs) {
    // 是规则 → 取出新内容（有些 init 用规则选出一段 html）
    const ctx = rule.makeContext({
      html: state.current(), baseUrl: state.baseUrl, host: state.host, state, root: state.root || undefined,
    });
    const html = rule.evalString(raw, ctx, ctx.root);
    if (html && /^\s*</.test(html) && html.length > 200) state.setContent(html);
    return;
  }
  const jsrt = require('./jsrt');
  const code2 = raw.replace(/^<js>([\s\S]*?)<\/js>$/i, '$1').replace(/^@?js:/, '');
  jsrt.runScript(code2, state, '');
}

/** chapterList 可能是 JS 返回 [{text, href}] 或元素数组 */
function evalChapterList(ruleStr, ctx, state) {
  const jsrt = require('./jsrt');
  if (/^\s*@?js:/.test(ruleStr) || /^\s*<js>/.test(ruleStr)) {
    const code = ruleStr.replace(/^\s*<js>/, '').replace(/<\/js>\s*$/i, '').replace(/^\s*@?js:/, '');
    const out = jsrt.runScript(code, state, '');
    if (Array.isArray(out)) {
      const chapters = [];
      for (const item of out) {
        if (item == null) continue;
        if (item.tag) { chapters.push(item); continue; }
        if (typeof item === 'object') {
          const href = item.href || item.url || item.link || '';
          const text = item.text || item.title || item.name || '';
          if (href || text) chapters.push({ __chapter: { text: String(text), href: String(href) }, textContent: String(text), attr: () => undefined });
          continue;
        }
        if (typeof item === 'string') chapters.push({ __chapter: { text: item, href: '' }, textContent: item, attr: () => undefined });
      }
      return chapters;
    }
    if (typeof out === 'string' && out) {
      return out.split('\n').filter(Boolean).map((line) => {
        const i = line.indexOf(',');
        if (i > 0) return { __chapter: { text: line.slice(0, i), href: line.slice(i + 1) }, textContent: line, attr: () => undefined };
        return { __chapter: { text: line, href: '' }, textContent: line, attr: () => undefined };
      });
    }
    return [];
  }
  return rule.evalElements(ruleStr, ctx, ctx.root);
}

/** 规则抓不到正文时：去掉末尾索引再选一次，取文字最多的 */
function tolerantContent(ruleStr, ctx) {
  if (!ruleStr) return '';
  let main = String(ruleStr).split('##')[0];
  main = main.split('@').filter((p) => p && !/^(text|html|all|textNodes|ownText)$/i.test(p.trim())).join('@');
  main = main.replace(/(?:\.-?\d+(?::\d+)?|\[[\d,\s-]+\])$/, '');
  let els = [];
  try { els = rule.evalElements(main, ctx, ctx.root); } catch (e) { els = []; }
  let best = null;
  let bestLen = 0;
  for (const el of els) {
    const t = el.textContent.trim();
    if (t.length > bestLen) { best = el; bestLen = t.length; }
  }
  return best && bestLen > 50 ? best.innerHTML : '';
}

/** 全网兜底：找文字最多、带换行的块 */
function guessContent(ctx) {
  const root = ctx.root;
  const skip = /^(script|style|nav|header|footer|aside|form|select|ol|ul|option|button)$/i;
  let best = null;
  let bestLen = 0;
  for (const el of root.descendants()) {
    if (skip.test(el.tag)) continue;
    const cls = (el.attrs.class || '') + ' ' + (el.attrs.id || '');
    if (/nav|menu|footer|header|breadcrumb|comment|ad-|advert|toolbar|bottom/i.test(cls)) continue;
    const t = el.textContent.trim();
    if (t.length < bestLen) continue;
    const brCount = (el.innerHTML.match(/<br\s*\/?>/gi) || []).length;
    const pCount = (el.innerHTML.match(/<p[\s>]/gi) || []).length;
    if (brCount + pCount < 3 && t.length < 300) continue;
    best = el;
    bestLen = t.length;
  }
  return best ? best.innerHTML : '';
}

module.exports = {
  BookSource, stripTags, toAbsolute, parseExplore, splitOptions, buildPageUrl, cleanLine,
};
