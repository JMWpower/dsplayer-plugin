'use strict';
/*
 * 聚合引擎（v3）
 *   分类 = 书源，列表 = 书，详情 = 书信息 + 章节目录，播放 = 章节正文
 *
 * v3 相比 v2：
 *   - 走新的 rule / jsrt / xpath / jsonpath，规则覆盖面和 v2 不是一个量级
 *   - 搜索有总预算（时间到了就把已有结果先返回，不让客户端干等）
 *   - 单个书源连续失败会被临时拉黑，避免每次都白等超时
 */

const { BookSource, stripTags } = require('./source');

function b64url(buf) {
  return Buffer.from(buf, 'utf8').toString('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function unb64url(str) {
  const s = String(str || '').replace(/-/g, '+').replace(/_/g, '/');
  const pad = s.length % 4 ? '='.repeat(4 - (s.length % 4)) : '';
  return Buffer.from(s + pad, 'base64').toString('utf8');
}

function token(idx, url) {
  return idx + '~' + b64url(String(url || ''));
}

function parseToken(t) {
  const s = String(t == null ? '' : t).trim();
  if (!s) return { idx: -1, url: '' };
  const legacy = s.indexOf('::');
  if (legacy > 0) return { idx: parseInt(s.slice(0, legacy), 10), url: s.slice(legacy + 2) };
  const tilde = s.indexOf('~');
  if (tilde > 0) {
    const idx = parseInt(s.slice(0, tilde), 10);
    if (/^\d+$/.test(String(idx))) {
      try { return { idx, url: unb64url(s.slice(tilde + 1)) }; } catch (e) { /* fallthrough */ }
    }
  }
  if (/^https?:\/\//i.test(s)) return { idx: -1, url: s };
  return { idx: -1, url: s };
}

function withTimeout(promise, ms, fallback) {
  let timer;
  const timeout = new Promise((resolve) => { timer = setTimeout(() => resolve(fallback), ms); });
  return Promise.race([Promise.resolve(promise).catch(() => fallback), timeout])
    .finally(() => clearTimeout(timer));
}

async function mapLimit(items, limit, worker) {
  const out = new Array(items.length);
  let cursor = 0;
  const runners = new Array(Math.max(1, Math.min(limit, items.length || 1))).fill(0).map(async () => {
    while (cursor < items.length) {
      const i = cursor++;
      out[i] = await worker(items[i], i);
    }
  });
  await Promise.all(runners);
  return out;
}

function cleanLine(s) {
  return String(s == null ? '' : s).split(/[\r\n]+/)[0].replace(/\s+/g, ' ').trim();
}

/* 从书源地址 / 体检条目里取出站点域名，用来对齐体检结果：
 *   https://www.Shellbook.cc/abc#x  →  shellbook.cc
 *   DragonQuestQBall               →  dragonquestqball（非 http 的伪地址也照样归一） */
function hostOf(u) {
  return String(u == null ? '' : u)
    .trim()
    .replace(/^[a-z][a-z0-9+.-]*:\/\//i, '')
    .split('/')[0]
    .split('#')[0]
    .split('?')[0]
    .toLowerCase()
    .replace(/^www\./, '');
}

/* 体检条目 → 1 / -1 / null（认不出来） */
function healthVerdict(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === 'object') return v.ok ? 1 : -1;
  return v ? 1 : -1;
}

function cleanName(s) {
  let v = cleanLine(s);
  v = v.replace(/\s*(作者|著)[:：].*$/, '').trim();
  v = v.replace(/^[《【](.+)[》】]$/, '$1').trim();
  return v.slice(0, 60);
}

function cleanKind(s) {
  return String(s == null ? '' : s)
    .split(/[\r\n]+/)
    .map((x) => x.replace(/^[^：:]{1,6}[:：]/, '').trim())
    .filter(Boolean)
    .filter((x, i, arr) => arr.indexOf(x) === i)
    .join(' · ')
    .slice(0, 40);
}

function cleanIntro(s) {
  if (!s) return '';
  return stripTags(String(s).replace(/<br\s*\/?>/gi, '\n')).replace(/\n{3,}/g, '\n\n').trim().slice(0, 600);
}

function cleanChapterName(raw, i) {
  let v = cleanLine(raw)
    // 章节名里常混进 HTML 实体（&lrm; 这类方向标记尤其常见），先解掉
    .replace(/&(?:lrm|rlm|zwj|zwnj|thinsp|ensp|emsp|nbsp);/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#(\d+);/g, (m, d) => { try { return String.fromCharCode(parseInt(d, 10)); } catch (e) { return ''; } })
    .replace(/&#x([0-9a-f]+);/gi, (m, d) => { try { return String.fromCharCode(parseInt(d, 16)); } catch (e) { return ''; } })
    .replace(/\s*[（(]?\s*(?:免费|最新|手机阅读|无弹窗|全文阅读|请记住本站)[^)）]*[)）]?\s*$/g, '')
    .replace(/[$#]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!v) v = '第' + (i + 1) + '章';
  return v.slice(0, 80);
}

/* 正文页的 <title> 常把整站导航拼进来（书名 + 阅读文章 + 章节名），
 * 目录里已经有干净章节名时优先用目录的，没有才清洗页面标题拿来做兜底 */
function cleanChapterTitle(raw, fallback) {
  let v = cleanLine(raw);
  if (!v) return fallback || '';
  const m = v.match(/(第\s*[\d零一二三四五六七八九十百千万两]+\s*[章节回卷][^\s，,。]{0,30})/);
  if (m) return cleanChapterName(m[1], 0);
  v = v.replace(/(阅读文章|加入书签|收藏到书柜|加入书架|最新章节|全文阅读|无弹窗|请记住本站|手机阅读|章节列表)/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return v.slice(0, 60) || fallback || '';
}

/* 站点常把「书名 + 阅读文章 + 收藏到书柜」拼进每个章节名，
 * 取出所有章节的公共前缀一次性去掉；但不能误删「第 X 章」这种正常结构 */
function commonPrefixOf(arr) {
  if (!arr || arr.length < 2) return '';
  let p = arr[0];
  for (const s of arr) {
    while (p && !s.startsWith(p)) p = p.slice(0, -1);
    if (!p) break;
  }
  if (p.length < 6) return '';
  if (/^(第|序|楔子|番外|chapter|vol)/i.test(p)) return '';
  const cut = Math.max(p.lastIndexOf(' '), p.lastIndexOf('：'), p.lastIndexOf('·'), p.lastIndexOf('-'));
  if (cut > 0) p = p.slice(0, cut + 1);
  return p;
}

class Engine {
  constructor(sourcesJson, opts = {}) {
    const list = Array.isArray(sourcesJson) ? sourcesJson
      : (sourcesJson && Array.isArray(sourcesJson.sources) ? sourcesJson.sources : []);
    this.opts = Object.assign({
      searchTimeout: 6000,
      sourceTimeout: 12000,
      detailTimeout: 25000,
      chapterTimeout: 20000,
      searchConcurrency: 24,
      channelConcurrency: 4,
      maxChapters: 3000,
      listLimit: 40,
      searchBudget: 10000,
      requestTimeout: 15000,
      maxCategories: 300,
      onlyHealthy: false,
      storeFile: null,
    }, opts);

    this.sources = [];
    list.forEach((raw) => {
      if (!raw || raw.enabled === false) return;
      try {
        const s = new BookSource(raw, this.sources.length, {
          requestTimeout: this.opts.requestTimeout,
          storeFile: this.opts.storeFile,
        });
        if (!s.url) return;
        this.sources.push(s);
      } catch (e) { /* 单条书源坏掉不影响整体 */ }
    });

    this._cache = new Map();
    this._cacheMax = 1200;
    this._titles = new Map();
    this._fail = new Map();
    this._catOk = new Set();    // 分类真能出内容的源
    this._catFail = new Set();  // 分类点了是空/报错的源，排到后面去
    this._bookNames = new Map(); // vod_id → 列表里已解析出的书名/作者，详情页兜底用
    this._status = new Map();    // 面板用：每个源最近一次抓取结果
  }

  get size() { return this.sources.length; }

  /* ── 最近一次抓取状态（管理面板「源管理」/ 健康检查用）──
   * 面板那套是 v2 带过来的：真的抓一次分类页，然后把「有没有内容 / 为什么没有」记下来，
   * 免得用户只看到一屏空白。跟上面的体检（按域名）互不干扰。 */
  _markOk(idx) {
    const prev = this._status.get(idx);
    this._status.set(idx, { state: 'ok', msg: '', bad: 0, at: Date.now(), ms: prev ? prev.ms : 0 });
  }

  _markEmpty(idx, msg, ms) {
    this._status.set(idx, { state: 'empty', msg: msg || '', bad: 1, at: Date.now(), ms: ms || 0 });
  }

  _markError(idx, msg, ms) {
    this._status.set(idx, {
      state: /超时|timeout|aborted/i.test(String(msg)) ? 'timeout' : 'error',
      msg: String(msg || '').slice(0, 180), bad: 1, at: Date.now(), ms: ms || 0,
    });
  }

  statusOf(idx) {
    const s = this._status.get(idx);
    if (s) return s;
    return { state: 'unknown', msg: '', at: 0, ms: 0 };
  }

  /** 按书源地址拿状态（store 的下标和 engine 的下标不一定一致） */
  statusForUrl(url) {
    const norm = (u) => String(u || '').split('#')[0].trim().replace(/\/+$/, '').toLowerCase();
    const want = norm(url);
    const at = this.sources.findIndex((s) => norm(s.url) === want);
    return at < 0 ? { state: 'disabled', msg: '已停用', at: 0, ms: 0 } : this.statusOf(at);
  }

  statusMap() {
    const out = {};
    this.sources.forEach((s, i) => { out[s.url] = this.statusOf(i); });
    return out;
  }

  /** 这个源是不是 JS 源（用 @js / jsLib 生成页面，HTML 规则抓不出来） */
  _jsSource(s) {
    const raw = (s && s.raw) || {};
    if (raw.jsLib && String(raw.jsLib).trim()) return true;
    const fields = ['exploreUrl', 'ruleExplore', 'ruleSearch', 'ruleBookInfo', 'ruleToc', 'ruleContent'];
    for (const f of fields) {
      const v = raw[f];
      if (v == null) continue;
      const text = typeof v === 'string' ? v : JSON.stringify(v);
      if (/(^|@)js\s*:/.test(text)) return true;
    }
    return false;
  }

  _emptyReason(idx, extra) {
    const s = this.sources[idx];
    if (!s) return '书源不存在';
    if (!s.channels.length) {
      if (this._jsSource(s)) return '这个源用 JS 脚本（jsLib/@js）生成发现页，抓不到内容';
      return '这个源没有配置发现/分类页（exploreUrl），只能搜索，不能浏览';
    }
    if (this._jsSource(s)) return '这个源的规则是 JS 脚本（@js），可能抓不到内容';
    return extra || '页面能打开，但按规则没解析到书（站点可能改版或需要 JS）';
  }

  /** 健康检查：真的抓一次分类页，回报「有没有内容 / 为什么没有」 */
  async probe(idx, page = 1) {
    const s = this.sources[idx];
    if (!s) return { index: idx, name: '', state: 'missing', msg: '书源不存在', count: 0, ms: 0 };
    const started = Date.now();
    let count = 0;
    try {
      const r = await this.category(String(idx), page, '');
      count = (r.list || []).length;
    } catch (e) {
      this._markError(idx, e.message, Date.now() - started);
    }
    if (count > 0) this._markOk(idx);
    else if (this.statusOf(idx).state === 'unknown') this._markEmpty(idx, this._emptyReason(idx), Date.now() - started);
    const st = this.statusOf(idx);
    return {
      index: idx, name: s.name, state: count ? 'ok' : st.state,
      msg: count ? '' : st.msg, count, ms: Date.now() - started,
    };
  }

  /* ── 书源体检结果（data/health.json） ──
   * 1 = 体检通过  0 = 没测过  -1 = 体检失败
   * 用来给分类排序：能用的排前面，用户点进去就不会一屏全空
   *
   * 注意：体检结果里带的是站点域名，不是书源下标。书源列表一重新排序（build-sources /
   * sort-sources 都会改顺序），下标就全错位了，照下标套等于把 A 的结论套到 B 头上。
   * 所以这里一律按「域名」匹配，域名对不上再按「书源名」兜一次，两边都对不上就当没测过。 */
  setHealth(map) {
    this._healthHost = {};
    this._healthName = {};
    if (!map || typeof map !== 'object') return this;
    for (const k of Object.keys(map)) {
      const v = map[k];
      const ok = healthVerdict(v);
      if (ok === null) continue;
      if (v && typeof v === 'object' && (v.host || v.name)) {
        const h = hostOf(v.host);
        if (h) this._healthHost[h] = ok;
        const n = String(v.name || '').trim();
        if (n) this._healthName[n] = ok;
      }
      // 只有裸 true/false、没有 host 的老格式：认不出是谁，宁可当没测过
    }
    return this;
  }

  healthState(idx) {
    const s = this.sources[idx];
    if (!s) return 0;
    const h = hostOf(s.url);
    if (h && this._healthHost && this._healthHost[h] !== undefined) return this._healthHost[h];
    const n = String(s.name || '').trim();
    if (n && this._healthName && this._healthName[n] !== undefined) return this._healthName[n];
    return 0;
  }

  /* 客户端传来的频道值五花八门：可能是地址、可能是频道标题、也可能是筛选参数。
   * 以前把筛选参数当频道去抓，整页必空。这里认不出来就返回 ''（走默认频道）。 */
  resolveChannel(idx, channel) {
    const s = this.sources[idx];
    const raw = String(channel == null ? '' : channel).trim();
    if (!s || !raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return 'https:' + raw;
    const hit = (s.channels || []).find((c) => c.title === raw);
    if (hit && hit.url && hit.url !== '/') return hit.url;
    if (raw.startsWith('/')) {
      const same = (s.channels || []).find((c) => c.url === raw);
      return same ? same.url : '';
    }
    if (/^\d+$/.test(raw)) {
      const c = (s.channels || [])[parseInt(raw, 10)];
      if (c && c.url && c.url !== '/') return c.url;
    }
    return '';
  }

  /* ── 缓存 ── */

  _remember(key, value, ttlMs) {
    this._cache.set(key, { at: Date.now(), ttl: ttlMs, value });
    if (this._cache.size > this._cacheMax) {
      const now = Date.now();
      for (const [k, v] of this._cache) if (now - v.at > v.ttl) this._cache.delete(k);
      while (this._cache.size > this._cacheMax) this._cache.delete(this._cache.keys().next().value);
    }
    return value;
  }

  _recall(key) {
    const hit = this._cache.get(key);
    if (!hit) return null;
    if (Date.now() - hit.at > hit.ttl) { this._cache.delete(key); return null; }
    return hit.value;
  }

  markFail(idx) {
    const cur = this._fail.get(idx) || { n: 0, until: 0 };
    cur.n += 1;
    cur.until = Date.now() + Math.min(30 * 60 * 1000, 60000 * Math.pow(2, Math.min(cur.n - 1, 5)));
    this._fail.set(idx, cur);
  }

  markOk(idx) {
    this._fail.delete(idx);
  }

  isDead(idx) {
    const f = this._fail.get(idx);
    return !!(f && f.until > Date.now() && f.n >= 3);
  }

  _putTitle(idx, url, name) {
    if (!url || !name) return;
    this._titles.set(idx + '|' + url, name);
    if (this._titles.size > 30000) {
      const drop = this._titles.size - 24000;
      let n = 0;
      for (const k of this._titles.keys()) { this._titles.delete(k); if (++n >= drop) break; }
    }
  }

  /* ── 元信息 ── */

  info() {
    return this.sources.map((s, i) => ({
      index: i,
      type_id: String(i),
      name: s.name,
      host: s.url,
      group: s.group,
      altHosts: s.altHosts,
      channels: s.channels.length,
      searchable: !!s.searchUrl,
      dead: this.isDead(i),
    }));
  }

  categories() {
    const max = this.opts.maxCategories > 0 ? this.opts.maxCategories : this.sources.length;
    const rows = [];
    for (let i = 0; i < this.sources.length; i++) {
      if (this.isDead(i)) continue;
      const s = this.sources[i];
      // 没有频道页的源放进「分类」里必然是空的（只能搜），不进分类列表
      if (!s.channels.length) continue;
      rows.push({ i, s, score: this._catScore(i) });
    }
    // 真出过内容的排最前，其次是体检通过的，没测过的中间，点了会空的垫底
    rows.sort((a, b) => (b.score - a.score) || (a.i - b.i));
    return rows.slice(0, max).map((r) => ({
      type_id: String(r.i),
      type_name: r.s.name,
      healthy: r.score > 0,
    }));
  }

  _catScore(i) {
    if (this._catFail.has(i)) return -2;
    if (this._catOk.has(i)) return 3;
    return Math.max(-1, Math.min(1, this.healthState(i)));
  }

  markCatOk(i) {
    this._catOk.add(i);
    this._catFail.delete(i);
  }

  markCatFail(i) {
    if (!this._catOk.has(i)) this._catFail.add(i);
  }

  /* 载入 tools/probe-category.js 的结果，让分类一上来就按可用性排好 */
  setCatHealth(map) {
    if (!map || typeof map !== 'object') return this;
    // 同样按下标不可靠：换成域名/名字 → 结论，再落到当前列表的下标上
    const byHost = {};
    const byName = {};
    for (const k of Object.keys(map)) {
      const v = map[k];
      const ok = healthVerdict(v);
      if (ok === null) continue;
      if (v && typeof v === 'object' && (v.host || v.name)) {
        const h = hostOf(v.host);
        if (h) byHost[h] = ok;
        const n = String(v.name || '').trim();
        if (n) byName[n] = ok;
      } else {
        const i = parseInt(k, 10);
        if (isFinite(i)) { if (ok > 0) this._catOk.add(i); else this._catFail.add(i); }
      }
    }
    this.sources.forEach((s, i) => {
      const h = hostOf(s.url);
      const n = String(s.name || '').trim();
      let ok;
      if (h && byHost[h] !== undefined) ok = byHost[h];
      else if (n && byName[n] !== undefined) ok = byName[n];
      if (ok === undefined) return;
      if (ok > 0) this._catOk.add(i);
      else if (!this._catOk.has(i)) this._catFail.add(i);
    });
    return this;
  }

  filters() {
    const out = {};
    for (let i = 0; i < this.sources.length; i++) {
      const s = this.sources[i];
      if (!s.channels.length) continue;
      out[String(i)] = [{
        key: 'channel',
        name: '频道',
        value: [{ n: '全部', v: '' }].concat(s.channels.map((c) => ({ n: c.title, v: c.url }))),
      }];
    }
    return out;
  }

  /* ── 分类内容 ── */

  async category(typeId, page = 1, channel = '') {
    const idx = parseInt(typeId, 10);
    const s = this.sources[idx];
    if (!s) return { list: [], page, pagecount: 1, total: 0 };
    const pg = Math.max(1, parseInt(page, 10) || 1);
    // 认不出来就当没传：绝不让客户端的筛选参数把整页打成空
    const ch = this.resolveChannel(idx, channel);

    if (ch) {
      const key = 'c:' + idx + ':' + ch + ':' + pg;
      const hit = this._recall(key);
      if (hit) return hit;
      let list = [];
      try {
        const arr = await withTimeout(s.explore(ch, pg), this.opts.sourceTimeout, []);
        list = (arr || []).map((b) => this.toVod(idx, b));
      } catch (e) { list = []; }
      if (list.length) { this.markOk(idx); this.markCatOk(idx); }
      else this.markCatFail(idx);
      return this._remember(key, this._pageOf(list.slice(0, this.opts.listLimit), pg), 120 * 1000);
    }

    if (!s.channels.length) {
      // 没有分类页的源只能搜，分类本来就给不出东西
      return { list: [], page: pg, pagecount: 1, total: 0 };
    }

    const real = s.channels.filter((c) => c.url && c.url !== '/' && c.url !== '');
    if (!real.length) return { list: [], page: pg, pagecount: 1, total: 0 };

    // 「全部 / 推荐 / 最新」这类频道信息量最大，排前面；但绝不能只用它们——
    // 有些源的「全部」频道本身是死的，多带几个频道并发抓，任一成功就有内容
    const named = real.filter((c) => /全部|所有|推荐|最新|热门|all/i.test(String(c.title || '')));
    const ordered = [];
    const pushCh = (c) => {
      if (c && c.url && ordered.indexOf(c) < 0) ordered.push(c);
    };
    named.slice(0, 2).forEach(pushCh);
    real.forEach(pushCh);
    const use = ordered.slice(0, 5);

    const key = 'c:' + idx + ':all:' + pg;
    const hit = this._recall(key);
    if (hit) return hit;

    const results = await mapLimit(use, this.opts.channelConcurrency, (c) =>
      withTimeout(s.explore(c.url, pg), this.opts.sourceTimeout, [])
    );
    const merged = [];
    const seen = new Set();
    for (const arr of results) {
      for (const b of arr || []) {
        if (!b || !b.bookUrl || seen.has(b.bookUrl)) continue;
        seen.add(b.bookUrl);
        merged.push(this.toVod(idx, b));
      }
    }
    if (!merged.length) {
      this.markFail(idx);
      this.markCatFail(idx);
    } else {
      this.markCatOk(idx);
    }
    return this._remember(key, this._pageOf(merged.slice(0, this.opts.listLimit), pg), 120 * 1000);
  }

  /* 分页信息按实际条数算，不再写死 999 页 / 9999 条 */
  _pageOf(list, pg) {
    const full = list.length >= this.opts.listLimit;
    return {
      list,
      page: pg,
      pagecount: full ? pg + 1 : pg,
      total: list.length,
    };
  }

  /* ── 搜索 ── */

  async search(keyword, opts = {}) {
    const cacheKey = 's:' + keyword + ':' + (opts.only || '');
    const cached = this._recall(cacheKey);
    if (cached && !opts.force) return cached;
    const limit = opts.limit || this.opts.listLimit;
    const only = opts.only;
    const budget = opts.budget || this.opts.searchBudget;
    const deadline = Date.now() + budget;

    const jobs = [];
    const slowJobs = [];
    this.sources.forEach((s, i) => {
      if (!s.searchUrl) return;
      if (only != null && only !== '' && String(only) !== String(i)) return;
      if (this.isDead(i)) return;
      (s.usesJsNet ? slowJobs : jobs).push(i);
    });
    jobs.push(...slowJobs);

    const out = [];
    const seen = new Set();
    let stop = false;

    await mapLimit(jobs, this.opts.searchConcurrency, async (i) => {
      if (stop || Date.now() > deadline) return;
      const s = this.sources[i];
      try {
        const list = await withTimeout(s.search(keyword, 1), this.opts.searchTimeout, []);
        if (list && list.length) {
          this.markOk(i);
          for (const b of list) {
            const v = this.toVod(i, b);
            const k = v.vod_name + '|' + (v.vod_actor || '');
            if (!v.vod_name || seen.has(k)) continue;
            seen.add(k);
            out.push(v);
          }
        }
      } catch (e) {
        this.markFail(i);
      }
      if (Date.now() > deadline) stop = true;
    });

    return this._remember(cacheKey, {
      list: out.slice(0, Math.max(limit * 2, 60)),
      total: out.length,
    }, 120 * 1000);
  }

  toVod(idx, b) {
    const vid = token(idx, b.bookUrl);
    this._bookNames.set(vid, { name: cleanName(b.name), author: cleanLine(b.author) });
    if (this._bookNames.size > 5000) this._bookNames.delete(this._bookNames.keys().next().value);
    return {
      vod_id: vid,
      vod_name: cleanName(b.name),
      vod_pic: b.coverUrl || '',
      vod_remarks: cleanLine(b.lastChapter || b.wordCount || '').slice(0, 40),
      vod_content: cleanIntro(b.intro),
      vod_actor: cleanLine(b.author).replace(/^作者[:：]/, ''),
      vod_area: cleanKind(b.kind),
      source: this.sources[idx] ? this.sources[idx].name : '',
      type_id: String(idx),
      type_name: this.sources[idx] ? this.sources[idx].name : '',
    };
  }

  /* ── 详情 ── */

  async detail(id) {
    const { idx, url } = parseToken(id);
    const s = this.sources[idx];
    if (!s || !url) throw new Error('书源无效或链接缺失');

    const key = 'd:' + id;
    const hit = this._recall(key);
    if (hit) return hit;

    const build = async () => {
      const known = this._bookNames.get(id) || {};
      const info = await s.bookInfo(url, { bookUrl: url, origin: s.name, name: known.name || '', author: known.author || '' });
      let chapters = await s.toc(info.tocUrls || info.tocUrl, info);
      // 只解出 1 章基本等于目录没抓到：拿详情页地址再兜一次
      if (!chapters || chapters.length <= 1) {
        try {
          const alt = await withTimeout(s.toc([url], info), this.opts.sourceTimeout, null);
          if (alt && alt.length > (chapters ? chapters.length : 0)) chapters = alt;
        } catch (e) { /* 兜底失败就算了，别把整条详情拖死 */ }
      }
      if (!chapters) chapters = [];
      const max = this.opts.maxChapters;
      const list = chapters.slice(0, max);
      // 章节名去掉整本共有的那截前缀（书名 / 站点导航），显示才干净
      const names = list.map((c, i) => cleanChapterName(c.name, i));
      const prefix = commonPrefixOf(names);
      const playUrl = list.map((c, i) => {
        let nm = names[i];
        if (prefix && nm.startsWith(prefix)) {
          nm = nm.slice(prefix.length).trim() || nm;
        }
        this._putTitle(idx, c.url, nm);
        return nm + '$' + token(idx, c.url);
      }).join('#');
      return {
        vod_id: id,
        vod_name: cleanName(info.name) || '未知书名',
        vod_pic: info.coverUrl || '',
        vod_content: cleanIntro(info.intro),
        vod_actor: cleanLine(info.author).replace(/^作者[:：]/, ''),
        vod_area: cleanKind(info.kind),
        vod_remarks: (cleanLine(info.lastChapter) || info.wordCount || '').slice(0, 60),
        vod_year: info.wordCount || '',
        vod_play_from: s.name || '阅读',
        vod_play_url: playUrl,
        chapter_count: list.length,
        chapters: list,
      };
    };

    const value = await withTimeout(build(), this.opts.detailTimeout, null);
    if (!value) {
      this.markFail(idx);
      throw new Error('详情获取超时');
    }
    this.markOk(idx);
    return this._remember(key, value, 10 * 60 * 1000);
  }

  async chapters(id) {
    const d = await this.detail(id);
    return d.chapters || [];
  }

  async chapter(flag) {
    const d = await this.chapterDetail(flag);
    return d.content;
  }

  async chapterDetail(flag) {
    const { idx, url } = parseToken(flag);
    const s = this.sources[idx];
    if (!s || !url) throw new Error('章节标记无效');

    const key = 'ch:' + flag;
    const hit = this._recall(key);
    if (hit) return hit;

    const title = this._titles.get(idx + '|' + url) || '';
    const r = await withTimeout(s.content(url, null, { title, url }), this.opts.chapterTimeout, null);
    if (!r || !r.content) {
      this.markFail(idx);
      throw new Error('正文获取失败');
    }
    this.markOk(idx);
    const value = {
      title: title || cleanChapterTitle(r.title, ''),
      content: r.content,
      chars: r.content.length,
    };
    return this._remember(key, value, 30 * 60 * 1000);
  }
}

module.exports = { Engine, token, parseToken, cleanChapterName, cleanName, mapLimit, withTimeout };
