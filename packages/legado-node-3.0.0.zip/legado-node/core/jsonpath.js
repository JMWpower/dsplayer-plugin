'use strict';
/*
 * JSONPath 子集
 *   $.data.list[*].name / $..name / $.a[0] / $.a[0:2] / $['a']['b']
 *   [?(@.type=='x')] / [?(@.n>3 && @.ok)] / [*]
 */

function parsePath(path) {
  const s = String(path || '$').trim();
  const tokens = [];
  let i = 0;
  if (s[0] === '$') i = 1;
  while (i < s.length) {
    const ch = s[i];
    if (ch !== '.' && ch !== '[') {
      // ..list 这种：deep 之后紧跟裸名字
      let name = '';
      while (i < s.length && !'.[]'.includes(s[i])) { name += s[i]; i++; }
      if (name === '*') tokens.push({ type: 'wild' });
      else if (name) tokens.push({ type: 'key', key: name });
      continue;
    }
    if (ch === '.') {
      if (s[i + 1] === '.') { tokens.push({ type: 'deep' }); i += 2; continue; }
      i++;
      let name = '';
      while (i < s.length && !'.[]'.includes(s[i])) { name += s[i]; i++; }
      if (name === '*') tokens.push({ type: 'wild' });
      else if (name) tokens.push({ type: 'key', key: name });
      continue;
    }
    if (ch === '[') {
      let depth = 1;
      let j = i + 1;
      let quote = null;
      for (; j < s.length; j++) {
        const c = s[j];
        if (quote) { if (c === quote) quote = null; continue; }
        if (c === '"' || c === "'") { quote = c; continue; }
        if (c === '[') depth++;
        if (c === ']') { depth--; if (depth === 0) break; }
      }
      const body = s.slice(i + 1, j).trim();
      i = j + 1;
      if (!body) { tokens.push({ type: 'wild' }); continue; }
      if (body === '*') { tokens.push({ type: 'wild' }); continue; }
      if (body.startsWith('?')) {
        tokens.push({ type: 'filter', expr: body.replace(/^\?\s*\(?/, '').replace(/\)$/, '') });
        continue;
      }
      if (body.startsWith('(') && body.endsWith(')')) {
        tokens.push({ type: 'filter', expr: body.slice(1, -1) });
        continue;
      }
      if (/^-?\d+$/.test(body)) { tokens.push({ type: 'index', index: parseInt(body, 10) }); continue; }
      if (/^-?\d*:-?\d*$/.test(body)) {
        const [a, b] = body.split(':');
        tokens.push({ type: 'slice', from: a === '' ? 0 : parseInt(a, 10), to: b === '' ? Infinity : parseInt(b, 10) });
        continue;
      }
      if (/^-?\d+(,-?\d+)+$/.test(body)) {
        tokens.push({ type: 'indexList', list: body.split(',').map((x) => parseInt(x, 10)) });
        continue;
      }
      if ((body[0] === '"' && body.endsWith('"')) || (body[0] === "'" && body.endsWith("'"))) {
        tokens.push({ type: 'key', key: body.slice(1, -1) });
        continue;
      }
      tokens.push({ type: 'key', key: body });
      continue;
    }
    i++;
  }
  return tokens;
}

function collectDeep(node, out) {
  if (node == null) return;
  if (Array.isArray(node)) {
    for (const v of node) { out.push(v); collectDeep(v, out); }
  } else if (typeof node === 'object') {
    for (const k of Object.keys(node)) { out.push(node[k]); collectDeep(node[k], out); }
  }
}

function getKey(node, key) {
  if (node == null) return undefined;
  if (Array.isArray(node)) return node.map((x) => (x == null ? undefined : x[key]));
  if (typeof node === 'object') return node[key];
  return undefined;
}

function evalFilter(node, expr) {
  const list = Array.isArray(node) ? node : [node];
  return list.filter((item) => evalExpr(expr, item));
}

function evalExpr(expr, item) {
  try {
    const src = String(expr)
      .replace(/(^|[^A-Za-z0-9_.])@(?=\.|\b)/g, '$1__it')
      .replace(/==/g, '===')
      .replace(/!==/g, '!==');
    // eslint-disable-next-line no-new-func
    const fn = new Function('__it', 'return (' + src + ');');
    return fn(item);
  } catch (e) {
    return false;
  }
}

/**
 * 查询
 * @returns {Array} 命中的值（对象或标量）
 */
function query(data, path) {
  let tokens;
  try { tokens = parsePath(path); } catch (e) { return []; }
  let nodes = [data];
  for (const t of tokens) {
    const next = [];
    for (const node of nodes) {
      switch (t.type) {
        case 'key': {
          const v = getKey(node, t.key);
          if (v !== undefined) next.push(v);
          break;
        }
        case 'wild': {
          if (Array.isArray(node)) next.push(...node);
          else if (node && typeof node === 'object') for (const k of Object.keys(node)) next.push(node[k]);
          break;
        }
        case 'deep': {
          const out = [];
          collectDeep(node, out);
          next.push(...out);
          break;
        }
        case 'index': {
          if (Array.isArray(node)) {
            const i = t.index < 0 ? node.length + t.index : t.index;
            if (i >= 0 && i < node.length) next.push(node[i]);
          }
          break;
        }
        case 'indexList': {
          if (Array.isArray(node)) {
            for (const raw of t.list) {
              const i = raw < 0 ? node.length + raw : raw;
              if (i >= 0 && i < node.length) next.push(node[i]);
            }
          }
          break;
        }
        case 'slice': {
          if (Array.isArray(node)) {
            const to = t.to === Infinity ? node.length : t.to;
            next.push(...node.slice(t.from, to));
          }
          break;
        }
        case 'filter': {
          const hits = evalFilter(node, t.expr);
          next.push(...hits);
          break;
        }
        default: break;
      }
    }
    nodes = next;
    if (!nodes.length) break;
  }
  // 最后把数组摊平一层（$.data.list 这种没写 [*] 的也能直接当列表用）
  const flat = [];
  for (const n of nodes) {
    if (Array.isArray(n)) flat.push(...n);
    else flat.push(n);
  }
  return flat.filter((x) => x !== undefined && x !== null);
}

/** 取第一个结果并转字符串 */
function queryString(data, path) {
  const r = query(data, path);
  if (!r.length) return '';
  const v = r[0];
  if (v == null) return '';
  if (typeof v === 'object') {
    try { return JSON.stringify(v); } catch (e) { return ''; }
  }
  return String(v);
}

function isJSONPath(rule) {
  const s = String(rule || '').trim();
  if (!s) return false;
  if (/^@json:/i.test(s)) return true;
  return s.startsWith('$.') || s === '$' || s.startsWith('$[') || s.startsWith('$..');
}

module.exports = { query, queryString, isJSONPath, parsePath };
