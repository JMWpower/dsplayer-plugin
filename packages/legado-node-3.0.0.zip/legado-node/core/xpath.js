'use strict';
/*
 * XPath 子集引擎
 * 覆盖书源里实际出现的写法：
 *   //div[@class="book"]/a[1]/@href
 *   //*[@id="list"]//li[position()>1]
 *   //p[contains(text(),"更新")]/text()
 *   //div[not(@class)] | //span[last()]/text()
 *   following-sibling:: / preceding-sibling:: / parent:: / ancestor:: / descendant:: / self::
 *   函数：text() node() last() position() contains() starts-with() not() normalize-space() string()
 */

const { Element } = require('./html');

/* ───────── 词法 ───────── */

function splitSteps(path) {
  const steps = [];
  let i = 0;
  const s = String(path).trim();
  let pendingDesc = false;
  if (s.startsWith('//')) { pendingDesc = true; i = 2; } else if (s.startsWith('/')) { i = 1; }

  while (i < s.length) {
    // 跳过空白
    while (i < s.length && /\s/.test(s[i])) i++;
    if (i >= s.length) break;
    let depth = 0;
    let quote = null;
    let buf = '';
    let desc = pendingDesc;
    pendingDesc = false;
    while (i < s.length) {
      const ch = s[i];
      if (quote) { buf += ch; if (ch === quote) quote = null; i++; continue; }
      if (ch === '"' || ch === "'") { quote = ch; buf += ch; i++; continue; }
      if (ch === '[' || ch === '(') depth++;
      if (ch === ']' || ch === ')') depth--;
      if (depth === 0 && ch === '/') {
        if (s[i + 1] === '/') { pendingDesc = true; i += 2; } else { i++; }
        break;
      }
      if (depth === 0 && ch === '|') {
        // 联合表达式交给上层切成多条路径
        break;
      }
      buf += ch;
      i++;
    }
    if (buf.trim()) steps.push({ desc, raw: buf.trim() });
  }
  return steps;
}

function parseStep(raw) {
  let axis = null;
  let expr = raw;
  const axisMatch = /^([a-zA-Z-]+)::/.exec(expr);
  if (axisMatch) {
    axis = axisMatch[1].toLowerCase();
    expr = expr.slice(axisMatch[0].length);
  }
  // 谓词
  const preds = [];
  let nodeTest = expr;
  const firstBracket = expr.indexOf('[');
  if (firstBracket >= 0) {
    nodeTest = expr.slice(0, firstBracket);
    let i = firstBracket;
    while (i < expr.length) {
      if (expr[i] !== '[') { i++; continue; }
      let depth = 0;
      let quote = null;
      let j = i;
      for (; j < expr.length; j++) {
        const ch = expr[j];
        if (quote) { if (ch === quote) quote = null; continue; }
        if (ch === '"' || ch === "'") { quote = ch; continue; }
        if (ch === '[') depth++;
        if (ch === ']') { depth--; if (depth === 0) break; }
      }
      preds.push(expr.slice(i + 1, j).trim());
      i = j + 1;
    }
  }
  nodeTest = nodeTest.trim();
  let kind = 'tag';
  let name = nodeTest;
  if (nodeTest === '*') kind = 'any';
  else if (nodeTest === 'text()') kind = 'text';
  else if (nodeTest === 'node()') kind = 'node';
  else if (nodeTest === '.') kind = 'self';
  else if (nodeTest === '..') { kind = 'tag'; name = '..'; }
  else if (nodeTest.startsWith('@')) { kind = 'attr'; name = nodeTest.slice(1); }
  else if (nodeTest === 'string()') kind = 'text';
  else if (nodeTest.endsWith('()')) { kind = 'text'; }
  else kind = 'tag';
  return { axis, kind, name, preds };
}

/* ───────── 谓词求值 ───────── */

function elementChildren(node) {
  if (!node || !node.children) return [];
  return node.children.filter((c) => c.type === 'tag');
}

function stringOf(v) {
  if (v == null) return '';
  if (typeof v === 'string') return v;
  if (v.type === 'text') return v.text;
  if (v.tag) return v.textContent;
  return String(v);
}

/** 简易表达式求值：支持 and/or、比较、函数、数字 */
function evalPredicate(expr, node, ctx) {
  const tokens = tokenize(expr);
  const parser = { i: 0, tokens, node, ctx };
  try {
    const v = parseOr(parser);
    return v;
  } catch (e) {
    return false;
  }
}

function tokenize(s) {
  const out = [];
  let i = 0;
  while (i < s.length) {
    const ch = s[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === '"' || ch === "'") {
      const end = s.indexOf(ch, i + 1);
      out.push({ t: 'str', v: s.slice(i + 1, end < 0 ? s.length : end) });
      i = end < 0 ? s.length : end + 1;
      continue;
    }
    if ('()[],'.indexOf(ch) >= 0) { out.push({ t: ch }); i++; continue; }
    const op = /^(>=|<=|!=|=|>|<|\+|-)/.exec(s.slice(i));
    if (op) { out.push({ t: 'op', v: op[1] }); i += op[1].length; continue; }
    const num = /^-?\d+(\.\d+)?/.exec(s.slice(i));
    if (num) { out.push({ t: 'num', v: parseFloat(num[0]) }); i += num[0].length; continue; }
    const ident = /^[A-Za-z_][A-Za-z0-9_.:-]*/.exec(s.slice(i));
    if (ident) { out.push({ t: 'id', v: ident[0] }); i += ident[0].length; continue; }
    if (ch === '@') { out.push({ t: '@' }); i++; continue; }
    if (ch === '.') { out.push({ t: 'id', v: '.' }); i++; continue; }
    if (ch === '*') { out.push({ t: 'id', v: '*' }); i++; continue; }
    i++;
  }
  return out;
}

function parseOr(p) {
  let left = parseAnd(p);
  while (p.tokens[p.i] && p.tokens[p.i].t === 'id' && /^or$/i.test(p.tokens[p.i].v)) {
    p.i++;
    const right = parseAnd(p);
    left = truthy(left) || truthy(right);
  }
  return left;
}

function parseAnd(p) {
  let left = parseCmp(p);
  while (p.tokens[p.i] && p.tokens[p.i].t === 'id' && /^and$/i.test(p.tokens[p.i].v)) {
    p.i++;
    const right = parseCmp(p);
    left = truthy(left) && truthy(right);
  }
  return left;
}

function parseCmp(p) {
  let left = parsePrimary(p);
  const tk = p.tokens[p.i];
  if (tk && tk.t === 'op') {
    p.i++;
    const right = parsePrimary(p);
    const a = scalar(left);
    const b = scalar(right);
    const na = parseFloat(a);
    const nb = parseFloat(b);
    const numeric = isFinite(na) && isFinite(nb) && String(a).trim() !== '' && String(b).trim() !== '';
    switch (tk.v) {
      case '=': return numeric ? na === nb : String(a) === String(b);
      case '!=': return numeric ? na !== nb : String(a) !== String(b);
      case '>': return numeric ? na > nb : String(a) > String(b);
      case '<': return numeric ? na < nb : String(a) < String(b);
      case '>=': return numeric ? na >= nb : String(a) >= String(b);
      case '<=': return numeric ? na <= nb : String(a) <= String(b);
      default: return false;
    }
  }
  return left;
}

function parsePrimary(p) {
  const tk = p.tokens[p.i];
  if (!tk) return '';
  if (tk.t === 'num') { p.i++; return tk.v; }
  if (tk.t === 'str') { p.i++; return tk.v; }
  if (tk.t === '(') {
    p.i++;
    const v = parseOr(p);
    if (p.tokens[p.i] && p.tokens[p.i].t === ')') p.i++;
    return v;
  }
  if (tk.t === '(') return '';
  if (tk.t === '@') {
    p.i++;
    const name = p.tokens[p.i] && p.tokens[p.i].t === 'id' ? p.tokens[p.i].v : '';
    if (p.tokens[p.i] && p.tokens[p.i].t === 'id') p.i++;
    if (!p.node || !p.node.attr) return '';
    const v = p.node.attr(name);
    return v === undefined ? '' : v;
  }
  if (tk.t === 'id') {
    p.i++;
    const name = tk.v;
    if (p.tokens[p.i] && p.tokens[p.i].t === '(') {
      p.i++;
      const args = [];
      while (p.tokens[p.i] && p.tokens[p.i].t !== ')') {
        args.push(parseOr(p));
        if (p.tokens[p.i] && p.tokens[p.i].t === ',') p.i++;
      }
      if (p.tokens[p.i]) p.i++;
      return callFn(name, args, p);
    }
    if (name === '.') return p.node;
    if (name === '*') return p.node;
    return name;
  }
  p.i++;
  return '';
}

function callFn(name, args, p) {
  const node = p.node;
  const fn = String(name).toLowerCase();
  const s0 = scalar(args[0]);
  switch (fn) {
    case 'text': return node ? node.textContent : '';
    case 'node': return node;
    case 'last': return p.ctx && p.ctx.siblings ? p.ctx.siblings.length : 1;
    case 'position': return p.ctx && p.ctx.position != null ? p.ctx.position : 1;
    case 'contains': return String(s0).indexOf(String(scalar(args[1]))) >= 0;
    case 'starts-with': return String(s0).startsWith(String(scalar(args[1])));
    case 'ends-with': return String(s0).endsWith(String(scalar(args[1])));
    case 'not': return !truthy(args[0]);
    case 'normalize-space': return String(s0).replace(/\s+/g, ' ').trim();
    case 'string': return String(s0);
    case 'concat': return args.map((a) => String(scalar(a))).join('');
    case 'substring-before': {
      const s = String(s0); const t = String(scalar(args[1])); const i = s.indexOf(t); return i < 0 ? '' : s.slice(0, i);
    }
    case 'substring-after': {
      const s = String(s0); const t = String(scalar(args[1])); const i = s.indexOf(t); return i < 0 ? '' : s.slice(i + t.length);
    }
    case 'translate': {
      const s = String(s0); const from = String(scalar(args[1])); const to = String(scalar(args[2]));
      let out = '';
      for (const ch of s) {
        const k = from.indexOf(ch);
        out += k < 0 ? ch : (to[k] || '');
      }
      return out;
    }
    case 'count': return Array.isArray(args[0]) ? args[0].length : 1;
    case 'name': return node && node.tag ? node.tag : '';
    default: return '';
  }
}

function scalar(v) {
  if (v == null) return '';
  if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') return v;
  if (Array.isArray(v)) return v.length ? scalar(v[0]) : '';
  if (v.type === 'text') return v.text;
  if (v.tag) return v.textContent;
  return String(v);
}

function truthy(v) {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'number') return v !== 0;
  if (Array.isArray(v)) return v.length > 0;
  if (v && v.tag) return true;
  return String(v || '').length > 0;
}

/* ───────── 主求值 ───────── */

function collectByAxis(node, step) {
  const axis = step.axis || (step.desc ? 'descendant-or-self' : 'child');
  const out = [];
  switch (axis) {
    case 'descendant-or-self': {
      // 自身 + 全部后代（由调用方再按 nodeTest 过滤，保持 XPath 语义）
      out.push(node);
      walk(node, out);
      break;
    }
    case 'descendant': {
      walk(node, out);
      break;
    }
    case 'self':
      out.push(node);
      break;
    case 'parent': {
      if (node.parent && node.parent.tag !== '#document') out.push(node.parent);
      else if (node.parent) out.push(node.parent);
      break;
    }
    case 'ancestor': {
      let p = node.parent;
      while (p) { out.push(p); p = p.parent; }
      break;
    }
    case 'following-sibling': {
      if (node.parent) {
        const sibs = elementChildren(node.parent);
        const i = sibs.indexOf(node);
        for (let k = i + 1; k < sibs.length; k++) out.push(sibs[k]);
      }
      break;
    }
    case 'preceding-sibling': {
      if (node.parent) {
        const sibs = elementChildren(node.parent);
        const i = sibs.indexOf(node);
        for (let k = 0; k < i; k++) out.push(sibs[k]);
      }
      break;
    }
    case 'attribute': {
      if (node.attrs) for (const a of Object.keys(node.attrs)) out.push({ __attr: a, __node: node });
      break;
    }
    case 'child':
    default:
      out.push(...elementChildren(node));
      break;
  }
  return out;
}

function walk(node, out) {
  for (const c of elementChildren(node)) {
    out.push(c);
    walk(c, out);
  }
}

function applyPredicates(list, preds, base) {
  let arr = list;
  for (const pred of preds) {
    const p = pred.trim();
    if (!p) continue;
    if (/^\d+$/.test(p)) {
      const n = parseInt(p, 10);
      arr = arr.filter((_, idx) => idx === n - 1);
      continue;
    }
    if (/^last\(\)$/i.test(p)) {
      arr = arr.length ? [arr[arr.length - 1]] : [];
      continue;
    }
    arr = arr.filter((node, idx) => {
      const ctx = { position: idx + 1, siblings: arr };
      return truthy(evalPredicate(p, node, ctx));
    });
  }
  return arr;
}

/**
 * 执行 XPath
 * @returns {{elements: Element[], values: string[]}}
 */
function evalXPath(path, root) {
  const parts = splitPathUnion(path);
  const elements = [];
  const values = [];
  for (const one of parts) {
    const steps = splitSteps(one);
    let current = [root];
    let resultIsValue = false;
    for (const raw of steps) {
      const step = parseStep(raw.raw);
      step.desc = raw.desc;

      // 属性：直接从当前节点取 attr
      if (step.kind === 'attr') {
        const vals = [];
        for (const node of current) {
          if (!node || typeof node === 'string') continue;
          const v = node.attr ? node.attr(step.name) : undefined;
          if (v !== undefined && v !== null && v !== '') vals.push(String(v));
        }
        current = vals;
        resultIsValue = true;
        if (!current.length) break;
        continue;
      }

      // 文本节点
      if (step.kind === 'text') {
        const vals = [];
        for (const node of current) {
          if (typeof node === 'string') { if (node.trim()) vals.push(node.trim()); continue; }
          const t = node.textContent == null ? '' : String(node.textContent).trim();
          if (t) vals.push(t);
        }
        current = vals;
        resultIsValue = true;
        if (!current.length) break;
        continue;
      }

      const next = [];
      for (const node of current) {
        if (!node || typeof node === 'string') continue;
        const cands = collectByAxis(node, step).filter((c) => matchNodeTest(c, step, node));
        // 谓词按每个父节点分别算（XPath 语义：a[1] 是每个父节点下的第一个）
        next.push(...applyPredicates(cands, step.preds, node));
      }
      const filtered = next;
      current = filtered.filter((n) => n && n.tag);
      resultIsValue = false;
      if (!current.length) break;
    }
    if (resultIsValue) values.push(...current.map((v) => String(v)));
    else elements.push(...current.filter((n) => n && n.tag));
  }
  return { elements, values };
}

function matchNodeTest(c, step) {
  if (c && c.__attr) return step.kind === 'attr' && step.name === '*';
  if (typeof c === 'string') return true;
  if (step.kind === 'any' || step.kind === 'descendant-or-self') return true;
  if (step.kind === 'text' || step.kind === 'node') {
    // text() 需要节点本身，交给后续取 textContent
    return true;
  }
  if (step.kind === 'self') return true;
  if (!c.tag || c.tag === '#document') return false;
  if (step.name === '..') return false;
  return String(c.tag).toLowerCase() === String(step.name).toLowerCase();
}

function splitPathUnion(path) {
  const out = [];
  let depth = 0;
  let quote = null;
  let buf = '';
  for (const ch of String(path)) {
    if (quote) { buf += ch; if (ch === quote) quote = null; continue; }
    if (ch === '"' || ch === "'") { quote = ch; buf += ch; continue; }
    if (ch === '[' || ch === '(') depth++;
    if (ch === ']' || ch === ')') depth--;
    if (ch === '|' && depth === 0) { out.push(buf); buf = ''; continue; }
    buf += ch;
  }
  if (buf.trim()) out.push(buf);
  return out.length ? out : [String(path)];
}

function isXPath(rule) {
  const s = String(rule || '').trim();
  if (!s) return false;
  if (s.startsWith('//')) return true;
  if (s.startsWith('/') && !s.startsWith('//')) return true;
  if (/@XPath:/i.test(s)) return true;
  if (/^(\(|\*\/)/.test(s) && /\[\s*@/.test(s)) return true;
  return false;
}

module.exports = { evalXPath, isXPath };
