'use strict';
/*
 * Legado 书源 JS 运行时（Node 版）
 *
 * 为什么要自己写：乐读书源的 JS 是同步跑的（java.ajax 直接返回字符串），
 * Node 主线程不能同步发请求，所以这里做了三件事：
 *   1. 同步 HTTP —— 子进程请求（core/sync-http.js），主进程阻塞等待结果
 *   2. 完整 java.* / source.* / book.* / chapter.* / cookie.* / cache.* / result 对象
 *   3. vm 沙箱 —— 给每段脚本独立作用域 + 超时保护
 *
 * 覆盖书源里出现频率最高的 API：
 *   java.ajax / post / connect / getString / getStringList / getElement(s)
 *   java.md5Encode / base64* / hex* / encodeURI / timeFormat / toNumChapter / t2s
 *   java.aesBase64DecodeToString / createSymmetricCrypto / digestHex / HMacHex
 *   java.put/get / setContent / getContent / log / toast / longToast
 *   source.getKey / getVariable / setVariable / bookSourceUrl ...
 *   cookie.getKey / getCookie / setCookie / removeCookie
 *   cache.get / put / getFromMemory / putMemory
 *   book.* / chapter.* / result.* / org.jsoup.Jsoup.parse()
 */

let vm = null;
let path = null;
let crypto = null;
let spawnSync = null;
try { vm = require('vm'); } catch (e) { vm = null; }
try { path = require('path'); } catch (e) { path = null; }
try { crypto = require('crypto'); } catch (e) { crypto = null; }
try { ({ spawnSync } = require('child_process')); } catch (e) { spawnSync = null; }
const { CookieJar } = require('./http');
const { parseHTML, selectAll, makeElements } = require('./dom');

// 打包成单文件（DsPlayer 的 drpy-node）时同步请求不可用，这里做降级
let SYNC_HTTP = '';
try { SYNC_HTTP = path ? path.join(__dirname, 'sync-http.js') : ''; } catch (e) { SYNC_HTTP = ''; }

const HAS_CRYPTO = !!crypto;
function hash(algorithm, data, enc) {
  if (!HAS_CRYPTO) return '';
  return crypto.createHash(algorithm).update(String(data)).digest(enc || 'hex');
}
const DEFAULT_JS_TIMEOUT = 12000;

/* ─────────── 繁简映射（由 opencc 抽取的常用字表）─────────── */

let T2S_MAP = null;
function t2sMap() {
  if (T2S_MAP) return T2S_MAP;
  T2S_MAP = new Map();
  try {
    const raw = require('fs').readFileSync(path.join(__dirname, 't2s.txt'), 'utf8');
    for (let i = 0; i + 1 < raw.length; i += 2) T2S_MAP.set(raw[i], raw[i + 1]);
  } catch (e) { /* 没表就原样返回 */ }
  return T2S_MAP;
}

function toSimplified(str) {
  const map = t2sMap();
  if (!map.size) return String(str == null ? '' : str);
  let out = '';
  for (const ch of String(str == null ? '' : str)) out += map.get(ch) || ch;
  return out;
}

function toTraditional(str) {
  const map = t2sMap();
  if (!map.size) return String(str == null ? '' : str);
  const rev = new Map();
  for (const [k, v] of map) if (!rev.has(v)) rev.set(v, k);
  let out = '';
  for (const ch of String(str == null ? '' : str)) out += rev.get(ch) || ch;
  return out;
}

/* ─────────── 中文数字 → 阿拉伯数字 ─────────── */

const CN_NUM = { 零: 0, 〇: 0, 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
const CN_UNIT = { 十: 10, 百: 100, 千: 1000, 万: 10000, 亿: 100000000 };

function cnToNumber(s) {
  let total = 0;
  let section = 0;
  let number = 0;
  for (const ch of String(s)) {
    if (ch in CN_NUM) {
      number = CN_NUM[ch];
    } else if (ch in CN_UNIT) {
      const unit = CN_UNIT[ch];
      if (unit >= 10000) {
        total = (total + section + number) * unit;
        section = 0;
      } else {
        section += (number || 1) * unit;
      }
      number = 0;
    } else {
      continue;
    }
  }
  return total + section + number;
}

function toNumChapter(str) {
  const s = String(str == null ? '' : str);
  const digits = /(\d+)/.exec(s);
  if (digits) return parseInt(digits[1], 10);
  const cn = /([零〇一二两三四五六七八九十百千万亿]+)[章回节话]?/.exec(s);
  if (cn) return cnToNumber(cn[1]);
  return 0;
}

/* ─────────── 同步 HTTP ─────────── */

function remainingBudget(state, want) {
  if (!state) return want;
  if (!state.jsBudgetEnd) state.jsBudgetEnd = Date.now() + (state.jsBudgetMs || 6000);
  const left = state.jsBudgetEnd - Date.now();
  if (left <= 200) return 0;
  return Math.min(want, left);
}

function syncRequest(opts, state) {
  // 打包成单文件（DsPlayer）时同步请求会卡死事件循环，直接禁用
  if (typeof __DISABLE_SYNC_HTTP !== 'undefined' && __DISABLE_SYNC_HTTP) {
    return { ok: false, status: 0, url: opts.url, text: '', error: '当前环境不支持同步请求' };
  }
  if (!spawnSync || !SYNC_HTTP) {
    return { ok: false, status: 0, url: opts.url, text: '', error: '当前环境不支持同步请求（java.ajax）' };
  }
  const budget = remainingBudget(state, Math.min(Math.max(opts.timeout || 12000, 1000), 45000));
  if (!budget) return { ok: false, status: 0, url: opts.url, text: '', error: '本次请求预算已用完' };
  const payload = JSON.stringify({
    url: opts.url,
    method: opts.method || 'GET',
    headers: opts.headers || {},
    body: opts.body,
    timeout: budget,
    charset: opts.charset,
    cookie: opts.cookie || '',
    referer: opts.referer,
    retry: opts.retry === undefined ? 1 : opts.retry,
  });
  try {
    const res = spawnSync(process.execPath, [SYNC_HTTP], {
      input: payload,
      maxBuffer: 64 * 1024 * 1024,
      timeout: budget + 8000,
      encoding: 'utf8',
      windowsHide: true,
    });
    if (!res || !res.stdout) {
      return { ok: false, status: 0, url: opts.url, text: '', error: (res && res.error && res.error.message) || '同步请求无返回' };
    }
    const data = JSON.parse(res.stdout);
    return data;
  } catch (e) {
    return { ok: false, status: 0, url: opts.url, text: '', error: e.message || '同步请求失败' };
  }
}

/* ─────────── 参数解析：java.ajax(url, header) / "url,{json}" ─────────── */

function parseAjaxArg(arg, extra) {
  let url = '';
  let opts = {};
  if (arg && typeof arg === 'object') {
    url = arg.url || arg.URL || '';
    opts = Object.assign({}, arg);
    delete opts.url;
  } else {
    const s = String(arg == null ? '' : arg);
    const brace = s.indexOf(',{');
    if (brace > 0) {
      url = s.slice(0, brace).trim();
      try {
        opts = JSON.parse(s.slice(brace + 1));
      } catch (e) {
        try {
          const fixed = JSON.parse(s.slice(brace + 1));
          opts = fixed;
        } catch (e2) { opts = {}; }
      }
    } else {
      url = s.trim();
    }
  }
  if (extra && typeof extra === 'object') {
    // java.ajax(url, {"headers":{...}})
    if (extra.headers || extra.method || extra.body || extra.charset) opts = Object.assign({}, opts, extra);
  } else if (typeof extra === 'string' && extra.trim().startsWith('{')) {
    try { opts = Object.assign({}, opts, JSON.parse(extra)); } catch (e) { /* ignore */ }
  }
  return { url, opts };
}

function normHeaders(h) {
  const out = {};
  if (!h) return out;
  if (typeof h === 'string') {
    for (const line of h.split(/\r?\n/)) {
      const i = line.indexOf(':');
      if (i > 0) out[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    }
    return out;
  }
  if (typeof h === 'object') {
    for (const k of Object.keys(h)) out[k] = String(h[k]);
  }
  return out;
}

/* ─────────── 状态 ─────────── */

class RuntimeState {
  constructor(opts) {
    this.src = opts.src || '';
    this.root = null;
    this.baseUrl = opts.baseUrl || '';
    this.host = opts.host || opts.baseUrl || '';
    this.key = opts.key || '';
    this.page = opts.page || 1;
    this.title = opts.title || '';
    this.jar = opts.jar || new CookieJar();
    this.vars = opts.vars || new Map();          // source.getVariable
    this.bookVars = opts.bookVars || new Map();  // book.getVariable
    this.book = opts.book || null;               // {name, author, bookUrl, tocUrl, kind, intro, coverUrl}
    this.chapter = opts.chapter || null;         // {title, url, index, ...}
    this.source = opts.source || {};             // 原始书源 JSON
    this.cache = opts.cache || new Map();        // 内存缓存
    this.headers = opts.headers || {};
    this.timeout = opts.timeout || 12000;
    this.logs = [];
    // 单次任务里 JS 同步请求的总预算（毫秒），防止个别源把主线程卡死
    this.jsBudgetMs = opts.jsBudgetMs || 6000;
    this.jsBudgetEnd = 0;
    this.dirtyVars = false;
    this.contentOverride = null;
    this.code = opts.code || '';                 // 书源码（source.getKey）
    this.onVarsChange = opts.onVarsChange || null;
  }

  doc() {
    if (!this.root) this.root = parseHTML(this.src || '');
    return this.root;
  }

  setContent(html) {
    this.src = String(html == null ? '' : html);
    this.root = null;
    this.contentOverride = this.src;
  }

  current() {
    return this.contentOverride != null ? this.contentOverride : this.src;
  }
}

/* ─────────── 构建沙箱 ─────────── */

function buildSandbox(state) {
  const rule = require('./rule'); // 延迟到调用时，避免循环依赖

  const evalStr = (r, el) => {
    if (r == null || r === '') return '';
    try {
      const ctx = rule.makeContext({
        html: state.current(), baseUrl: state.baseUrl, host: state.host,
        key: state.key, page: state.page, cookie: state.jar.header(state.baseUrl),
        state, root: el || undefined, title: state.title,
      });
      return rule.evalString(String(r), ctx, el || ctx.root);
    } catch (e) { return ''; }
  };

  const evalEls = (r, el) => {
    if (r == null || r === '') return [];
    try {
      const ctx = rule.makeContext({
        html: state.current(), baseUrl: state.baseUrl, host: state.host,
        key: state.key, page: state.page, state, root: el || undefined,
      });
      return rule.evalElements(String(r), ctx, el || ctx.root);
    } catch (e) { return []; }
  };

  function doRequest(u, options) {
    const { url, opts } = parseAjaxArg(u, options);
    const full = /^https?:\/\//i.test(url) ? url : resolveUrl(url, state.baseUrl);
    const headers = Object.assign({}, state.headers, normHeaders(opts.headers));
    let body = opts.body;
    const method = String(opts.method || (body ? 'POST' : 'GET')).toUpperCase();
    if (body && typeof body === 'object') {
      if (!headers['Content-Type'] && !headers['content-type']) {
        headers['Content-Type'] = 'application/x-www-form-urlencoded';
      }
      body = rule.applyTemplate
        ? String(body)
        : String(body);
    }
    const res = syncRequest({
      url: full,
      method,
      headers,
      body: body == null ? undefined : String(body),
      timeout: opts.timeout || state.timeout,
      charset: opts.charset,
      cookie: state.jar.header(full),
      referer: headers.Referer || headers.referer || state.baseUrl,
    }, state);
    if (res && Array.isArray(res.setCookie)) {
      for (const c of res.setCookie) state.jar.setFromString(full, c);
    }
    if (res && res.text) state.jar && state.jar.header(full);
    return res;
  }

  const java = {
    ajax: (u, options) => {
      const res = doRequest(u, options);
      if (!res || res.error) {
        state.logs.push('[ajax] ' + (res && res.error ? res.error : '失败') + ' ' + (typeof u === 'string' ? u.slice(0, 120) : ''));
        return '';
      }
      return res.text || '';
    },
    ajaxAll: (urls) => (Array.isArray(urls) ? urls.map((u) => java.ajax(u)) : []),
    connect: (u, options) => {
      const res = doRequest(u, options);
      return {
        body: () => (res && res.text) || '',
        code: () => (res && res.status) || 0,
        url: () => (res && res.url) || '',
        headers: () => (res && res.headers) || {},
        toString: () => (res && res.text) || '',
      };
    },
    post: (u, body, headers) => {
      const res = doRequest(u, { method: 'POST', body, headers });
      return (res && res.text) || '';
    },
    get: (key) => (state.vars.has(key) ? state.vars.get(key) : ''),
    put: (key, value) => {
      state.vars.set(String(key), value);
      state.dirtyVars = true;
      return value;
    },
    remove: (key) => { state.vars.delete(String(key)); state.dirtyVars = true; },
    getString: (r, el) => evalStr(r, el),
    getStringList: (r, el) => {
      const v = evalStr(r, el);
      return v ? v.split('\n') : [];
    },
    getElement: (r, el) => {
      const list = evalEls(r, el);
      return list.length ? list[0] : null;
    },
    getElements: (r, el) => makeElements(evalEls(r, el)),
    setContent: (html) => { state.setContent(html); return html; },
    getContent: () => state.current(),
    log: (...args) => { state.logs.push(args.map(fmt).join(' ')); },
    toast: (...args) => { state.logs.push(args.map(fmt).join(' ')); },
    longToast: (...args) => { state.logs.push(args.map(fmt).join(' ')); },
    base64Encode: (s) => Buffer.from(String(s == null ? '' : s), 'utf8').toString('base64'),
    base64Decode: (s) => Buffer.from(String(s == null ? '' : s), 'base64').toString('utf8'),
    base64DecodeToByteArray: (s) => Array.from(Buffer.from(String(s == null ? '' : s), 'base64')),
    base64DecodeToByteArrayUTF8: (s) => Array.from(Buffer.from(String(s == null ? '' : s), 'base64')),
    hexEncodeToString: (s) => Buffer.from(String(s == null ? '' : s), 'utf8').toString('hex'),
    hexDecodeToString: (s) => Buffer.from(String(s == null ? '' : s).replace(/[^0-9a-fA-F]/g, ''), 'hex').toString('utf8'),
    strToBytes: (s) => Array.from(Buffer.from(String(s == null ? '' : s), 'utf8')),
    bytesToStr: (arr) => Buffer.from(arr || []).toString('utf8'),
    md5Encode: (s) => hash('md5', String(s == null ? '' : s), 'hex'),
    md5Encode16: (s) => hash('md5', String(s == null ? '' : s), 'hex').slice(8, 24),
    digestHex: (algo, s) => {
      try { return hash(String(algo || 'sha256').toLowerCase().replace('-', ''), String(s), 'hex'); } catch (e) { return ''; }
    },
    digestBase64: (algo, s) => {
      try { return hash(String(algo || 'sha256').toLowerCase().replace('-', ''), String(s), 'base64'); } catch (e) { return ''; }
    },
    HMacHex: (algo, data, key) => {
      try {
        if (!HAS_CRYPTO) return '';
        return crypto.createHmac(String(algo || 'sha256').toLowerCase(), String(key)).update(String(data)).digest('hex');
      } catch (e) { return ''; }
    },
    HMacBase64: (algo, data, key) => {
      try {
        if (!HAS_CRYPTO) return '';
        return crypto.createHmac(String(algo || 'sha256').toLowerCase(), String(key)).update(String(data)).digest('base64');
      } catch (e) { return ''; }
    },
    timeFormat: (ts) => formatDate(ts),
    timeFormatUTC: (ts) => formatDateUTC(ts),
    encodeURI: (s, enc) => {
      try { return encodeURIComponent(String(s == null ? '' : s)); } catch (e) { return ''; }
    },
    encodeBase64: (s) => Buffer.from(String(s == null ? '' : s), 'utf8').toString('base64'),
    toNumChapter,
    t2s: (s) => toSimplified(s),
    s2t: (s) => toTraditional(s),
    htmlFormat: (s) => String(s == null ? '' : s).split(/\r?\n/).filter((x) => x.trim())
      .map((x) => '<p>' + x.trim() + '</p>').join('\n'),
    strFormat: (fmt, ...args) => {
      let i = 0;
      return String(fmt == null ? '' : fmt).replace(/%[sd]/g, () => String(args[i++] == null ? '' : args[i - 1]));
    },
    randomUUID: () => (HAS_CRYPTO ? crypto.randomUUID() : String(Date.now()) + Math.random()),
    random: (n) => Math.random() * (n || 1),
    refreshTocUrl: () => '',
    webView: () => '',
    startBrowser: () => '',
    startBrowserAwait: () => '',
    getCookie: (u) => state.jar.header(u || state.baseUrl),
    setCookie: (u, v) => { state.jar.setFromString(u || state.baseUrl, v); },
    createSymmetricCrypto: (transformation, key, iv) => makeCrypto(transformation, key, iv),
    aesBase64DecodeToString: (data, key, transformation, iv) => {
      try {
        return decryptBase64(data, key, transformation || 'AES/CBC/PKCS5Padding', iv);
      } catch (e) { return ''; }
    },
    aesDecodeToString: (data, key, transformation, iv) => {
      try { return decryptBase64(data, key, transformation || 'AES/CBC/PKCS5Padding', iv); } catch (e) { return ''; }
    },
    desBase64DecodeToString: (data, key, transformation, iv) => {
      try { return decryptBase64(data, key, transformation || 'DES/CBC/PKCS5Padding', iv); } catch (e) { return ''; }
    },
    java: {},
    util: {
      Arrays: { asList: (...a) => a, toString: (a) => String(a) },
      HashMap: function HashMap() { const m = new Map(); this.put = (k, v) => m.set(k, v); this.get = (k) => m.get(k); },
      Base64: {
        encodeToString: (s) => Buffer.from(String(s)).toString('base64'),
        decode: (s) => Buffer.from(String(s), 'base64').toString('utf8'),
      },
    },
    lang: {
      String: { valueOf: (v) => String(v) },
      Long: { parseLong: (v) => parseInt(v, 10) },
      Integer: { parseInt: (v) => parseInt(v, 10) },
    },
    security: {
      MessageDigest: {
        getInstance: (algo) => ({
          digest: (s) => {
            if (!HAS_CRYPTO) return [];
            return Array.from(crypto.createHash(String(algo).toLowerCase().replace('-', ''))
              .update(String(s)).digest());
          },
        }),
      },
    },
  };
  java.java = java;

  const sourceObj = {
    bookSourceUrl: state.source.bookSourceUrl || '',
    bookSourceName: state.source.bookSourceName || '',
    bookSourceGroup: state.source.bookSourceGroup || '',
    bookSourceComment: state.source.bookSourceComment || '',
    bookSourceType: state.source.bookSourceType || 0,
    loginUrl: state.source.loginUrl || '',
    header: state.source.header || '',
    getKey: () => state.source.bookSourceUrl || '',
    getVariable: (k) => (k == null ? mapToObj(state.vars) : (state.vars.has(k) ? state.vars.get(k) : '')),
    setVariable: (k, v) => { state.vars.set(k, v); state.dirtyVars = true; return v; },
    getVariableMap: () => mapToObj(state.vars),
    getLoginInfo: () => '',
    getLoginInfoMap: () => ({}),
    getHeaderMap: () => state.headers,
    getTag: () => '',
    getName: () => state.source.bookSourceName || '',
  };

  const bookObj = state.book ? {
    name: state.book.name || '',
    author: state.book.author || '',
    kind: state.book.kind || '',
    intro: state.book.intro || '',
    bookUrl: state.book.bookUrl || '',
    tocUrl: state.book.tocUrl || '',
    coverUrl: state.book.coverUrl || '',
    origin: state.book.origin || '',
    type: state.book.type || 0,
    variableMap: mapToObj(state.bookVars),
    getVariable: (k) => (k == null ? mapToObj(state.bookVars) : (state.bookVars.has(k) ? state.bookVars.get(k) : '')),
    putVariable: (k, v) => { state.bookVars.set(k, v); return v; },
    setReverseToc: () => {},
    getUrl: () => state.book.bookUrl || '',
    toString: () => state.book.name || '',
  } : {};

  const chapterObj = state.chapter ? {
    title: state.chapter.title || '',
    url: state.chapter.url || '',
    baseUrl: state.chapter.url || '',
    index: state.chapter.index || 0,
    isVip: !!state.chapter.isVip,
    isVolume: !!state.chapter.isVolume,
    getVariable: () => '',
    putVariable: () => {},
    toString: () => state.chapter.title || '',
  } : {};

  const cookieObj = {
    getCookie: (u) => state.jar.header(u || state.baseUrl),
    getKey: (u, k) => state.jar.get(u || state.baseUrl, k),
    setCookie: (u, v) => { state.jar.setFromString(u || state.baseUrl, v); return v; },
    removeCookie: (u) => { state.jar.remove(u || state.baseUrl); return ''; },
    replaceCookie: (u, v) => {
      state.jar.remove(u || state.baseUrl);
      state.jar.setFromString(u || state.baseUrl, v);
      return v;
    },
    cookieList: () => state.jar.all(),
  };

  const cacheObj = {
    get: (k) => (state.cache.has('c:' + k) ? state.cache.get('c:' + k) : null),
    put: (k, v) => { state.cache.set('c:' + k, v); return v; },
    delete: (k) => { state.cache.delete('c:' + k); },
    getFromMemory: (k) => (state.cache.has('m:' + k) ? state.cache.get('m:' + k) : null),
    putMemory: (k, v) => { state.cache.set('m:' + k, v); return v; },
  };

  const Jsoup = {
    parse: (html) => {
      const root = parseHTML(String(html == null ? '' : html));
      return makeJsoupDoc(root);
    },
    parseBodyFragment: (html) => makeJsoupDoc(parseHTML(String(html || ''))),
  };

  const sandbox = {
    java,
    source: sourceObj,
    book: bookObj,
    chapter: chapterObj,
    cookie: cookieObj,
    cache: cacheObj,
    baseUrl: state.baseUrl,
    baseURL: state.baseUrl,
    host: state.host,
    key: state.key,
    page: state.page,
    title: state.title,
    result: '',
    src: state.current(),
    cookieStr: state.jar.header(state.baseUrl),
    org: { jsoup: { Jsoup } },
    Packages: { org: { jsoup: { Jsoup } } },
    console: { log: java.log, error: java.log, warn: java.log, info: java.log },
  };
  sandbox.globalThis = sandbox;
  return sandbox;
}

function makeJsoupDoc(root) {
  const doc = {
    select: (sel) => makeElements(selectAll(root, String(sel))),
    selectFirst: (sel) => {
      const arr = selectAll(root, String(sel));
      return arr.length ? arr[0] : null;
    },
    text: () => root.textContent.trim(),
    html: () => root.innerHTML,
    body: () => ({ text: () => root.textContent.trim(), html: () => root.innerHTML, select: doc.select }),
    toString: () => root.innerHTML,
    __root: root,
  };
  return doc;
}

function mapToObj(map) {
  const o = {};
  for (const [k, v] of map) o[k] = v;
  return o;
}

function fmt(v) {
  if (v == null) return 'null';
  if (typeof v === 'object') {
    try { return JSON.stringify(v); } catch (e) { return String(v); }
  }
  return String(v);
}

function pad2(n) { return n < 10 ? '0' + n : String(n); }

function formatDate(ts) {
  const d = ts ? new Date(Number(ts)) : new Date();
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' '
    + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
}

function formatDateUTC(ts) {
  const d = ts ? new Date(Number(ts)) : new Date();
  return d.getUTCFullYear() + '-' + pad2(d.getUTCMonth() + 1) + '-' + pad2(d.getUTCDate()) + ' '
    + pad2(d.getUTCHours()) + ':' + pad2(d.getUTCMinutes()) + ':' + pad2(d.getUTCSeconds());
}

/* ─────────── 加解密 ─────────── */

function normAlgo(transformation) {
  const t = String(transformation || 'AES/CBC/PKCS5Padding').toUpperCase();
  const parts = t.split('/');
  let algo = (parts[0] || 'AES').toLowerCase();
  let mode = (parts[1] || 'CBC').toLowerCase();
  const pad = (parts[2] || 'PKCS5Padding').toLowerCase();
  if (algo === 'aes') algo = 'aes-128-cbc';
  if (mode === 'ecb') algo = algo.replace('-cbc', '-ecb');
  let keyLen = 128;
  return { algo, mode, pad, keyLen };
}

function buildCipher(algoName, key, iv, mode, decrypt) {
  const keyBuf = Buffer.isBuffer(key) ? key : Buffer.from(String(key), 'utf8');
  let name = algoName;
  if (name === 'aes-128-cbc' || name === 'aes-128-ecb') {
    const bits = keyBuf.length === 32 ? '256' : keyBuf.length === 24 ? '192' : '128';
    name = 'aes-' + bits + '-' + (name.endsWith('ecb') ? 'ecb' : 'cbc');
  }
  const opts = {};
  if (!name.endsWith('-ecb')) {
    const ivBuf = Buffer.isBuffer(iv) ? iv : Buffer.from(String(iv || ''), 'utf8');
    opts.iv = ivBuf;
  }
  if (decrypt) return crypto.createDecipheriv(name, keyBuf, opts.iv || null);
  return crypto.createCipheriv(name, keyBuf, opts.iv || null);
}

function makeCrypto(transformation, key, iv) {
  const t = String(transformation || 'AES/CBC/PKCS5Padding');
  const { algo } = normAlgo(t);
  return {
    encryptHex: (data) => {
      const c = buildCipher(algo, key, iv, 'cbc', false);
      return Buffer.concat([c.update(String(data), 'utf8'), c.final()]).toString('hex');
    },
    encryptBase64: (data) => {
      const c = buildCipher(algo, key, iv, 'cbc', false);
      return Buffer.concat([c.update(String(data), 'utf8'), c.final()]).toString('base64');
    },
    decryptStr: (data, isHex) => {
      const c = buildCipher(algo, key, iv, 'cbc', true);
      const buf = isHex ? Buffer.from(String(data), 'hex') : Buffer.from(String(data), 'base64');
      return Buffer.concat([c.update(buf), c.final()]).toString('utf8');
    },
  };
}

function decryptBase64(data, key, transformation, iv) {
  const { algo } = normAlgo(transformation);
  const c = buildCipher(algo, key, iv, 'cbc', true);
  const buf = Buffer.from(String(data || ''), 'base64');
  return Buffer.concat([c.update(buf), c.final()]).toString('utf8');
}

/* ─────────── 工具 ─────────── */

function resolveUrl(url, base) {
  const u = String(url || '').trim();
  if (!u) return base || '';
  if (/^https?:\/\//i.test(u)) return u;
  if (u.startsWith('//')) return 'https:' + u;
  try { return new URL(u, base || undefined).toString(); } catch (e) { return u; }
}

/* ─────────── 执行 ─────────── */

/**
 * 跑一段书源 JS
 * @param {string} code
 * @param {RuntimeState} state
 * @param {*} resultValue 传给脚本的 result
 * @returns {string|Array|object} 按脚本返回值
 */
function runScript(code, state, resultValue, opts = {}) {
  const sandbox = buildSandbox(state);
  sandbox.result = wrapResult(resultValue);
  sandbox.src = state.current();
  let src = String(code == null ? '' : code).trim();
  // <js>…</js> 写法
  const jsTag = /^<js>([\s\S]*?)<\/js>$/i.exec(src);
  if (jsTag) src = jsTag[1];
  const timeout = opts.timeout || DEFAULT_JS_TIMEOUT;
  try {
    if (vm) {
      const ctx = vm.createContext(sandbox);
      const out = vm.runInContext(src, ctx, { timeout, displayErrors: true });
      return unwrapResult(out);
    }
    // 没有 vm 模块时的降级：new Function（无超时保护）
    const names = Object.keys(sandbox);
    const fn = new Function(...names, 'var __out = (function(){' + src + '})(); return __out;');
    const out = fn(...names.map((n) => sandbox[n]));
    return unwrapResult(out);
  } catch (e) {
    state.logs.push('[js] ' + (e && e.message ? e.message : '脚本执行失败'));
    return '';
  }
}

function wrapResult(v) {
  if (v == null) return '';
  if (Array.isArray(v)) {
    if (v.length && v[0] && v[0].tag) return makeElements(v);
    return v;
  }
  return v;
}

function unwrapResult(out) {
  if (out == null) return '';
  if (Array.isArray(out)) {
    if (out.length && out[0] && out[0].tag) {
      return out.map((e) => e.textContent.trim());
    }
    return out;
  }
  if (typeof out === 'object') {
    if (out.tag) return out.textContent.trim();
    if (out.__elements) return out.__elements;
    return out;
  }
  return String(out);
}

module.exports = {
  RuntimeState, runScript, toNumChapter, toSimplified, toTraditional,
  cnToNumber, makeElements, resolveUrl,
};
