'use strict';
/*
 * Legado 规则求值引擎（v3）
 *
 * 支持的写法：
 *   CSS 选择器 / class.xxx / id.xxx / tag.xxx / text.xxx / children
 *   XPath：//div[@class="a"]/a/@href / @XPath:...
 *   JSONPath：$.data.list[*].name / @json:...
 *   @text @html @textNodes @ownText @all @href @src @任意属性
 *   `@` 链式、`&&` 并列、`||` 兜底、`%%` 无分隔并列、`<$>` 交替
 *   `##正则##替换`（支持 $1、多段、空替换=删除）
 *   索引：`.0` `[-1]` `[0]` `[0,2]` `[0:2]` `.1:3` `[!0]`（排除）
 *   `-` 前缀倒序
 *   `@put:{key:rule}` / `@get:{key}` 书源内变量
 *   `{{ }}` 模板：任意 JS 表达式 + `@@规则` + `$.json`
 *   `js:` / `@js:` / `<js>…</js>`：完整 JS 运行时（见 jsrt.js）
 *   `@@` 前缀：强制从文档根开始选（忽略当前节点作用域）
 */

const { parseHTML, selectAll, findByText, selectorFromLegado, makeElements } = require('./dom');
const xpath = require('./xpath');
const jsonpath = require('./jsonpath');

const OUTPUT_TOKENS = new Set(['text', 'textNodes', 'ownText', 'html', 'all', 'textHtml', 'outerHtml']);

function collapse(s) {
  return String(s == null ? '' : s).replace(/[\s\u00a0\u3000]+/g, ' ').trim();
}

/* ───────────── 顶层切分（不碰引号/括号里的分隔符）───────────── */

function splitTopLevel(str, sep) {
  const out = [];
  let depth = 0;
  let quote = null;
  let buf = '';
  const s = String(str);
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) {
      buf += ch;
      if (ch === '\\') { buf += s[i + 1] || ''; i++; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; buf += ch; continue; }
    if (ch === '(' || ch === '[' || ch === '{') depth++;
    if (ch === ')' || ch === ']' || ch === '}') depth--;
    if (depth <= 0 && s.startsWith(sep, i)) {
      out.push(buf);
      buf = '';
      i += sep.length - 1;
      continue;
    }
    buf += ch;
  }
  out.push(buf);
  return out;
}

function hasTop(str, sep) {
  return splitTopLevel(str, sep).length > 1;
}

/* ───────────── 替换段 ───────────── */

function splitReplace(rule) {
  const parts = splitTopLevel(rule, '##');
  if (parts.length === 1) return { main: rule, replaces: [] };
  const main = parts.shift();
  const replaces = [];
  for (let i = 0; i < parts.length; i += 2) {
    const pattern = parts[i];
    const replacement = i + 1 < parts.length ? parts[i + 1] : '';
    if (pattern === '') continue;
    replaces.push([pattern, replacement]);
  }
  return { main, replaces };
}

function applyReplaces(str, replaces) {
  if (!replaces.length) return str;
  let out = String(str == null ? '' : str);
  for (const [pattern, replacement] of replaces) {
    let re = null;
    try {
      re = new RegExp(pattern, 'g');
    } catch (e) {
      re = null;
    }
    if (re) {
      out = out.replace(re, replacement.replace(/\$(\d+)/g, '$$$1'));
    } else {
      try { out = out.split(pattern).join(replacement); } catch (e2) { /* ignore */ }
    }
  }
  return out;
}

/* ───────────── 索引 ───────────── */

function extractIndex(token) {
  let rest = token;
  let spec = null;
  let m0 = /!(-?\d+(?::\d+)?(?:,-?\d+)*)$/.exec(token);
  if (m0 && !/\[!\d/.test(token)) {
    return { rest: token.slice(0, m0.index), index: { at: parseInt(m0[1], 10), negate: true } };
  }
  let m = /\[([!\-0-9\s,:]+)\]$/.exec(token);
  if (m) {
    spec = m[1];
    rest = token.slice(0, m.index);
  } else {
    m = /\.(-?\d+(?::\d+)?(?:,-?\d+)*)$/.exec(token);
    if (m && !/^\.[a-zA-Z#*[]/.test(m[0])) {
      spec = m[1];
      rest = token.slice(0, m.index);
    }
  }
  if (spec === null) return { rest, index: null };
  const negate = spec.trim().startsWith('!');
  const body = negate ? spec.trim().slice(1) : spec.trim();

  let index = null;
  if (body.indexOf(':') >= 0) {
    const [a, b] = body.split(':');
    const from = parseInt(a, 10);
    const to = parseInt(b, 10);
    if (isFinite(from) && isFinite(to)) index = { from, to };
    else if (isFinite(from)) index = { from };
    else index = null;
  } else if (body.indexOf(',') >= 0) {
    index = { list: body.split(',').map((x) => parseInt(x, 10)).filter((x) => isFinite(x)) };
  } else {
    const n = parseInt(body, 10);
    if (isFinite(n)) index = { at: n };
  }
  if (index && negate) index.negate = true;
  return { rest, index };
}

function applyIndex(list, index) {
  if (!index || !list.length) return list;
  const pick = (i) => (i < 0 ? list.length + i : i);
  if (index.negate) {
    const drop = new Set();
    if (index.list) index.list.forEach((i) => drop.add(pick(i)));
    else if (index.at !== undefined) drop.add(pick(index.at));
    else if (index.from !== undefined) {
      const to = index.to === undefined ? list.length - 1 : pick(index.to);
      for (let k = pick(index.from); k <= to; k++) drop.add(k);
    }
    return list.filter((_, i) => !drop.has(i));
  }
  if (index.list) return index.list.map(pick).map((i) => list[i]).filter(Boolean);
  if (index.at !== undefined) {
    const el = list[pick(index.at)];
    return el ? [el] : [];
  }
  const from = index.from >= 0 ? index.from : Math.max(0, list.length + index.from);
  if (index.to === undefined) return list.slice(from);
  const to = index.to >= 0 ? index.to : list.length + index.to;
  return list.slice(from, to + 1);
}

/* ───────────── JSON 作用域 ───────────── */

function jsonItem(value) {
  return { __jsonItem: true, value, textContent: jsonToText(value), attr: () => undefined, children: [] };
}

function jsonToText(v) {
  if (v == null) return '';
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  try { return JSON.stringify(v); } catch (e) { return ''; }
}

/** 当前内容是不是 JSON（接口型书源很多） */
function isJsonContent(ctx) {
  if (ctx._isJson !== undefined && ctx._jsonSrc2 === ctx.src) return ctx._isJson;
  const content = (ctx.src && String(ctx.src).trim()) ? String(ctx.src).trim()
    : (ctx.state ? String(ctx.state.current()).trim() : '');
  let ok = false;
  if (content && (content[0] === '{' || content[0] === '[')) {
    try { JSON.parse(content); ok = true; } catch (e) { ok = false; }
  }
  ctx._jsonSrc2 = ctx.src;
  ctx._isJson = ok;
  return ok;
}

/** 长得像 JSON 路径的规则（接口源里常直接写 data[*] / authorName） */
function looksJsonPath(rule) {
  const s = String(rule || '').trim();
  if (!s) return false;
  if (s.startsWith('$')) return true;
  if (/[\s<>=~^|@#]/.test(s)) return false;
  if (s.includes('//') || s.includes('::')) return false;
  return /^[A-Za-z_][\w$]*(\([^)]*\))?(\[[^\]]*\])?(\.[A-Za-z_$][\w$]*(\[[^\]]*\])?)*$/.test(s);
}

function jsonData(ctx, scopeEl) {
  if (scopeEl && scopeEl.__jsonItem) return scopeEl.value;
  if (Array.isArray(scopeEl) && scopeEl.length && scopeEl[0] && scopeEl[0].__jsonItem) return scopeEl[0].value;
  const content = (ctx.src && String(ctx.src).trim()) ? ctx.src
    : (ctx.state ? ctx.state.current() : '');
  if (ctx._jsonParsed !== undefined && ctx._jsonSrc === content) return ctx._jsonParsed;
  let data = null;
  try { data = JSON.parse(content); } catch (e) { data = null; }
  ctx._jsonSrc = content;
  ctx._jsonParsed = data;
  return data;
}

/* ───────────── 上下文 ───────────── */

function makeContext(opts) {
  const html = opts.html || '';
  let root = opts.root;
  if (!root) {
    if (opts.state && opts.state._root) root = opts.state._root;
    else root = typeof html === 'string' ? parseHTML(html) : html;
  }
  const ctx = {
    root,
    src: typeof html === 'string' ? html : (opts.state ? opts.state.current() : ''),
    baseUrl: opts.baseUrl || '',
    host: opts.host || '',
    key: opts.key || '',
    page: opts.page || 1,
    cookie: opts.cookie || '',
    vars: opts.vars || {},
    state: opts.state || null,
    title: opts.title || '',
    book: opts.book || {},
  };
  return ctx;
}

function scopedRoot(ctx, scopeEl) {
  if (scopeEl == null) return ctx.root;
  return scopeEl;
}

/* ───────────── JS ───────────── */

function getState(ctx) {
  if (ctx.state) return ctx.state;
  // 没有 state 时造个轻量壳，保证 java.* 至少不炸
  const { RuntimeState } = require('./jsrt');
  ctx.state = new RuntimeState({
    src: ctx.src, baseUrl: ctx.baseUrl, host: ctx.host, key: ctx.key, page: ctx.page,
    vars: new Map(), cache: new Map(),
  });
  ctx.state.root = ctx.root;
  return ctx.state;
}

function runJs(code, ctx, resultValue) {
  const jsrt = require('./jsrt');
  const state = getState(ctx);
  if (!state.root) state.root = ctx.root;
  if (!state.src) state.src = ctx.src;
  const out = jsrt.runScript(code, state, resultValue);
  return out;
}

/* ───────────── 模板 {{ }} ───────────── */

function evalTemplate(str, ctx, scopeEl) {
  const s = String(str);
  let out = '';
  let i = 0;
  while (i < s.length) {
    const start = s.indexOf('{{', i);
    if (start < 0) { out += s.slice(i); break; }
    out += s.slice(i, start);
    const end = s.indexOf('}}', start + 2);
    if (end < 0) { out += s.slice(start); break; }
    const expr = s.slice(start + 2, end).trim();
    out += evalTemplateExpr(expr, ctx, scopeEl);
    i = end + 2;
  }
  return out;
}

function evalTemplateExpr(exprRaw, ctx, scopeEl) {
  let expr = String(exprRaw || '').trim();
  if (!expr) return '';
  // @@ 规则：从文档根开始
  if (expr.startsWith('@@')) {
    const rest = expr.slice(1); // 保留一个 @ 交给链式解析？不：把 @@ 当根作用域标记
    return evalString(rest.replace(/^@/, ''), ctx, ctx.root);
  }
  // $.json 路径（当前内容为 JSON，可能作用在列表项上）
  if (jsonpath.isJSONPath(expr)) {
    const data = jsonData(ctx, scopeEl);
    if (data === null || data === undefined) return '';
    const segs = splitTopLevel(expr.replace(/^@json:/i, ''), '##');
    return applyReplaces(jsonpath.queryString(data, segs[0]), splitReplace(expr).replaces);
  }
  // 先当 JS 表达式
  const jsOut = runJs('(' + expr + ')', ctx, '');
  if (jsOut !== '' && jsOut !== undefined) return String(jsOut);
  // 再当规则
  try {
    const v = evalString(expr, ctx, scopeEl);
    if (v) return v;
  } catch (e) { /* ignore */ }
  // 最后当成普通变量名
  if (/^[a-zA-Z_$][\w$]*$/.test(expr)) {
    const st = ctx.state;
    if (st && st.vars && st.vars.has(expr)) return String(st.vars.get(expr));
    if (expr === 'baseUrl') return ctx.baseUrl;
    if (expr === 'key') return ctx.key;
    if (expr === 'page') return String(ctx.page);
  }
  return '';
}

/** 内嵌 @get / @put 的字符串替换 */
function substituteVars(str, ctx, scopeEl) {
  let out = String(str);
  let guard = 0;
  while (guard++ < 20) {
    const putAt = out.indexOf('@put:{');
    const getAt = out.indexOf('@get:{');
    if (putAt < 0 && getAt < 0) break;
    const usePut = putAt >= 0 && (getAt < 0 || putAt < getAt);
    const start = usePut ? putAt : getAt;
    const open = start + (usePut ? 5 : 5);
    // 找到配对的右花括号
    let depth = 1;
    let i = open + 1;
    for (; i < out.length; i++) {
      if (out[i] === '{') depth++;
      if (out[i] === '}') { depth--; if (depth === 0) break; }
    }
    const body = out.slice(open + 1, i);
    let value = '';
    if (usePut) {
      const kv = splitTopLevel(body, ':');
      const name = (kv[0] || '').trim();
      const sub = kv.slice(1).join(':').trim();
      try { value = evalString(sub, ctx, scopeEl); } catch (e) { value = ''; }
      if (ctx.state && ctx.state.vars && name) { ctx.state.vars.set(name, value); ctx.state.dirtyVars = true; }
    } else {
      const name = (body.split(':')[0] || '').trim();
      value = ctx.state && ctx.state.vars ? (ctx.state.vars.get(name) || '') : '';
    }
    out = out.slice(0, start) + String(value == null ? '' : value) + out.slice(i + 1);
  }
  return out;
}

/* ───────────── 元素取值 ───────────── */

function elementsTo(accessor, elements) {
  const out = [];
  for (const el of elements) {
    if (typeof el === 'string') { if (el) out.push(el); continue; }
    switch (accessor) {
      case 'text': out.push(collapse(el.textContent)); break;
      case 'ownText': {
        let s = '';
        for (const c of el.children) if (c.type === 'text') s += c.text;
        out.push(collapse(s));
        break;
      }
      case 'textNodes': {
        const arr = [];
        const walk = (n) => {
          for (const c of n.children) {
            if (c.type === 'text') { const t = collapse(c.text); if (t) arr.push(t); }
            else walk(c);
          }
        };
        walk(el);
        out.push(arr.join('\n'));
        break;
      }
      case 'html':
      case 'all':
      case 'textHtml': out.push(el.innerHTML); break;
      case 'outerHtml': out.push(el.outerHTML); break;
      default: out.push('');
    }
  }
  return out.filter((x) => x !== '');
}

function attrOf(elements, name) {
  const out = [];
  for (const el of elements) {
    if (typeof el === 'string') continue;
    if (el.__attr) continue;
    const v = el.attr ? el.attr(name) : undefined;
    if (v !== undefined && v !== '') out.push(v);
  }
  return out;
}

/* ───────────── 单段选择 ───────────── */

function selectPart(elements, part, ctx) {
  const { rest, index } = extractIndex(part);
  let token = rest.trim();
  if (!token) return applyIndex(elements, index);

  // @css: / @XPath: 前缀（@ 已被链式切开，这里只剩 css: / XPath:）
  const pref = /^(css|xpath|json):/i.exec(token);
  if (pref) {
    token = token.slice(pref[0].length).trim();
    if (!token) return applyIndex(elements, index);
  }
  if (/^@?XPath:/i.test(token)) token = token.replace(/^@?XPath:/i, '').trim();
  if (/^@?css:/i.test(token)) token = token.replace(/^@?css:/i, '').trim();

  // @get / @put 变量
  if (/^@?get:\{/.test(token)) {
    const key = /\{([^}]*)\}/.exec(token);
    const name = key ? key[1].split(':')[0].trim() : '';
    const st = ctx.state;
    const val = st && st.vars ? st.vars.get(name) : '';
    return val == null ? [] : [String(val)];
  }
  if (/^@?put:\{/.test(token)) {
    const body = /\{([\s\S]*)\}/.exec(token);
    if (body) {
      const kv = splitTopLevel(body[1], ':');
      const name = (kv[0] || '').trim();
      const valRule = kv.slice(1).join(':').trim();
      let val = '';
      try { val = evalString(valRule, ctx, elements.length === 1 ? elements[0] : undefined); } catch (e) { val = ''; }
      const st = ctx.state;
      if (st && st.vars && name) { st.vars.set(name, val); st.dirtyVars = true; }
    }
    return [];
  }

  // children 语法
  if (token === 'children' || token.startsWith('children.')) {
    const sub = token === 'children' ? '' : token.slice(9);
    const picked = [];
    for (const el of elements) {
      if (typeof el === 'string') continue;
      let kids = el.children.filter((c) => c.type === 'tag');
      if (sub) kids = selectPart(makeElements(kids), sub, ctx);
      picked.push(...kids);
    }
    return applyIndex(picked, index);
  }

  // XPath
  if (xpath.isXPath(token)) {
    const picked = [];
    for (const el of elements) {
      if (typeof el === 'string') continue;
      const r = xpath.evalXPath(token, el);
      picked.push(...r.elements);
      if (r.values.length) picked.push(...r.values);
    }
    return applyIndex(picked, index);
  }

  const mapped = selectorFromLegado(token);
  if (mapped && typeof mapped === 'object' && mapped.text != null) {
    const picked = [];
    for (const el of elements) {
      if (typeof el === 'string') continue;
      picked.push(...findByText(el, mapped.text));
    }
    return applyIndex(picked, index);
  }

  const selector = typeof mapped === 'string' ? mapped : token;
  const picked = [];
  for (const el of elements) {
    if (typeof el === 'string') continue;
    try { picked.push(...selectAll(el, selector)); } catch (e) { /* 选择器不合法就跳过 */ }
  }
  return applyIndex(picked, index);
}

/* ───────────── 链式求值 ───────────── */

function splitChain(rule) {
  const parts = [];
  let buf = '';
  let inJs = false;
  let depth = 0;
  let quote = null;
  for (let i = 0; i < rule.length; i++) {
    const ch = rule[i];
    if (quote) { buf += ch; if (ch === quote) quote = null; continue; }
    if (ch === '"' || ch === "'") { quote = ch; buf += ch; continue; }
    if (ch === '(' || ch === '[' || ch === '{') depth++;
    if (ch === ')' || ch === ']' || ch === '}') depth--;
    if (!inJs && ch === '@' && depth === 0) {
      parts.push(buf);
      buf = '';
      continue;
    }
    buf += ch;
    if (buf.trimEnd().endsWith('js:') && !inJs) inJs = true;
  }
  parts.push(buf);
  return parts;
}

function evalMain(rule, ctx, scopeEl) {
  let str = String(rule);
  if (!str.trim()) return '';

  // @@ 前缀：强制从文档根开始（忽略当前节点作用域）
  if (str.startsWith('@@')) {
    return evalMain(str.slice(1).replace(/^@/, ''), ctx, ctx.root);
  }

  // 字符串里内嵌 @get:{x} / @put:{k:rule}（URL 类规则常见）
  if ((str.indexOf('@get:{') >= 0 || str.indexOf('@put:{') >= 0)
      && /^(https?:|\/|\{\{|\w+\/)/i.test(str.trim())) {
    return evalTemplate(substituteVars(str, ctx, scopeEl), ctx, scopeEl);
  }

  // 模板
  if (str.indexOf('{{') >= 0) return evalTemplate(str, ctx, scopeEl);

  // JSON 源里的单花括号模板：http://x/{$.id}.html
  if (str.indexOf('{$.') >= 0 && ((scopeEl && scopeEl.__jsonItem) || isJsonContent(ctx))) {
    return str.replace(/\{(\$[^{}]*)\}/g, (m, p) => {
      const data = jsonData(ctx, scopeEl);
      if (data == null) return '';
      return jsonpath.queryString(data, p);
    });
  }

  // <js>…</js>
  let m = /^\s*<js>([\s\S]*?)<\/js>\s*$/i.exec(str);
  if (m) return String(runJs(m[1], ctx, scopeElText(ctx, scopeEl)) || '');

  // 纯 JS 规则
  if (/^\s*@?js:/.test(str)) {
    const code = str.replace(/^\s*@?js:/, '');
    const out = runJs(code, ctx, scopeElValue(ctx, scopeEl));
    return typeof out === 'string' ? out : (Array.isArray(out) ? out.join('\n') : String(out == null ? '' : out));
  }

  // || 兜底
  if (hasTop(str, '||')) {
    for (const alt of splitTopLevel(str, '||')) {
      const v = evalMain(alt, ctx, scopeEl);
      if (v !== '' && v != null) return v;
    }
    return '';
  }

  // && 并列（换行）/ %% 并列（不换行）
  const andSep = hasTop(str, '&&') ? '&&' : (hasTop(str, '%%') ? '%%' : null);
  if (andSep) {
    const segs = splitTopLevel(str, andSep).map((x) => x.trim()).filter(Boolean);
    const vals = [];
    for (const seg of segs) {
      const v = evalMain(seg, ctx, scopeEl);
      if (v !== '' && v != null) vals.push(String(v));
    }
    return vals.join(andSep === '%%' ? '' : '\n');
  }

  // <$> 交替
  if (hasTop(str, '<$>')) {
    const segs = splitTopLevel(str, '<$>');
    const lists = segs.map((s) => String(evalMain(s, ctx, scopeEl)).split('\n'));
    const out = [];
    const max = Math.max(...lists.map((l) => l.length));
    for (let i = 0; i < max; i++) for (const l of lists) if (l[i] != null) out.push(l[i]);
    return out.join('\n');
  }

  const { main, replaces } = splitReplace(str);
  let reverse = false;
  let body = main.trim();
  if (body.startsWith('-') && !body.startsWith('->')) { reverse = true; body = body.slice(1); }

  let out = evalChain(body, ctx, scopeEl, reverse);
  return applyReplaces(out, replaces);
}

function evalChain(rule, ctx, scopeEl, reverse) {
  const parts = splitChain(rule);
  let current = [scopedRoot(ctx, scopeEl)];
  let isString = false;
  let stringVal = '';
  let asValue = false;

  for (let i = 0; i < parts.length; i++) {
    let part = parts[i].trim();
    if (!part) continue;

    // @put / @get 段：不打断取值链
    if (/^@?put:\{/.test(part)) {
      const body = /\{([\s\S]*)\}/.exec(part);
      if (body) {
        const kv = splitTopLevel(body[1], ':');
        const name = (kv[0] || '').trim();
        const valRule = kv.slice(1).join(':').trim();
        let val = '';
        try { val = evalString(valRule, ctx, undefined); } catch (e) { val = ''; }
        if (ctx.state && ctx.state.vars && name) { ctx.state.vars.set(name, val); ctx.state.dirtyVars = true; }
      }
      continue;
    }
    if (/^@?get:\{/.test(part)) {
      const body = /\{([\s\S]*)\}/.exec(part);
      const name = body ? body[1].split(':')[0].trim() : '';
      const val = ctx.state && ctx.state.vars ? ctx.state.vars.get(name) : '';
      isString = true;
      stringVal = val == null ? '' : String(val);
      current = [];
      continue;
    }

    // JSONPath 段
    if (part.startsWith('$') && !isString
        && ((scopeEl && scopeEl.__jsonItem) || ctx._jsonParsed || isJsonContent(ctx))) {
      const data = jsonData(ctx, scopeEl);
      if (data != null) {
        const segs = splitTopLevel(part, '##');
        isString = true;
        stringVal = applyReplaces(jsonpath.queryString(data, segs[0]), splitReplace(part).replaces);
        current = [];
        continue;
      }
    }

    if (part.startsWith('js:') || part.startsWith('@js:')) {
      const code = part.replace(/^@?js:/, '');
      const input = isString ? stringVal : (current.length === 1 ? current[0] : makeElements(current.filter((x) => x && x.tag)));
      const value = runJs(code, ctx, input);
      isString = true;
      stringVal = Array.isArray(value) ? value.join('\n') : String(value == null ? '' : value);
      current = [];
      continue;
    }

    // output token
    if (OUTPUT_TOKENS.has(part)) {
      if (isString) continue;
      const vals = elementsTo(part, current);
      isString = true;
      stringVal = vals.join('\n');
      current = [];
      continue;
    }

    // 属性取值（href / src / title / data-xxx ...）
    if (isString) {
      // 字符串之后还能接 @ 链的情况极少，直接忽略
      continue;
    }
    const attrVals = (/^[a-zA-Z_:][-a-zA-Z0-9_:.]*$/.test(part)) ? attrOf(current, part) : [];
    if (attrVals.length) {
      isString = true;
      stringVal = attrVals.join('\n');
      current = [];
      continue;
    }

    const before = current.length;
    const next = selectPart(current, part, ctx);
    if (next.length && typeof next[0] === 'string') {
      isString = true;
      stringVal = next.join('\n');
      current = [];
      continue;
    }
    current = next;
    asValue = asValue || before !== next.length;
  }

  let outText;
  if (isString) outText = stringVal;
  else outText = current.map((e) => (e && e.textContent != null ? collapse(e.textContent) : String(e || '')))
    .filter((s) => s !== '').join('\n');

  if (reverse) {
    const arr = outText.split('\n').filter((x) => x !== '');
    outText = arr.reverse().join('\n');
  }
  return outText;
}

function scopeElText(ctx, scopeEl) {
  if (!scopeEl || scopeEl === ctx.root) return ctx.src || '';
  if (typeof scopeEl === 'string') return scopeEl;
  if (Array.isArray(scopeEl)) return scopeEl.map((e) => (e && e.textContent) || '').join('\n');
  return scopeEl.textContent || '';
}

function scopeElValue(ctx, scopeEl) {
  // 顶层（没有具体节点）时，result 给整页内容，和 Legado 一致
  if (!scopeEl || scopeEl === ctx.root) return ctx.src || '';
  if (Array.isArray(scopeEl)) return makeElements(scopeEl);
  return scopeEl;
}

/* ───────────── 对外 ───────────── */

function evalString(rule, ctx, scopeEl) {
  if (rule == null) return '';
  const raw = String(rule).trim();
  if (!raw) return '';
  // JSONPath 后面还接了 @js: （例如 "$.id@js:'https://x/'+result"）
  if (raw.startsWith('$') && raw.includes('@js:')) {
    const at = raw.indexOf('@js:');
    const pathPart = raw.slice(0, at).trim();
    const code = raw.slice(at + 4);
    const data = jsonData(ctx, scopeEl);
    const v = pathPart && data != null ? jsonpath.queryString(data, pathPart) : '';
    const out = runJs(code, ctx, v);
    return out == null ? '' : String(out);
  }

  // 纯 JSONPath：直接对当前（或列表项）JSON 取值
  if (jsonpath.isJSONPath(raw)
    || (raw.indexOf('{{') < 0 && looksJsonPath(raw)
      && ((scopeEl && scopeEl.__jsonItem) || isJsonContent(ctx)))) {
    try {
      const data = jsonData(ctx, scopeEl);
      if (data == null) return '';
      let pathStr = raw.replace(/^@json:/i, '');
      if (!pathStr.startsWith('$')) pathStr = '$.' + pathStr;
      const segs = splitTopLevel(pathStr, '##');
      const v = jsonpath.queryString(data, segs[0]);
      return applyReplaces(v, splitReplace(raw).replaces);
    } catch (e) { return ''; }
  }
  try {
    return evalMain(raw, ctx, scopeEl);
  } catch (e) {
    return '';
  }
}

/**
 * 求值成元素数组（bookList / chapterList 用）
 * 支持 JS 返回数组、JSONPath 返回数组
 */
function evalElements(rule, ctx, scopeEl) {
  if (rule == null) return [];
  let str = String(rule).trim();
  if (!str) return [];
  if (str.startsWith('@@')) return evalElements(str.slice(1).replace(/^@/, ''), ctx, ctx.root);

  // JS 规则
  if (/^\s*@?js:/.test(str) || /^\s*<js>/.test(str)) {
    const code = str.replace(/^\s*<js>/, '').replace(/<\/js>\s*$/i, '').replace(/^\s*@?js:/, '');
    const out = runJs(code, ctx, scopeElValue(ctx, scopeEl));
    if (Array.isArray(out)) {
      const els = out.filter((x) => x && x.tag);
      if (els.length) return makeElements(els);
      // JS 直接返回 [{name, url}] 的情况（书源里很常见）
      const objs = out.filter((x) => x && typeof x === 'object');
      if (objs.length) return makeElements(objs.map((v) => jsonItem(v)));
    }
    return [];
  }

  // JSONPath：JSON 接口源的列表
  if (jsonpath.isJSONPath(str)
    || (str.indexOf('{{') < 0 && looksJsonPath(str)
      && ((scopeEl && scopeEl.__jsonItem) || isJsonContent(ctx)))) {
    try {
      const data = jsonData(ctx, scopeEl);
      if (data == null) return [];
      let p = str.replace(/^@json:/i, '').split('##')[0];
      if (!p.startsWith('$')) p = '$.' + p;
      const hits = jsonpath.query(data, p);
      return makeElements(hits.map((v) => jsonItem(v)));
    } catch (e) { return []; }
  }

  // 模板里可能是一段 js 生成 html/元素
  if (str.indexOf('{{') >= 0) {
    const html = evalTemplate(str, ctx, scopeEl);
    if (!html) return [];
    if (/^\s*</.test(html)) {
      const root = parseHTML(html);
      const kids = root.children.filter((c) => c.type === 'tag');
      return makeElements(kids);
    }
    return [];
  }

  // || 兜底
  if (hasTop(str, '||')) {
    for (const alt of splitTopLevel(str, '||')) {
      const r = evalElements(alt, ctx, scopeEl);
      if (r.length) return r;
    }
    return [];
  }

  // && 并列
  if (hasTop(str, '&&')) {
    const out = [];
    for (const seg of splitTopLevel(str, '&&')) out.push(...evalElements(seg, ctx, scopeEl));
    return out;
  }

  const { main } = splitReplace(str);
  let body = main.trim();
  let reverse = false;
  if (body.startsWith('-')) { reverse = true; body = body.slice(1); }

  // <$> 交替
  if (hasTop(body, '<$>')) {
    const lists = splitTopLevel(body, '<$>').map((s) => evalElements(s, ctx, scopeEl));
    const out = [];
    const max = Math.max(...lists.map((l) => l.length));
    for (let i = 0; i < max; i++) for (const l of lists) if (l[i]) out.push(l[i]);
    return out;
  }

  const parts = splitChain(body);
  let current = [scopedRoot(ctx, scopeEl)];
  for (const raw of parts) {
    const p = raw.trim();
    if (!p) continue;
    if (OUTPUT_TOKENS.has(p)) break;
    if (p.startsWith('js:')) break;
    const next = selectPart(current, p, ctx);
    current = next;
    if (!current.length) break;
  }
  let out = current;
  if (out.length && typeof out[0] === 'string') {
    // 字符串结果转成伪元素
    out = out.map((t) => ({ tag: '#text', textContent: t, attr: () => undefined, children: [] }));
  }
  if (reverse) out = out.slice().reverse();
  return makeElements(out);
}

module.exports = {
  makeContext,
  evalString,
  evalElements,
  evalTemplate,
  isJsonContent,
  looksJsonPath,
  applyTemplate: (str, vars) => {
    if (typeof str !== 'string' || str.indexOf('{{') < 0) return str;
    const ctx = makeContext({ html: '', baseUrl: vars && vars.baseUrl });
    ctx.key = (vars && vars.key) || '';
    ctx.page = (vars && vars.page) || 1;
    return evalTemplate(str, ctx);
  },
  collapse,
  splitTopLevel,
  splitReplace,
  applyReplaces,
  runJs,
  getState,
};
