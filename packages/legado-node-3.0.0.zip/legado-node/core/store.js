'use strict';
/*
 * 书源变量 / Cookie 持久化
 * 乐读书源的 source.getVariable() / putVariable() / cookie.* 在 App 里是存在书源对象上的，
 * 服务端要跨请求保持，就得落盘。
 */

let fs = null;
let path = null;
try { fs = require('fs'); } catch (e) { fs = null; }
try { path = require('path'); } catch (e) { path = null; }

class Store {
  constructor(file) {
    this.file = file || (path ? path.join(__dirname, '..', 'data', 'store.json') : '');
    this.data = { vars: {}, cookies: {}, books: {} };
    this.timer = null;
    this.load();
  }

  load() {
    if (!fs || !this.file) return;
    try {
      const raw = fs.readFileSync(this.file, 'utf8');
      const obj = JSON.parse(raw);
      if (obj && typeof obj === 'object') {
        this.data.vars = obj.vars || {};
        this.data.cookies = obj.cookies || {};
        this.data.books = obj.books || {};
      }
    } catch (e) { /* 没文件就从空开始 */ }
  }

  save() {
    if (!fs || !this.file) return;
    if (this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      try {
        fs.mkdirSync(path.dirname(this.file), { recursive: true });
        fs.writeFileSync(this.file, JSON.stringify(this.data));
      } catch (e) { /* 磁盘写失败不影响主流程 */ }
    }, 800);
    if (this.timer.unref) this.timer.unref();
  }

  varsOf(key) {
    const o = this.data.vars[key];
    return o && typeof o === 'object' ? o : {};
  }

  setVars(key, obj) {
    this.data.vars[key] = obj || {};
    this.save();
  }

  cookiesOf(key) {
    const a = this.data.cookies[key];
    return Array.isArray(a) ? a : [];
  }

  setCookies(key, arr) {
    this.data.cookies[key] = Array.isArray(arr) ? arr : [];
    this.save();
  }

  bookOf(key) {
    return this.data.books[key] || null;
  }

  setBook(key, obj) {
    this.data.books[key] = obj || null;
    this.save();
  }
}

let singleton = null;
function store(file) {
  if (!singleton || (file && singleton.file !== file)) singleton = new Store(file);
  return singleton;
}

module.exports = { Store, store };
