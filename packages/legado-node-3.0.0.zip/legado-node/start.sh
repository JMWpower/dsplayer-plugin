#!/usr/bin/env bash
# 直接跑（不用 Docker）
set -e
cd "$(dirname "$0")"
PORT="${PORT:-13000}"
exec node index.js --port "$PORT" "$@"
