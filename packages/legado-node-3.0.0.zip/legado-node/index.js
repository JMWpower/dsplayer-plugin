'use strict';
/*
 * 阅读源 · Node 服务入口（v2）
 *
 * 契约与 肉书屋.py 模板对齐：
 *   - 分类带 filters（每个书源的频道）
 *   - 详情 vod_play_url = "章节名$章节标记"，并标出共 N 章
 *   - 正文同时提供 JSON（/novel）与纯文本（/txt），供 novel:// 契约与网页兜底
 *
 * 用法：
 *   node index.js                      # 0.0.0.0:13000
 *   node index.js --port 13001
 *   node index.js --sources ./sources.json
 *   node index.js --chapters 500       # 单本最多返回 500 章
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const { Engine, token } = require('./core/engine');
const { SourceStore } = require('./server/store');
const { createRenderer, bookSourceJson } = require('./server/legado');
const { createApi } = require('./server/webui');

const argv = process.argv.slice(2);
function arg(name, dflt) {
  const i = argv.indexOf('--' + name);
  return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : dflt;
}

const PORT = parseInt(arg('port', process.env.PORT || '13000'), 10);
const HOST = arg('host', process.env.HOST || '0.0.0.0');
const SOURCES = arg('sources', process.env.SOURCES || path.join(__dirname, 'sources.json'));
const MAX_CHAPTERS = parseInt(arg('chapters', process.env.MAX_CHAPTERS || '3000'), 10);
const SEARCH_TIMEOUT = parseInt(arg('search-timeout', process.env.SEARCH_TIMEOUT || '6000'), 10);
const SEARCH_BUDGET = parseInt(arg('search-budget', process.env.SEARCH_BUDGET || '10000'), 10);
const REQ_TIMEOUT = parseInt(arg('req-timeout', process.env.REQ_TIMEOUT || '60000'), 10);
const REQ_TIMEOUT_MS = parseInt(arg('upstream-timeout', process.env.UPSTREAM_TIMEOUT || '15000'), 10);
const SOURCE_TIMEOUT = parseInt(arg('source-timeout', process.env.SOURCE_TIMEOUT || '12000'), 10);
const LIST_LIMIT = parseInt(arg('list-limit', process.env.LIST_LIMIT || '40'), 10);
const MAX_CATEGORIES = parseInt(arg('max-categories', process.env.MAX_CATEGORIES || '300'), 10);
const START_AT = Date.now();

let engine = null;
let engineError = '';

const ENGINE_OPTS = {
  searchTimeout: SEARCH_TIMEOUT,
  searchBudget: SEARCH_BUDGET,
  requestTimeout: REQ_TIMEOUT_MS,
  sourceTimeout: SOURCE_TIMEOUT,
  listLimit: LIST_LIMIT,
  maxCategories: MAX_CATEGORIES,
  // 全源搜索默认并发高一点，否则 20+ 个源要排好几轮，页面容易超时
  searchConcurrency: parseInt(arg('search-concurrency', process.env.SEARCH_CONCURRENCY || '12'), 10),
  maxChapters: MAX_CHAPTERS > 0 ? MAX_CHAPTERS : 3000,
};

// HTML 页面（给「阅读」的书源规则抓）里搜索的预算，压到 9 秒内返回，
// 免得超过书源客户端 15 秒的默认超时
const HTML_SEARCH_BUDGET = parseInt(arg('html-search-budget', process.env.HTML_SEARCH_BUDGET || '9000'), 10);

/* 体检结果（tools/probe-all.js / probe-category.js 产出）。
 * 按站点域名对齐，不能压成 {下标:true}——书源一重排，下标就指到别人头上了。 */
function readResults(file) {
  try {
    const d = JSON.parse(fs.readFileSync(file, 'utf8'));
    return (d && d.results) || d || null;
  } catch (e) {
    return null;
  }
}

const HEALTH_FILE = path.join(__dirname, 'data', 'health.json');
const CAT_HEALTH_FILE = path.join(__dirname, 'data', 'cat-health.json');

/* sources.json 缺失时兜底：有的包只带了 sources_ok.json（体检通过的那批） */
function resolveSources(p) {
  if (/^https?:\/\//i.test(p)) return p;
  if (fs.existsSync(p)) return p;
  for (const alt of ['sources_ok.json', 'sources.json']) {
    const f = path.join(__dirname, alt);
    if (fs.existsSync(f) && f !== p) {
      console.warn('[书源] 没找到 ' + p + '，改用 ' + alt);
      return f;
    }
  }
  return p;
}

/* 本地书源仓库：/sources 的增删改都落到这个文件 */
const SOURCES_FILE = resolveSources(SOURCES);
const STORE_FILE = /^https?:\/\//i.test(SOURCES_FILE)
  ? path.join(__dirname, 'sources.cache.json')
  : path.resolve(SOURCES_FILE);
const store = new SourceStore(STORE_FILE);

function buildEngine() {
  engine = new Engine(store.list(), ENGINE_OPTS);
  engine.setHealth(readResults(HEALTH_FILE));
  engine.setCatHealth(readResults(CAT_HEALTH_FILE));
  // 筛选表缓存跟着书源一起换代
  _filtersCache = null;
  _filtersAt = 0;
  engineError = '';
  return engine;
}

/** 书源增删改之后重建引擎（不需要重启服务） */
function reload() {
  try {
    store.load();
    buildEngine();
    console.log('[阅读源] 书源已重载：' + engine.size + ' 个启用 / ' + store.size + ' 个总计');
  } catch (e) {
    engineError = '书源重载失败: ' + e.message;
    console.error(engineError);
  }
  return engine;
}

async function loadEngine() {
  if (/^https?:\/\//i.test(SOURCES)) {
    const res = await fetch(SOURCES, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    const json = JSON.parse(await res.text());
    store.raw = Array.isArray(json) ? json : ((json && json.sources) || []);
    store.save();
  } else {
    try {
      store.load();
    } catch (e) {
      if (e.code !== 'ENOENT') throw e;
      store.raw = [];
    }
  }
  return buildEngine();
}

const renderer = createRenderer({
  getEngine: () => engine,
  store,
  reload,
  searchBudget: HTML_SEARCH_BUDGET,
});

const api = createApi({
  getEngine: () => engine,
  getEngineError: () => engineError,
  store,
  reload,
  searchBudget: HTML_SEARCH_BUDGET,
});

function baseOf(req) {
  const host = req.headers['x-forwarded-host'] || req.headers.host || ('127.0.0.1:' + PORT);
  const proto = req.headers['x-forwarded-proto'] || 'http';
  return proto + '://' + String(host).split(',')[0].trim();
}

function sendJson(res, obj, status = 200) {
  const body = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function sendText(res, text, status = 200, type = 'text/plain; charset=utf-8') {
  const body = Buffer.from(text == null ? '' : String(text), 'utf8');
  res.writeHead(status, {
    'Content-Type': type,
    'Content-Length': body.length,
    'Access-Control-Allow-Origin': '*',
  });
  res.end(body);
}

function enc(s) { return encodeURIComponent(String(s == null ? '' : s)); }

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/* ────────── 筛选：把客户端传的筛选值统一成 channel ────────── */

function readChannel(params) {
  // 只认频道本身（channel / ch）。
  // f、filter、cateId、extend 这些是客户端传的筛选器，以前被当成频道去抓，
  // 结果整页直接空掉（还套着 999 页的假兜底）——这里彻底不碰它们。
  for (const k of ['channel', 'ch']) {
    const v = params.get(k);
    if (v == null) continue;
    const s = String(v).trim();
    if (!s) continue;
    if (s.startsWith('{')) {
      try {
        const obj = JSON.parse(s);
        const c = obj.channel || obj.ch || '';
        if (c) return String(c).trim();
      } catch (e) { /* 不是 JSON */ }
      continue;
    }
    if (s.includes('=')) continue;
    return s;
  }
  // extend 只认里面显式写的 channel 字段，裸值不当频道
  const ext = params.get('extend');
  if (ext) {
    const s = String(ext).trim();
    if (s.startsWith('{')) {
      try {
        const obj = JSON.parse(s);
        const c = obj.channel || obj.ch || '';
        if (c) return String(c).trim();
      } catch (e) { /* 不是 JSON */ }
    }
  }
  return '';
}

/* ────────── T3（CMS / 影视仓 / 阅读器）───────── */

function t3Class() {
  // engine.categories() 已经剔掉「没有频道页」和「已判死」的源，并按体检结果排序
  return engine.categories();
}

let _filtersCache = null;
let _filtersAt = 0;
function t3Filters() {
  // 筛选表只给展示中的分类，且每个源最多 13 个频道——否则响应能到 6MB
  const now = Date.now();
  if (_filtersCache && now - _filtersAt < 60000) return _filtersCache;
  const allowed = new Set(engine.categories().map((c) => String(c.type_id)));
  const all = engine.filters();
  const out = {};
  let n = 0;
  for (const k of Object.keys(all)) {
    if (!allowed.has(k)) continue;
    const item = all[k][0];
    if (!item) continue;
    out[k] = [{ key: item.key, name: item.name, value: item.value.slice(0, 13) }];
    if (++n >= 300) break;
  }
  _filtersCache = out;
  _filtersAt = now;
  return out;
}

function t3Item(v) {
  return {
    vod_id: v.vod_id,
    vod_name: v.vod_name,
    vod_pic: v.vod_pic || '',
    vod_remarks: v.vod_remarks || '',
    vod_actor: v.vod_actor || '',
    vod_area: v.vod_area || '',
    type_id: v.type_id || '',
    type_name: v.type_name || v.source || '',
  };
}

/** 详情：把 engine.detail 的结果转成 T3 结构（章节即剧集） */
function t3Detail(d) {
  return {
    vod_id: d.vod_id,
    vod_name: d.vod_name,
    vod_pic: d.vod_pic || '',
    vod_content: d.vod_content || '',
    vod_actor: d.vod_actor || '',
    vod_area: d.vod_area || '',
    vod_year: '',
    vod_remarks: d.vod_remarks || ('共' + (d.chapter_count || 0) + '章'),
    vod_play_from: d.vod_play_from || '阅读',
    vod_play_url: d.vod_play_url || '',
  };
}

function isEmptyList(r) {
  return !r || !r.list || !r.list.length;
}

async function t3List(params) {
  const pg = parseInt(params.get('pg') || params.get('page') || '1', 10) || 1;
  const t = params.get('t') || params.get('type_id') || '';
  const wd = params.get('wd') || params.get('key') || params.get('search') || '';
  const channel = readChannel(params);
  // first=0：只要分类表，不要首屏列表（首页要快，跟模板保持一致）
  const wantFirst = params.get('first') !== '0';

  if (wd) {
    const r = await engine.search(wd);
    return {
      class: t3Class(),
      filters: t3Filters(),
      list: r.list.map(t3Item),
      page: 1,
      pagecount: 1,
      limit: String(r.list.length || 20),
      total: r.list.length,
    };
  }

  if (t !== '' && t != null && /^-?\d+$/.test(String(t))) {
    const idx = parseInt(t, 10);
    if (!engine.sources[idx]) {
      // 越界就是真没这个分类，老实返回空，别去猜首页糊弄客户端
      return {
        class: t3Class(), filters: t3Filters(), list: [],
        page: pg, pagecount: 1, limit: String(LIST_LIMIT), total: 0,
      };
    }
    const r = await engine.category(String(idx), pg, channel);
    return {
      class: t3Class(),
      filters: t3Filters(),
      list: r.list.map(t3Item),
      page: pg,
      // 满页才有下一页，不满就是最后一页；以前写死 999 页，客户端会一直往下翻
      pagecount: r.pagecount || pg,
      limit: String(LIST_LIMIT),
      total: r.total,
    };
  }

  // 没指定分类：返回分类表 + 首页推荐（有 first=0 就只给分类表）
  // 以前串行试 3 个源 × 12 秒，能把 60 秒请求硬超时拖满；现在并发探 8 个，谁先出内容用谁
  let first = { list: [] };
  if (wantFirst) {
    const cands = [];
    for (let i = 0; i < engine.sources.length && cands.length < 8; i++) {
      const s = engine.sources[i];
      if (!s.channels || !s.channels.length) continue;
      if (engine.healthState(i) < 0) continue;
      cands.push(i);
    }
    const rs = await Promise.all(cands.map((i) =>
      engine.category(String(i), 1, '').catch(() => ({ list: [] }))
    ));
    for (const r of rs) {
      if (r.list && r.list.length) { first = r; break; }
    }
  }
  return {
    class: t3Class(),
    filters: t3Filters(),
    list: (first.list || []).map(t3Item),
    page: 1,
    pagecount: 1,
    limit: String(LIST_LIMIT),
    total: (first.list || []).length,
  };
}

/* ────────── T4（catvod 原生接口）───────── */

function t4Home() {
  return {
    class: engine.categories().map((c) => ({ type_id: c.type_id, type_name: c.type_name })),
    filters: t3Filters(),
    list: [],
  };
}

function t4Vod(v) {
  return {
    vod_id: v.vod_id,
    vod_name: v.vod_name,
    vod_pic: v.vod_pic || '',
    vod_remarks: v.vod_remarks || '',
    vod_actor: v.vod_actor || '',
    vod_area: v.vod_area || '',
    type_id: v.type_id || '',
    type_name: v.type_name || v.source || '',
  };
}

/* ────────── 正文 ────────── */

function renderChapterHtml(title, text) {
  const body = String(text || '').split(/\n+/).filter(Boolean)
    .map((x) => '<p>' + escapeHtml(x) + '</p>').join('');
  return '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
    + '<meta name="viewport" content="width=device-width,initial-scale=1">'
    + '<title>' + escapeHtml(title || '正文') + '</title>'
    + '<style>body{margin:0;padding:18px 18px 48px;font-size:17.5px;line-height:1.9;color:#1f1f1f;background:#fff;'
    + 'font-family:system-ui,-apple-system,"PingFang SC","Noto Sans CJK SC",serif}'
    + 'h1{font-size:18px;margin:0 0 14px;font-weight:600}'
    + 'p{margin:0 0 .95em;text-indent:2em}</style></head><body>'
    + (title ? '<h1>' + escapeHtml(title) + '</h1>' : '')
    + body + '</body></html>';
}

/* ────────── HTML 页面 ────────── */

function statusPage(req) {
  const base = baseOf(req);
  const info = engine.info();
  const rows = info.slice(0, 400).map((s) => {
    const st = s.channels ? (s.channels + ' 频道') : '仅搜索';
    const alt = (s.altHosts || []).length ? ' <span class="dim">(+备用域名)</span>' : '';
    return '<tr><td>' + s.index + '</td><td>' + escapeHtml(s.name) + '</td>'
      + '<td class="dim">' + escapeHtml(s.host) + alt + '</td>'
      + '<td>' + (s.searchable ? '搜索' : '—') + ' / ' + st
      + (s.dead ? ' <b style="color:#ff6b6b">暂不可用</b>' : '') + '</td>'
      + '<td><a href="' + base + '/api.php/provide/vod/?ac=list&t=' + s.index + '&pg=1" target="_blank">测</a></td></tr>';
  }).join('');

  return '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
    + '<meta name="viewport" content="width=device-width,initial-scale=1">'
    + '<title>阅读源 · Node 服务</title><style>'
    + 'body{margin:0;padding:18px;font-family:system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:#0f1115;color:#e6e6e6}'
    + 'h1{font-size:18px;margin:0 0 4px} .sub{color:#8b93a1;font-size:12.5px;margin-bottom:14px}'
    + '.card{background:#171a21;border:1px solid #242833;border-radius:12px;padding:14px;margin-bottom:12px}'
    + 'table{width:100%;border-collapse:collapse;font-size:12.5px}'
    + 'td,th{padding:6px 8px;border-bottom:1px solid #242833;text-align:left;vertical-align:top}'
    + 'th{color:#8b93a1;font-weight:500} .dim{color:#8b93a1}'
    + 'code{background:#0f1115;border:1px solid #242833;padding:2px 6px;border-radius:6px;font-size:12px;word-break:break-all}'
    + 'a{color:#6cc7ff;text-decoration:none}</style></head><body>'
    + '<h1>阅读源 · Node 服务</h1>'
    + '<div class="sub">运行 ' + Math.round((Date.now() - START_AT) / 1000) + ' 秒 · Node ' + process.version
    + ' · 书源 ' + engine.size + ' 个'
    + (engineError ? ' · <b style="color:#ff6b6b">' + escapeHtml(engineError) + '</b>' : '') + '</div>'
    + '<div class="card"><div style="margin-bottom:8px">订阅地址（阅读器 / 影视仓 里添加接口时填这个）：</div>'
    + '<code>' + base + '/sub</code>'
    + '<div class="dim" style="margin-top:8px;font-size:12px">CMS 接口：<code>' + base + '/api.php/provide/vod/</code>'
    + ' · 正文 JSON：<code>' + base + '/novel?f=&lt;章节标记&gt;</code></div></div>'
    + '<div class="card"><table><thead><tr><th>#</th><th>书源</th><th>域名</th><th>能力</th><th></th></tr></thead><tbody>'
    + rows + '</tbody></table></div>'
    + '</body></html>';
}

/* ────────── 管理面板静态资源 ────────── */

const WEB_DIR = path.join(__dirname, 'web');
const assetCache = new Map();

function readAsset(name) {
  const hit = assetCache.get(name);
  if (hit && Date.now() - hit.at < 2000) return hit.text;
  const text = fs.readFileSync(path.join(WEB_DIR, name), 'utf8');
  assetCache.set(name, { at: Date.now(), text });
  return text;
}

const ASSET_TYPES = {
  'index.html': 'text/html; charset=utf-8',
  'app.css': 'text/css; charset=utf-8',
  'app.js': 'application/javascript; charset=utf-8',
};

/** HTML 规则书源页面的路由表（/hs/xxx） */
const HS_ROUTES = {
  browse: (q) => renderer.browse(q),
  search: (q) => renderer.search(q),
  book: (q) => renderer.book(q),
  chapter: (q) => renderer.chapter(q),
  manage: () => renderer.manage(),
  source: (q) => renderer.sourceDetail(q),
  act: (q) => renderer.action(q),
  repos: () => renderer.repoList(),
  repo: (q) => renderer.repoDetail(q),
  import: (q) => renderer.importOne(q),
};

/* ────────── 路由 ────────── */

async function handle(req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': '*',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    });
    return res.end();
  }

  const u = new URL(req.url, baseOf(req));
  const p = u.pathname;
  const params = u.searchParams;
  const base = baseOf(req);

  // 管理面板（浏览 / 源管理 / 源仓库）
  if (p === '/' || p === '/index.html' || p === '/panel') {
    try {
      return sendText(res, readAsset('index.html'), 200, ASSET_TYPES['index.html']);
    } catch (e) {
      return sendText(res, statusPage(req), 200, 'text/html; charset=utf-8');
    }
  }
  if (p === '/assets/app.css') return sendText(res, readAsset('app.css'), 200, ASSET_TYPES['app.css']);
  if (p === '/assets/app.js') return sendText(res, readAsset('app.js'), 200, ASSET_TYPES['app.js']);

  // 旧状态页
  if (p === '/status') return sendText(res, statusPage(req), 200, 'text/html; charset=utf-8');

  // 管理面板接口
  if (p.startsWith('/api/')) {
    if (await api.handle(req, res, u, sendJson, base)) return;
    return sendJson(res, { ok: false, error: '未知接口 ' + p }, 404);
  }

  // HTML 规则书源（给「阅读」的书源规则抓）
  if (p.startsWith('/hs/')) {
    const route = p.slice(4).replace(/\/+$/, '');
    const fn = HS_ROUTES[route];
    if (!fn) return sendText(res, '<!DOCTYPE html><meta charset="utf-8"><h1>404</h1>', 404, 'text/html; charset=utf-8');
    try {
      const html = await fn(params);
      return sendText(res, html, 200, 'text/html; charset=utf-8');
    } catch (e) {
      return sendText(res,
        '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>出错了</title></head>'
        + '<body style="font:14px/1.6 system-ui;padding:20px"><h2>页面出错</h2><pre style="white-space:pre-wrap">'
        + escapeHtml(e.stack || e.message) + '</pre></body></html>',
        500, 'text/html; charset=utf-8');
    }
  }

  // HTML 规则书源 JSON：在「阅读」里添加书源时填这个地址
  if (p === '/legado_html.json' || p === '/book-source.json') {
    return sendJson(res, bookSourceJson(base));
  }

  // 当前书源仓库（可直接下载备份）
  if (p === '/sources.json' || p === '/source-store.json') {
    return sendJson(res, store.list());
  }

  // 订阅
  if (p === '/sub' || p === '/tvbox.json' || p === '/api/sub') {
    const base = baseOf(req);
    return sendJson(res, {
      spider: '',
      wallpaper: '',
      sites: [{
        key: 'legado',
        name: '阅读源',
        type: 3,
        api: base + '/api.php/provide/vod/',
        searchable: 1,
        quickSearch: 1,
        filterable: 1,
        ext: '',
      }],
      lives: [],
      parsers: [],
      flags: [],
    });
  }

  // 书源清单 / 筛选表
  if (p === '/sources') return sendJson(res, { total: engine.size, sources: engine.info() });
  if (p === '/filters') return sendJson(res, { filters: t3Filters() });

  // 单源诊断：/diag?t=542 → 一次跑完 分类/详情/目录/正文，直接告诉你这个源卡在哪一步
  if (p === '/diag') {
    const t = params.get('t');
    if (t == null || t === '') return sendJson(res, { error: '缺少参数 t' }, 400);
    const idx = parseInt(t, 10);
    const s = engine.sources[idx];
    if (!s) return sendJson(res, { error: '没有这个书源下标: ' + t }, 404);
    const out = {
      index: idx,
      name: s.name,
      host: s.url,
      channels: (s.channels || []).length,
      searchable: !!s.searchUrl,
      health: engine.healthState(idx),
      steps: {},
    };
    const started = Date.now();
    try {
      const r = await engine.category(String(idx), 1, params.get('channel') || '');
      out.steps.category = { ok: r.list.length > 0, count: r.list.length, pagecount: r.pagecount };
      if (r.list.length) {
        const d = await engine.detail(r.list[0].vod_id);
        out.steps.detail = { ok: (d.chapters || []).length > 0, name: d.vod_name, chapters: (d.chapters || []).length };
        if ((d.chapters || []).length) {
          try {
            const c = await engine.chapterDetail(token(idx, d.chapters[0].url));
            out.steps.content = { ok: (c.content || '').length > 0, chars: (c.content || '').length, title: c.title };
          } catch (e) { out.steps.content = { ok: false, error: e.message }; }
        }
      }
    } catch (e) {
      out.error = e.message;
    }
    out.ms = Date.now() - started;
    return sendJson(res, out);
  }

  if (p === '/health-report') {
    try {
      return sendJson(res, JSON.parse(fs.readFileSync(HEALTH_FILE, 'utf8')));
    } catch (e) {
      return sendJson(res, { error: '还没有体检报告，先运行 node tools/probe-all.js' }, 404);
    }
  }

  if (p === '/reload') {
    try {
      reload();
      return sendJson(res, { ok: true, sources: engine ? engine.size : 0 });
    } catch (e) {
      return sendJson(res, { ok: false, error: e.message }, 500);
    }
  }

  // 章节正文 · JSON（novel:// 契约）
  if (p === '/novel' || p === '/chapter.json' || p === '/api/novel') {
    const flag = params.get('f') || params.get('flag') || params.get('id') || params.get('url') || '';
    if (!flag) return sendJson(res, { code: 400, msg: '缺少参数 f', title: '', content: '' }, 400);
    try {
      const d = await engine.chapterDetail(flag);
      return sendJson(res, {
        code: 0,
        title: d.title || '',
        content: d.content || '',
        chars: d.chars || 0,
      });
    } catch (e) {
      return sendJson(res, { code: 500, msg: e.message || '正文获取失败', title: '', content: '' }, 500);
    }
  }

  // 章节正文 · 纯文本 / HTML
  if (p === '/txt' || p === '/chapter' || p === '/content' || p === '/proxy') {
    const flag = params.get('f') || params.get('flag') || params.get('url') || '';
    if (!flag) return sendText(res, '缺少参数 f', 400);
    try {
      const d = await engine.chapterDetail(flag);
      if (params.get('fmt') === 'html') {
        return sendText(res, renderChapterHtml(d.title, d.content), 200, 'text/html; charset=utf-8');
      }
      return sendText(res, d.content, 200);
    } catch (e) {
      const msg = '正文获取失败：' + (e.message || '');
      if (params.get('fmt') === 'html') {
        return sendText(res, renderChapterHtml('', msg), 500, 'text/html; charset=utf-8');
      }
      return sendText(res, msg, 500);
    }
  }

  // T4 接口
  if (p === '/t4' || p.startsWith('/t4/')) {
    const action = p === '/t4' ? (params.get('do') || 'home') : p.slice(4).replace(/^\//, '');
    try {
      if (action === 'home' || action === '') return sendJson(res, t4Home());
      if (action === 'sites' || action === 'config') {
        const base = baseOf(req);
        return sendJson(res, {
          sites: [{
            key: 'legado', name: '阅读源', type: 3, api: base + '/t4',
            searchable: 1, quickSearch: 1, filterable: 1, ext: '',
          }],
        });
      }
      if (action === 'categoryContent' || action === 'category') {
        const tid = params.get('tid') || params.get('t') || '0';
        const pg = parseInt(params.get('pg') || params.get('page') || '1', 10) || 1;
        const r = await engine.category(tid, pg, readChannel(params));
        return sendJson(res, {
          page: pg, pagecount: r.pagecount || pg, limit: LIST_LIMIT, total: r.total,
          list: r.list.map(t4Vod),
        });
      }
      if (action === 'detailContent' || action === 'detail') {
        const ids = (params.get('ids') || params.get('id') || '').split(',').filter(Boolean);
        const out = [];
        for (const id of ids) {
          try {
            out.push(t3Detail(await engine.detail(id)));
          } catch (e) { /* 单本失败不影响其它 */ }
        }
        return sendJson(res, { list: out });
      }
      if (action === 'searchContent' || action === 'search') {
        const wd = params.get('wd') || params.get('key') || '';
        const r = await engine.search(wd);
        return sendJson(res, { list: r.list.map(t4Vod), page: 1, pagecount: 1, total: r.list.length });
      }
      if (action === 'playerContent' || action === 'play') {
        const flag = params.get('flag') || params.get('f') || params.get('url') || '';
        const base = baseOf(req);
        return sendJson(res, { parse: 0, url: base + '/novel?f=' + enc(flag), header: {} });
      }
      return sendJson(res, { error: 'unknown action: ' + action }, 404);
    } catch (e) {
      return sendJson(res, { error: e.message }, 500);
    }
  }

  // T3 CMS
  if (p === '/api.php/provide/vod/' || p === '/api.php/provide/vod' || p === '/vod' || p === '/api') {
    try {
      const ac = params.get('ac') || 'list';
      const ids = params.get('ids') || params.get('id') || '';
      if ((ac === 'detail' || ac === 'videolist') && ids) {
        const list = [];
        for (const id of ids.split(',').filter(Boolean)) {
          try {
            list.push(t3Detail(await engine.detail(id)));
          } catch (e) { /* 单本失败跳过 */ }
        }
        return sendJson(res, { class: t3Class(), filters: t3Filters(), list, page: 1, pagecount: 1, limit: '20', total: list.length });
      }
      const r = await t3List(params);
      return sendJson(res, r);
    } catch (e) {
      return sendJson(res, { code: 500, msg: e.message, list: [], class: [], filters: {} });
    }
  }

  // 健康检查
  if (p === '/health' || p === '/ping') {
    return sendJson(res, {
      ok: true,
      sources: engine ? engine.size : 0,
      uptime: Math.round((Date.now() - START_AT) / 1000),
    });
  }

  return sendText(res, '404', 404);
}

(async () => {
  try {
    await loadEngine();
  } catch (e) {
    engineError = '书源加载失败: ' + e.message;
    console.error(engineError);
    engine = new Engine([]);
  }

  const server = http.createServer((req, res) => {
    // 单请求兜底超时：某个站卡死也不会把连接一直吊着
    const timer = setTimeout(() => {
      try {
        if (!res.writableEnded) sendJson(res, { code: 504, msg: '请求超时', list: [] }, 504);
      } catch (e) { /* ignore */ }
    }, REQ_TIMEOUT);
    res.on('finish', () => clearTimeout(timer));

    handle(req, res).catch((e) => {
      try { if (!res.writableEnded) sendJson(res, { error: e.message }, 500); } catch (e2) { /* ignore */ }
    });
  });

  server.listen(PORT, HOST, () => {
    const shown = HOST === '0.0.0.0' ? '127.0.0.1' : HOST;
    console.log('[阅读源] 服务已启动 http://' + shown + ':' + PORT
      + '  书源 ' + engine.size + ' 个（总计 ' + store.size + ' 个）');
    console.log('[阅读源] 管理面板: http://' + shown + ':' + PORT + '/');
    console.log('[阅读源] HTML 书源: http://' + shown + ':' + PORT + '/legado_html.json');
    console.log('[阅读源] 订阅地址: http://<本机IP>:' + PORT + '/sub');
  });

  const stop = (sig) => {
    console.log('[阅读源] 收到 ' + sig + '，正在关闭…');
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000);
  };
  process.on('SIGINT', () => stop('SIGINT'));
  process.on('SIGTERM', () => stop('SIGTERM'));
})();
