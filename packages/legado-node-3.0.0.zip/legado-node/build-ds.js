'use strict';
/*
 * 把所有 core/* 打包成单文件 ds 源（喂给 DsPlayer 的 drpy-node）
 *
 *   node build-ds.js                 # 默认最多 300 个书源
 *   node build-ds.js --max 800       # 换数量（文件会明显变大）
 *   node build-ds.js --health        # 只挑体检通过的书源（需要 data/health.json）
 *   node build-ds.js --all           # 全部书源（可能 20MB+，手机端慎用）
 *
 * 产物：spider/legado_node.js（文件名保持英文，中文名在部分 JS 引擎里会掉）
 * 放到 /sdcard/dsplayer/server/node/drpy-node/spider/js/ 下面即可被自动扫描。
 */

const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
function arg(name, dflt) {
  const i = args.indexOf('--' + name);
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : dflt;
}
const has = (n) => args.includes('--' + n);

const root = __dirname;
const MAX = has('all') ? 0 : parseInt(arg('max', '300'), 10);
const ONLY_OK = has('health');

const modules = ['gbk', 'html', 'dom', 'xpath', 'jsonpath', 'http', 'rule', 'jsrt', 'store', 'source', 'engine'];

let sourcesData = JSON.parse(fs.readFileSync(path.join(root, 'sources.json'), 'utf8'));
let list = Array.isArray(sourcesData) ? sourcesData : (sourcesData.sources || []);

// 体检过滤
if (ONLY_OK) {
  const hf = path.join(root, 'data', 'health.json');
  if (fs.existsSync(hf)) {
    const h = JSON.parse(fs.readFileSync(hf, 'utf8')).results || {};
    const okSet = new Set(Object.values(h).filter((r) => r.ok).map((r) => r.i));
    list = list.filter((_, i) => okSet.has(i));
    console.log('按体检结果筛选：' + list.length + ' 个可用的书源');
  } else {
    console.log('没有 data/health.json，跳过体检过滤');
  }
}

// 优先放有分类页/能搜索的源
const usesNet = (s) => /java\.(ajax|post|connect)/.test(JSON.stringify(s));
list = list.slice().sort((a, b) => {
  // 不用同步请求的源排前面：ds 环境里它们最快出结果
  if (usesNet(a) !== usesNet(b)) return usesNet(a) ? 1 : -1;
  const w = (s) => (s.searchUrl ? 2 : 0) + (s.exploreUrl ? 1 : 0);
  return w(b) - w(a);
});
if (MAX > 0) list = list.slice(0, MAX);

const parts = [];
parts.push(`/* eslint-disable */
/*
@header({
  title: '阅读源',
  lang: 'ds',
  searchable: 1, filterable: 1, quickSearch: 1,
})
*/
/*
 * 阅读源（Legado 书源 → DsPlayer ds 源）
 * 纯 Node 实现，零 npm 依赖；内置 ${list.length} 个乐读书源。
 *
 * 放置：/sdcard/dsplayer/server/node/drpy-node/spider/js/legado_node.js
 * 说明：文件名请用英文（中文名在部分 JS 引擎里会被剥掉，导致导出名对不上）。
 *
 * 注意：ds 运行环境没有 child_process 时，依赖 java.ajax 的书源会自动跳过，
 *       其余书源（纯 HTML / JSON 规则）照常可用。想要全功能请用 Node 服务模式。
 */
var __DISABLE_SYNC_HTTP = true; // ds 环境不跑同步请求（会卡死事件循环）
var __modules = {};
var __loading = {};
function __require(name) {
  var key = String(name).replace(/^\\.\\//, '');
  if (__modules[key]) return __modules[key].exports;
  if (typeof module !== 'undefined') {
    try { return require(name); } catch (e) { /* 继续用内置模块 */ }
  }
  throw new Error('module not found: ' + name);
}
`);

for (const f of modules) {
  const code = fs.readFileSync(path.join(root, 'core', f + '.js'), 'utf8')
    .replace(/^'use strict';\s*/, '')
    .replace(/require\('\.\/([a-zA-Z0-9_-]+)'\)/g, "__require('$1')");
  parts.push(`__modules['${f}'] = { exports: {} };\n(function (module, exports, __require) {\n${code}\n})(__modules['${f}'], __modules['${f}'].exports, __require);\n`);
}

parts.push('var __sourcesData = ' + JSON.stringify(list) + ';\n');

parts.push(`
/* ───────────── 引擎实例 ───────────── */

var __engine = null;
function __getEngine() {
  if (!__engine) {
    var Engine = __require('engine').Engine;
    __engine = new Engine(__sourcesData, { searchTimeout: 6000, sourceTimeout: 12000, searchBudget: 9000 });
  }
  return __engine;
}
`);

parts.push(fs.readFileSync(path.join(root, 'spider', 'ds-wrapper.js'), 'utf8'));

const out = parts.join('\n');
const target = path.join(root, 'spider', 'legado_node.js');
fs.writeFileSync(target, out, 'utf8');
console.log('生成 ' + target + '  ' + (out.length / 1024).toFixed(1) + ' KB，书源 ' + list.length + ' 个');
