#!/usr/bin/env bash
# 一键部署到 Linux 服务器（systemd）
#   sudo bash deploy.sh
set -e
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVICE="/etc/systemd/system/legado-node.service"
PORT="${PORT:-13000}"

if ! command -v node >/dev/null 2>&1; then
  echo "没装 Node，先装：curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt install -y nodejs"
  exit 1
fi

cat > "$SERVICE" <<UNIT
[Unit]
Description=Legado Book Source Node Service
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
ExecStart=$(command -v node) $APP_DIR/index.js --port $PORT
Restart=always
RestartSec=3
Environment=MAX_CATEGORIES=300
Environment=SOURCE_TIMEOUT=12000
Environment=LIST_LIMIT=40
Environment=SEARCH_TIMEOUT=6000
Environment=SEARCH_BUDGET=10000

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable legado-node
systemctl restart legado-node
sleep 1
systemctl --no-pager status legado-node | head -12
echo "接口地址: http://<本机IP>:$PORT/sub"
