'use strict';
/*
 * 合并书源：把一个目录里所有 json（乐读书源导出格式）合成一个 sources.json
 *   node tools/build-sources.js <目录> [-o sources.json] [--only-enabled] [--only-searchable]
 *
 * 去重按 bookSourceUrl（忽略结尾斜杠），同一书源出现多次时保留「字段更全 / enabled」的那份。
 */

const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
function arg(name, dflt) {
  for (const flag of ['--' + name, '-' + name]) {
    const i = args.indexOf(flag);
    if (i >= 0 && args[i + 1] && !args[i + 1].startsWith('-')) return args[i + 1];
  }
  return dflt;
}
const has = (name) => args.includes('--' + name);

const dir = args.find((a) => !a.startsWith('--') && fs.existsSync(a)) || '.';
const outFile = arg('o', arg('out', path.join(__dirname, '..', 'sources.json')));
const onlyEnabled = has('only-enabled');
const onlySearchable = has('only-searchable');

function readSources(file) {
  let raw = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
  let data;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    console.error('[跳过] ' + path.basename(file) + ' 不是合法 JSON：' + e.message);
    return [];
  }
  if (data && typeof data === 'object' && Array.isArray(data.sources)) data = data.sources;
  if (!Array.isArray(data)) data = [data];
  return data.filter((x) => x && typeof x === 'object' && (x.bookSourceName || x.bookSourceUrl));
}

function weight(s) {
  let w = 0;
  if (s.enabled !== false) w += 2;
  for (const k of ['ruleSearch', 'ruleExplore', 'ruleBookInfo', 'ruleToc', 'ruleContent']) {
    const r = s[k];
    if (r && typeof r === 'object' && Object.keys(r).length) w += 2;
    else if (typeof r === 'string' && r.length > 4) w += 2;
  }
  if (s.searchUrl) w += 2;
  if (s.exploreUrl) w += 2;
  if (s.bookSourceComment) w += 1;
  return w;
}

function main() {
  const files = fs.readdirSync(dir).filter((f) => /\.json$/i.test(f));
  const map = new Map();
  let total = 0;
  for (const f of files) {
    const list = readSources(path.join(dir, f));
    total += list.length;
    for (const s of list) {
      let key = String(s.bookSourceUrl || '').trim().replace(/\/+$/, '');
      if (!key) key = 'name:' + String(s.bookSourceName || '').trim();
      const old = map.get(key);
      if (!old || weight(s) > weight(old)) map.set(key, s);
    }
  }

  let list = Array.from(map.values());
  if (onlyEnabled) list = list.filter((s) => s.enabled !== false);
  if (onlySearchable) list = list.filter((s) => s.searchUrl || s.exploreUrl);

  // 去掉一些明显没用的字段，缩小体积
  list = list.map((s) => {
    const o = Object.assign({}, s);
    for (const k of ['customOrder', 'weight', 'respondTime', 'lastUpdateTime', 'bookSourceType']) {
      if (k === 'bookSourceType') continue;
      // 保留但先不管
    }
    return o;
  });

  const payload = {
    version: 3,
    updatedAt: new Date().toISOString(),
    count: list.length,
    sources: list,
  };
  fs.writeFileSync(outFile, JSON.stringify(payload));
  const size = (fs.statSync(outFile).size / 1024 / 1024).toFixed(2);

  const withSearch = list.filter((s) => s.searchUrl).length;
  const withExplore = list.filter((s) => s.exploreUrl).length;
  const withJs = list.filter((s) => JSON.stringify(s).includes('js:')).length;
  const groups = new Map();
  for (const s of list) {
    const g = String(s.bookSourceGroup || '未分组').split(/[,\n]/)[0].trim() || '未分组';
    groups.set(g, (groups.get(g) || 0) + 1);
  }

  console.log('读入文件 ' + files.length + ' 个，原始书源 ' + total + ' 条');
  console.log('去重后 ' + list.length + ' 条 → ' + outFile + '（' + size + ' MB）');
  console.log('有搜索 ' + withSearch + ' / 有分类页 ' + withExplore + ' / 含 JS 规则 ' + withJs);
  console.log('分组 top10：');
  Array.from(groups.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10)
    .forEach(([g, n]) => console.log('  ' + g + '  ' + n));
}

main();
