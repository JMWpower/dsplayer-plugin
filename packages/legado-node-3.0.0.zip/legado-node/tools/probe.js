'use strict';
/*
 * 书源体检（单条，带诊断输出）
 *   node tools/probe.js <sources.json> <下标或书源名关键字> [关键词]
 */

const fs = require('fs');
const path = require('path');
const { Engine } = require('../core/engine');

const file = process.argv[2] || path.join(__dirname, '..', 'sources.json');
const pick = process.argv[3] || '0';
const kw = process.argv[4] || '斗罗';

const data = JSON.parse(fs.readFileSync(file, 'utf8'));
const eng = new Engine(data, { searchTimeout: 12000, requestTimeout: 15000, detailTimeout: 30000 });

function find() {
  if (/^\d+$/.test(pick)) return Number(pick);
  const i = eng.sources.findIndex((s) => s.name.includes(pick));
  return i >= 0 ? i : 0;
}

(async () => {
  const i = find();
  const s = eng.sources[i];
  if (!s) { console.log('没有这个书源'); return; }
  console.log('# ' + i + ' ' + s.name + '  ' + s.url);
  console.log('  搜索:' + (s.searchUrl ? '有' : '无') + '  分类:' + s.channels.length + ' 个');

  const t0 = Date.now();
  const list = await s.search(kw, 1).catch((e) => { console.log('搜索异常: ' + e.message); return []; });
  console.log('  搜索「' + kw + '」→ ' + list.length + ' 条，' + (Date.now() - t0) + 'ms');
  list.slice(0, 5).forEach((b) => console.log('    - ' + b.name + ' | ' + b.author + ' | ' + b.bookUrl));
  if (!list.length) return;

  const t1 = Date.now();
  const info = await s.bookInfo(list[0].bookUrl, list[0]).catch((e) => { console.log('  详情异常: ' + e.message); return null; });
  if (!info) return;
  console.log('  详情: ' + info.name + ' / ' + info.author + ' / ' + (info.intro || '').slice(0, 40) + '  ' + (Date.now() - t1) + 'ms');

  const t2 = Date.now();
  const toc = await s.toc(info.tocUrls || info.tocUrl, info).catch((e) => { console.log('  目录异常: ' + e.message); return []; });
  console.log('  目录: ' + toc.length + ' 章，' + (Date.now() - t2) + 'ms');
  toc.slice(0, 3).forEach((c) => console.log('    - ' + c.name + '  ' + c.url));
  if (!toc.length) return;

  const t3 = Date.now();
  const c = await s.content(toc[0].url, info, toc[0]).catch((e) => { console.log('  正文异常: ' + e.message); return null; });
  console.log('  正文: ' + (c ? c.content.length : 0) + ' 字，' + (Date.now() - t3) + 'ms');
  if (c) console.log('    ' + c.content.slice(0, 120).replace(/\s+/g, ' '));
})();
