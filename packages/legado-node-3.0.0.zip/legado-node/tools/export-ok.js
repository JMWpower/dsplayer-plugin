'use strict';
/*
 * 按体检结果导出「能用的书源」
 *   node tools/export-ok.js [--health data/health.json] [-o sources_ok.json]
 *
 * 只有跑通「搜索/分类 → 详情 → 目录 → 正文」的书源才会被保留。
 */

const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
function arg(name, dflt) {
  const i = args.indexOf('--' + name);
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : dflt;
}

const root = path.join(__dirname, '..');
const healthFile = arg('health', path.join(root, 'data', 'health.json'));
const outFile = arg('o', path.join(root, 'sources_ok.json'));
const srcFile = arg('sources', path.join(root, 'sources.json'));

const src = JSON.parse(fs.readFileSync(srcFile, 'utf8'));
const list = Array.isArray(src) ? src : (src.sources || []);
let health = {};
try {
  health = JSON.parse(fs.readFileSync(healthFile, 'utf8')).results || {};
} catch (e) {
  console.error('读不到体检报告：' + healthFile);
  process.exit(1);
}

const ok = [];
for (const k of Object.keys(health)) {
  const r = health[k];
  const i = parseInt(k, 10);
  if (r && r.ok && list[i]) ok.push(list[i]);
}

fs.writeFileSync(outFile, JSON.stringify({ version: 3, updatedAt: new Date().toISOString(), count: ok.length, sources: ok }));
console.log('体检通过 ' + ok.length + ' 条 → ' + outFile);
