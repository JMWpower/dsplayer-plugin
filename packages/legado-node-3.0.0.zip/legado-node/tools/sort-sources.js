'use strict';
/*
 * 按体检结果给书源排序：能跑通的排前面，health.json 的下标同步改写
 *   node tools/sort-sources.js [--health data/health.json] [--sources sources.json] [--apply]
 *
 * 不加 --apply 只打印结果，不改文件。
 */

const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
function arg(name, dflt) {
  const i = args.indexOf('--' + name);
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : dflt;
}
const root = path.join(__dirname, '..');
const healthFile = arg('health', path.join(root, 'data', 'health.json'));
const srcFile = arg('sources', path.join(root, 'sources.json'));
const APPLY = args.includes('--apply');

const src = JSON.parse(fs.readFileSync(srcFile, 'utf8'));
const list = Array.isArray(src) ? src : (src.sources || []);
let health = { results: {} };
try { health = JSON.parse(fs.readFileSync(healthFile, 'utf8')); } catch (e) { console.error('没有体检报告'); process.exit(1); }
const results = health.results || {};

const okIdx = [];
const restIdx = [];
for (let i = 0; i < list.length; i++) {
  const r = results[i];
  if (r && r.ok) okIdx.push(i);
  else restIdx.push(i);
}

const order = okIdx.concat(restIdx);
const newIndex = new Map();
order.forEach((oldI, newI) => newIndex.set(oldI, newI));

const sorted = order.map((i) => list[i]);
const newHealth = { updatedAt: health.updatedAt, results: {} };
for (const k of Object.keys(results)) {
  const oldI = parseInt(k, 10);
  const ni = newIndex.get(oldI);
  if (ni === undefined) continue;
  newHealth.results[ni] = Object.assign({}, results[k], { i: ni });
}

console.log('总书源 ' + list.length + '，体检通过 ' + okIdx.length + '，排到最前面');
if (!APPLY) {
  console.log('前 10 个：' + okIdx.slice(0, 10).map((i) => list[i].bookSourceName).join(' / '));
  console.log('加 --apply 才会写回文件');
  process.exit(0);
}

const payload = Array.isArray(src) ? sorted : Object.assign({}, src, { sources: sorted, count: sorted.length });
fs.writeFileSync(srcFile, JSON.stringify(payload));
fs.writeFileSync(healthFile, JSON.stringify(newHealth));
console.log('已写回 ' + srcFile + ' 和 ' + healthFile);
