'use strict';
/*
 * 书源批量体检
 *   node tools/probe-all.js --limit 100 --concurrency 12 --kw 斗罗 --out data/health.json
 *
 * 每个源跑一遍：搜索 → 详情 → 目录 → 正文，记录到哪一步、耗时、失败原因。
 * 结果可断点续跑：已有结果会跳过（除非 --force）。
 */

const fs = require('fs');
const path = require('path');
const { Engine } = require('../core/engine');

const args = process.argv.slice(2);
function arg(name, dflt) {
  const i = args.indexOf('--' + name);
  return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : dflt;
}
const LIMIT = parseInt(arg('limit', '0'), 10);
const CONC = parseInt(arg('concurrency', '10'), 10);
const KW = arg('kw', '斗罗');
const OFFSET = parseInt(arg('offset', '0'), 10);
const OUT = arg('out', path.join(__dirname, '..', 'data', 'health.json'));
const SRC = arg('sources', path.join(__dirname, '..', 'sources.json'));
const FORCE = args.includes('--force');
const TIMEOUT = parseInt(arg('timeout', '12000'), 10);

const data = JSON.parse(fs.readFileSync(SRC, 'utf8'));
const eng = new Engine(data, {
  searchTimeout: TIMEOUT,
  requestTimeout: TIMEOUT + 2000,
  detailTimeout: TIMEOUT * 2 + 4000,
  chapterTimeout: TIMEOUT * 2,
});

let health = { updatedAt: '', results: {} };
if (fs.existsSync(OUT)) {
  try { health = JSON.parse(fs.readFileSync(OUT, 'utf8')); } catch (e) { /* ignore */ }
}
health.results = health.results || {};

function save() {
  health.updatedAt = new Date().toISOString();
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, JSON.stringify(health, null, 1));
}

async function hostAlive(i) {
  const s = eng.sources[i];
  try {
    const res = await s.fetch(s.url, { retry: 0, timeout: 6000 });
    return res && res.status ? res.status : 0;
  } catch (e) { return -1; }
}

async function probeOne(i) {
  const s = eng.sources[i];
  const r = { i, name: s.name, host: s.url, stage: 'start', ok: false, ms: 0, err: '' };
  const t0 = Date.now();
  try {
    if (!s.searchUrl && !s.channels.length) { r.stage = 'norule'; r.err = '没有搜索和分类规则'; return r; }
    let books = [];
    if (s.searchUrl) {
      books = await s.search(KW, 1);
      r.stage = 'search';
      r.searchCount = books.length;
    }
    if (!books.length && s.channels.length) {
      const ch = s.channels.find((c) => c.url) || s.channels[0];
      books = await s.explore(ch.url, 1);
      r.stage = 'explore';
      r.searchCount = books.length;
    }
    if (!books.length) { r.err = '列表为空'; return r; }
    const info = await s.bookInfo(books[0].bookUrl, books[0]);
    r.stage = 'detail';
    r.detailName = info.name;
    const toc = await s.toc(info.tocUrls || info.tocUrl, info);
    r.stage = 'toc';
    r.chapters = toc.length;
    if (!toc.length) { r.err = '目录为空'; return r; }
    const c = await s.content(toc[0].url, info, toc[0]);
    r.stage = 'content';
    r.chars = c && c.content ? c.content.length : 0;
    if (!c || !c.content) { r.err = '正文为空'; return r; }
    r.ok = true;
    return r;
  } catch (e) {
    r.err = (e && e.message) || '异常';
    return r;
  } finally {
    r.ms = Date.now() - t0;
    if (!r.ok) {
      r.hostStatus = await hostAlive(i).catch(() => 0);
      r.dead = r.hostStatus <= 0 || r.hostStatus >= 500 || r.hostStatus === 403;
    }
  }
}

(async () => {
  const list = [];
  for (let i = OFFSET; i < eng.sources.length; i++) {
    if (LIMIT && list.length >= LIMIT) break;
    if (!FORCE && health.results[i] && health.results[i].ok) continue;
    list.push(i);
  }
  console.log('待测 ' + list.length + ' 条，并发 ' + CONC + '，关键词「' + KW + '」');

  let done = 0;
  let ok = 0;
  let cursor = 0;
  const stat = {};
  await Promise.all(new Array(Math.min(CONC, list.length || 1)).fill(0).map(async () => {
    while (cursor < list.length) {
      const i = list[cursor++];
      const r = await probeOne(i);
      health.results[i] = r;
      done++;
      if (r.ok) ok++;
      stat[r.stage] = (stat[r.stage] || 0) + 1;
      if (done % 10 === 0) {
        save();
        console.log('  ' + done + '/' + list.length + '  通过 ' + ok + '  ' + JSON.stringify(stat));
      }
    }
  }));
  save();

  const all = Object.values(health.results);
  const allOk = all.filter((x) => x.ok).length;
  console.log('\n本轮完成 ' + done + ' 条，通过 ' + ok + ' 条');
  console.log('累计 ' + all.length + ' 条，通过 ' + allOk + ' 条（' + (all.length ? (allOk / all.length * 100).toFixed(1) : 0) + '%）');
  const byStage = {};
  for (const x of all) byStage[x.stage] = (byStage[x.stage] || 0) + 1;
  console.log('停在阶段：' + JSON.stringify(byStage));
  console.log('报告：' + OUT);
})();
