'use strict';
/*
 * 分类体检：测每个书源的「分类页到底能不能出书」，结果写进 data/cat-health.json
 *
 *   node tools/probe-category.js                       # 测前 300 个有频道页的源
 *   node tools/probe-category.js --limit 500 -c 12     # 测 500 个，12 并发
 *   node tools/probe-category.js --limit 0             # 全部（慢，2000+ 个源）
 *   node tools/probe-category.js --force               # 已经 ok 的也重测
 *   node tools/probe-category.js --only 7,9,11         # 只测指定下标
 *
 * 说明：
 *  - 只有「有频道页（exploreUrl）」的源才需要测，只能搜的源分类必然为空，不测。
 *  - 结果按 host / 名字记录，不按下标——书源列表重新排序也不会套错。
 *  - 每测 10 个就落盘一次，Ctrl+C 中断后重跑会接着上次的结果继续。
 *  - 跑完让服务重新加载： curl http://127.0.0.1:13000/reload
 */

const fs = require('fs');
const path = require('path');
const { Engine, mapLimit } = require('../core/engine');

const root = path.join(__dirname, '..');
const args = process.argv.slice(2);
function arg(name, dflt) {
  const i = args.indexOf('--' + name);
  if (i >= 0 && args[i + 1] && !args[i + 1].startsWith('--')) return args[i + 1];
  const j = args.indexOf('-' + name);
  if (name.length === 1 && j >= 0 && args[j + 1] && !args[j + 1].startsWith('-')) return args[j + 1];
  return dflt;
}
const has = (n) => args.includes('--' + n);

const LIMIT = parseInt(arg('limit', process.env.PROBE_LIMIT || '300'), 10);
const CONCURRENCY = Math.max(1, parseInt(arg('concurrency', arg('c', process.env.PROBE_CONCURRENCY || '8')), 10));
const TIMEOUT = parseInt(arg('timeout', process.env.PROBE_TIMEOUT || '45000'), 10);
const FORCE = has('force');
const ONLY = String(arg('only', '') || '').split(',').map((x) => x.trim()).filter(Boolean);
const OUT = arg('out', path.join(root, 'data', 'cat-health.json'));

function resolveSources(p) {
  if (fs.existsSync(p)) return p;
  for (const alt of ['sources_ok.json', 'sources.json']) {
    const f = path.join(root, alt);
    if (fs.existsSync(f)) return f;
  }
  return p;
}

const srcFile = resolveSources(arg('sources', path.join(root, 'sources.json')));

function hostOf(u) {
  return String(u == null ? '' : u)
    .trim()
    .replace(/^[a-z][a-z0-9+.-]*:\/\//i, '')
    .split('/')[0]
    .split('#')[0]
    .split('?')[0]
    .toLowerCase()
    .replace(/^www\./, '');
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return null; }
}

function withTimeout(promise, ms, fallback) {
  let timer;
  const t = new Promise((resolve) => { timer = setTimeout(() => resolve(fallback), ms); });
  return Promise.race([Promise.resolve(promise).catch(() => fallback), t])
    .finally(() => clearTimeout(timer));
}

function main() {
  if (!fs.existsSync(srcFile)) {
    console.error('找不到书源文件：' + srcFile);
    process.exit(1);
  }
  const data = readJson(srcFile);
  const list = Array.isArray(data) ? data : ((data && data.sources) || []);
  if (!list.length) {
    console.error('书源文件里没有书源：' + srcFile);
    process.exit(1);
  }

  const engine = new Engine(data, {
    sourceTimeout: 12000,
    requestTimeout: 15000,
    listLimit: 40,
    searchTimeout: 6000,
  });

  console.log('书源文件：' + srcFile);
  console.log('载入书源：' + engine.size + ' 个，其中有频道页的 ' +
    engine.sources.filter((s) => (s.channels || []).length).length + ' 个');

  // 上次的结果：跑过的跳过，除非 --force
  const prev = readJson(OUT);
  const prevResults = (prev && prev.results) || {};
  const doneHosts = new Set();
  const doneNames = new Set();
  if (!FORCE) {
    for (const k of Object.keys(prevResults)) {
      const v = prevResults[k];
      if (!v || typeof v !== 'object' || !v.ok) continue; // 只续成功的，失败的值得重试
      doneHosts.add(hostOf(v.host));
      if (v.name) doneNames.add(String(v.name).trim());
    }
  }

  // 待测清单：有频道页的源，按配置的上限取
  let cands = [];
  for (let i = 0; i < engine.sources.length; i++) {
    const s = engine.sources[i];
    if (!(s.channels || []).length) continue;
    if (ONLY.length) {
      if (ONLY.indexOf(String(i)) < 0) continue;
    } else if (!FORCE) {
      const h = hostOf(s.url);
      if (h && doneHosts.has(h)) continue;
      if (doneNames.has(String(s.name || '').trim())) continue;
    }
    cands.push(i);
    if (!ONLY.length && LIMIT > 0 && cands.length >= LIMIT) break;
  }

  if (!cands.length) {
    console.log('没有需要测的书源（都测过了？加 --force 强制重测）');
    return;
  }
  console.log('本次要测：' + cands.length + ' 个，并发 ' + CONCURRENCY + '，单源超时 ' + TIMEOUT + 'ms\n');

  // 结果容器：保留上次的条目，新的按 host 覆盖
  const results = {};
  for (const k of Object.keys(prevResults)) {
    const v = prevResults[k];
    if (v && typeof v === 'object' && v.host) results[hostOf(v.host)] = Object.assign({}, v);
    else if (v && typeof v === 'object') results[k] = Object.assign({}, v);
  }

  let okCount = 0;
  let finished = 0;
  let dirty = 0;

  function flush() {
    const out = { updatedAt: new Date().toISOString(), source: path.basename(srcFile), results };
    fs.mkdirSync(path.dirname(OUT), { recursive: true });
    fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
    dirty = 0;
  }

  async function probe(i) {
    const s = engine.sources[i];
    const started = Date.now();
    let r = null;
    let err = '';
    try {
      r = await withTimeout(engine.category(String(i), 1, ''), TIMEOUT, null);
      if (!r) err = 'timeout';
    } catch (e) {
      err = (e && e.message) || 'error';
    }
    const list0 = (r && r.list) || [];
    const rec = {
      i,
      name: s.name,
      host: s.url,
      ok: list0.length > 0,
      count: list0.length,
      ms: Date.now() - started,
      err,
    };
    finished++;
    if (rec.ok) okCount++;
    results[hostOf(s.url)] = rec;
    dirty++;
    if (dirty >= 10 || finished === cands.length) flush();

    const tag = rec.ok ? 'ok  ' : 'FAIL';
    const tail = rec.ok ? (rec.count + '条') : (err || '0条');
    console.log('[' + finished + '/' + cands.length + '] ' + tag + ' ' + String(i).padStart(4) +
      ' ' + String(s.name || '').slice(0, 22).padEnd(24) + ' ' + tail + '  ' + rec.ms + 'ms');
    return rec;
  }

  // 小批跑，跑完一批落盘一次，别一口气把 2000 个请求全发出去
  const batchSize = Math.max(CONCURRENCY, CONCURRENCY * 4);
  (async () => {
    for (let off = 0; off < cands.length; off += batchSize) {
      const batch = cands.slice(off, off + batchSize);
      await mapLimit(batch, CONCURRENCY, probe);
      flush();
    }
    const all = Object.keys(results).map((k) => results[k]).filter((v) => v && typeof v === 'object' && 'ok' in v);
    const okAll = all.filter((v) => v.ok).length;
    console.log('\n本次测完 ' + finished + ' 个：能出书 ' + okCount + ' 个，空的/失败 ' + (finished - okCount) + ' 个');
    console.log('累计记录 ' + all.length + ' 个源，其中能出书 ' + okAll + ' 个');
    console.log('已写入：' + OUT);
    console.log('让服务重新加载： curl http://127.0.0.1:13000/reload');
  })().catch((e) => {
    flush();
    console.error('中断了：' + (e && e.message));
    console.error('已经测完的 ' + finished + ' 个结果已保存，重跑会接着来。');
    process.exit(1);
  });
}

main();
